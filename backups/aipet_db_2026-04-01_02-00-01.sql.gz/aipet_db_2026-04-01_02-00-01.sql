--
-- PostgreSQL database dump
--

\restrict 0wArMGYy5L51cBIRSUpzsHNZaeFMnoezv4ZwtPmk9ZFBvWPYpUlIIIaMPAxoUKQ

-- Dumped from database version 17.5 (Debian 17.5-1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    name character varying(255),
    last_used timestamp without time zone,
    created_at timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.api_keys OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.findings (
    id integer NOT NULL,
    scan_id integer NOT NULL,
    module character varying(100) NOT NULL,
    attack character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    description text,
    target character varying(255),
    created_at timestamp without time zone
);


ALTER TABLE public.findings OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.findings_id_seq OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.findings_id_seq OWNED BY public.findings.id;


--
-- Name: scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.scans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target character varying(255) NOT NULL,
    mode character varying(50),
    status character varying(50),
    result_dir character varying(500),
    report_path character varying(500),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone,
    critical integer,
    high integer,
    medium integer,
    low integer
);


ALTER TABLE public.scans OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scans_id_seq OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.scans_id_seq OWNED BY public.scans.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    plan character varying(50),
    scans_used integer,
    scans_limit integer,
    created_at timestamp without time zone,
    last_login timestamp without time zone,
    is_active boolean,
    stripe_customer_id character varying(100),
    stripe_subscription_id character varying(100),
    plan_expires_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings ALTER COLUMN id SET DEFAULT nextval('public.findings_id_seq'::regclass);


--
-- Name: scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans ALTER COLUMN id SET DEFAULT nextval('public.scans_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.api_keys (id, user_id, key_hash, name, last_used, created_at, is_active) FROM stdin;
1	1	2cf027461a731b41b3d9cc55789dedb5e73595fadbc678c157405ce5d5be3b28	My CI/CD Pipeline	\N	2026-03-30 16:28:58.227803	f
2	1	4582d10b9e9f90dff98b800eebd04b4971b8285781f4d6a22b2029e5f200c220	Production CI/CD	\N	2026-03-30 16:47:46.966119	t
3	1	7b17991ccbdb3b7168b2520919490d2f8a94589b016f747c3216b50022ff38a0	End-to-end test	2026-03-31 20:15:39.858877	2026-03-31 20:13:29.613879	t
\.


--
-- Data for Name: findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.findings (id, scan_id, module, attack, severity, description, target, created_at) FROM stdin;
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.scans (id, user_id, target, mode, status, result_dir, report_path, started_at, completed_at, created_at, critical, high, medium, low) FROM stdin;
1	1	localhost	demo	failed	\N	\N	\N	\N	2026-03-31 20:15:39.867425	0	0	0	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.users (id, email, password_hash, name, plan, scans_used, scans_limit, created_at, last_login, is_active, stripe_customer_id, stripe_subscription_id, plan_expires_at) FROM stdin;
1	test@aipet.io	$2b$12$wgEcI9DJXURKO0Dwhk8mLekA0BCcRS4FpDRLLGoC0lsZ4ZDJ6ZY12	Test User	enterprise	1	5	2026-03-29 23:20:50.618499	2026-03-31 20:11:04.781969	t	cus_UEwnvwFwOEvO5Z	sub_1TGT75EOqz4Ugi362qNaY7M5	2026-04-30 00:51:27
\.


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 3, true);


--
-- Name: findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.findings_id_seq', 1, false);


--
-- Name: scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.scans_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: findings findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_pkey PRIMARY KEY (id);


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_stripe_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_key UNIQUE (stripe_customer_id);


--
-- Name: users users_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: ix_findings_scan_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_findings_scan_id ON public.findings USING btree (scan_id);


--
-- Name: ix_scans_user_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_scans_user_id ON public.scans USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: findings findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: scans scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 0wArMGYy5L51cBIRSUpzsHNZaeFMnoezv4ZwtPmk9ZFBvWPYpUlIIIaMPAxoUKQ

