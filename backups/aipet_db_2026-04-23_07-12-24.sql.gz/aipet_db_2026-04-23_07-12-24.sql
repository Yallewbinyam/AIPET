--
-- PostgreSQL database dump
--

\restrict fP1w9OZ99fyv44pjp8pMi4ZzSq3MOrYCZsBePjahlohhbmCk2BCfTXbaSYfbi4w

-- Dumped from database version 17.5 (Debian 17.5-1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adversary_profiles; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.adversary_profiles (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    actor_name character varying(256),
    actor_type character varying(64),
    origin character varying(128),
    motivation character varying(128),
    sophistication character varying(32),
    confidence double precision,
    threat_level character varying(16),
    active_since character varying(32),
    targets text,
    ttps text,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.adversary_profiles OWNER TO aipet_user;

--
-- Name: ap_analyses; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ap_analyses (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    scope character varying(200),
    total_paths integer,
    critical_paths integer,
    max_depth integer,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.ap_analyses OWNER TO aipet_user;

--
-- Name: ap_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ap_analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ap_analyses_id_seq OWNER TO aipet_user;

--
-- Name: ap_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ap_analyses_id_seq OWNED BY public.ap_analyses.id;


--
-- Name: ap_paths; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ap_paths (
    id integer NOT NULL,
    analysis_id integer NOT NULL,
    entry_point character varying(200) NOT NULL,
    target character varying(200) NOT NULL,
    severity character varying(20),
    hops integer,
    chain text,
    techniques text,
    likelihood integer,
    impact character varying(200),
    blocked boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.ap_paths OWNER TO aipet_user;

--
-- Name: ap_paths_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ap_paths_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ap_paths_id_seq OWNER TO aipet_user;

--
-- Name: ap_paths_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ap_paths_id_seq OWNED BY public.ap_paths.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    name character varying(255),
    last_used timestamp without time zone,
    created_at timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.api_keys OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: apm_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.apm_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    service_name character varying(256),
    environment character varying(64),
    health_score double precision,
    avg_latency_ms double precision,
    p99_latency_ms double precision,
    throughput_rps double precision,
    error_rate_pct double precision,
    apdex_score double precision,
    issues integer,
    summary text,
    services_data text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.apm_reports OWNER TO aipet_user;

--
-- Name: arch_builder_components; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.arch_builder_components (
    id character varying(64) NOT NULL,
    design_id character varying(64) NOT NULL,
    layer character varying(64),
    component character varying(256),
    service character varying(256),
    purpose text,
    security_note text,
    iac_snippet text,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.arch_builder_components OWNER TO aipet_user;

--
-- Name: arch_builder_designs; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.arch_builder_designs (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    title character varying(256),
    cloud_provider character varying(32),
    arch_type character varying(64),
    security_score double precision,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.arch_builder_designs OWNER TO aipet_user;

--
-- Name: as_endpoints; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.as_endpoints (
    id integer NOT NULL,
    path character varying(500) NOT NULL,
    method character varying(10) NOT NULL,
    service character varying(200),
    version character varying(20),
    auth_type character varying(50),
    authenticated boolean,
    rate_limited boolean,
    encrypted boolean,
    has_cors boolean,
    cors_wildcard boolean,
    sensitive_data boolean,
    deprecated boolean,
    risk_score integer,
    finding_count integer,
    last_tested timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.as_endpoints OWNER TO aipet_user;

--
-- Name: as_endpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.as_endpoints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.as_endpoints_id_seq OWNER TO aipet_user;

--
-- Name: as_endpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.as_endpoints_id_seq OWNED BY public.as_endpoints.id;


--
-- Name: as_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.as_findings (
    id integer NOT NULL,
    endpoint_id integer NOT NULL,
    finding_type character varying(100) NOT NULL,
    severity character varying(20),
    owasp_id character varying(20),
    title character varying(300) NOT NULL,
    description text,
    evidence text,
    remediation text,
    status character varying(30),
    created_at timestamp without time zone
);


ALTER TABLE public.as_findings OWNER TO aipet_user;

--
-- Name: as_findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.as_findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.as_findings_id_seq OWNER TO aipet_user;

--
-- Name: as_findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.as_findings_id_seq OWNED BY public.as_findings.id;


--
-- Name: as_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.as_scans (
    id integer NOT NULL,
    endpoints_scanned integer,
    findings_found integer,
    critical_count integer,
    duration_sec integer,
    created_at timestamp without time zone
);


ALTER TABLE public.as_scans OWNER TO aipet_user;

--
-- Name: as_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.as_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.as_scans_id_seq OWNER TO aipet_user;

--
-- Name: as_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.as_scans_id_seq OWNED BY public.as_scans.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.audit_log (
    id character varying(36) NOT NULL,
    user_id integer,
    action character varying(100) NOT NULL,
    resource character varying(100),
    ip_address character varying(45),
    user_agent text,
    "timestamp" timestamp without time zone,
    status character varying(20)
);


ALTER TABLE public.audit_log OWNER TO aipet_user;

--
-- Name: ba_anomalies; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ba_anomalies (
    id integer NOT NULL,
    baseline_id integer NOT NULL,
    entity_name character varying(200) NOT NULL,
    anomaly_type character varying(100) NOT NULL,
    severity character varying(20),
    title character varying(300) NOT NULL,
    description text,
    deviation double precision,
    observed text,
    expected text,
    mitre_id character varying(50),
    status character varying(30),
    created_at timestamp without time zone,
    resolved_at timestamp without time zone
);


ALTER TABLE public.ba_anomalies OWNER TO aipet_user;

--
-- Name: ba_anomalies_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ba_anomalies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ba_anomalies_id_seq OWNER TO aipet_user;

--
-- Name: ba_anomalies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ba_anomalies_id_seq OWNED BY public.ba_anomalies.id;


--
-- Name: ba_baselines; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ba_baselines (
    id integer NOT NULL,
    entity_id character varying(200) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_name character varying(200) NOT NULL,
    baseline text,
    confidence integer,
    risk_score integer,
    anomaly_count integer,
    last_updated timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.ba_baselines OWNER TO aipet_user;

--
-- Name: ba_baselines_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ba_baselines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ba_baselines_id_seq OWNER TO aipet_user;

--
-- Name: ba_baselines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ba_baselines_id_seq OWNED BY public.ba_baselines.id;


--
-- Name: ba_patterns; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ba_patterns (
    id integer NOT NULL,
    baseline_id integer NOT NULL,
    entity_name character varying(200) NOT NULL,
    hour integer NOT NULL,
    day_of_week integer NOT NULL,
    metrics text,
    recorded_at timestamp without time zone
);


ALTER TABLE public.ba_patterns OWNER TO aipet_user;

--
-- Name: ba_patterns_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ba_patterns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ba_patterns_id_seq OWNER TO aipet_user;

--
-- Name: ba_patterns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ba_patterns_id_seq OWNED BY public.ba_patterns.id;


--
-- Name: ca_assessments; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ca_assessments (
    id integer NOT NULL,
    framework_id integer NOT NULL,
    score integer,
    passed integer,
    failed integer,
    partial integer,
    triggered_by character varying(100),
    created_at timestamp without time zone
);


ALTER TABLE public.ca_assessments OWNER TO aipet_user;

--
-- Name: ca_assessments_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ca_assessments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ca_assessments_id_seq OWNER TO aipet_user;

--
-- Name: ca_assessments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ca_assessments_id_seq OWNED BY public.ca_assessments.id;


--
-- Name: ca_controls; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ca_controls (
    id integer NOT NULL,
    framework_id integer NOT NULL,
    control_id character varying(50) NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    category character varying(100),
    status character varying(30),
    evidence text,
    gap text,
    remediation text,
    severity character varying(20),
    automated boolean,
    last_tested timestamp without time zone
);


ALTER TABLE public.ca_controls OWNER TO aipet_user;

--
-- Name: ca_controls_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ca_controls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ca_controls_id_seq OWNER TO aipet_user;

--
-- Name: ca_controls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ca_controls_id_seq OWNED BY public.ca_controls.id;


--
-- Name: ca_frameworks; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ca_frameworks (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    version character varying(50),
    description text,
    total_controls integer,
    passed integer,
    failed integer,
    partial integer,
    score integer,
    last_assessed timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.ca_frameworks OWNER TO aipet_user;

--
-- Name: ca_frameworks_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ca_frameworks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ca_frameworks_id_seq OWNER TO aipet_user;

--
-- Name: ca_frameworks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ca_frameworks_id_seq OWNED BY public.ca_frameworks.id;


--
-- Name: cloud_accounts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_accounts (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    provider character varying(50) NOT NULL,
    account_id character varying(200),
    region character varying(100),
    status character varying(30),
    asset_count integer,
    finding_count integer,
    last_scan timestamp without time zone,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.cloud_accounts OWNER TO aipet_user;

--
-- Name: cloud_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.cloud_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cloud_accounts_id_seq OWNER TO aipet_user;

--
-- Name: cloud_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.cloud_accounts_id_seq OWNED BY public.cloud_accounts.id;


--
-- Name: cloud_assets; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_assets (
    id integer NOT NULL,
    account_id integer NOT NULL,
    asset_id character varying(200) NOT NULL,
    name character varying(200),
    asset_type character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    region character varying(100),
    ip_address character varying(100),
    tags text,
    risk_score integer,
    public boolean,
    encrypted boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.cloud_assets OWNER TO aipet_user;

--
-- Name: cloud_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.cloud_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cloud_assets_id_seq OWNER TO aipet_user;

--
-- Name: cloud_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.cloud_assets_id_seq OWNED BY public.cloud_assets.id;


--
-- Name: cloud_dashboard_snapshots; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_dashboard_snapshots (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    overall_score double precision,
    aws_score double precision,
    azure_score double precision,
    gcp_score double precision,
    total_resources integer,
    exposed_resources integer,
    critical_findings integer,
    high_findings integer,
    medium_findings integer,
    compliance_score double precision,
    trend_data text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.cloud_dashboard_snapshots OWNER TO aipet_user;

--
-- Name: cloud_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_findings (
    id integer NOT NULL,
    account_id integer,
    asset_id integer,
    provider character varying(50) NOT NULL,
    finding_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    resource character varying(300),
    remediation text,
    mitre_id character varying(50),
    created_at timestamp without time zone
);


ALTER TABLE public.cloud_findings OWNER TO aipet_user;

--
-- Name: cloud_findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.cloud_findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cloud_findings_id_seq OWNER TO aipet_user;

--
-- Name: cloud_findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.cloud_findings_id_seq OWNED BY public.cloud_findings.id;


--
-- Name: cloud_hardener_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_hardener_findings (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    check_id character varying(32),
    category character varying(64),
    title character varying(256),
    status character varying(16),
    severity character varying(16),
    description text,
    remediation text,
    cis_ref character varying(64),
    auto_fix character varying(256),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.cloud_hardener_findings OWNER TO aipet_user;

--
-- Name: cloud_hardener_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_hardener_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    cloud_provider character varying(32),
    environment character varying(64),
    risk_score double precision,
    severity character varying(16),
    total_checks integer,
    passed integer,
    failed integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.cloud_hardener_scans OWNER TO aipet_user;

--
-- Name: cloud_runtime_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_runtime_findings (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    category character varying(64),
    title character varying(256),
    severity character varying(16),
    description text,
    resource character varying(256),
    remediation text,
    wiz_ref character varying(64),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.cloud_runtime_findings OWNER TO aipet_user;

--
-- Name: cloud_runtime_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_runtime_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    cloud_provider character varying(32),
    environment character varying(64),
    risk_score double precision,
    severity character varying(16),
    total_findings integer,
    critical_count integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.cloud_runtime_scans OWNER TO aipet_user;

--
-- Name: code_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.code_findings (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    engine character varying(32),
    severity character varying(16),
    category character varying(64),
    title character varying(256),
    description text,
    file_path character varying(512),
    line_number integer,
    recommendation text,
    cwe_id character varying(32),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.code_findings OWNER TO aipet_user;

--
-- Name: code_sbom; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.code_sbom (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    component character varying(256),
    version character varying(64),
    ecosystem character varying(32),
    license character varying(128),
    is_vulnerable integer,
    vuln_summary text,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.code_sbom OWNER TO aipet_user;

--
-- Name: code_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.code_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    target_type character varying(32),
    target_name character varying(256),
    status character varying(32),
    risk_score double precision,
    total_findings integer,
    created_at timestamp without time zone,
    completed_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.code_scans OWNER TO aipet_user;

--
-- Name: compliance_assessments; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.compliance_assessments (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    framework character varying(64),
    organisation character varying(256),
    overall_score double precision,
    passed integer,
    failed integer,
    partial integer,
    critical_gaps integer,
    status character varying(32),
    summary text,
    controls text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.compliance_assessments OWNER TO aipet_user;

--
-- Name: compliance_fabric_controls; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.compliance_fabric_controls (
    id character varying(64) NOT NULL,
    report_id character varying(64) NOT NULL,
    control_id character varying(32),
    title character varying(256),
    status character varying(16),
    severity character varying(16),
    description text,
    remediation text,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.compliance_fabric_controls OWNER TO aipet_user;

--
-- Name: compliance_fabric_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.compliance_fabric_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    framework character varying(64),
    score double precision,
    status character varying(32),
    total_controls integer,
    passed integer,
    failed integer,
    partial integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.compliance_fabric_reports OWNER TO aipet_user;

--
-- Name: compliance_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.compliance_results (
    id integer NOT NULL,
    user_id integer NOT NULL,
    scan_id integer NOT NULL,
    framework character varying(50) NOT NULL,
    score integer NOT NULL,
    total integer NOT NULL,
    controls json,
    created_at timestamp without time zone
);


ALTER TABLE public.compliance_results OWNER TO aipet_user;

--
-- Name: compliance_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.compliance_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_results_id_seq OWNER TO aipet_user;

--
-- Name: compliance_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.compliance_results_id_seq OWNED BY public.compliance_results.id;


--
-- Name: cs_recommendations; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cs_recommendations (
    id integer NOT NULL,
    resource_id integer NOT NULL,
    category character varying(50) NOT NULL,
    priority character varying(20),
    title character varying(300) NOT NULL,
    description text,
    action text,
    monthly_saving double precision,
    security_gain character varying(100),
    effort character varying(20),
    status character varying(30),
    created_at timestamp without time zone
);


ALTER TABLE public.cs_recommendations OWNER TO aipet_user;

--
-- Name: cs_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.cs_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cs_recommendations_id_seq OWNER TO aipet_user;

--
-- Name: cs_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.cs_recommendations_id_seq OWNED BY public.cs_recommendations.id;


--
-- Name: cs_resources; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cs_resources (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    resource_type character varying(50) NOT NULL,
    cloud_provider character varying(50) NOT NULL,
    region character varying(100),
    monthly_cost double precision,
    optimised_cost double precision,
    waste_pct integer,
    security_score integer,
    security_issues integer,
    status character varying(30),
    tags text,
    created_at timestamp without time zone
);


ALTER TABLE public.cs_resources OWNER TO aipet_user;

--
-- Name: cs_resources_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.cs_resources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cs_resources_id_seq OWNER TO aipet_user;

--
-- Name: cs_resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.cs_resources_id_seq OWNED BY public.cs_resources.id;


--
-- Name: dd_baselines; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.dd_baselines (
    id integer NOT NULL,
    identity_name character varying(200) NOT NULL,
    identity_type character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    environment character varying(50),
    permissions text,
    permission_count integer,
    drift_score integer,
    drift_count integer,
    status character varying(30),
    last_scanned timestamp without time zone,
    baseline_set_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.dd_baselines OWNER TO aipet_user;

--
-- Name: dd_baselines_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.dd_baselines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dd_baselines_id_seq OWNER TO aipet_user;

--
-- Name: dd_baselines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.dd_baselines_id_seq OWNED BY public.dd_baselines.id;


--
-- Name: dd_drifts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.dd_drifts (
    id integer NOT NULL,
    baseline_id integer NOT NULL,
    identity_name character varying(200) NOT NULL,
    drift_type character varying(100) NOT NULL,
    severity character varying(20),
    title character varying(300) NOT NULL,
    description text,
    old_value text,
    new_value text,
    remediation text,
    regulation character varying(200),
    status character varying(30),
    detected_at timestamp without time zone,
    resolved_at timestamp without time zone
);


ALTER TABLE public.dd_drifts OWNER TO aipet_user;

--
-- Name: dd_drifts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.dd_drifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dd_drifts_id_seq OWNER TO aipet_user;

--
-- Name: dd_drifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.dd_drifts_id_seq OWNED BY public.dd_drifts.id;


--
-- Name: dd_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.dd_scans (
    id integer NOT NULL,
    identities_scanned integer,
    drifts_found integer,
    critical_drifts integer,
    duration_sec integer,
    created_at timestamp without time zone
);


ALTER TABLE public.dd_scans OWNER TO aipet_user;

--
-- Name: dd_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.dd_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dd_scans_id_seq OWNER TO aipet_user;

--
-- Name: dd_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.dd_scans_id_seq OWNED BY public.dd_scans.id;


--
-- Name: defense_actions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.defense_actions (
    id integer NOT NULL,
    playbook_id integer,
    playbook_name character varying(200),
    action_type character varying(100) NOT NULL,
    target character varying(200),
    status character varying(20),
    reason text,
    outcome text,
    triggered_by character varying(100),
    created_at timestamp without time zone
);


ALTER TABLE public.defense_actions OWNER TO aipet_user;

--
-- Name: defense_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.defense_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.defense_actions_id_seq OWNER TO aipet_user;

--
-- Name: defense_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.defense_actions_id_seq OWNED BY public.defense_actions.id;


--
-- Name: defense_mesh_pillars; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.defense_mesh_pillars (
    id character varying(64) NOT NULL,
    report_id character varying(64) NOT NULL,
    pillar_name character varying(128),
    score double precision,
    status character varying(32),
    gap_count integer,
    description text,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.defense_mesh_pillars OWNER TO aipet_user;

--
-- Name: defense_mesh_recommendations; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.defense_mesh_recommendations (
    id character varying(64) NOT NULL,
    report_id character varying(64) NOT NULL,
    priority integer,
    pillar character varying(128),
    title character varying(256),
    description text,
    effort character varying(32),
    impact character varying(32),
    timeframe character varying(64),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.defense_mesh_recommendations OWNER TO aipet_user;

--
-- Name: defense_mesh_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.defense_mesh_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    organisation character varying(256),
    defense_score double precision,
    maturity_level character varying(64),
    total_gaps integer,
    critical_gaps integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.defense_mesh_reports OWNER TO aipet_user;

--
-- Name: defense_playbooks; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.defense_playbooks (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    enabled boolean,
    trigger_field character varying(50) NOT NULL,
    trigger_op character varying(20) NOT NULL,
    trigger_value character varying(200) NOT NULL,
    actions text NOT NULL,
    cooldown_minutes integer,
    trigger_count integer,
    last_triggered timestamp without time zone,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.defense_playbooks OWNER TO aipet_user;

--
-- Name: defense_playbooks_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.defense_playbooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.defense_playbooks_id_seq OWNER TO aipet_user;

--
-- Name: defense_playbooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.defense_playbooks_id_seq OWNED BY public.defense_playbooks.id;


--
-- Name: device_tags; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.device_tags (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    business_function character varying(100) NOT NULL,
    industry character varying(100) DEFAULT 'General Business'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.device_tags OWNER TO aipet_user;

--
-- Name: device_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.device_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.device_tags_id_seq OWNER TO aipet_user;

--
-- Name: device_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.device_tags_id_seq OWNED BY public.device_tags.id;


--
-- Name: digital_twin_v2_anomalies; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.digital_twin_v2_anomalies (
    id character varying(64) NOT NULL,
    env_id character varying(64) NOT NULL,
    device_name character varying(256),
    anomaly_type character varying(64),
    severity character varying(16),
    description text,
    recommendation text,
    mitre_tactic character varying(128),
    detected_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.digital_twin_v2_anomalies OWNER TO aipet_user;

--
-- Name: digital_twin_v2_devices; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.digital_twin_v2_devices (
    id character varying(64) NOT NULL,
    env_id character varying(64) NOT NULL,
    device_name character varying(256),
    device_type character varying(64),
    ip_address character varying(64),
    status character varying(32),
    risk_level character varying(16),
    cpu_usage double precision,
    memory_usage double precision,
    last_seen timestamp without time zone,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.digital_twin_v2_devices OWNER TO aipet_user;

--
-- Name: digital_twin_v2_environments; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.digital_twin_v2_environments (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    name character varying(256),
    env_type character varying(64),
    device_count integer,
    risk_score double precision,
    health_score double precision,
    anomaly_count integer,
    status character varying(32),
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.digital_twin_v2_environments OWNER TO aipet_user;

--
-- Name: dspm_datastores; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.dspm_datastores (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    store_type character varying(50) NOT NULL,
    location character varying(200),
    cloud_provider character varying(50),
    sensitivity character varying(50),
    data_types text,
    size_gb double precision,
    record_count integer,
    encrypted_at_rest boolean,
    encrypted_in_transit boolean,
    access_control character varying(50),
    publicly_accessible boolean,
    risk_score integer,
    finding_count integer,
    last_scanned timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.dspm_datastores OWNER TO aipet_user;

--
-- Name: dspm_datastores_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.dspm_datastores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dspm_datastores_id_seq OWNER TO aipet_user;

--
-- Name: dspm_datastores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.dspm_datastores_id_seq OWNED BY public.dspm_datastores.id;


--
-- Name: dspm_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.dspm_findings (
    id integer NOT NULL,
    datastore_id integer NOT NULL,
    finding_type character varying(100) NOT NULL,
    severity character varying(20),
    title character varying(300) NOT NULL,
    description text,
    remediation text,
    regulation character varying(200),
    status character varying(30),
    created_at timestamp without time zone
);


ALTER TABLE public.dspm_findings OWNER TO aipet_user;

--
-- Name: dspm_findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.dspm_findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dspm_findings_id_seq OWNER TO aipet_user;

--
-- Name: dspm_findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.dspm_findings_id_seq OWNED BY public.dspm_findings.id;


--
-- Name: dspm_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.dspm_scans (
    id integer NOT NULL,
    datastores_found integer,
    findings_found integer,
    critical_count integer,
    duration_sec integer,
    created_at timestamp without time zone
);


ALTER TABLE public.dspm_scans OWNER TO aipet_user;

--
-- Name: dspm_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.dspm_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dspm_scans_id_seq OWNER TO aipet_user;

--
-- Name: dspm_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.dspm_scans_id_seq OWNED BY public.dspm_scans.id;


--
-- Name: endpoint_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.endpoint_findings (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    category character varying(64),
    title character varying(256),
    severity character varying(16),
    tactic character varying(128),
    technique character varying(128),
    description text,
    remediation text,
    ioc character varying(256),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.endpoint_findings OWNER TO aipet_user;

--
-- Name: endpoint_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.endpoint_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    hostname character varying(256),
    os_type character varying(64),
    os_version character varying(64),
    risk_score double precision,
    severity character varying(16),
    total_findings integer,
    critical_count integer,
    health_score double precision,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.endpoint_scans OWNER TO aipet_user;

--
-- Name: enterprise_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.enterprise_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    report_type character varying(64),
    organisation character varying(256),
    period character varying(64),
    risk_score double precision,
    status character varying(32),
    content text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.enterprise_reports OWNER TO aipet_user;

--
-- Name: explain_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.explain_results (
    id integer NOT NULL,
    scan_id integer,
    finding_id integer,
    explain_type character varying(50) NOT NULL,
    content text NOT NULL,
    model_used character varying(100) NOT NULL,
    tokens_used integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.explain_results OWNER TO aipet_user;

--
-- Name: explain_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.explain_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.explain_results_id_seq OWNER TO aipet_user;

--
-- Name: explain_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.explain_results_id_seq OWNED BY public.explain_results.id;


--
-- Name: findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.findings (
    id integer NOT NULL,
    scan_id integer NOT NULL,
    module character varying(100) NOT NULL,
    attack character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    description text,
    target character varying(255),
    created_at timestamp without time zone,
    fix_status character varying(50) DEFAULT 'open'::character varying,
    fix_notes text
);


ALTER TABLE public.findings OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.findings_id_seq OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.findings_id_seq OWNED BY public.findings.id;


--
-- Name: forensic_artifacts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.forensic_artifacts (
    id character varying(64) NOT NULL,
    case_id character varying(64) NOT NULL,
    artifact_type character varying(32),
    value character varying(512),
    source character varying(256),
    confidence character varying(16),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.forensic_artifacts OWNER TO aipet_user;

--
-- Name: forensic_cases; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.forensic_cases (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    title character varying(256),
    severity character varying(16),
    status character varying(32),
    risk_score double precision,
    summary text,
    created_at timestamp without time zone,
    completed_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.forensic_cases OWNER TO aipet_user;

--
-- Name: forensic_timeline; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.forensic_timeline (
    id character varying(64) NOT NULL,
    case_id character varying(64) NOT NULL,
    step integer,
    stage character varying(64),
    description text,
    mitre_tactic character varying(128),
    mitre_technique character varying(128),
    severity character varying(16),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.forensic_timeline OWNER TO aipet_user;

--
-- Name: iam_exposure_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.iam_exposure_findings (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    category character varying(64),
    title character varying(256),
    severity character varying(16),
    identity_type character varying(64),
    identity_name character varying(256),
    description text,
    remediation text,
    blast_radius character varying(32),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.iam_exposure_findings OWNER TO aipet_user;

--
-- Name: iam_exposure_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.iam_exposure_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    cloud_provider character varying(32),
    risk_score double precision,
    severity character varying(16),
    total_findings integer,
    critical_count integer,
    identities_at_risk integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.iam_exposure_scans OWNER TO aipet_user;

--
-- Name: identity_guardian_alerts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.identity_guardian_alerts (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    subject character varying(256),
    risk_score double precision,
    severity character varying(16),
    status character varying(32),
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.identity_guardian_alerts OWNER TO aipet_user;

--
-- Name: identity_guardian_signals; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.identity_guardian_signals (
    id character varying(64) NOT NULL,
    alert_id character varying(64) NOT NULL,
    signal_type character varying(64),
    title character varying(256),
    description text,
    severity character varying(16),
    recommendation text,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.identity_guardian_signals OWNER TO aipet_user;

--
-- Name: ig_edges; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ig_edges (
    id integer NOT NULL,
    source_id integer NOT NULL,
    target_id integer NOT NULL,
    relationship character varying(100) NOT NULL,
    weight integer,
    is_risky boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.ig_edges OWNER TO aipet_user;

--
-- Name: ig_edges_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ig_edges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ig_edges_id_seq OWNER TO aipet_user;

--
-- Name: ig_edges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ig_edges_id_seq OWNED BY public.ig_edges.id;


--
-- Name: ig_identities; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ig_identities (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    identity_type character varying(50) NOT NULL,
    email character varying(200),
    source character varying(100),
    risk_score integer,
    blast_radius integer,
    is_privileged boolean,
    is_dormant boolean,
    is_overprivileged boolean,
    last_active timestamp without time zone,
    permissions text,
    tags text,
    created_at timestamp without time zone
);


ALTER TABLE public.ig_identities OWNER TO aipet_user;

--
-- Name: ig_identities_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ig_identities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ig_identities_id_seq OWNER TO aipet_user;

--
-- Name: ig_identities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ig_identities_id_seq OWNED BY public.ig_identities.id;


--
-- Name: ig_risks; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ig_risks (
    id integer NOT NULL,
    identity_id integer NOT NULL,
    risk_type character varying(100) NOT NULL,
    severity character varying(20),
    description text,
    remediation text,
    resolved boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.ig_risks OWNER TO aipet_user;

--
-- Name: ig_risks_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ig_risks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ig_risks_id_seq OWNER TO aipet_user;

--
-- Name: ig_risks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ig_risks_id_seq OWNED BY public.ig_risks.id;


--
-- Name: ioc_entries; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ioc_entries (
    id integer NOT NULL,
    feed_id integer NOT NULL,
    ioc_type character varying(20) NOT NULL,
    value character varying(500) NOT NULL,
    threat_type character varying(100),
    confidence integer,
    severity character varying(20),
    description text,
    source_ref character varying(500),
    active boolean,
    created_at timestamp without time zone,
    expires_at timestamp without time zone
);


ALTER TABLE public.ioc_entries OWNER TO aipet_user;

--
-- Name: ioc_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ioc_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ioc_entries_id_seq OWNER TO aipet_user;

--
-- Name: ioc_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ioc_entries_id_seq OWNED BY public.ioc_entries.id;


--
-- Name: ioc_feeds; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ioc_feeds (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    feed_type character varying(50) NOT NULL,
    description text,
    enabled boolean,
    api_key text,
    last_sync timestamp without time zone,
    entry_count integer,
    created_at timestamp without time zone
);


ALTER TABLE public.ioc_feeds OWNER TO aipet_user;

--
-- Name: ioc_feeds_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ioc_feeds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ioc_feeds_id_seq OWNER TO aipet_user;

--
-- Name: ioc_feeds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ioc_feeds_id_seq OWNED BY public.ioc_feeds.id;


--
-- Name: ir_incidents; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ir_incidents (
    id integer NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    status character varying(30),
    priority character varying(10),
    affected text,
    attack_vector character varying(200),
    mitre_id character varying(50),
    assigned_to character varying(200),
    timeline_ref integer,
    resolution text,
    lessons text,
    created_by integer,
    created_at timestamp without time zone,
    resolved_at timestamp without time zone,
    sla_hours integer
);


ALTER TABLE public.ir_incidents OWNER TO aipet_user;

--
-- Name: ir_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ir_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ir_incidents_id_seq OWNER TO aipet_user;

--
-- Name: ir_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ir_incidents_id_seq OWNED BY public.ir_incidents.id;


--
-- Name: ir_tasks; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ir_tasks (
    id integer NOT NULL,
    incident_id integer NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    status character varying(20),
    assigned_to character varying(200),
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.ir_tasks OWNER TO aipet_user;

--
-- Name: ir_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ir_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ir_tasks_id_seq OWNER TO aipet_user;

--
-- Name: ir_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ir_tasks_id_seq OWNED BY public.ir_tasks.id;


--
-- Name: itdr_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.itdr_findings (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    attack_type character varying(64),
    title character varying(256),
    severity character varying(16),
    affected_identity character varying(256),
    mitre_tactic character varying(128),
    mitre_technique character varying(128),
    description text,
    remediation text,
    urgency character varying(32),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.itdr_findings OWNER TO aipet_user;

--
-- Name: itdr_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.itdr_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    environment character varying(64),
    identity_store character varying(64),
    risk_score double precision,
    severity character varying(16),
    total_findings integer,
    critical_count integer,
    identities_compromised integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.itdr_scans OWNER TO aipet_user;

--
-- Name: k8s_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.k8s_findings (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    category character varying(64),
    title character varying(256),
    severity character varying(16),
    resource_type character varying(64),
    namespace character varying(128),
    description text,
    remediation text,
    cis_ref character varying(64),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.k8s_findings OWNER TO aipet_user;

--
-- Name: k8s_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.k8s_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    cluster_name character varying(256),
    k8s_version character varying(32),
    risk_score double precision,
    severity character varying(16),
    total_findings integer,
    critical_count integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.k8s_scans OWNER TO aipet_user;

--
-- Name: log_analysis_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.log_analysis_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    log_source character varying(128),
    total_lines integer,
    error_count integer,
    warning_count integer,
    anomaly_count integer,
    security_events integer,
    risk_score double precision,
    summary text,
    findings text,
    patterns text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.log_analysis_reports OWNER TO aipet_user;

--
-- Name: metrics_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.metrics_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    service_name character varying(256),
    trace_id character varying(64),
    total_spans integer,
    error_spans integer,
    total_duration_ms double precision,
    bottleneck character varying(256),
    anomalies integer,
    summary text,
    spans_data text,
    metrics_data text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.metrics_reports OWNER TO aipet_user;

--
-- Name: mp_installs; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.mp_installs (
    id integer NOT NULL,
    plugin_id integer NOT NULL,
    user_id integer NOT NULL,
    config text,
    enabled boolean,
    installed_at timestamp without time zone
);


ALTER TABLE public.mp_installs OWNER TO aipet_user;

--
-- Name: mp_installs_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.mp_installs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mp_installs_id_seq OWNER TO aipet_user;

--
-- Name: mp_installs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.mp_installs_id_seq OWNED BY public.mp_installs.id;


--
-- Name: mp_plugins; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.mp_plugins (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    long_desc text,
    category character varying(50) NOT NULL,
    publisher character varying(200) NOT NULL,
    version character varying(20),
    icon character varying(10),
    tags text,
    verified boolean,
    free boolean,
    price_gbp double precision,
    install_count integer,
    avg_rating double precision,
    review_count integer,
    active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.mp_plugins OWNER TO aipet_user;

--
-- Name: mp_plugins_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.mp_plugins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mp_plugins_id_seq OWNER TO aipet_user;

--
-- Name: mp_plugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.mp_plugins_id_seq OWNED BY public.mp_plugins.id;


--
-- Name: mp_reviews; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.mp_reviews (
    id integer NOT NULL,
    plugin_id integer NOT NULL,
    user_id integer NOT NULL,
    rating integer NOT NULL,
    review text,
    created_at timestamp without time zone
);


ALTER TABLE public.mp_reviews OWNER TO aipet_user;

--
-- Name: mp_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.mp_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mp_reviews_id_seq OWNER TO aipet_user;

--
-- Name: mp_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.mp_reviews_id_seq OWNED BY public.mp_reviews.id;


--
-- Name: multicloud_scale_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.multicloud_scale_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    total_providers integer,
    total_regions integer,
    total_workloads integer,
    security_score double precision,
    cost_risk_score double precision,
    scale_issues integer,
    summary text,
    recommendations text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.multicloud_scale_reports OWNER TO aipet_user;

--
-- Name: network_exposure_assets; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.network_exposure_assets (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    asset_type character varying(64),
    asset_name character varying(256),
    exposure_level character varying(32),
    public_ip character varying(64),
    open_ports text,
    risk_level character varying(16),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.network_exposure_assets OWNER TO aipet_user;

--
-- Name: network_exposure_paths; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.network_exposure_paths (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    path_type character varying(64),
    source character varying(256),
    destination character varying(256),
    severity character varying(16),
    protocol character varying(32),
    port character varying(32),
    description text,
    remediation text,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.network_exposure_paths OWNER TO aipet_user;

--
-- Name: network_exposure_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.network_exposure_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    environment character varying(64),
    cloud_provider character varying(32),
    risk_score double precision,
    severity character varying(16),
    total_paths integer,
    critical_paths integer,
    exposed_assets integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.network_exposure_scans OWNER TO aipet_user;

--
-- Name: nv_edges; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.nv_edges (
    id integer NOT NULL,
    source_id integer NOT NULL,
    target_id integer NOT NULL,
    protocol character varying(50) NOT NULL,
    port integer,
    encrypted boolean,
    risk_level character varying(20),
    cross_zone boolean,
    bidirectional boolean,
    traffic_gbday double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.nv_edges OWNER TO aipet_user;

--
-- Name: nv_edges_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.nv_edges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nv_edges_id_seq OWNER TO aipet_user;

--
-- Name: nv_edges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.nv_edges_id_seq OWNED BY public.nv_edges.id;


--
-- Name: nv_issues; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.nv_issues (
    id integer NOT NULL,
    node_id integer,
    edge_id integer,
    severity character varying(20),
    title character varying(300) NOT NULL,
    description text,
    remediation text,
    status character varying(30),
    created_at timestamp without time zone
);


ALTER TABLE public.nv_issues OWNER TO aipet_user;

--
-- Name: nv_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.nv_issues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nv_issues_id_seq OWNER TO aipet_user;

--
-- Name: nv_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.nv_issues_id_seq OWNED BY public.nv_issues.id;


--
-- Name: nv_nodes; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.nv_nodes (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    node_type character varying(50) NOT NULL,
    zone character varying(50) NOT NULL,
    cloud_provider character varying(50),
    ip_address character varying(50),
    region character varying(100),
    risk_score integer,
    internet_facing boolean,
    encrypted boolean,
    issue_count integer,
    status character varying(30),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.nv_nodes OWNER TO aipet_user;

--
-- Name: nv_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.nv_nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nv_nodes_id_seq OWNER TO aipet_user;

--
-- Name: nv_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.nv_nodes_id_seq OWNED BY public.nv_nodes.id;


--
-- Name: ot_devices; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ot_devices (
    id integer NOT NULL,
    device_ip character varying(100) NOT NULL,
    device_name character varying(200),
    protocol character varying(50) NOT NULL,
    port integer,
    vendor character varying(200),
    model character varying(200),
    firmware character varying(100),
    zone character varying(50),
    criticality character varying(20),
    location character varying(200),
    last_seen timestamp without time zone,
    online boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.ot_devices OWNER TO aipet_user;

--
-- Name: ot_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ot_devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ot_devices_id_seq OWNER TO aipet_user;

--
-- Name: ot_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ot_devices_id_seq OWNED BY public.ot_devices.id;


--
-- Name: ot_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ot_findings (
    id integer NOT NULL,
    scan_id integer,
    device_ip character varying(100) NOT NULL,
    protocol character varying(50) NOT NULL,
    finding_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    evidence text,
    mitre_ics_id character varying(50),
    remediation text,
    created_at timestamp without time zone
);


ALTER TABLE public.ot_findings OWNER TO aipet_user;

--
-- Name: ot_findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ot_findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ot_findings_id_seq OWNER TO aipet_user;

--
-- Name: ot_findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ot_findings_id_seq OWNED BY public.ot_findings.id;


--
-- Name: ot_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ot_scans (
    id integer NOT NULL,
    target character varying(200) NOT NULL,
    protocol character varying(50) NOT NULL,
    status character varying(30),
    findings_count integer,
    risk_level character varying(20),
    scan_duration double precision,
    user_id integer,
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.ot_scans OWNER TO aipet_user;

--
-- Name: ot_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ot_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ot_scans_id_seq OWNER TO aipet_user;

--
-- Name: ot_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ot_scans_id_seq OWNED BY public.ot_scans.id;


--
-- Name: patch_brain_items; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.patch_brain_items (
    id character varying(64) NOT NULL,
    session_id character varying(64) NOT NULL,
    cve_id character varying(32),
    component character varying(256),
    current_version character varying(64),
    fixed_version character varying(64),
    severity character varying(16),
    cvss_score double precision,
    priority integer,
    patch_action text,
    deadline character varying(64),
    exploited integer,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.patch_brain_items OWNER TO aipet_user;

--
-- Name: patch_brain_sessions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.patch_brain_sessions (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    environment character varying(64),
    risk_score double precision,
    severity character varying(16),
    total_patches integer,
    critical_count integer,
    high_count integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.patch_brain_sessions OWNER TO aipet_user;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.permissions (
    id character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    resource character varying(50),
    action character varying(50)
);


ALTER TABLE public.permissions OWNER TO aipet_user;

--
-- Name: policy_brain_policies; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.policy_brain_policies (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    title character varying(256),
    policy_type character varying(64),
    framework_map text,
    coverage_score double precision,
    word_count integer,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.policy_brain_policies OWNER TO aipet_user;

--
-- Name: policy_brain_sections; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.policy_brain_sections (
    id character varying(64) NOT NULL,
    policy_id character varying(64) NOT NULL,
    section_number integer,
    section_title character varying(256),
    content text,
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.policy_brain_sections OWNER TO aipet_user;

--
-- Name: predict_alerts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.predict_alerts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    cve_id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    description text NOT NULL,
    severity character varying(50) NOT NULL,
    cvss_score double precision DEFAULT 0.0,
    affected_devices jsonb,
    weaponisation_pct integer DEFAULT 0,
    published_date timestamp without time zone NOT NULL,
    nvd_url character varying(500),
    is_reviewed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.predict_alerts OWNER TO aipet_user;

--
-- Name: predict_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.predict_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.predict_alerts_id_seq OWNER TO aipet_user;

--
-- Name: predict_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.predict_alerts_id_seq OWNED BY public.predict_alerts.id;


--
-- Name: protocol_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.protocol_scans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    protocol character varying(50) NOT NULL,
    target character varying(255) NOT NULL,
    status character varying(50),
    findings json,
    device_count integer,
    risk_level character varying(50),
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.protocol_scans OWNER TO aipet_user;

--
-- Name: protocol_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.protocol_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.protocol_scans_id_seq OWNER TO aipet_user;

--
-- Name: protocol_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.protocol_scans_id_seq OWNED BY public.protocol_scans.id;


--
-- Name: rbac_assessments; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.rbac_assessments (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    organisation character varying(256),
    total_roles integer,
    over_privileged integer,
    sso_configured integer,
    mfa_enforced integer,
    risk_score double precision,
    issues integer,
    summary text,
    findings text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.rbac_assessments OWNER TO aipet_user;

--
-- Name: rbac_roles; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.rbac_roles (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    role_name character varying(128),
    role_type character varying(64),
    permissions text,
    description text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.rbac_roles OWNER TO aipet_user;

--
-- Name: re_assets; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.re_assets (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    asset_type character varying(50) NOT NULL,
    criticality character varying(20),
    location character varying(200),
    rto_target double precision,
    rpo_target double precision,
    rto_actual double precision,
    rpo_actual double precision,
    has_dr_plan boolean,
    has_backup boolean,
    backup_tested boolean,
    failover_ready boolean,
    readiness_score integer,
    last_tested timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.re_assets OWNER TO aipet_user;

--
-- Name: re_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.re_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.re_assets_id_seq OWNER TO aipet_user;

--
-- Name: re_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.re_assets_id_seq OWNED BY public.re_assets.id;


--
-- Name: re_plans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.re_plans (
    id integer NOT NULL,
    asset_id integer NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    steps text,
    contacts text,
    status character varying(30),
    last_reviewed timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.re_plans OWNER TO aipet_user;

--
-- Name: re_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.re_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.re_plans_id_seq OWNER TO aipet_user;

--
-- Name: re_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.re_plans_id_seq OWNED BY public.re_plans.id;


--
-- Name: re_tests; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.re_tests (
    id integer NOT NULL,
    asset_id integer NOT NULL,
    test_type character varying(50) NOT NULL,
    result character varying(20),
    rto_achieved double precision,
    rpo_achieved double precision,
    notes text,
    conducted_by character varying(200),
    created_at timestamp without time zone
);


ALTER TABLE public.re_tests OWNER TO aipet_user;

--
-- Name: re_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.re_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.re_tests_id_seq OWNER TO aipet_user;

--
-- Name: re_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.re_tests_id_seq OWNED BY public.re_tests.id;


--
-- Name: realtime_snapshots; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.realtime_snapshots (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    security_score double precision,
    threat_level character varying(16),
    active_threats integer,
    open_incidents integer,
    compliance_pct double precision,
    uptime_pct double precision,
    events_per_min double precision,
    widgets_data text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.realtime_snapshots OWNER TO aipet_user;

--
-- Name: remediation_kb; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.remediation_kb (
    id integer NOT NULL,
    attack_type character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    explanation text NOT NULL,
    fix_commands text NOT NULL,
    time_estimate_minutes integer NOT NULL,
    difficulty character varying(50) NOT NULL,
    source character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.remediation_kb OWNER TO aipet_user;

--
-- Name: remediation_kb_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.remediation_kb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.remediation_kb_id_seq OWNER TO aipet_user;

--
-- Name: remediation_kb_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.remediation_kb_id_seq OWNED BY public.remediation_kb.id;


--
-- Name: risk_narratives; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.risk_narratives (
    id integer NOT NULL,
    audience character varying(50),
    narrative text NOT NULL,
    risk_score integer,
    findings integer,
    devices integer,
    tokens_used integer,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.risk_narratives OWNER TO aipet_user;

--
-- Name: risk_narratives_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.risk_narratives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_narratives_id_seq OWNER TO aipet_user;

--
-- Name: risk_narratives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.risk_narratives_id_seq OWNED BY public.risk_narratives.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.role_permissions (
    role_id character varying(36) NOT NULL,
    permission_id character varying(36) NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO aipet_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.roles (
    id character varying(36) NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp without time zone
);


ALTER TABLE public.roles OWNER TO aipet_user;

--
-- Name: rt_attacks; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.rt_attacks (
    id integer NOT NULL,
    campaign_id integer NOT NULL,
    mitre_id character varying(50) NOT NULL,
    tactic character varying(100) NOT NULL,
    technique character varying(200) NOT NULL,
    target character varying(200),
    result character varying(30),
    impact text,
    evidence text,
    blocked_by character varying(200),
    severity character varying(20),
    executed_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.rt_attacks OWNER TO aipet_user;

--
-- Name: rt_attacks_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.rt_attacks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rt_attacks_id_seq OWNER TO aipet_user;

--
-- Name: rt_attacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.rt_attacks_id_seq OWNED BY public.rt_attacks.id;


--
-- Name: rt_campaigns; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.rt_campaigns (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    scope text,
    objectives text,
    status character varying(30),
    attack_count integer,
    success_count integer,
    blocked_count integer,
    overall_score integer,
    duration_sec integer,
    created_by integer,
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.rt_campaigns OWNER TO aipet_user;

--
-- Name: rt_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.rt_campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rt_campaigns_id_seq OWNER TO aipet_user;

--
-- Name: rt_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.rt_campaigns_id_seq OWNED BY public.rt_campaigns.id;


--
-- Name: runtime_protection_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.runtime_protection_findings (
    id character varying(64) NOT NULL,
    scan_id character varying(64) NOT NULL,
    category character varying(64),
    title character varying(256),
    severity character varying(16),
    technique character varying(128),
    description text,
    remediation text,
    confidence character varying(16),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.runtime_protection_findings OWNER TO aipet_user;

--
-- Name: runtime_protection_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.runtime_protection_scans (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    workload_type character varying(64),
    workload_name character varying(256),
    risk_score double precision,
    severity character varying(16),
    total_findings integer,
    critical_count integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.runtime_protection_scans OWNER TO aipet_user;

--
-- Name: sandbox_analyses; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.sandbox_analyses (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    sample_name character varying(256),
    file_type character varying(64),
    sha256 character varying(64),
    verdict character varying(32),
    malware_family character varying(128),
    threat_score double precision,
    severity character varying(16),
    behaviours integer,
    iocs_found integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.sandbox_analyses OWNER TO aipet_user;

--
-- Name: sandbox_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.sandbox_findings (
    id character varying(64) NOT NULL,
    analysis_id character varying(64) NOT NULL,
    category character varying(64),
    finding_type character varying(64),
    title character varying(256),
    severity character varying(16),
    description text,
    ioc character varying(512),
    mitre_technique character varying(128),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.sandbox_findings OWNER TO aipet_user;

--
-- Name: sc_components; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.sc_components (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    version character varying(50),
    component_type character varying(50) NOT NULL,
    ecosystem character varying(50),
    license character varying(100),
    supplier character varying(200),
    used_in text,
    direct_dep boolean,
    vuln_count integer,
    critical_vulns integer,
    risk_level character varying(20),
    license_risk character varying(20),
    last_updated timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.sc_components OWNER TO aipet_user;

--
-- Name: sc_components_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.sc_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sc_components_id_seq OWNER TO aipet_user;

--
-- Name: sc_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.sc_components_id_seq OWNED BY public.sc_components.id;


--
-- Name: sc_sboms; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.sc_sboms (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    format character varying(50),
    version character varying(20),
    components_count integer,
    vuln_count integer,
    content text,
    created_at timestamp without time zone
);


ALTER TABLE public.sc_sboms OWNER TO aipet_user;

--
-- Name: sc_sboms_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.sc_sboms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sc_sboms_id_seq OWNER TO aipet_user;

--
-- Name: sc_sboms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.sc_sboms_id_seq OWNED BY public.sc_sboms.id;


--
-- Name: sc_vulns; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.sc_vulns (
    id integer NOT NULL,
    component_id integer NOT NULL,
    cve_id character varying(50) NOT NULL,
    severity character varying(20),
    cvss_score double precision,
    title character varying(300) NOT NULL,
    description text,
    fixed_version character varying(50),
    exploit_public boolean,
    cisa_kev boolean,
    status character varying(30),
    created_at timestamp without time zone
);


ALTER TABLE public.sc_vulns OWNER TO aipet_user;

--
-- Name: sc_vulns_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.sc_vulns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sc_vulns_id_seq OWNER TO aipet_user;

--
-- Name: sc_vulns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.sc_vulns_id_seq OWNED BY public.sc_vulns.id;


--
-- Name: scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.scans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target character varying(255) NOT NULL,
    mode character varying(50),
    status character varying(50),
    result_dir character varying(500),
    report_path character varying(500),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone,
    critical integer,
    high integer,
    medium integer,
    low integer
);


ALTER TABLE public.scans OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scans_id_seq OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.scans_id_seq OWNED BY public.scans.id;


--
-- Name: score_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.score_results (
    id integer NOT NULL,
    scan_id integer NOT NULL,
    user_id integer NOT NULL,
    industry character varying(100) NOT NULL,
    total_exposure_gbp bigint DEFAULT 0 NOT NULL,
    findings_breakdown jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.score_results OWNER TO aipet_user;

--
-- Name: score_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.score_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.score_results_id_seq OWNER TO aipet_user;

--
-- Name: score_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.score_results_id_seq OWNED BY public.score_results.id;


--
-- Name: siem_events; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.siem_events (
    id integer NOT NULL,
    event_type character varying(100) NOT NULL,
    source character varying(200) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    raw_payload text,
    mitre_id character varying(50),
    user_id integer,
    incident_id integer,
    acknowledged boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.siem_events OWNER TO aipet_user;

--
-- Name: siem_events_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.siem_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.siem_events_id_seq OWNER TO aipet_user;

--
-- Name: siem_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.siem_events_id_seq OWNED BY public.siem_events.id;


--
-- Name: siem_incidents; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.siem_incidents (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    severity character varying(20) NOT NULL,
    status character varying(50),
    assigned_to integer,
    created_by integer,
    event_count integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.siem_incidents OWNER TO aipet_user;

--
-- Name: siem_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.siem_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.siem_incidents_id_seq OWNER TO aipet_user;

--
-- Name: siem_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.siem_incidents_id_seq OWNED BY public.siem_incidents.id;


--
-- Name: siem_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.siem_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    event_source character varying(128),
    total_events integer,
    correlated integer,
    critical_alerts integer,
    incidents integer,
    risk_score double precision,
    summary text,
    alerts text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.siem_reports OWNER TO aipet_user;

--
-- Name: siem_rules; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.siem_rules (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    condition text NOT NULL,
    action character varying(50),
    severity character varying(20),
    enabled boolean,
    trigger_count integer,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.siem_rules OWNER TO aipet_user;

--
-- Name: siem_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.siem_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.siem_rules_id_seq OWNER TO aipet_user;

--
-- Name: siem_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.siem_rules_id_seq OWNED BY public.siem_rules.id;


--
-- Name: soc_twin_actions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.soc_twin_actions (
    id character varying(64) NOT NULL,
    session_id character varying(64) NOT NULL,
    priority integer,
    phase character varying(64),
    action text,
    owner character varying(128),
    timeframe character varying(64),
    mitre_ref character varying(128),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.soc_twin_actions OWNER TO aipet_user;

--
-- Name: soc_twin_sessions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.soc_twin_sessions (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    scenario_name character varying(256),
    scenario_type character varying(64),
    threat_actor character varying(128),
    severity character varying(16),
    risk_score double precision,
    impact_score double precision,
    status character varying(32),
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.soc_twin_sessions OWNER TO aipet_user;

--
-- Name: sso_providers; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.sso_providers (
    id character varying(36) NOT NULL,
    name character varying(50) NOT NULL,
    client_id text,
    tenant_id text,
    metadata_url text,
    enabled boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.sso_providers OWNER TO aipet_user;

--
-- Name: synthetic_checks; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.synthetic_checks (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    check_name character varying(256),
    check_type character varying(64),
    target_url character varying(512),
    overall_status character varying(16),
    uptime_pct double precision,
    avg_latency_ms double precision,
    sla_met integer,
    total_checks integer,
    failed_checks integer,
    issues integer,
    summary text,
    results_data text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.synthetic_checks OWNER TO aipet_user;

--
-- Name: te_clusters; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.te_clusters (
    id integer NOT NULL,
    title character varying(300) NOT NULL,
    cluster_type character varying(50) NOT NULL,
    severity character varying(20),
    event_count integer,
    modules_involved text,
    ai_summary text,
    status character varying(30),
    started_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.te_clusters OWNER TO aipet_user;

--
-- Name: te_clusters_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.te_clusters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.te_clusters_id_seq OWNER TO aipet_user;

--
-- Name: te_clusters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.te_clusters_id_seq OWNED BY public.te_clusters.id;


--
-- Name: te_events; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.te_events (
    id integer NOT NULL,
    source_module character varying(50) NOT NULL,
    event_type character varying(100) NOT NULL,
    severity character varying(20),
    title character varying(300) NOT NULL,
    description text,
    entity character varying(200),
    entity_type character varying(50),
    mitre_id character varying(50),
    cluster_id integer,
    correlated boolean,
    risk_score integer,
    raw_ref_id integer,
    resolved boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.te_events OWNER TO aipet_user;

--
-- Name: te_events_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.te_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.te_events_id_seq OWNER TO aipet_user;

--
-- Name: te_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.te_events_id_seq OWNED BY public.te_events.id;


--
-- Name: tenant_assessments; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.tenant_assessments (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    tenant_name character varying(256),
    tenant_type character varying(64),
    isolation_score double precision,
    risk_score double precision,
    total_tenants integer,
    issues integer,
    summary text,
    findings text,
    tenants_data text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.tenant_assessments OWNER TO aipet_user;

--
-- Name: terminal_audit_log; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.terminal_audit_log (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_key character varying(100),
    raw_input character varying(500) NOT NULL,
    parsed_cmd character varying(200),
    module character varying(100),
    success boolean,
    error text,
    duration_ms integer,
    ip_address character varying(50),
    created_at timestamp without time zone
);


ALTER TABLE public.terminal_audit_log OWNER TO aipet_user;

--
-- Name: terminal_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.terminal_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.terminal_audit_log_id_seq OWNER TO aipet_user;

--
-- Name: terminal_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.terminal_audit_log_id_seq OWNED BY public.terminal_audit_log.id;


--
-- Name: terminal_sessions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.terminal_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_key character varying(100) NOT NULL,
    last_command character varying(500),
    context text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.terminal_sessions OWNER TO aipet_user;

--
-- Name: terminal_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.terminal_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.terminal_sessions_id_seq OWNER TO aipet_user;

--
-- Name: terminal_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.terminal_sessions_id_seq OWNED BY public.terminal_sessions.id;


--
-- Name: threat_intel_feeds; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.threat_intel_feeds (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    feed_name character varying(256),
    feed_type character varying(64),
    total_iocs integer,
    critical_iocs integer,
    threat_actors integer,
    ttps_mapped integer,
    risk_score double precision,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.threat_intel_feeds OWNER TO aipet_user;

--
-- Name: threat_intel_iocs; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.threat_intel_iocs (
    id character varying(64) NOT NULL,
    feed_id character varying(64) NOT NULL,
    ioc_type character varying(32),
    ioc_value character varying(512),
    severity character varying(16),
    confidence character varying(16),
    threat_actor character varying(128),
    ttp character varying(128),
    description text,
    first_seen character varying(32),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.threat_intel_iocs OWNER TO aipet_user;

--
-- Name: threat_matches; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.threat_matches (
    id integer NOT NULL,
    ioc_entry_id integer,
    scan_id integer,
    matched_value character varying(500) NOT NULL,
    match_source character varying(100) NOT NULL,
    threat_type character varying(100),
    confidence integer,
    severity character varying(20),
    details text,
    user_id integer,
    created_at timestamp without time zone
);


ALTER TABLE public.threat_matches OWNER TO aipet_user;

--
-- Name: threat_matches_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.threat_matches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.threat_matches_id_seq OWNER TO aipet_user;

--
-- Name: threat_matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.threat_matches_id_seq OWNED BY public.threat_matches.id;


--
-- Name: threat_radar_reports; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.threat_radar_reports (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    organisation character varying(256),
    region character varying(64),
    sector character varying(64),
    risk_score double precision,
    severity character varying(16),
    threat_count integer,
    summary text,
    created_at timestamp without time zone,
    node_meta text
);


ALTER TABLE public.threat_radar_reports OWNER TO aipet_user;

--
-- Name: threat_radar_threats; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.threat_radar_threats (
    id character varying(64) NOT NULL,
    report_id character varying(64) NOT NULL,
    threat_type character varying(64),
    actor character varying(128),
    severity character varying(16),
    confidence character varying(16),
    description text,
    mitigation text,
    mitre_tactic character varying(128),
    node_meta text,
    created_at timestamp without time zone
);


ALTER TABLE public.threat_radar_threats OWNER TO aipet_user;

--
-- Name: timeline_events; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.timeline_events (
    id integer NOT NULL,
    source character varying(50) NOT NULL,
    event_type character varying(100) NOT NULL,
    severity character varying(20),
    title character varying(300) NOT NULL,
    detail text,
    entity character varying(200),
    mitre_id character varying(50),
    user_id integer,
    resolved boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.timeline_events OWNER TO aipet_user;

--
-- Name: timeline_events_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.timeline_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.timeline_events_id_seq OWNER TO aipet_user;

--
-- Name: timeline_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.timeline_events_id_seq OWNED BY public.timeline_events.id;


--
-- Name: twin_edges; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.twin_edges (
    id integer NOT NULL,
    source_id integer NOT NULL,
    target_id integer NOT NULL,
    edge_type character varying(50),
    protocol character varying(50),
    port integer,
    encrypted boolean,
    bandwidth character varying(50),
    latency_ms integer,
    active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.twin_edges OWNER TO aipet_user;

--
-- Name: twin_edges_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.twin_edges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.twin_edges_id_seq OWNER TO aipet_user;

--
-- Name: twin_edges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.twin_edges_id_seq OWNED BY public.twin_edges.id;


--
-- Name: twin_nodes; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.twin_nodes (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    node_type character varying(50) NOT NULL,
    ip_address character varying(100),
    mac_address character varying(50),
    vendor character varying(200),
    firmware character varying(100),
    location character varying(200),
    zone character varying(50),
    expected_state text,
    actual_state text,
    diverged boolean,
    risk_score integer,
    online boolean,
    x_pos double precision,
    y_pos double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.twin_nodes OWNER TO aipet_user;

--
-- Name: twin_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.twin_nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.twin_nodes_id_seq OWNER TO aipet_user;

--
-- Name: twin_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.twin_nodes_id_seq OWNED BY public.twin_nodes.id;


--
-- Name: twin_snapshots; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.twin_snapshots (
    id integer NOT NULL,
    label character varying(200),
    snapshot_type character varying(50),
    node_count integer,
    edge_count integer,
    diverged_count integer,
    risk_avg double precision,
    data text,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.twin_snapshots OWNER TO aipet_user;

--
-- Name: twin_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.twin_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.twin_snapshots_id_seq OWNER TO aipet_user;

--
-- Name: twin_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.twin_snapshots_id_seq OWNED BY public.twin_snapshots.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.user_roles (
    id character varying(36) NOT NULL,
    user_id integer NOT NULL,
    role_id character varying(36) NOT NULL,
    assigned_by integer,
    assigned_at timestamp without time zone
);


ALTER TABLE public.user_roles OWNER TO aipet_user;

--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.user_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    slack_webhook_url text,
    teams_webhook_url text,
    notify_critical boolean DEFAULT true,
    notify_high boolean DEFAULT false,
    notify_cve boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    siem_webhook_url text
);


ALTER TABLE public.user_settings OWNER TO aipet_user;

--
-- Name: user_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.user_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_settings_id_seq OWNER TO aipet_user;

--
-- Name: user_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.user_settings_id_seq OWNED BY public.user_settings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    plan character varying(50),
    scans_used integer,
    scans_limit integer,
    created_at timestamp without time zone,
    last_login timestamp without time zone,
    is_active boolean,
    stripe_customer_id character varying(100),
    stripe_subscription_id character varying(100),
    plan_expires_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: watch_alerts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.watch_alerts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(50) NOT NULL,
    description text NOT NULL,
    details jsonb,
    is_acknowledged boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.watch_alerts OWNER TO aipet_user;

--
-- Name: watch_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.watch_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watch_alerts_id_seq OWNER TO aipet_user;

--
-- Name: watch_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.watch_alerts_id_seq OWNED BY public.watch_alerts.id;


--
-- Name: watch_baselines; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.watch_baselines (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    device_function character varying(100) DEFAULT 'Unknown'::character varying,
    baseline_data jsonb NOT NULL,
    first_seen timestamp without time zone DEFAULT now(),
    last_seen timestamp without time zone DEFAULT now(),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.watch_baselines OWNER TO aipet_user;

--
-- Name: watch_baselines_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.watch_baselines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watch_baselines_id_seq OWNER TO aipet_user;

--
-- Name: watch_baselines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.watch_baselines_id_seq OWNED BY public.watch_baselines.id;


--
-- Name: zt_access_log; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.zt_access_log (
    id integer NOT NULL,
    source_ip character varying(100) NOT NULL,
    dest_ip character varying(100),
    port character varying(50),
    protocol character varying(20),
    action character varying(30) NOT NULL,
    policy_id integer,
    policy_name character varying(200),
    reason text,
    trust_score integer,
    created_at timestamp without time zone
);


ALTER TABLE public.zt_access_log OWNER TO aipet_user;

--
-- Name: zt_access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.zt_access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zt_access_log_id_seq OWNER TO aipet_user;

--
-- Name: zt_access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.zt_access_log_id_seq OWNED BY public.zt_access_log.id;


--
-- Name: zt_device_trust; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.zt_device_trust (
    id integer NOT NULL,
    device_ip character varying(100) NOT NULL,
    device_name character varying(200),
    trust_score integer,
    status character varying(30),
    risk_factors text,
    last_scan_id integer,
    last_assessed timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.zt_device_trust OWNER TO aipet_user;

--
-- Name: zt_device_trust_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.zt_device_trust_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zt_device_trust_id_seq OWNER TO aipet_user;

--
-- Name: zt_device_trust_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.zt_device_trust_id_seq OWNED BY public.zt_device_trust.id;


--
-- Name: zt_policies; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.zt_policies (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    source character varying(200) NOT NULL,
    destination character varying(200) NOT NULL,
    port character varying(50),
    protocol character varying(20),
    action character varying(30) NOT NULL,
    priority integer,
    enabled boolean,
    hit_count integer,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.zt_policies OWNER TO aipet_user;

--
-- Name: zt_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.zt_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zt_policies_id_seq OWNER TO aipet_user;

--
-- Name: zt_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.zt_policies_id_seq OWNED BY public.zt_policies.id;


--
-- Name: ap_analyses id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ap_analyses ALTER COLUMN id SET DEFAULT nextval('public.ap_analyses_id_seq'::regclass);


--
-- Name: ap_paths id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ap_paths ALTER COLUMN id SET DEFAULT nextval('public.ap_paths_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: as_endpoints id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.as_endpoints ALTER COLUMN id SET DEFAULT nextval('public.as_endpoints_id_seq'::regclass);


--
-- Name: as_findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.as_findings ALTER COLUMN id SET DEFAULT nextval('public.as_findings_id_seq'::regclass);


--
-- Name: as_scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.as_scans ALTER COLUMN id SET DEFAULT nextval('public.as_scans_id_seq'::regclass);


--
-- Name: ba_anomalies id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ba_anomalies ALTER COLUMN id SET DEFAULT nextval('public.ba_anomalies_id_seq'::regclass);


--
-- Name: ba_baselines id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ba_baselines ALTER COLUMN id SET DEFAULT nextval('public.ba_baselines_id_seq'::regclass);


--
-- Name: ba_patterns id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ba_patterns ALTER COLUMN id SET DEFAULT nextval('public.ba_patterns_id_seq'::regclass);


--
-- Name: ca_assessments id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ca_assessments ALTER COLUMN id SET DEFAULT nextval('public.ca_assessments_id_seq'::regclass);


--
-- Name: ca_controls id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ca_controls ALTER COLUMN id SET DEFAULT nextval('public.ca_controls_id_seq'::regclass);


--
-- Name: ca_frameworks id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ca_frameworks ALTER COLUMN id SET DEFAULT nextval('public.ca_frameworks_id_seq'::regclass);


--
-- Name: cloud_accounts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_accounts ALTER COLUMN id SET DEFAULT nextval('public.cloud_accounts_id_seq'::regclass);


--
-- Name: cloud_assets id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_assets ALTER COLUMN id SET DEFAULT nextval('public.cloud_assets_id_seq'::regclass);


--
-- Name: cloud_findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_findings ALTER COLUMN id SET DEFAULT nextval('public.cloud_findings_id_seq'::regclass);


--
-- Name: compliance_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results ALTER COLUMN id SET DEFAULT nextval('public.compliance_results_id_seq'::regclass);


--
-- Name: cs_recommendations id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cs_recommendations ALTER COLUMN id SET DEFAULT nextval('public.cs_recommendations_id_seq'::regclass);


--
-- Name: cs_resources id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cs_resources ALTER COLUMN id SET DEFAULT nextval('public.cs_resources_id_seq'::regclass);


--
-- Name: dd_baselines id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dd_baselines ALTER COLUMN id SET DEFAULT nextval('public.dd_baselines_id_seq'::regclass);


--
-- Name: dd_drifts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dd_drifts ALTER COLUMN id SET DEFAULT nextval('public.dd_drifts_id_seq'::regclass);


--
-- Name: dd_scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dd_scans ALTER COLUMN id SET DEFAULT nextval('public.dd_scans_id_seq'::regclass);


--
-- Name: defense_actions id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_actions ALTER COLUMN id SET DEFAULT nextval('public.defense_actions_id_seq'::regclass);


--
-- Name: defense_playbooks id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_playbooks ALTER COLUMN id SET DEFAULT nextval('public.defense_playbooks_id_seq'::regclass);


--
-- Name: device_tags id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags ALTER COLUMN id SET DEFAULT nextval('public.device_tags_id_seq'::regclass);


--
-- Name: dspm_datastores id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dspm_datastores ALTER COLUMN id SET DEFAULT nextval('public.dspm_datastores_id_seq'::regclass);


--
-- Name: dspm_findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dspm_findings ALTER COLUMN id SET DEFAULT nextval('public.dspm_findings_id_seq'::regclass);


--
-- Name: dspm_scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dspm_scans ALTER COLUMN id SET DEFAULT nextval('public.dspm_scans_id_seq'::regclass);


--
-- Name: explain_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results ALTER COLUMN id SET DEFAULT nextval('public.explain_results_id_seq'::regclass);


--
-- Name: findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings ALTER COLUMN id SET DEFAULT nextval('public.findings_id_seq'::regclass);


--
-- Name: ig_edges id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_edges ALTER COLUMN id SET DEFAULT nextval('public.ig_edges_id_seq'::regclass);


--
-- Name: ig_identities id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_identities ALTER COLUMN id SET DEFAULT nextval('public.ig_identities_id_seq'::regclass);


--
-- Name: ig_risks id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_risks ALTER COLUMN id SET DEFAULT nextval('public.ig_risks_id_seq'::regclass);


--
-- Name: ioc_entries id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_entries ALTER COLUMN id SET DEFAULT nextval('public.ioc_entries_id_seq'::regclass);


--
-- Name: ioc_feeds id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_feeds ALTER COLUMN id SET DEFAULT nextval('public.ioc_feeds_id_seq'::regclass);


--
-- Name: ir_incidents id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ir_incidents ALTER COLUMN id SET DEFAULT nextval('public.ir_incidents_id_seq'::regclass);


--
-- Name: ir_tasks id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ir_tasks ALTER COLUMN id SET DEFAULT nextval('public.ir_tasks_id_seq'::regclass);


--
-- Name: mp_installs id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_installs ALTER COLUMN id SET DEFAULT nextval('public.mp_installs_id_seq'::regclass);


--
-- Name: mp_plugins id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_plugins ALTER COLUMN id SET DEFAULT nextval('public.mp_plugins_id_seq'::regclass);


--
-- Name: mp_reviews id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_reviews ALTER COLUMN id SET DEFAULT nextval('public.mp_reviews_id_seq'::regclass);


--
-- Name: nv_edges id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_edges ALTER COLUMN id SET DEFAULT nextval('public.nv_edges_id_seq'::regclass);


--
-- Name: nv_issues id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_issues ALTER COLUMN id SET DEFAULT nextval('public.nv_issues_id_seq'::regclass);


--
-- Name: nv_nodes id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_nodes ALTER COLUMN id SET DEFAULT nextval('public.nv_nodes_id_seq'::regclass);


--
-- Name: ot_devices id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_devices ALTER COLUMN id SET DEFAULT nextval('public.ot_devices_id_seq'::regclass);


--
-- Name: ot_findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_findings ALTER COLUMN id SET DEFAULT nextval('public.ot_findings_id_seq'::regclass);


--
-- Name: ot_scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_scans ALTER COLUMN id SET DEFAULT nextval('public.ot_scans_id_seq'::regclass);


--
-- Name: predict_alerts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts ALTER COLUMN id SET DEFAULT nextval('public.predict_alerts_id_seq'::regclass);


--
-- Name: protocol_scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans ALTER COLUMN id SET DEFAULT nextval('public.protocol_scans_id_seq'::regclass);


--
-- Name: re_assets id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.re_assets ALTER COLUMN id SET DEFAULT nextval('public.re_assets_id_seq'::regclass);


--
-- Name: re_plans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.re_plans ALTER COLUMN id SET DEFAULT nextval('public.re_plans_id_seq'::regclass);


--
-- Name: re_tests id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.re_tests ALTER COLUMN id SET DEFAULT nextval('public.re_tests_id_seq'::regclass);


--
-- Name: remediation_kb id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb ALTER COLUMN id SET DEFAULT nextval('public.remediation_kb_id_seq'::regclass);


--
-- Name: risk_narratives id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.risk_narratives ALTER COLUMN id SET DEFAULT nextval('public.risk_narratives_id_seq'::regclass);


--
-- Name: rt_attacks id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_attacks ALTER COLUMN id SET DEFAULT nextval('public.rt_attacks_id_seq'::regclass);


--
-- Name: rt_campaigns id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_campaigns ALTER COLUMN id SET DEFAULT nextval('public.rt_campaigns_id_seq'::regclass);


--
-- Name: sc_components id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sc_components ALTER COLUMN id SET DEFAULT nextval('public.sc_components_id_seq'::regclass);


--
-- Name: sc_sboms id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sc_sboms ALTER COLUMN id SET DEFAULT nextval('public.sc_sboms_id_seq'::regclass);


--
-- Name: sc_vulns id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sc_vulns ALTER COLUMN id SET DEFAULT nextval('public.sc_vulns_id_seq'::regclass);


--
-- Name: scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans ALTER COLUMN id SET DEFAULT nextval('public.scans_id_seq'::regclass);


--
-- Name: score_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results ALTER COLUMN id SET DEFAULT nextval('public.score_results_id_seq'::regclass);


--
-- Name: siem_events id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_events ALTER COLUMN id SET DEFAULT nextval('public.siem_events_id_seq'::regclass);


--
-- Name: siem_incidents id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_incidents ALTER COLUMN id SET DEFAULT nextval('public.siem_incidents_id_seq'::regclass);


--
-- Name: siem_rules id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_rules ALTER COLUMN id SET DEFAULT nextval('public.siem_rules_id_seq'::regclass);


--
-- Name: te_clusters id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.te_clusters ALTER COLUMN id SET DEFAULT nextval('public.te_clusters_id_seq'::regclass);


--
-- Name: te_events id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.te_events ALTER COLUMN id SET DEFAULT nextval('public.te_events_id_seq'::regclass);


--
-- Name: terminal_audit_log id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.terminal_audit_log ALTER COLUMN id SET DEFAULT nextval('public.terminal_audit_log_id_seq'::regclass);


--
-- Name: terminal_sessions id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.terminal_sessions ALTER COLUMN id SET DEFAULT nextval('public.terminal_sessions_id_seq'::regclass);


--
-- Name: threat_matches id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches ALTER COLUMN id SET DEFAULT nextval('public.threat_matches_id_seq'::regclass);


--
-- Name: timeline_events id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.timeline_events ALTER COLUMN id SET DEFAULT nextval('public.timeline_events_id_seq'::regclass);


--
-- Name: twin_edges id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_edges ALTER COLUMN id SET DEFAULT nextval('public.twin_edges_id_seq'::regclass);


--
-- Name: twin_nodes id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_nodes ALTER COLUMN id SET DEFAULT nextval('public.twin_nodes_id_seq'::regclass);


--
-- Name: twin_snapshots id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_snapshots ALTER COLUMN id SET DEFAULT nextval('public.twin_snapshots_id_seq'::regclass);


--
-- Name: user_settings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_settings ALTER COLUMN id SET DEFAULT nextval('public.user_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: watch_alerts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts ALTER COLUMN id SET DEFAULT nextval('public.watch_alerts_id_seq'::regclass);


--
-- Name: watch_baselines id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines ALTER COLUMN id SET DEFAULT nextval('public.watch_baselines_id_seq'::regclass);


--
-- Name: zt_access_log id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_access_log ALTER COLUMN id SET DEFAULT nextval('public.zt_access_log_id_seq'::regclass);


--
-- Name: zt_device_trust id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_device_trust ALTER COLUMN id SET DEFAULT nextval('public.zt_device_trust_id_seq'::regclass);


--
-- Name: zt_policies id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_policies ALTER COLUMN id SET DEFAULT nextval('public.zt_policies_id_seq'::regclass);


--
-- Data for Name: adversary_profiles; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.adversary_profiles (id, user_id, actor_name, actor_type, origin, motivation, sophistication, confidence, threat_level, active_since, targets, ttps, summary, created_at, node_meta) FROM stdin;
32dc34fc-503b-4964-a9f0-4e18705e9690	1	APT29 (Cozy Bear / Midnight Blizzard)	Nation-State APT	Russia — SVR (Foreign Intelligence Service)	Espionage — Government, Defence, Think Tanks	Very High	99	CRITICAL	2008	["Government", "Defence", "Healthcare", "Think Tanks", "Energy", "Technology"]	["T1566 Phishing", "T1195 Supply Chain", "T1078 Valid Accounts", "T1027 Obfuscated Files", "T1071 C2", "T1003 Credential Dump"]	APT29 is one of the most sophisticated nation-state threat actors globally. Operating on behalf of Russian SVR, they conduct long-term espionage campaigns with exceptional stealth and patience. Known for the SolarWinds supply chain attack affecting 18,000+ organisations.	2026-04-22 19:21:25.424147	{"tools": ["SUNBURST", "TEARDROP", "WellMess", "GoldFinder", "Cobalt Strike"], "campaigns": ["SolarWinds 2020", "Microsoft Exchange 2021", "TeamViewer 2024"], "mitigations": ["Zero Trust Architecture", "MFA Everywhere", "Supply Chain Security", "Privileged Access Management", "Threat Hunting"]}
bc03ec96-186a-4a54-9df9-cf142a540932	1	APT29 (Cozy Bear / Midnight Blizzard)	Nation-State APT	Russia — SVR (Foreign Intelligence Service)	Espionage — Government, Defence, Think Tanks	Very High	99	CRITICAL	2008	["Government", "Defence", "Healthcare", "Think Tanks", "Energy", "Technology"]	["T1566 Phishing", "T1195 Supply Chain", "T1078 Valid Accounts", "T1027 Obfuscated Files", "T1071 C2", "T1003 Credential Dump"]	APT29 is one of the most sophisticated nation-state threat actors globally. Operating on behalf of Russian SVR, they conduct long-term espionage campaigns with exceptional stealth and patience. Known for the SolarWinds supply chain attack affecting 18,000+ organisations.	2026-04-22 21:54:48.703341	{"tools": ["SUNBURST", "TEARDROP", "WellMess", "GoldFinder", "Cobalt Strike"], "campaigns": ["SolarWinds 2020", "Microsoft Exchange 2021", "TeamViewer 2024"], "mitigations": ["Zero Trust Architecture", "MFA Everywhere", "Supply Chain Security", "Privileged Access Management", "Threat Hunting"]}
\.


--
-- Data for Name: ap_analyses; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ap_analyses (id, name, scope, total_paths, critical_paths, max_depth, created_by, created_at) FROM stdin;
1	Test Analysis	Full Network	5	3	4	1	2026-04-17 17:11:15.875829
2	Attack Path Analysis — 17/04/2026	Full Network	5	3	4	1	2026-04-17 17:22:36.151926
3	Attack Path Analysis — 21/04/2026	Full Network	5	3	4	1	2026-04-21 23:52:26.680422
\.


--
-- Data for Name: ap_paths; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ap_paths (id, analysis_id, entry_point, target, severity, hops, chain, techniques, likelihood, impact, blocked, created_at) FROM stdin;
1	1	IP Camera	PLC Controller	Critical	4	[{"device": "IP Camera", "action": "Initial compromise via CVE-2024-1234", "technique": "T1190", "zone": "iot"}, {"device": "IoT Gateway", "action": "Lateral movement via default SSH credentials", "technique": "T1021", "zone": "iot"}, {"device": "SCADA Server", "action": "Pivot to OT network via unpatched Modbus service", "technique": "T1210", "zone": "operational"}, {"device": "PLC Controller", "action": "Direct manipulation of control registers", "technique": "T1565", "zone": "field"}]	["T1190", "T1021", "T1210", "T1565"]	78	Physical process manipulation — potential equipment damage or safety incident	f	2026-04-17 17:11:15.881208
2	1	VPN Gateway	Historian Server	Critical	3	[{"device": "VPN Gateway", "action": "Credential stuffing attack succeeds", "technique": "T1078", "zone": "dmz"}, {"device": "AD Controller", "action": "Kerberoasting yields domain admin hash", "technique": "T1558", "zone": "corporate"}, {"device": "Historian Server", "action": "Full access to all historical OT data", "technique": "T1530", "zone": "operational"}]	["T1078", "T1558", "T1530"]	65	Full access to 5 years of operational data — regulatory breach, IP theft	f	2026-04-17 17:11:15.881216
3	1	MQTT Broker	Water Treatment Controller	Critical	3	[{"device": "MQTT Broker", "action": "Unencrypted MQTT traffic captured and injected", "technique": "T1040", "zone": "iot"}, {"device": "IoT Gateway", "action": "MQTT broker compromise gives device control", "technique": "T1565", "zone": "iot"}, {"device": "Water Treatment Controller", "action": "False sensor data injection alters treatment levels", "technique": "T1565", "zone": "field"}]	["T1040", "T1565", "T1565"]	55	Public health risk — chemical dosing manipulation	f	2026-04-17 17:11:15.881216
4	1	Smart Thermostat	SCADA Server	High	2	[{"device": "Smart Thermostat", "action": "Firmware vulnerability exploited", "technique": "T1203", "zone": "iot"}, {"device": "SCADA Server", "action": "Network pivot via shared segment", "technique": "T1021", "zone": "operational"}]	["T1203", "T1021"]	45	SCADA compromise — full operational visibility to attacker	f	2026-04-17 17:11:15.881217
5	1	Email Server	HMI Terminal	High	3	[{"device": "Email Server", "action": "Spear phishing email delivers malware", "technique": "T1566", "zone": "dmz"}, {"device": "AD Controller", "action": "Credential theft via LSASS dump", "technique": "T1003", "zone": "corporate"}, {"device": "HMI Terminal", "action": "Remote desktop to HMI with stolen creds", "technique": "T1021", "zone": "operational"}]	["T1566", "T1003", "T1021"]	40	Human-machine interface control — operator-level access to all OT systems	f	2026-04-17 17:11:15.881218
6	2	IP Camera	PLC Controller	Critical	4	[{"device": "IP Camera", "action": "Initial compromise via CVE-2024-1234", "technique": "T1190", "zone": "iot"}, {"device": "IoT Gateway", "action": "Lateral movement via default SSH credentials", "technique": "T1021", "zone": "iot"}, {"device": "SCADA Server", "action": "Pivot to OT network via unpatched Modbus service", "technique": "T1210", "zone": "operational"}, {"device": "PLC Controller", "action": "Direct manipulation of control registers", "technique": "T1565", "zone": "field"}]	["T1190", "T1021", "T1210", "T1565"]	78	Physical process manipulation — potential equipment damage or safety incident	f	2026-04-17 17:22:36.160056
7	2	VPN Gateway	Historian Server	Critical	3	[{"device": "VPN Gateway", "action": "Credential stuffing attack succeeds", "technique": "T1078", "zone": "dmz"}, {"device": "AD Controller", "action": "Kerberoasting yields domain admin hash", "technique": "T1558", "zone": "corporate"}, {"device": "Historian Server", "action": "Full access to all historical OT data", "technique": "T1530", "zone": "operational"}]	["T1078", "T1558", "T1530"]	65	Full access to 5 years of operational data — regulatory breach, IP theft	f	2026-04-17 17:22:36.160065
8	2	MQTT Broker	Water Treatment Controller	Critical	3	[{"device": "MQTT Broker", "action": "Unencrypted MQTT traffic captured and injected", "technique": "T1040", "zone": "iot"}, {"device": "IoT Gateway", "action": "MQTT broker compromise gives device control", "technique": "T1565", "zone": "iot"}, {"device": "Water Treatment Controller", "action": "False sensor data injection alters treatment levels", "technique": "T1565", "zone": "field"}]	["T1040", "T1565", "T1565"]	55	Public health risk — chemical dosing manipulation	f	2026-04-17 17:22:36.160066
9	2	Smart Thermostat	SCADA Server	High	2	[{"device": "Smart Thermostat", "action": "Firmware vulnerability exploited", "technique": "T1203", "zone": "iot"}, {"device": "SCADA Server", "action": "Network pivot via shared segment", "technique": "T1021", "zone": "operational"}]	["T1203", "T1021"]	45	SCADA compromise — full operational visibility to attacker	f	2026-04-17 17:22:36.160067
10	2	Email Server	HMI Terminal	High	3	[{"device": "Email Server", "action": "Spear phishing email delivers malware", "technique": "T1566", "zone": "dmz"}, {"device": "AD Controller", "action": "Credential theft via LSASS dump", "technique": "T1003", "zone": "corporate"}, {"device": "HMI Terminal", "action": "Remote desktop to HMI with stolen creds", "technique": "T1021", "zone": "operational"}]	["T1566", "T1003", "T1021"]	40	Human-machine interface control — operator-level access to all OT systems	f	2026-04-17 17:22:36.160068
11	3	IP Camera	PLC Controller	Critical	4	[{"device": "IP Camera", "action": "Initial compromise via CVE-2024-1234", "technique": "T1190", "zone": "iot"}, {"device": "IoT Gateway", "action": "Lateral movement via default SSH credentials", "technique": "T1021", "zone": "iot"}, {"device": "SCADA Server", "action": "Pivot to OT network via unpatched Modbus service", "technique": "T1210", "zone": "operational"}, {"device": "PLC Controller", "action": "Direct manipulation of control registers", "technique": "T1565", "zone": "field"}]	["T1190", "T1021", "T1210", "T1565"]	78	Physical process manipulation — potential equipment damage or safety incident	f	2026-04-21 23:52:26.690186
12	3	VPN Gateway	Historian Server	Critical	3	[{"device": "VPN Gateway", "action": "Credential stuffing attack succeeds", "technique": "T1078", "zone": "dmz"}, {"device": "AD Controller", "action": "Kerberoasting yields domain admin hash", "technique": "T1558", "zone": "corporate"}, {"device": "Historian Server", "action": "Full access to all historical OT data", "technique": "T1530", "zone": "operational"}]	["T1078", "T1558", "T1530"]	65	Full access to 5 years of operational data — regulatory breach, IP theft	f	2026-04-21 23:52:26.690191
13	3	MQTT Broker	Water Treatment Controller	Critical	3	[{"device": "MQTT Broker", "action": "Unencrypted MQTT traffic captured and injected", "technique": "T1040", "zone": "iot"}, {"device": "IoT Gateway", "action": "MQTT broker compromise gives device control", "technique": "T1565", "zone": "iot"}, {"device": "Water Treatment Controller", "action": "False sensor data injection alters treatment levels", "technique": "T1565", "zone": "field"}]	["T1040", "T1565", "T1565"]	55	Public health risk — chemical dosing manipulation	f	2026-04-21 23:52:26.690192
14	3	Smart Thermostat	SCADA Server	High	2	[{"device": "Smart Thermostat", "action": "Firmware vulnerability exploited", "technique": "T1203", "zone": "iot"}, {"device": "SCADA Server", "action": "Network pivot via shared segment", "technique": "T1021", "zone": "operational"}]	["T1203", "T1021"]	45	SCADA compromise — full operational visibility to attacker	f	2026-04-21 23:52:26.690192
15	3	Email Server	HMI Terminal	High	3	[{"device": "Email Server", "action": "Spear phishing email delivers malware", "technique": "T1566", "zone": "dmz"}, {"device": "AD Controller", "action": "Credential theft via LSASS dump", "technique": "T1003", "zone": "corporate"}, {"device": "HMI Terminal", "action": "Remote desktop to HMI with stolen creds", "technique": "T1021", "zone": "operational"}]	["T1566", "T1003", "T1021"]	40	Human-machine interface control — operator-level access to all OT systems	f	2026-04-21 23:52:26.690193
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.api_keys (id, user_id, key_hash, name, last_used, created_at, is_active) FROM stdin;
1	1	2cf027461a731b41b3d9cc55789dedb5e73595fadbc678c157405ce5d5be3b28	My CI/CD Pipeline	\N	2026-03-30 16:28:58.227803	f
3	1	7b17991ccbdb3b7168b2520919490d2f8a94589b016f747c3216b50022ff38a0	End-to-end test	2026-03-31 20:15:39.858877	2026-03-31 20:13:29.613879	t
4	1	59f2a21c6276395ea2c8eb2e71fdd36f476471a7c1c25679caa85ba4c57d72ca	Test Key	\N	2026-04-09 16:34:43.62576	t
5	1	ca11c6af63b9dc2fae56f1a5be98236898e0fbaf5282f94c0a10047815177bb5	Test Key	\N	2026-04-09 16:34:56.359076	t
2	1	4582d10b9e9f90dff98b800eebd04b4971b8285781f4d6a22b2029e5f200c220	Production CI/CD	\N	2026-03-30 16:47:46.966119	f
\.


--
-- Data for Name: apm_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.apm_reports (id, user_id, service_name, environment, health_score, avg_latency_ms, p99_latency_ms, throughput_rps, error_rate_pct, apdex_score, issues, summary, services_data, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: arch_builder_components; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.arch_builder_components (id, design_id, layer, component, service, purpose, security_note, iac_snippet, node_meta, created_at) FROM stdin;
694bd964-f4a1-472f-8f23-08336953fbd6	8ec8d829-133c-4343-91b5-319f669ca48c	Edge	CDN + WAF	CloudFront + AWS WAF	Global content delivery with DDoS protection and OWASP Top 10 filtering.	Enable WAF rules for SQLi, XSS, RCE. Set rate limiting at edge.	aws_wafv2_web_acl main { scope=CLOUDFRONT, default_action=allow }	{}	2026-04-22 14:51:16.301564
84f41bb1-c07e-42c7-9671-1567a7b97e53	8ec8d829-133c-4343-91b5-319f669ca48c	DNS	DNS with DNSSEC	Route 53	Resilient DNS routing with DNSSEC to prevent spoofing and cache poisoning.	Enable DNSSEC. Use health checks and failover routing for availability.	aws_route53_zone main { name=yourdomain.com, dnssec_config=SIGNING }	{}	2026-04-22 14:51:16.301571
3799e3f9-55ed-4fcc-a7fb-125c52126c5f	8ec8d829-133c-4343-91b5-319f669ca48c	Identity	Identity Provider + MFA	AWS Cognito / Azure AD	Centralised identity management with MFA and OAuth2/OIDC for all users.	Enforce MFA for all users. Use short-lived JWTs. Implement token rotation.	aws_cognito_user_pool main { mfa_configuration=ON, password_policy={min_length=16} }	{}	2026-04-22 14:51:16.301574
41bf1456-0e88-4ad2-ba77-1245c5fa5934	8ec8d829-133c-4343-91b5-319f669ca48c	Network	Zero Trust VPC	VPC + Private Subnets + NACLs	Micro-segmented VPC with public/private/data subnet tiers. No direct internet to app layer.	Block all inbound by default. Use security groups as firewalls. Enable VPC Flow Logs.	aws_vpc main { cidr=10.0.0.0/16, enable_dns_hostnames=true, flow_logs=ALL }	{}	2026-04-22 14:51:16.301577
64864024-167e-4cae-9d49-f83d5d728337	8ec8d829-133c-4343-91b5-319f669ca48c	Compute	Auto-scaling App Tier	ECS Fargate / Cloud Run	Containerised application with auto-scaling and immutable infrastructure.	Run as non-root. Use read-only filesystems. Scan images in CI/CD pipeline.	aws_ecs_task_definition app { requires_compatibilities=FARGATE, network_mode=awsvpc }	{}	2026-04-22 14:51:16.301579
cdc0f5a6-0657-4820-8510-ef41f75ca8cb	8ec8d829-133c-4343-91b5-319f669ca48c	API	API Gateway + Rate Limiting	AWS API Gateway / Kong	Centralised API management with auth, rate limiting and audit logging.	Enforce JWT auth. Enable request throttling. Log all API calls.	aws_api_gateway_rest_api main { name=secure-api, throttling_burst_limit=5000 }	{}	2026-04-22 14:51:16.301583
a2d25cb3-2817-4765-aedc-238c5674e9db	8ec8d829-133c-4343-91b5-319f669ca48c	Data	Encrypted Database	RDS Aurora / Azure SQL	Multi-AZ encrypted database with automated backups and private subnet placement.	Enable encryption at rest and in transit. Restrict to app tier only. Enable audit logging.	aws_db_instance main { storage_encrypted=true, multi_az=true, publicly_accessible=false }	{}	2026-04-22 14:51:16.301585
c8fa773b-4619-4a12-982a-7181e9537739	8ec8d829-133c-4343-91b5-319f669ca48c	Secrets	Secrets Manager	AWS Secrets Manager / Vault	Centralised secrets with automatic rotation for credentials and API keys.	Never hardcode secrets. Rotate all credentials every 90 days. Audit all access.	aws_secretsmanager_secret db { name=db-credentials, rotation_days=90 }	{}	2026-04-22 14:51:16.301587
416e78c9-5de7-4950-b227-3f3d07e5ae25	8ec8d829-133c-4343-91b5-319f669ca48c	Observability	SIEM + Monitoring	CloudWatch + GuardDuty	Centralised logging, threat detection and security posture management.	Enable GuardDuty in all regions. Set alarms for security events. Retain logs 1 year.	aws_guardduty_detector main { enable=true, publishing_frequency=SIX_HOURS }	{}	2026-04-22 14:51:16.30159
860515a8-4590-4ffc-97df-e1c3e702ac2f	8ec8d829-133c-4343-91b5-319f669ca48c	Backup	Immutable Backup	AWS Backup	Automated daily backups with immutable retention and cross-region replication.	Enable backup vault lock. Test restores monthly. Store in separate AWS account.	aws_backup_plan main { rule={ schedule=cron(0 2 * * ? *), lifecycle={delete_after=90} } }	{}	2026-04-22 14:51:16.301592
\.


--
-- Data for Name: arch_builder_designs; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.arch_builder_designs (id, user_id, title, cloud_provider, arch_type, security_score, summary, created_at, node_meta) FROM stdin;
8ec8d829-133c-4343-91b5-319f669ca48c	1	Secure Web Application Architecture	aws	web_app	92	Secure Secure Web Application Architecture generated for AWS. 10 architecture components with Zero Trust principles. Security score: 92/100.	2026-04-22 14:51:16.296105	{}
\.


--
-- Data for Name: as_endpoints; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.as_endpoints (id, path, method, service, version, auth_type, authenticated, rate_limited, encrypted, has_cors, cors_wildcard, sensitive_data, deprecated, risk_score, finding_count, last_tested, created_at) FROM stdin;
1	/api/auth/login	POST	AIPET Platform	v1	none	f	f	t	t	f	t	f	65	2	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847028
2	/api/scans	POST	AIPET Platform	v1	jwt	t	t	t	f	f	f	f	0	0	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847034
3	/api/findings	GET	AIPET Platform	v1	jwt	t	f	t	f	f	t	f	30	1	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847035
4	/api/v1/devices	GET	IoT Gateway	v1	api_key	t	f	f	t	t	t	f	65	3	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847036
5	/api/v1/telemetry	POST	IoT Gateway	v1	none	f	f	f	t	t	t	f	95	4	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847037
6	/api/v0/config	GET	IoT Gateway	v0	none	f	f	f	f	f	t	t	90	4	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847038
7	/scada/api/status	GET	SCADA Server	v2	basic	t	f	f	f	f	t	f	50	2	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847039
8	/scada/api/control	POST	SCADA Server	v2	basic	t	f	f	f	f	t	f	85	2	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847039
9	/api/v2/patients	GET	NHS Patient System	v2	oauth2	t	t	t	f	f	t	f	10	0	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.84704
10	/api/v1/patients	GET	NHS Patient System	v1	api_key	t	f	t	f	f	t	t	45	2	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.84704
11	/admin/api/users	GET	Admin Portal	v1	none	f	f	t	t	t	t	f	98	4	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847041
12	/admin/api/export	POST	Admin Portal	v1	none	f	f	t	f	f	t	f	70	2	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847041
13	/webhooks/stripe	POST	Payment Service	v1	api_key	t	t	t	f	f	t	f	10	0	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847042
14	/api/v1/reports/export	GET	Reporting Service	v1	jwt	t	f	t	f	f	t	f	30	1	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847042
15	/api/internal/health	GET	Internal	v1	none	f	f	t	f	f	f	f	60	2	2026-04-18 14:49:16.772986	2026-04-18 14:46:08.847043
\.


--
-- Data for Name: as_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.as_findings (id, endpoint_id, finding_type, severity, owasp_id, title, description, evidence, remediation, status, created_at) FROM stdin;
1	11	broken_auth	Critical	API2	Admin user management API accessible without authentication	GET /admin/api/users returns full user list including password hashes without any authentication token	curl http://api/admin/api/users → 200 with 1,847 user records	Implement JWT authentication immediately. Restrict to admin role. Add audit logging.	open	2026-04-18 14:46:08.858422
2	11	cors_misconfiguration	High	API8	Admin API CORS wildcard enables cross-site attacks	Access-Control-Allow-Origin: * on admin API allows malicious sites to make authenticated requests	Response: Access-Control-Allow-Origin: * on unauthenticated admin endpoint	Remove CORS entirely from admin endpoints. Admin API should not be browser-accessible.	open	2026-04-18 14:46:08.858428
3	11	no_rate_limit	High	API4	Admin user API has no rate limiting	Admin endpoint can be enumerated or scraped without restriction	10,000 requests in 60 seconds — all successful	Implement rate limiting: 10 req/min on admin endpoints. Add IP allowlist.	open	2026-04-18 14:46:08.858429
4	11	excessive_exposure	Critical	API3	User API returning password hashes and internal fields	Response includes password_hash, internal_id, admin_notes — not required by any client	Response body contains: password_hash, salt, last_login_ip, admin_notes	Implement response filtering. Use DTOs. Never return sensitive internal fields.	open	2026-04-18 14:46:08.858429
5	5	broken_auth	Critical	API2	IoT telemetry endpoint accepts data without device authentication	Any device or attacker can POST telemetry data — enables false sensor injection	POST /api/v1/telemetry without auth token → 200 OK	Implement device certificate authentication. Reject unauthenticated telemetry.	open	2026-04-18 14:46:08.85843
6	5	missing_encryption	Critical	API8	IoT telemetry transmitted over HTTP — OT data in plaintext	Sensor readings including industrial process data transmitted without TLS	Wireshark capture shows plaintext MQTT/HTTP telemetry data	Force HTTPS/TLS for all IoT API endpoints. Deploy certificates to all devices.	open	2026-04-18 14:46:08.858431
7	5	no_rate_limit	High	API4	Telemetry endpoint has no rate limiting — DoS vector	Flooding endpoint with fake telemetry can overwhelm SCADA system	10,000 fake sensor readings injected in 1 second	Rate limit to 1 request/second per device ID. Validate device ID against inventory.	open	2026-04-18 14:46:08.858431
8	6	outdated_version	High	API9	Deprecated IoT config API (v0) still active — no security patches	API v0 deprecated 18 months ago but still responding. Missing all security updates from v1.	GET /api/v0/config → 200 (should be 410 Gone)	Return 410 Gone from all v0 endpoints. Redirect clients to v1. Decommission within 30 days.	open	2026-04-18 14:46:08.858432
9	6	broken_auth	Critical	API2	Deprecated config endpoint exposes device configuration without auth	v0 config endpoint returns full device configuration including credentials	GET /api/v0/config → 200 with MQTT credentials and PLC setpoints	Decommission immediately. Rotate all credentials returned by this endpoint.	open	2026-04-18 14:46:08.858432
10	8	missing_encryption	Critical	API8	SCADA control API transmitting industrial commands over HTTP	Process control commands sent in plaintext — attacker can intercept and replay	HTTP POST /scada/api/control with PLC register write commands in plaintext	Implement TLS 1.2+ on SCADA API. Use mutual TLS for control commands.	open	2026-04-18 14:46:08.858433
11	8	no_rate_limit	High	API4	SCADA control API has no rate limiting — command flooding risk	No limit on control command frequency — could cause physical equipment damage	1000 control commands accepted in 10 seconds	Rate limit to 1 command/second. Implement command queue. Add anomaly detection.	open	2026-04-18 14:46:08.858433
12	10	outdated_version	Medium	API9	Deprecated NHS Patient API v1 still active	v1 lacks field-level encryption and audit logging added in v2	GET /api/v1/patients → 200 (deprecated endpoint responding)	Migrate all clients to v2. Return 301 redirect from v1 to v2.	open	2026-04-18 14:46:08.858434
13	10	no_rate_limit	High	API4	Deprecated patient API v1 has no rate limiting	Patient data can be scraped without restriction via deprecated endpoint	50,000 patient records extractable in under 10 minutes	Add rate limiting immediately. Decommission v1 within 30 days.	open	2026-04-18 14:46:08.858435
14	1	no_rate_limit	Critical	API4	Login endpoint has no rate limiting — brute force possible	Authentication endpoint accepts unlimited login attempts — password brute force possible	10,000 login attempts accepted without lockout or rate limiting	Implement: 5 failed attempts → 15 min lockout. Rate limit: 10 req/min per IP.	open	2026-04-18 14:46:08.858435
15	14	no_rate_limit	Medium	API4	Report export endpoint missing rate limiting	Large report exports can be triggered repeatedly causing server load	100 concurrent export requests accepted	Rate limit exports to 5/hour per user. Implement async export queue.	open	2026-04-18 14:46:08.858436
16	3	no_rate_limit	High	API4	No rate limiting — GET /api/findings	Endpoint has no rate limiting — vulnerable to brute force and DoS	1000 requests in 10 seconds — all returned 200	Implement rate limiting: 100 req/min per IP, 1000 req/hour per token.	open	2026-04-18 14:49:16.793336
17	4	no_rate_limit	High	API4	No rate limiting — GET /api/v1/devices	Endpoint has no rate limiting — vulnerable to brute force and DoS	1000 requests in 10 seconds — all returned 200	Implement rate limiting: 100 req/min per IP, 1000 req/hour per token.	open	2026-04-18 14:49:16.800197
18	4	cors_misconfiguration	High	API8	CORS wildcard — GET /api/v1/devices	Access-Control-Allow-Origin: * allows any domain to call this API	Response header: Access-Control-Allow-Origin: *	Restrict CORS to specific allowed origins. Never use wildcard on authenticated endpoints.	open	2026-04-18 14:49:16.800203
19	4	missing_encryption	Critical	API8	Sensitive data over unencrypted channel — /api/v1/devices	Endpoint transmitting sensitive data without TLS encryption	HTTP protocol detected — no TLS/SSL	Force HTTPS. Redirect HTTP to HTTPS. Enable HSTS.	open	2026-04-18 14:49:16.800205
20	7	no_rate_limit	High	API4	No rate limiting — GET /scada/api/status	Endpoint has no rate limiting — vulnerable to brute force and DoS	1000 requests in 10 seconds — all returned 200	Implement rate limiting: 100 req/min per IP, 1000 req/hour per token.	open	2026-04-18 14:49:16.810677
21	7	missing_encryption	Critical	API8	Sensitive data over unencrypted channel — /scada/api/status	Endpoint transmitting sensitive data without TLS encryption	HTTP protocol detected — no TLS/SSL	Force HTTPS. Redirect HTTP to HTTPS. Enable HSTS.	open	2026-04-18 14:49:16.810683
22	12	broken_auth	Critical	API2	Unauthenticated endpoint — POST /admin/api/export	Endpoint accessible without authentication credentials	No Authorization header required — 200 response without token	Implement JWT or API key authentication. Return 401 for unauthenticated requests.	open	2026-04-18 14:49:16.831607
23	12	no_rate_limit	High	API4	No rate limiting — POST /admin/api/export	Endpoint has no rate limiting — vulnerable to brute force and DoS	1000 requests in 10 seconds — all returned 200	Implement rate limiting: 100 req/min per IP, 1000 req/hour per token.	open	2026-04-18 14:49:16.831615
24	15	broken_auth	Critical	API2	Unauthenticated endpoint — GET /api/internal/health	Endpoint accessible without authentication credentials	No Authorization header required — 200 response without token	Implement JWT or API key authentication. Return 401 for unauthenticated requests.	open	2026-04-18 14:49:16.843861
25	15	no_rate_limit	High	API4	No rate limiting — GET /api/internal/health	Endpoint has no rate limiting — vulnerable to brute force and DoS	1000 requests in 10 seconds — all returned 200	Implement rate limiting: 100 req/min per IP, 1000 req/hour per token.	open	2026-04-18 14:49:16.843869
\.


--
-- Data for Name: as_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.as_scans (id, endpoints_scanned, findings_found, critical_count, duration_sec, created_at) FROM stdin;
1	15	10	4	0	2026-04-18 14:49:16.847968
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.audit_log (id, user_id, action, resource, ip_address, user_agent, "timestamp", status) FROM stdin;
2135e45c-be32-4552-897f-4535ea2ab136	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 00:30:46.088256	blocked
62527630-0b6c-4016-b894-6c11e8a256df	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 00:31:48.005888	blocked
eb9cf4ce-7bee-4edb-9e8f-71b0a9907faa	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 00:42:46.720903	blocked
61237597-770b-4846-af4c-f2d46f17f171	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 00:56:55.555092	blocked
c16de546-6eff-44f2-bf08-f05e3a04adfd	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 01:15:28.89233	blocked
fc2af1bd-c469-42f4-a068-2603b9cced89	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 02:39:02.856133	blocked
ae656c85-4dda-49a7-a7be-a517ad4a89d2	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 13:30:30.404773	blocked
cae4541f-3b16-47cc-9279-2bdd68af0fba	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 19:38:23.547961	blocked
52c15cc6-a9f1-4d22-bb43-91c927d5fb9b	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-04-17 01:27:30.992782	blocked
ef9f3d8a-4dca-4c8f-9862-186c60fbf569	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-17 21:07:04.817478	blocked
\.


--
-- Data for Name: ba_anomalies; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ba_anomalies (id, baseline_id, entity_name, anomaly_type, severity, title, description, deviation, observed, expected, mitre_id, status, created_at, resolved_at) FROM stdin;
2	8	Water Treatment Controller	traffic_spike	Critical	Water Treatment Controller — 12x traffic spike detected	Outbound traffic 12x above 90-day baseline. Observed 96,000 bytes/hour vs baseline mean 8,000 bytes/hour (11.8σ deviation).	11.8	{"bytes_per_hour": 96000, "unit": "bytes/hour"}	{"mean": 8000, "std": 720, "unit": "bytes/hour"}	T1041	investigating	2026-04-18 12:27:38.609785	\N
3	2	PLC Controller — Production Line A	protocol_change	High	PLC Controller using HTTP — not in baseline protocol set	PLC device using HTTP protocol. Baseline only shows Modbus and DNP3. Possible firmware compromise or misconfiguration.	6.2	{"protocol": "HTTP", "port": 80, "destination": "192.168.1.100"}	{"protocols": ["Modbus", "DNP3"], "ports": [502, 20000]}	T1040	new	2026-04-18 11:32:38.609785	\N
4	2	PLC Controller — Production Line A	unusual_hours	High	PLC Controller active at 03:00 — 5.1σ outside normal window	PLC showing activity at 03:00. Baseline active hours: 06:00-18:00. Unscheduled maintenance or attacker persistence.	5.1	{"hour": 3, "activity": "Modbus register writes"}	{"normal_hours": "06:00-18:00", "mean": 12, "std": 6}	T1078	new	2026-04-18 10:32:38.609785	\N
5	1	IP Camera — Floor 2	data_exfil	High	IP Camera exfiltrating 6x normal data volume	Camera sending 2.7MB/hour vs baseline 450KB/hour. Data leaving network to unknown destination on port 4444.	4.8	{"bytes_per_hour": 2700000, "destination_port": 4444}	{"mean": 450000, "std": 45000, "normal_ports": [554, 80]}	T1041	new	2026-04-18 09:32:38.609785	\N
6	5	contractor_01	geo_anomaly	Critical	Contractor account login from Romania — baseline shows UK only	Authentication from Bucharest, Romania. Account baseline shows United Kingdom only across 6-month history.	9.1	{"location": "Bucharest, Romania", "ip": "89.45.123.67", "time": "02:34 UTC"}	{"locations": ["United Kingdom"], "normal_hours": "09:00-17:00"}	T1078	new	2026-04-18 08:32:38.609785	\N
7	5	contractor_01	lateral_movement	High	Contractor accessing 8 new systems — baseline shows 2	Contractor account accessing systems outside contracted scope. Baseline: 2 systems. Observed: 10 systems in past 4 hours.	4.3	{"systems_accessed": 10, "new_systems": 8}	{"mean": 2, "std": 0.5, "systems": ["iot-gateway-01"]}	T1021	investigating	2026-04-18 07:32:38.609785	\N
8	7	IoT Gateway — Building A	beacon	High	IoT Gateway beaconing every 60 seconds to external IP	Regular periodic connections to 45.89.123.45 every 60 seconds. Classic C2 beaconing pattern. Connection started 6 hours ago.	7.2	{"interval_seconds": 60, "destination": "45.89.123.45", "duration_hours": 6}	{"normal_destinations": ["192.168.1.0/24", "10.0.1.0/24"], "no_periodic_pattern": true}	T1071	new	2026-04-18 07:32:38.609785	\N
9	3	MQTT Broker — IoT Hub	traffic_spike	Medium	MQTT Broker traffic spike — resolved (firmware update)	Traffic spike caused by firmware update broadcast to all IoT devices. Confirmed legitimate. Baseline will be updated.	3.2	{"bytes_per_hour": 3500000}	{"mean": 890000, "std": 89000}	T1071	resolved	2026-04-16 13:32:38.609785	2026-04-17 13:32:38.609785
17	8	Water Treatment Controller	traffic_spike	Critical	Traffic Volume Spike — Water Treatment Controller	Significant increase in network traffic volume above baseline Observed: 55825.8 bytes/hour (19.9σ above baseline)	19.93	{"value": 55825.76, "unit": "bytes/hour"}	{"mean": 8000, "std": 2400.0, "unit": "bytes/hour"}	T1071	false_positive	2026-04-18 13:41:38.041494	\N
1	8	Water Treatment Controller	new_connection	Critical	Water Treatment Controller connecting to unknown external IP	Device established connection to 185.234.219.45 (Russia) — never seen in 90-day baseline. Possible C2 or data exfiltration.	8.4	{"destination": "185.234.219.45", "country": "Russia", "bytes": 45000}	{"destinations": ["10.0.2.1"], "countries": ["Internal"]}	T1071	resolved	2026-04-18 12:32:38.609785	2026-04-18 13:41:03.872404
10	1	IP Camera — Floor 2	traffic_spike	Critical	Traffic Volume Spike — IP Camera — Floor 2	Significant increase in network traffic volume above baseline Observed: 1405661.1 bytes/hour (7.1σ above baseline)	7.08	{"value": 1405661.09, "unit": "bytes/hour"}	{"mean": 450000, "std": 135000.0, "unit": "bytes/hour"}	T1071	new	2026-04-18 13:41:37.969731	\N
11	2	PLC Controller — Production Line A	traffic_spike	Critical	Traffic Volume Spike — PLC Controller — Production Line A	Significant increase in network traffic volume above baseline Observed: 39686.1 bytes/hour (7.7σ above baseline)	7.69	{"value": 39686.11, "unit": "bytes/hour"}	{"mean": 12000, "std": 3600.0, "unit": "bytes/hour"}	T1071	new	2026-04-18 13:41:37.975808	\N
12	3	MQTT Broker — IoT Hub	traffic_spike	Critical	Traffic Volume Spike — MQTT Broker — IoT Hub	Significant increase in network traffic volume above baseline Observed: 2654853.1 bytes/hour (6.6σ above baseline)	6.61	{"value": 2654853.12, "unit": "bytes/hour"}	{"mean": 890000, "std": 267000.0, "unit": "bytes/hour"}	T1071	new	2026-04-18 13:41:37.989533	\N
13	4	admin@aipet.io	traffic_spike	Critical	Traffic Volume Spike — admin@aipet.io	Significant increase in network traffic volume above baseline Observed: 75364.1 bytes/hour (6.7σ above baseline)	6.72	{"value": 75364.09, "unit": "bytes/hour"}	{"mean": 25000, "std": 7500.0, "unit": "bytes/hour"}	T1071	new	2026-04-18 13:41:38.017436	\N
14	5	contractor_01	traffic_spike	Critical	Traffic Volume Spike — contractor_01	Significant increase in network traffic volume above baseline Observed: 25882.3 bytes/hour (13.9σ above baseline)	13.92	{"value": 25882.27, "unit": "bytes/hour"}	{"mean": 5000, "std": 1500.0, "unit": "bytes/hour"}	T1071	new	2026-04-18 13:41:38.023053	\N
15	6	svc-scanner	traffic_spike	Critical	Traffic Volume Spike — svc-scanner	Significant increase in network traffic volume above baseline Observed: 1679435.7 bytes/hour (13.1σ above baseline)	13.13	{"value": 1679435.74, "unit": "bytes/hour"}	{"mean": 340000, "std": 102000.0, "unit": "bytes/hour"}	T1071	new	2026-04-18 13:41:38.027517	\N
16	6	svc-scanner	unusual_hours	Critical	Activity Outside Normal Hours — svc-scanner	Entity active at hours outside its established pattern Observed: 12.0 hour (10.0σ above baseline)	10	{"value": 12, "unit": "hour"}	{"mean": 2, "std": 1, "unit": "hour"}	T1078	investigating	2026-04-18 13:41:38.035498	\N
\.


--
-- Data for Name: ba_baselines; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ba_baselines (id, entity_id, entity_type, entity_name, baseline, confidence, risk_score, anomaly_count, last_updated, created_at) FROM stdin;
7	iot-gateway-01	device	IoT Gateway — Building A	{"avg_bytes_per_hour": 1200000, "avg_connections_per_hour": 234, "active_hours_mean": 12, "active_hours_std": 8, "normal_destinations": ["192.168.1.0/24", "10.0.1.0/24"], "normal_protocols": ["MQTT", "HTTP", "CoAP"], "normal_ports": [1883, 80, 5683]}	88	60	2	2026-04-18 13:41:41.838115	2026-04-18 13:32:38.612109
8	water-treatment-01	device	Water Treatment Controller	{"avg_bytes_per_hour": 8000, "avg_connections_per_hour": 2, "active_hours_mean": 12, "active_hours_std": 8, "normal_destinations": ["10.0.2.1"], "normal_protocols": ["DNP3", "Modbus"], "normal_ports": [20000, 502]}	96	100	7	2026-04-18 13:41:41.840121	2026-04-18 13:32:38.612109
6	svc-scanner	service	svc-scanner	{"avg_bytes_per_hour": 340000, "avg_connections_per_hour": 89, "active_hours_mean": 2, "active_hours_std": 1, "normal_destinations": ["192.168.1.0/24", "10.0.0.0/24"], "normal_protocols": ["TCP", "UDP", "ICMP"], "scan_frequency_per_day": 4}	99	100	2	2026-04-18 13:41:41.825119	2026-04-18 13:32:38.612109
1	ip-camera-01	device	IP Camera — Floor 2	{"avg_bytes_per_hour": 450000, "avg_connections_per_hour": 12, "active_hours_mean": 10, "active_hours_std": 3, "normal_destinations": ["192.168.1.1", "10.0.0.1"], "normal_protocols": ["RTSP", "HTTP"], "normal_ports": [554, 80, 443]}	94	100	4	2026-04-18 13:41:41.826943	2026-04-18 13:32:38.6121
2	plc-01	device	PLC Controller — Production Line A	{"avg_bytes_per_hour": 12000, "avg_connections_per_hour": 3, "active_hours_mean": 12, "active_hours_std": 6, "normal_destinations": ["10.0.1.5", "10.0.1.6"], "normal_protocols": ["Modbus", "DNP3"], "normal_ports": [502, 20000]}	98	100	6	2026-04-18 13:41:41.828775	2026-04-18 13:32:38.612106
3	mqtt-broker-01	device	MQTT Broker — IoT Hub	{"avg_bytes_per_hour": 890000, "avg_connections_per_hour": 145, "active_hours_mean": 12, "active_hours_std": 8, "normal_destinations": ["192.168.1.0/24"], "normal_protocols": ["MQTT"], "normal_ports": [1883, 8883]}	91	78	2	2026-04-18 13:41:41.83178	2026-04-18 13:32:38.612107
4	admin@aipet.io	user	admin@aipet.io	{"avg_bytes_per_hour": 25000, "avg_connections_per_hour": 8, "active_hours_mean": 13, "active_hours_std": 3, "normal_locations": ["United Kingdom"], "normal_hours": [8, 9, 10, 11, 12, 13, 14, 15, 16, 17], "avg_login_attempts": 1.2}	97	63	1	2026-04-18 13:41:41.834403	2026-04-18 13:32:38.612107
5	contractor_01	user	contractor_01	{"avg_bytes_per_hour": 5000, "avg_connections_per_hour": 2, "active_hours_mean": 10, "active_hours_std": 2, "normal_locations": ["United Kingdom"], "normal_hours": [9, 10, 11, 12, 13, 14, 15, 16], "avg_login_attempts": 1.0}	72	100	5	2026-04-18 13:41:41.838058	2026-04-18 13:32:38.612108
\.


--
-- Data for Name: ba_patterns; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ba_patterns (id, baseline_id, entity_name, hour, day_of_week, metrics, recorded_at) FROM stdin;
1	1	IP Camera — Floor 2	0	0	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636014
2	1	IP Camera — Floor 2	1	0	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.63602
3	1	IP Camera — Floor 2	2	0	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.63602
4	1	IP Camera — Floor 2	3	0	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636021
5	1	IP Camera — Floor 2	4	0	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636021
6	1	IP Camera — Floor 2	5	0	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636022
7	1	IP Camera — Floor 2	6	0	{"bytes": 481923.61391214165, "connections": 12.424078769814987}	2026-04-18 13:32:38.636022
8	1	IP Camera — Floor 2	7	0	{"bytes": 502944.2416401541, "connections": 11.008653198310597}	2026-04-18 13:32:38.636023
9	1	IP Camera — Floor 2	8	0	{"bytes": 439459.4456575115, "connections": 10.87151332665137}	2026-04-18 13:32:38.636023
10	1	IP Camera — Floor 2	9	0	{"bytes": 412016.12659848644, "connections": 12.01285269144807}	2026-04-18 13:32:38.636023
11	1	IP Camera — Floor 2	10	0	{"bytes": 386082.3559073216, "connections": 11.277210361647956}	2026-04-18 13:32:38.636024
12	1	IP Camera — Floor 2	11	0	{"bytes": 470234.3991002356, "connections": 12.107859553447721}	2026-04-18 13:32:38.636024
13	1	IP Camera — Floor 2	12	0	{"bytes": 412259.48397549405, "connections": 12.21423764130218}	2026-04-18 13:32:38.636024
14	1	IP Camera — Floor 2	13	0	{"bytes": 491773.1116515066, "connections": 10.815597023227346}	2026-04-18 13:32:38.636025
15	1	IP Camera — Floor 2	14	0	{"bytes": 491285.598997429, "connections": 12.475534547971744}	2026-04-18 13:32:38.636025
16	1	IP Camera — Floor 2	15	0	{"bytes": 428433.81972992886, "connections": 11.173150799548276}	2026-04-18 13:32:38.636026
17	1	IP Camera — Floor 2	16	0	{"bytes": 511723.7647479155, "connections": 11.607826908270305}	2026-04-18 13:32:38.636026
18	1	IP Camera — Floor 2	17	0	{"bytes": 395020.68885632, "connections": 11.032119304400315}	2026-04-18 13:32:38.636026
19	1	IP Camera — Floor 2	18	0	{"bytes": 496911.7394569071, "connections": 12.248942475280538}	2026-04-18 13:32:38.636027
20	1	IP Camera — Floor 2	19	0	{"bytes": 491462.31689204136, "connections": 12.551356288065161}	2026-04-18 13:32:38.636027
21	1	IP Camera — Floor 2	20	0	{"bytes": 454890.79234638455, "connections": 13.135477833550489}	2026-04-18 13:32:38.636027
22	1	IP Camera — Floor 2	21	0	{"bytes": 433602.1409231277, "connections": 12.124897515055745}	2026-04-18 13:32:38.636028
23	1	IP Camera — Floor 2	22	0	{"bytes": 494469.6296741543, "connections": 12.28444740567419}	2026-04-18 13:32:38.636028
24	1	IP Camera — Floor 2	23	0	{"bytes": 135000.0, "connections": 12.868096560745865}	2026-04-18 13:32:38.636028
25	1	IP Camera — Floor 2	0	1	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636029
26	1	IP Camera — Floor 2	1	1	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636029
27	1	IP Camera — Floor 2	2	1	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.63603
28	1	IP Camera — Floor 2	3	1	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.63603
29	1	IP Camera — Floor 2	4	1	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636031
30	1	IP Camera — Floor 2	5	1	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636031
31	1	IP Camera — Floor 2	6	1	{"bytes": 460442.5396096629, "connections": 12.490972406915818}	2026-04-18 13:32:38.636031
32	1	IP Camera — Floor 2	7	1	{"bytes": 388686.2917935144, "connections": 11.346955861563712}	2026-04-18 13:32:38.636032
33	1	IP Camera — Floor 2	8	1	{"bytes": 421567.3750862845, "connections": 10.991500744616705}	2026-04-18 13:32:38.636032
34	1	IP Camera — Floor 2	9	1	{"bytes": 413926.7696587391, "connections": 11.042403430583349}	2026-04-18 13:32:38.636032
35	1	IP Camera — Floor 2	10	1	{"bytes": 420026.43641986244, "connections": 12.325642666234561}	2026-04-18 13:32:38.636033
36	1	IP Camera — Floor 2	11	1	{"bytes": 431752.3441609614, "connections": 11.688434321080518}	2026-04-18 13:32:38.636033
37	1	IP Camera — Floor 2	12	1	{"bytes": 410783.44915415085, "connections": 11.440746772917873}	2026-04-18 13:32:38.636033
38	1	IP Camera — Floor 2	13	1	{"bytes": 508948.3693411867, "connections": 12.355284924591825}	2026-04-18 13:32:38.636034
39	1	IP Camera — Floor 2	14	1	{"bytes": 464732.6857650434, "connections": 11.210732755675433}	2026-04-18 13:32:38.636034
40	1	IP Camera — Floor 2	15	1	{"bytes": 480932.1177232971, "connections": 11.192165985028629}	2026-04-18 13:32:38.636034
41	1	IP Camera — Floor 2	16	1	{"bytes": 433726.48463728244, "connections": 13.174856041527828}	2026-04-18 13:32:38.636035
42	1	IP Camera — Floor 2	17	1	{"bytes": 468899.9675803025, "connections": 12.13667938505915}	2026-04-18 13:32:38.636035
43	1	IP Camera — Floor 2	18	1	{"bytes": 474922.9238836331, "connections": 12.822844608455544}	2026-04-18 13:32:38.636035
44	1	IP Camera — Floor 2	19	1	{"bytes": 487259.988058743, "connections": 11.34971537271385}	2026-04-18 13:32:38.636036
45	1	IP Camera — Floor 2	20	1	{"bytes": 386833.5329270451, "connections": 11.557087315341796}	2026-04-18 13:32:38.636036
46	1	IP Camera — Floor 2	21	1	{"bytes": 418645.01825671986, "connections": 11.306358824607184}	2026-04-18 13:32:38.636036
47	1	IP Camera — Floor 2	22	1	{"bytes": 509792.81143523235, "connections": 12.903282303534406}	2026-04-18 13:32:38.636037
48	1	IP Camera — Floor 2	23	1	{"bytes": 135000.0, "connections": 11.555226913916346}	2026-04-18 13:32:38.636037
49	1	IP Camera — Floor 2	0	2	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636037
50	1	IP Camera — Floor 2	1	2	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636038
51	1	IP Camera — Floor 2	2	2	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636038
52	1	IP Camera — Floor 2	3	2	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636038
53	1	IP Camera — Floor 2	4	2	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636039
54	1	IP Camera — Floor 2	5	2	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636039
55	1	IP Camera — Floor 2	6	2	{"bytes": 470984.2198148088, "connections": 11.749516562545594}	2026-04-18 13:32:38.63604
56	1	IP Camera — Floor 2	7	2	{"bytes": 505963.9246149734, "connections": 11.901244446209757}	2026-04-18 13:32:38.63604
57	1	IP Camera — Floor 2	8	2	{"bytes": 418258.8224772371, "connections": 11.39190601846556}	2026-04-18 13:32:38.63604
58	1	IP Camera — Floor 2	9	2	{"bytes": 458284.6981120254, "connections": 11.430579860455044}	2026-04-18 13:32:38.636041
389	3	MQTT Broker — IoT Hub	4	2	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636158
59	1	IP Camera — Floor 2	10	2	{"bytes": 461419.10868017795, "connections": 12.954774920645944}	2026-04-18 13:32:38.636041
60	1	IP Camera — Floor 2	11	2	{"bytes": 436419.06819395366, "connections": 11.32636982197748}	2026-04-18 13:32:38.636041
61	1	IP Camera — Floor 2	12	2	{"bytes": 517167.57687683986, "connections": 12.022863104823516}	2026-04-18 13:32:38.636042
62	1	IP Camera — Floor 2	13	2	{"bytes": 394772.7706434622, "connections": 10.913079301019362}	2026-04-18 13:32:38.636042
63	1	IP Camera — Floor 2	14	2	{"bytes": 397302.632597339, "connections": 12.305870500087416}	2026-04-18 13:32:38.636042
64	1	IP Camera — Floor 2	15	2	{"bytes": 489430.71418900014, "connections": 11.813183920319242}	2026-04-18 13:32:38.636043
65	1	IP Camera — Floor 2	16	2	{"bytes": 391076.2403305142, "connections": 11.715886287615689}	2026-04-18 13:32:38.636043
66	1	IP Camera — Floor 2	17	2	{"bytes": 516976.38633241307, "connections": 12.069874428237929}	2026-04-18 13:32:38.636043
67	1	IP Camera — Floor 2	18	2	{"bytes": 513595.58097783837, "connections": 12.865871285362797}	2026-04-18 13:32:38.636044
68	1	IP Camera — Floor 2	19	2	{"bytes": 384049.93796228064, "connections": 12.529732366464467}	2026-04-18 13:32:38.636044
69	1	IP Camera — Floor 2	20	2	{"bytes": 474530.8998185876, "connections": 12.088728792981108}	2026-04-18 13:32:38.636044
70	1	IP Camera — Floor 2	21	2	{"bytes": 418521.4006435933, "connections": 12.33830831659154}	2026-04-18 13:32:38.636045
71	1	IP Camera — Floor 2	22	2	{"bytes": 397559.5434354433, "connections": 11.843436601605852}	2026-04-18 13:32:38.636045
72	1	IP Camera — Floor 2	23	2	{"bytes": 135000.0, "connections": 11.888936895190096}	2026-04-18 13:32:38.636045
73	1	IP Camera — Floor 2	0	3	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636046
74	1	IP Camera — Floor 2	1	3	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636046
75	1	IP Camera — Floor 2	2	3	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636046
76	1	IP Camera — Floor 2	3	3	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636046
77	1	IP Camera — Floor 2	4	3	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636047
78	1	IP Camera — Floor 2	5	3	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636047
79	1	IP Camera — Floor 2	6	3	{"bytes": 511265.15021534584, "connections": 12.902047056907666}	2026-04-18 13:32:38.636047
80	1	IP Camera — Floor 2	7	3	{"bytes": 418057.52185139724, "connections": 12.001406671320716}	2026-04-18 13:32:38.636048
81	1	IP Camera — Floor 2	8	3	{"bytes": 406618.0038715677, "connections": 12.99030681442757}	2026-04-18 13:32:38.636048
82	1	IP Camera — Floor 2	9	3	{"bytes": 500020.0069279636, "connections": 11.516267499476719}	2026-04-18 13:32:38.636048
83	1	IP Camera — Floor 2	10	3	{"bytes": 468758.1818069107, "connections": 12.261528507451612}	2026-04-18 13:32:38.636049
84	1	IP Camera — Floor 2	11	3	{"bytes": 403133.3012542007, "connections": 12.630025920180362}	2026-04-18 13:32:38.636049
85	1	IP Camera — Floor 2	12	3	{"bytes": 455316.16906614945, "connections": 12.668703548713339}	2026-04-18 13:32:38.636049
86	1	IP Camera — Floor 2	13	3	{"bytes": 454097.7457463489, "connections": 10.801372550707065}	2026-04-18 13:32:38.63605
87	1	IP Camera — Floor 2	14	3	{"bytes": 426261.06769563083, "connections": 10.846744181725997}	2026-04-18 13:32:38.63605
88	1	IP Camera — Floor 2	15	3	{"bytes": 507928.31319572334, "connections": 12.908932506775642}	2026-04-18 13:32:38.63605
89	1	IP Camera — Floor 2	16	3	{"bytes": 494774.84646375926, "connections": 11.538033900966388}	2026-04-18 13:32:38.636051
90	1	IP Camera — Floor 2	17	3	{"bytes": 390319.8974767153, "connections": 12.907223038089699}	2026-04-18 13:32:38.636051
91	1	IP Camera — Floor 2	18	3	{"bytes": 510338.1751152292, "connections": 11.005568284962909}	2026-04-18 13:32:38.636051
92	1	IP Camera — Floor 2	19	3	{"bytes": 448108.7125477429, "connections": 10.96611004432412}	2026-04-18 13:32:38.636051
93	1	IP Camera — Floor 2	20	3	{"bytes": 485181.2923097263, "connections": 12.638002630336771}	2026-04-18 13:32:38.636052
94	1	IP Camera — Floor 2	21	3	{"bytes": 399832.84770746797, "connections": 11.940677707436956}	2026-04-18 13:32:38.636052
95	1	IP Camera — Floor 2	22	3	{"bytes": 456723.4851218174, "connections": 11.436135909456143}	2026-04-18 13:32:38.636052
96	1	IP Camera — Floor 2	23	3	{"bytes": 135000.0, "connections": 12.893839298604618}	2026-04-18 13:32:38.636053
97	1	IP Camera — Floor 2	0	4	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636053
98	1	IP Camera — Floor 2	1	4	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636053
99	1	IP Camera — Floor 2	2	4	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636054
100	1	IP Camera — Floor 2	3	4	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636054
101	1	IP Camera — Floor 2	4	4	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636054
102	1	IP Camera — Floor 2	5	4	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636055
103	1	IP Camera — Floor 2	6	4	{"bytes": 439623.62192711973, "connections": 11.308315693060997}	2026-04-18 13:32:38.636055
104	1	IP Camera — Floor 2	7	4	{"bytes": 455304.9719852269, "connections": 12.551834565815941}	2026-04-18 13:32:38.636055
105	1	IP Camera — Floor 2	8	4	{"bytes": 409655.39355760894, "connections": 11.548119099122147}	2026-04-18 13:32:38.636056
106	1	IP Camera — Floor 2	9	4	{"bytes": 516845.1631492208, "connections": 12.359707338334687}	2026-04-18 13:32:38.636056
107	1	IP Camera — Floor 2	10	4	{"bytes": 441643.51132845803, "connections": 12.042182018485418}	2026-04-18 13:32:38.636056
108	1	IP Camera — Floor 2	11	4	{"bytes": 398835.5664422159, "connections": 11.339273608875738}	2026-04-18 13:32:38.636057
109	1	IP Camera — Floor 2	12	4	{"bytes": 428141.5508899065, "connections": 12.211940924297359}	2026-04-18 13:32:38.636057
110	1	IP Camera — Floor 2	13	4	{"bytes": 413565.4889005379, "connections": 11.328521722683742}	2026-04-18 13:32:38.636057
111	1	IP Camera — Floor 2	14	4	{"bytes": 392084.06661121943, "connections": 12.314647097448239}	2026-04-18 13:32:38.636057
112	1	IP Camera — Floor 2	15	4	{"bytes": 413407.1408145058, "connections": 12.973008031214707}	2026-04-18 13:32:38.636058
113	1	IP Camera — Floor 2	16	4	{"bytes": 498550.77903425583, "connections": 10.970057639732769}	2026-04-18 13:32:38.636058
114	1	IP Camera — Floor 2	17	4	{"bytes": 414630.62563981436, "connections": 12.405546667911075}	2026-04-18 13:32:38.636058
115	1	IP Camera — Floor 2	18	4	{"bytes": 411421.9689950092, "connections": 11.117548436940059}	2026-04-18 13:32:38.636059
116	1	IP Camera — Floor 2	19	4	{"bytes": 508794.42247839057, "connections": 12.170503423980684}	2026-04-18 13:32:38.636059
117	1	IP Camera — Floor 2	20	4	{"bytes": 446310.5885520922, "connections": 12.683086618297807}	2026-04-18 13:32:38.636059
118	1	IP Camera — Floor 2	21	4	{"bytes": 491512.0946984968, "connections": 11.256983794468507}	2026-04-18 13:32:38.63606
119	1	IP Camera — Floor 2	22	4	{"bytes": 395585.65992089116, "connections": 11.834522837775307}	2026-04-18 13:32:38.63606
120	1	IP Camera — Floor 2	23	4	{"bytes": 135000.0, "connections": 11.816588695247809}	2026-04-18 13:32:38.63606
121	1	IP Camera — Floor 2	0	5	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636061
122	1	IP Camera — Floor 2	1	5	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636061
123	1	IP Camera — Floor 2	2	5	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636061
124	1	IP Camera — Floor 2	3	5	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636062
125	1	IP Camera — Floor 2	4	5	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636062
126	1	IP Camera — Floor 2	5	5	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636062
127	1	IP Camera — Floor 2	6	5	{"bytes": 445548.33018495113, "connections": 12.549782038703643}	2026-04-18 13:32:38.636063
128	1	IP Camera — Floor 2	7	5	{"bytes": 473404.21388459567, "connections": 13.161996507278317}	2026-04-18 13:32:38.636063
129	1	IP Camera — Floor 2	8	5	{"bytes": 395786.41260551446, "connections": 11.766291077045445}	2026-04-18 13:32:38.636065
130	1	IP Camera — Floor 2	9	5	{"bytes": 428305.85172832, "connections": 12.868014087246697}	2026-04-18 13:32:38.636066
131	1	IP Camera — Floor 2	10	5	{"bytes": 416068.60507923854, "connections": 11.256501380257948}	2026-04-18 13:32:38.636066
132	1	IP Camera — Floor 2	11	5	{"bytes": 443062.8289574728, "connections": 11.812515935602569}	2026-04-18 13:32:38.636066
133	1	IP Camera — Floor 2	12	5	{"bytes": 420103.59453003696, "connections": 11.399535474917041}	2026-04-18 13:32:38.636067
134	1	IP Camera — Floor 2	13	5	{"bytes": 507140.8559022617, "connections": 11.863513788128296}	2026-04-18 13:32:38.636067
135	1	IP Camera — Floor 2	14	5	{"bytes": 498782.12914284714, "connections": 12.120780749879636}	2026-04-18 13:32:38.636068
136	1	IP Camera — Floor 2	15	5	{"bytes": 389329.424485859, "connections": 13.198277924190542}	2026-04-18 13:32:38.636068
137	1	IP Camera — Floor 2	16	5	{"bytes": 495363.72398579353, "connections": 13.125591017483405}	2026-04-18 13:32:38.636068
138	1	IP Camera — Floor 2	17	5	{"bytes": 507559.54270609724, "connections": 12.836869762594334}	2026-04-18 13:32:38.636069
139	1	IP Camera — Floor 2	18	5	{"bytes": 404951.9999315284, "connections": 11.965538701081723}	2026-04-18 13:32:38.636069
140	1	IP Camera — Floor 2	19	5	{"bytes": 411355.88539188955, "connections": 11.762496702118687}	2026-04-18 13:32:38.636069
141	1	IP Camera — Floor 2	20	5	{"bytes": 390415.77899624413, "connections": 11.709535485544599}	2026-04-18 13:32:38.63607
142	1	IP Camera — Floor 2	21	5	{"bytes": 515516.693910263, "connections": 11.436487339613166}	2026-04-18 13:32:38.63607
143	1	IP Camera — Floor 2	22	5	{"bytes": 488349.53126305685, "connections": 11.892020081613943}	2026-04-18 13:32:38.636071
144	1	IP Camera — Floor 2	23	5	{"bytes": 135000.0, "connections": 11.815217966376391}	2026-04-18 13:32:38.636071
145	1	IP Camera — Floor 2	0	6	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636071
146	1	IP Camera — Floor 2	1	6	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636071
147	1	IP Camera — Floor 2	2	6	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636072
148	1	IP Camera — Floor 2	3	6	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636072
149	1	IP Camera — Floor 2	4	6	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636073
150	1	IP Camera — Floor 2	5	6	{"bytes": 135000.0, "connections": 2.4000000000000004}	2026-04-18 13:32:38.636073
151	1	IP Camera — Floor 2	6	6	{"bytes": 511737.8815160559, "connections": 13.189014454782512}	2026-04-18 13:32:38.636073
152	1	IP Camera — Floor 2	7	6	{"bytes": 457528.72365975846, "connections": 12.524179860711182}	2026-04-18 13:32:38.636074
153	1	IP Camera — Floor 2	8	6	{"bytes": 403397.57141199865, "connections": 11.512098781186955}	2026-04-18 13:32:38.636074
154	1	IP Camera — Floor 2	9	6	{"bytes": 513275.7642708365, "connections": 12.190032697959015}	2026-04-18 13:32:38.636074
155	1	IP Camera — Floor 2	10	6	{"bytes": 455696.352185527, "connections": 12.595141344909756}	2026-04-18 13:32:38.636075
156	1	IP Camera — Floor 2	11	6	{"bytes": 390217.3118425102, "connections": 12.202026226701532}	2026-04-18 13:32:38.636075
157	1	IP Camera — Floor 2	12	6	{"bytes": 450384.8016941343, "connections": 12.846527740915885}	2026-04-18 13:32:38.636075
158	1	IP Camera — Floor 2	13	6	{"bytes": 403753.41827183025, "connections": 13.10586936785868}	2026-04-18 13:32:38.636076
159	1	IP Camera — Floor 2	14	6	{"bytes": 393315.0478074792, "connections": 11.245979906353735}	2026-04-18 13:32:38.636076
160	1	IP Camera — Floor 2	15	6	{"bytes": 462829.73937075376, "connections": 12.420510128649816}	2026-04-18 13:32:38.636076
161	1	IP Camera — Floor 2	16	6	{"bytes": 414252.5258251257, "connections": 11.087727873473098}	2026-04-18 13:32:38.636077
162	1	IP Camera — Floor 2	17	6	{"bytes": 502688.78740747407, "connections": 11.3909168346927}	2026-04-18 13:32:38.636077
163	1	IP Camera — Floor 2	18	6	{"bytes": 462760.0857270145, "connections": 12.286515624797048}	2026-04-18 13:32:38.636077
164	1	IP Camera — Floor 2	19	6	{"bytes": 439095.3635703428, "connections": 12.200813494298938}	2026-04-18 13:32:38.636078
165	1	IP Camera — Floor 2	20	6	{"bytes": 453075.6665968144, "connections": 13.043295018567424}	2026-04-18 13:32:38.636078
166	1	IP Camera — Floor 2	21	6	{"bytes": 410074.99192217743, "connections": 12.518860321894596}	2026-04-18 13:32:38.636078
167	1	IP Camera — Floor 2	22	6	{"bytes": 414722.6036031392, "connections": 11.749886032299012}	2026-04-18 13:32:38.636078
168	1	IP Camera — Floor 2	23	6	{"bytes": 135000.0, "connections": 12.412056535103932}	2026-04-18 13:32:38.636079
169	2	PLC Controller — Production Line A	0	0	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636079
170	2	PLC Controller — Production Line A	1	0	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636079
171	2	PLC Controller — Production Line A	2	0	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.63608
172	2	PLC Controller — Production Line A	3	0	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.63608
173	2	PLC Controller — Production Line A	4	0	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.63608
390	3	MQTT Broker — IoT Hub	5	2	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636158
174	2	PLC Controller — Production Line A	5	0	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636081
175	2	PLC Controller — Production Line A	6	0	{"bytes": 11279.989487275545, "connections": 2.8897063177631126}	2026-04-18 13:32:38.636081
176	2	PLC Controller — Production Line A	7	0	{"bytes": 12906.712172691847, "connections": 2.7435258686958943}	2026-04-18 13:32:38.636081
177	2	PLC Controller — Production Line A	8	0	{"bytes": 11849.82788142691, "connections": 3.299072664512665}	2026-04-18 13:32:38.636082
178	2	PLC Controller — Production Line A	9	0	{"bytes": 13785.947212278339, "connections": 2.74395643265978}	2026-04-18 13:32:38.636082
179	2	PLC Controller — Production Line A	10	0	{"bytes": 10967.355524161347, "connections": 2.8591202488502407}	2026-04-18 13:32:38.636082
180	2	PLC Controller — Production Line A	11	0	{"bytes": 13559.733760777352, "connections": 3.2285185042118636}	2026-04-18 13:32:38.636083
181	2	PLC Controller — Production Line A	12	0	{"bytes": 13365.372872944354, "connections": 2.9217162532433303}	2026-04-18 13:32:38.636083
182	2	PLC Controller — Production Line A	13	0	{"bytes": 10767.888596486035, "connections": 3.2002469727838845}	2026-04-18 13:32:38.636083
183	2	PLC Controller — Production Line A	14	0	{"bytes": 12732.743730314536, "connections": 3.0670066594355703}	2026-04-18 13:32:38.636084
184	2	PLC Controller — Production Line A	15	0	{"bytes": 13754.039029073414, "connections": 3.092385790626439}	2026-04-18 13:32:38.636084
185	2	PLC Controller — Production Line A	16	0	{"bytes": 10228.163185747768, "connections": 3.1902624810692766}	2026-04-18 13:32:38.636084
186	2	PLC Controller — Production Line A	17	0	{"bytes": 11277.76350791992, "connections": 3.0980332289796464}	2026-04-18 13:32:38.636085
187	2	PLC Controller — Production Line A	18	0	{"bytes": 13580.148014137574, "connections": 2.780574668636021}	2026-04-18 13:32:38.636085
188	2	PLC Controller — Production Line A	19	0	{"bytes": 10615.543213508769, "connections": 2.7642215866256508}	2026-04-18 13:32:38.636085
189	2	PLC Controller — Production Line A	20	0	{"bytes": 12191.605107185336, "connections": 2.86340892738889}	2026-04-18 13:32:38.636086
190	2	PLC Controller — Production Line A	21	0	{"bytes": 12377.387377308805, "connections": 3.130567312283279}	2026-04-18 13:32:38.636086
191	2	PLC Controller — Production Line A	22	0	{"bytes": 10932.950324378831, "connections": 3.0805427753310477}	2026-04-18 13:32:38.636086
192	2	PLC Controller — Production Line A	23	0	{"bytes": 3600.0, "connections": 2.8583903409782456}	2026-04-18 13:32:38.636087
193	2	PLC Controller — Production Line A	0	1	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636087
194	2	PLC Controller — Production Line A	1	1	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636087
195	2	PLC Controller — Production Line A	2	1	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636088
196	2	PLC Controller — Production Line A	3	1	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636088
197	2	PLC Controller — Production Line A	4	1	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636088
198	2	PLC Controller — Production Line A	5	1	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636089
199	2	PLC Controller — Production Line A	6	1	{"bytes": 11958.714667737757, "connections": 3.2432018946475942}	2026-04-18 13:32:38.636089
200	2	PLC Controller — Production Line A	7	1	{"bytes": 13245.97336786148, "connections": 2.75537908062764}	2026-04-18 13:32:38.636089
201	2	PLC Controller — Production Line A	8	1	{"bytes": 11724.872781229415, "connections": 2.866008134383351}	2026-04-18 13:32:38.63609
202	2	PLC Controller — Production Line A	9	1	{"bytes": 10212.764480716016, "connections": 3.162671533811776}	2026-04-18 13:32:38.63609
203	2	PLC Controller — Production Line A	10	1	{"bytes": 12493.608158284966, "connections": 2.857173157460609}	2026-04-18 13:32:38.63609
204	2	PLC Controller — Production Line A	11	1	{"bytes": 12868.43127005255, "connections": 3.031008252675835}	2026-04-18 13:32:38.63609
205	2	PLC Controller — Production Line A	12	1	{"bytes": 11739.672908330445, "connections": 2.7058018197650036}	2026-04-18 13:32:38.636091
206	2	PLC Controller — Production Line A	13	1	{"bytes": 10470.877896265562, "connections": 3.229863835980086}	2026-04-18 13:32:38.636091
207	2	PLC Controller — Production Line A	14	1	{"bytes": 13454.142857615614, "connections": 3.027354173523314}	2026-04-18 13:32:38.636091
208	2	PLC Controller — Production Line A	15	1	{"bytes": 13204.542071589662, "connections": 3.0495057398938767}	2026-04-18 13:32:38.636092
209	2	PLC Controller — Production Line A	16	1	{"bytes": 10733.137628042938, "connections": 2.7764673115692835}	2026-04-18 13:32:38.636092
210	2	PLC Controller — Production Line A	17	1	{"bytes": 11309.730059748481, "connections": 3.239388893245554}	2026-04-18 13:32:38.636092
211	2	PLC Controller — Production Line A	18	1	{"bytes": 13066.04029759695, "connections": 3.2164215492005415}	2026-04-18 13:32:38.636093
212	2	PLC Controller — Production Line A	19	1	{"bytes": 13436.128691495307, "connections": 2.8260459230038526}	2026-04-18 13:32:38.636093
213	2	PLC Controller — Production Line A	20	1	{"bytes": 11098.307061202528, "connections": 2.7616761730030714}	2026-04-18 13:32:38.636095
214	2	PLC Controller — Production Line A	21	1	{"bytes": 13008.418470737193, "connections": 3.2304808208706053}	2026-04-18 13:32:38.636095
215	2	PLC Controller — Production Line A	22	1	{"bytes": 11662.95860339562, "connections": 3.0723969060904275}	2026-04-18 13:32:38.636096
216	2	PLC Controller — Production Line A	23	1	{"bytes": 3600.0, "connections": 2.7927320029993226}	2026-04-18 13:32:38.636096
217	2	PLC Controller — Production Line A	0	2	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636096
218	2	PLC Controller — Production Line A	1	2	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636097
219	2	PLC Controller — Production Line A	2	2	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636097
220	2	PLC Controller — Production Line A	3	2	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636097
221	2	PLC Controller — Production Line A	4	2	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636098
222	2	PLC Controller — Production Line A	5	2	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636098
223	2	PLC Controller — Production Line A	6	2	{"bytes": 13547.571656497228, "connections": 3.2187634177319784}	2026-04-18 13:32:38.636098
224	2	PLC Controller — Production Line A	7	2	{"bytes": 13714.341718551466, "connections": 3.186463031964238}	2026-04-18 13:32:38.636099
225	2	PLC Controller — Production Line A	8	2	{"bytes": 13373.098336787967, "connections": 2.7148718171389135}	2026-04-18 13:32:38.636099
226	2	PLC Controller — Production Line A	9	2	{"bytes": 12851.632098318296, "connections": 2.8993112807678574}	2026-04-18 13:32:38.636099
227	2	PLC Controller — Production Line A	10	2	{"bytes": 13550.937189773973, "connections": 3.1813410833622835}	2026-04-18 13:32:38.636099
228	2	PLC Controller — Production Line A	11	2	{"bytes": 13310.630502151005, "connections": 3.1864495899446332}	2026-04-18 13:32:38.6361
229	2	PLC Controller — Production Line A	12	2	{"bytes": 11160.500554540098, "connections": 3.1724247054812826}	2026-04-18 13:32:38.6361
230	2	PLC Controller — Production Line A	13	2	{"bytes": 10589.144255050645, "connections": 3.2233000697436536}	2026-04-18 13:32:38.6361
231	2	PLC Controller — Production Line A	14	2	{"bytes": 13290.935704816013, "connections": 2.8334602305273986}	2026-04-18 13:32:38.636101
232	2	PLC Controller — Production Line A	15	2	{"bytes": 13139.711780148944, "connections": 2.9761819408073653}	2026-04-18 13:32:38.636101
233	2	PLC Controller — Production Line A	16	2	{"bytes": 11298.687122418962, "connections": 3.177207299491717}	2026-04-18 13:32:38.636101
234	2	PLC Controller — Production Line A	17	2	{"bytes": 11019.343754667974, "connections": 2.714198660820871}	2026-04-18 13:32:38.636102
235	2	PLC Controller — Production Line A	18	2	{"bytes": 10895.267237979751, "connections": 2.8969571707186237}	2026-04-18 13:32:38.636102
236	2	PLC Controller — Production Line A	19	2	{"bytes": 13311.67059130903, "connections": 3.280133462429017}	2026-04-18 13:32:38.636102
237	2	PLC Controller — Production Line A	20	2	{"bytes": 11204.849973798737, "connections": 3.0848890431645763}	2026-04-18 13:32:38.636103
238	2	PLC Controller — Production Line A	21	2	{"bytes": 11638.842183696219, "connections": 3.288689812318956}	2026-04-18 13:32:38.636103
239	2	PLC Controller — Production Line A	22	2	{"bytes": 12130.376636923398, "connections": 3.263542284194829}	2026-04-18 13:32:38.636103
240	2	PLC Controller — Production Line A	23	2	{"bytes": 3600.0, "connections": 2.7692050511108564}	2026-04-18 13:32:38.636104
241	2	PLC Controller — Production Line A	0	3	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636104
242	2	PLC Controller — Production Line A	1	3	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636104
243	2	PLC Controller — Production Line A	2	3	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636105
244	2	PLC Controller — Production Line A	3	3	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636105
245	2	PLC Controller — Production Line A	4	3	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636105
246	2	PLC Controller — Production Line A	5	3	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636105
247	2	PLC Controller — Production Line A	6	3	{"bytes": 13693.442199680021, "connections": 2.8071406897034783}	2026-04-18 13:32:38.636106
248	2	PLC Controller — Production Line A	7	3	{"bytes": 13665.123536741597, "connections": 2.859279817513781}	2026-04-18 13:32:38.636106
249	2	PLC Controller — Production Line A	8	3	{"bytes": 10590.24916997296, "connections": 2.9607382551387866}	2026-04-18 13:32:38.636107
250	2	PLC Controller — Production Line A	9	3	{"bytes": 12822.762218349735, "connections": 2.888206388516995}	2026-04-18 13:32:38.636107
251	2	PLC Controller — Production Line A	10	3	{"bytes": 12382.351871902114, "connections": 3.0068538358016865}	2026-04-18 13:32:38.636107
252	2	PLC Controller — Production Line A	11	3	{"bytes": 11586.703560041018, "connections": 3.0459528260979596}	2026-04-18 13:32:38.636107
253	2	PLC Controller — Production Line A	12	3	{"bytes": 11117.001022098895, "connections": 3.1252711703005023}	2026-04-18 13:32:38.636108
254	2	PLC Controller — Production Line A	13	3	{"bytes": 10206.088601587066, "connections": 3.2553450992994497}	2026-04-18 13:32:38.636108
255	2	PLC Controller — Production Line A	14	3	{"bytes": 12138.427189534052, "connections": 3.131657999486907}	2026-04-18 13:32:38.636108
256	2	PLC Controller — Production Line A	15	3	{"bytes": 12871.020280222116, "connections": 3.1023771026597995}	2026-04-18 13:32:38.636109
257	2	PLC Controller — Production Line A	16	3	{"bytes": 11511.197298412551, "connections": 2.7419842866757858}	2026-04-18 13:32:38.636109
258	2	PLC Controller — Production Line A	17	3	{"bytes": 12591.255665680581, "connections": 2.898120021625558}	2026-04-18 13:32:38.636109
259	2	PLC Controller — Production Line A	18	3	{"bytes": 11330.096322210095, "connections": 3.208809167703801}	2026-04-18 13:32:38.63611
260	2	PLC Controller — Production Line A	19	3	{"bytes": 12791.11534685022, "connections": 2.8801933609267585}	2026-04-18 13:32:38.63611
261	2	PLC Controller — Production Line A	20	3	{"bytes": 11313.424783951152, "connections": 2.94503574517153}	2026-04-18 13:32:38.63611
262	2	PLC Controller — Production Line A	21	3	{"bytes": 11648.641393407808, "connections": 2.877393121515568}	2026-04-18 13:32:38.636111
263	2	PLC Controller — Production Line A	22	3	{"bytes": 10658.236076612951, "connections": 2.952267800263745}	2026-04-18 13:32:38.636111
264	2	PLC Controller — Production Line A	23	3	{"bytes": 3600.0, "connections": 3.2642182024381095}	2026-04-18 13:32:38.636111
265	2	PLC Controller — Production Line A	0	4	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636111
266	2	PLC Controller — Production Line A	1	4	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636112
267	2	PLC Controller — Production Line A	2	4	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636112
268	2	PLC Controller — Production Line A	3	4	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636112
269	2	PLC Controller — Production Line A	4	4	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636113
270	2	PLC Controller — Production Line A	5	4	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636113
271	2	PLC Controller — Production Line A	6	4	{"bytes": 12638.344602981839, "connections": 3.24168332743955}	2026-04-18 13:32:38.636113
272	2	PLC Controller — Production Line A	7	4	{"bytes": 12415.85369742497, "connections": 2.8805699247393393}	2026-04-18 13:32:38.636114
273	2	PLC Controller — Production Line A	8	4	{"bytes": 12172.573967288514, "connections": 2.7002435638183724}	2026-04-18 13:32:38.636114
274	2	PLC Controller — Production Line A	9	4	{"bytes": 11232.889380728138, "connections": 2.957932889993901}	2026-04-18 13:32:38.636114
275	2	PLC Controller — Production Line A	10	4	{"bytes": 12287.945212304454, "connections": 3.092823374221843}	2026-04-18 13:32:38.636115
276	2	PLC Controller — Production Line A	11	4	{"bytes": 11873.957484889252, "connections": 2.965295879582884}	2026-04-18 13:32:38.636115
277	2	PLC Controller — Production Line A	12	4	{"bytes": 10969.32504356076, "connections": 2.9839117115455958}	2026-04-18 13:32:38.636115
278	2	PLC Controller — Production Line A	13	4	{"bytes": 13444.250972981716, "connections": 3.1776148560760684}	2026-04-18 13:32:38.636116
279	2	PLC Controller — Production Line A	14	4	{"bytes": 10810.889026312996, "connections": 2.750877322035073}	2026-04-18 13:32:38.636116
280	2	PLC Controller — Production Line A	15	4	{"bytes": 12055.62723569478, "connections": 3.079764513459477}	2026-04-18 13:32:38.636116
281	2	PLC Controller — Production Line A	16	4	{"bytes": 11406.677719475283, "connections": 3.191054078721999}	2026-04-18 13:32:38.636116
282	2	PLC Controller — Production Line A	17	4	{"bytes": 12904.097295146637, "connections": 3.1036774023343}	2026-04-18 13:32:38.636117
283	2	PLC Controller — Production Line A	18	4	{"bytes": 11008.706397590238, "connections": 2.819477959635946}	2026-04-18 13:32:38.636117
284	2	PLC Controller — Production Line A	19	4	{"bytes": 10287.931395816575, "connections": 2.84690552644701}	2026-04-18 13:32:38.636117
285	2	PLC Controller — Production Line A	20	4	{"bytes": 11910.4908391877, "connections": 3.2098426167748393}	2026-04-18 13:32:38.636118
286	2	PLC Controller — Production Line A	21	4	{"bytes": 10462.181625064448, "connections": 2.9486646065986317}	2026-04-18 13:32:38.636118
287	2	PLC Controller — Production Line A	22	4	{"bytes": 12467.155370655768, "connections": 2.8166611420438254}	2026-04-18 13:32:38.636118
288	2	PLC Controller — Production Line A	23	4	{"bytes": 3600.0, "connections": 3.117812550294303}	2026-04-18 13:32:38.636119
289	2	PLC Controller — Production Line A	0	5	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636119
290	2	PLC Controller — Production Line A	1	5	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636119
291	2	PLC Controller — Production Line A	2	5	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.63612
292	2	PLC Controller — Production Line A	3	5	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.63612
293	2	PLC Controller — Production Line A	4	5	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.63612
294	2	PLC Controller — Production Line A	5	5	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636121
295	2	PLC Controller — Production Line A	6	5	{"bytes": 11979.757808437573, "connections": 2.846390663747063}	2026-04-18 13:32:38.636121
296	2	PLC Controller — Production Line A	7	5	{"bytes": 12561.80884000242, "connections": 2.703326890882819}	2026-04-18 13:32:38.636121
297	2	PLC Controller — Production Line A	8	5	{"bytes": 12903.472115826502, "connections": 3.1620277131444148}	2026-04-18 13:32:38.636122
298	2	PLC Controller — Production Line A	9	5	{"bytes": 10583.71426762874, "connections": 2.9550877163656404}	2026-04-18 13:32:38.636125
299	2	PLC Controller — Production Line A	10	5	{"bytes": 10833.192054143514, "connections": 3.2747796253677235}	2026-04-18 13:32:38.636125
300	2	PLC Controller — Production Line A	11	5	{"bytes": 12064.647901597467, "connections": 2.7301310310843845}	2026-04-18 13:32:38.636126
301	2	PLC Controller — Production Line A	12	5	{"bytes": 11097.113806775897, "connections": 3.2090018084109957}	2026-04-18 13:32:38.636126
302	2	PLC Controller — Production Line A	13	5	{"bytes": 11843.262571692621, "connections": 3.1808499610333585}	2026-04-18 13:32:38.636126
303	2	PLC Controller — Production Line A	14	5	{"bytes": 12603.279837310873, "connections": 3.2927354718398685}	2026-04-18 13:32:38.636127
304	2	PLC Controller — Production Line A	15	5	{"bytes": 12343.628346489912, "connections": 3.2700237650658934}	2026-04-18 13:32:38.636127
305	2	PLC Controller — Production Line A	16	5	{"bytes": 13409.133332917574, "connections": 3.0675913936570574}	2026-04-18 13:32:38.636127
306	2	PLC Controller — Production Line A	17	5	{"bytes": 12789.386260593481, "connections": 3.002866898894641}	2026-04-18 13:32:38.636128
307	2	PLC Controller — Production Line A	18	5	{"bytes": 13190.049010997094, "connections": 3.028723170366497}	2026-04-18 13:32:38.636128
308	2	PLC Controller — Production Line A	19	5	{"bytes": 13429.949171639742, "connections": 3.146193265295751}	2026-04-18 13:32:38.636128
309	2	PLC Controller — Production Line A	20	5	{"bytes": 11908.827972562993, "connections": 2.8555149290790114}	2026-04-18 13:32:38.636129
310	2	PLC Controller — Production Line A	21	5	{"bytes": 11090.063055034774, "connections": 3.082596862065694}	2026-04-18 13:32:38.636129
311	2	PLC Controller — Production Line A	22	5	{"bytes": 12956.929263469796, "connections": 3.012779887696789}	2026-04-18 13:32:38.636129
312	2	PLC Controller — Production Line A	23	5	{"bytes": 3600.0, "connections": 3.0760490621890693}	2026-04-18 13:32:38.63613
313	2	PLC Controller — Production Line A	0	6	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.63613
314	2	PLC Controller — Production Line A	1	6	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.63613
315	2	PLC Controller — Production Line A	2	6	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636131
316	2	PLC Controller — Production Line A	3	6	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636131
317	2	PLC Controller — Production Line A	4	6	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636131
318	2	PLC Controller — Production Line A	5	6	{"bytes": 3600.0, "connections": 0.6000000000000001}	2026-04-18 13:32:38.636132
319	2	PLC Controller — Production Line A	6	6	{"bytes": 11188.550808903137, "connections": 2.7464900123188416}	2026-04-18 13:32:38.636132
320	2	PLC Controller — Production Line A	7	6	{"bytes": 11228.621343107348, "connections": 2.863029064249311}	2026-04-18 13:32:38.636132
321	2	PLC Controller — Production Line A	8	6	{"bytes": 11350.954446307544, "connections": 3.024091333511074}	2026-04-18 13:32:38.636133
322	2	PLC Controller — Production Line A	9	6	{"bytes": 10698.146621458161, "connections": 2.838756887836912}	2026-04-18 13:32:38.636133
323	2	PLC Controller — Production Line A	10	6	{"bytes": 12698.219324276588, "connections": 3.123851485016732}	2026-04-18 13:32:38.636133
324	2	PLC Controller — Production Line A	11	6	{"bytes": 10431.223862569961, "connections": 2.944559621799952}	2026-04-18 13:32:38.636134
325	2	PLC Controller — Production Line A	12	6	{"bytes": 12153.400105814097, "connections": 2.9494645404618933}	2026-04-18 13:32:38.636134
326	2	PLC Controller — Production Line A	13	6	{"bytes": 10944.603802251877, "connections": 2.9520861106640552}	2026-04-18 13:32:38.636134
327	2	PLC Controller — Production Line A	14	6	{"bytes": 13457.418522024638, "connections": 3.0504476485225354}	2026-04-18 13:32:38.636134
328	2	PLC Controller — Production Line A	15	6	{"bytes": 12703.882751392686, "connections": 3.214039219382361}	2026-04-18 13:32:38.636135
329	2	PLC Controller — Production Line A	16	6	{"bytes": 12956.140474025051, "connections": 2.928228617356627}	2026-04-18 13:32:38.636135
330	2	PLC Controller — Production Line A	17	6	{"bytes": 10221.225900902375, "connections": 2.911055281603095}	2026-04-18 13:32:38.636135
331	2	PLC Controller — Production Line A	18	6	{"bytes": 12912.51045021379, "connections": 3.212068770341463}	2026-04-18 13:32:38.636136
332	2	PLC Controller — Production Line A	19	6	{"bytes": 13632.349218492382, "connections": 2.9514127695778933}	2026-04-18 13:32:38.636136
333	2	PLC Controller — Production Line A	20	6	{"bytes": 12891.056408320985, "connections": 3.0276793858403037}	2026-04-18 13:32:38.636136
334	2	PLC Controller — Production Line A	21	6	{"bytes": 12371.709320188469, "connections": 2.832323216594291}	2026-04-18 13:32:38.636137
335	2	PLC Controller — Production Line A	22	6	{"bytes": 10989.91788463717, "connections": 2.961501585627982}	2026-04-18 13:32:38.636137
336	2	PLC Controller — Production Line A	23	6	{"bytes": 3600.0, "connections": 2.717414891968029}	2026-04-18 13:32:38.636137
337	3	MQTT Broker — IoT Hub	0	0	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636138
338	3	MQTT Broker — IoT Hub	1	0	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636138
339	3	MQTT Broker — IoT Hub	2	0	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636138
340	3	MQTT Broker — IoT Hub	3	0	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636139
341	3	MQTT Broker — IoT Hub	4	0	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636139
342	3	MQTT Broker — IoT Hub	5	0	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636139
343	3	MQTT Broker — IoT Hub	6	0	{"bytes": 846246.5881674681, "connections": 150.19511466582216}	2026-04-18 13:32:38.63614
344	3	MQTT Broker — IoT Hub	7	0	{"bytes": 864452.5506597491, "connections": 135.28629720490176}	2026-04-18 13:32:38.63614
345	3	MQTT Broker — IoT Hub	8	0	{"bytes": 881293.1698450268, "connections": 134.20120612115366}	2026-04-18 13:32:38.63614
346	3	MQTT Broker — IoT Hub	9	0	{"bytes": 922642.6085800752, "connections": 131.282027105249}	2026-04-18 13:32:38.636141
347	3	MQTT Broker — IoT Hub	10	0	{"bytes": 861703.4084427011, "connections": 146.86736750771846}	2026-04-18 13:32:38.636141
348	3	MQTT Broker — IoT Hub	11	0	{"bytes": 763736.2463728634, "connections": 149.13973979227075}	2026-04-18 13:32:38.636141
349	3	MQTT Broker — IoT Hub	12	0	{"bytes": 792731.7630905607, "connections": 143.88925487749384}	2026-04-18 13:32:38.636142
350	3	MQTT Broker — IoT Hub	13	0	{"bytes": 769925.9971414636, "connections": 141.49401206145606}	2026-04-18 13:32:38.636142
351	3	MQTT Broker — IoT Hub	14	0	{"bytes": 813013.2958844656, "connections": 139.97852834155793}	2026-04-18 13:32:38.636142
352	3	MQTT Broker — IoT Hub	15	0	{"bytes": 959748.3320077052, "connections": 141.49466025135996}	2026-04-18 13:32:38.636143
353	3	MQTT Broker — IoT Hub	16	0	{"bytes": 957286.6228891276, "connections": 154.6258042695029}	2026-04-18 13:32:38.636143
354	3	MQTT Broker — IoT Hub	17	0	{"bytes": 823856.4989858955, "connections": 132.87528075008763}	2026-04-18 13:32:38.636143
355	3	MQTT Broker — IoT Hub	18	0	{"bytes": 761675.3376423528, "connections": 146.14315238975345}	2026-04-18 13:32:38.636144
356	3	MQTT Broker — IoT Hub	19	0	{"bytes": 1023475.3902119588, "connections": 140.64884996788533}	2026-04-18 13:32:38.636144
357	3	MQTT Broker — IoT Hub	20	0	{"bytes": 930088.4728977166, "connections": 153.15575843871596}	2026-04-18 13:32:38.636144
358	3	MQTT Broker — IoT Hub	21	0	{"bytes": 930518.4929501186, "connections": 152.37276291772628}	2026-04-18 13:32:38.636145
359	3	MQTT Broker — IoT Hub	22	0	{"bytes": 1010046.332635169, "connections": 136.28145978851344}	2026-04-18 13:32:38.636145
360	3	MQTT Broker — IoT Hub	23	0	{"bytes": 267000.0, "connections": 131.09102050228964}	2026-04-18 13:32:38.636145
361	3	MQTT Broker — IoT Hub	0	1	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636146
362	3	MQTT Broker — IoT Hub	1	1	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636146
363	3	MQTT Broker — IoT Hub	2	1	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636146
364	3	MQTT Broker — IoT Hub	3	1	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636146
365	3	MQTT Broker — IoT Hub	4	1	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636147
366	3	MQTT Broker — IoT Hub	5	1	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636147
367	3	MQTT Broker — IoT Hub	6	1	{"bytes": 797186.086324539, "connections": 134.16040827135197}	2026-04-18 13:32:38.636147
368	3	MQTT Broker — IoT Hub	7	1	{"bytes": 935245.5115135161, "connections": 146.85511787597056}	2026-04-18 13:32:38.636148
369	3	MQTT Broker — IoT Hub	8	1	{"bytes": 814696.5324220365, "connections": 150.78448416613836}	2026-04-18 13:32:38.636148
370	3	MQTT Broker — IoT Hub	9	1	{"bytes": 961261.7922611163, "connections": 135.36588515766627}	2026-04-18 13:32:38.636148
371	3	MQTT Broker — IoT Hub	10	1	{"bytes": 918635.0808688788, "connections": 152.18984390670326}	2026-04-18 13:32:38.636149
372	3	MQTT Broker — IoT Hub	11	1	{"bytes": 787080.2766581656, "connections": 154.25973405502148}	2026-04-18 13:32:38.636149
373	3	MQTT Broker — IoT Hub	12	1	{"bytes": 1014080.4464001014, "connections": 133.63486374007059}	2026-04-18 13:32:38.636149
374	3	MQTT Broker — IoT Hub	13	1	{"bytes": 763356.1396078235, "connections": 139.54676008744616}	2026-04-18 13:32:38.63615
375	3	MQTT Broker — IoT Hub	14	1	{"bytes": 937351.7255890592, "connections": 158.28701230797097}	2026-04-18 13:32:38.63615
376	3	MQTT Broker — IoT Hub	15	1	{"bytes": 862406.7358849394, "connections": 151.2354264464346}	2026-04-18 13:32:38.63615
377	3	MQTT Broker — IoT Hub	16	1	{"bytes": 776791.059584097, "connections": 150.52781806205644}	2026-04-18 13:32:38.636151
378	3	MQTT Broker — IoT Hub	17	1	{"bytes": 923973.7196254788, "connections": 133.45513785793332}	2026-04-18 13:32:38.636151
379	3	MQTT Broker — IoT Hub	18	1	{"bytes": 962752.3962819768, "connections": 155.15850393357508}	2026-04-18 13:32:38.636151
380	3	MQTT Broker — IoT Hub	19	1	{"bytes": 916809.9011560974, "connections": 134.01059688695213}	2026-04-18 13:32:38.636152
381	3	MQTT Broker — IoT Hub	20	1	{"bytes": 1019186.4418544172, "connections": 153.19642504446958}	2026-04-18 13:32:38.636152
382	3	MQTT Broker — IoT Hub	21	1	{"bytes": 849203.4053373559, "connections": 142.92296238380757}	2026-04-18 13:32:38.636152
383	3	MQTT Broker — IoT Hub	22	1	{"bytes": 855442.423950221, "connections": 145.17286290063524}	2026-04-18 13:32:38.636156
384	3	MQTT Broker — IoT Hub	23	1	{"bytes": 267000.0, "connections": 140.39570407097722}	2026-04-18 13:32:38.636156
385	3	MQTT Broker — IoT Hub	0	2	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636157
386	3	MQTT Broker — IoT Hub	1	2	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636157
387	3	MQTT Broker — IoT Hub	2	2	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636157
388	3	MQTT Broker — IoT Hub	3	2	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636158
391	3	MQTT Broker — IoT Hub	6	2	{"bytes": 983336.6924088871, "connections": 154.34759662461167}	2026-04-18 13:32:38.636159
392	3	MQTT Broker — IoT Hub	7	2	{"bytes": 784678.8784619475, "connections": 158.36283944922278}	2026-04-18 13:32:38.636159
393	3	MQTT Broker — IoT Hub	8	2	{"bytes": 926201.223329086, "connections": 154.5325120190713}	2026-04-18 13:32:38.636159
394	3	MQTT Broker — IoT Hub	9	2	{"bytes": 945351.4078695225, "connections": 143.12912720522263}	2026-04-18 13:32:38.63616
395	3	MQTT Broker — IoT Hub	10	2	{"bytes": 952423.3461715756, "connections": 158.49873820590426}	2026-04-18 13:32:38.63616
396	3	MQTT Broker — IoT Hub	11	2	{"bytes": 828611.9998354361, "connections": 153.93777734539592}	2026-04-18 13:32:38.636161
397	3	MQTT Broker — IoT Hub	12	2	{"bytes": 900192.1660216843, "connections": 144.52142761261268}	2026-04-18 13:32:38.636161
398	3	MQTT Broker — IoT Hub	13	2	{"bytes": 872798.3896320398, "connections": 151.69976021484854}	2026-04-18 13:32:38.636161
399	3	MQTT Broker — IoT Hub	14	2	{"bytes": 828161.6086591431, "connections": 155.1996816405606}	2026-04-18 13:32:38.636162
400	3	MQTT Broker — IoT Hub	15	2	{"bytes": 978305.1820437912, "connections": 133.01322404361457}	2026-04-18 13:32:38.636162
401	3	MQTT Broker — IoT Hub	16	2	{"bytes": 991895.5261287402, "connections": 137.57203973653773}	2026-04-18 13:32:38.636162
402	3	MQTT Broker — IoT Hub	17	2	{"bytes": 880577.1605830629, "connections": 148.1996194226851}	2026-04-18 13:32:38.636163
403	3	MQTT Broker — IoT Hub	18	2	{"bytes": 857690.1442022464, "connections": 131.3322999353326}	2026-04-18 13:32:38.636163
404	3	MQTT Broker — IoT Hub	19	2	{"bytes": 983704.4072954266, "connections": 135.77335585757305}	2026-04-18 13:32:38.636164
405	3	MQTT Broker — IoT Hub	20	2	{"bytes": 813135.9999979903, "connections": 153.6371383480148}	2026-04-18 13:32:38.636164
406	3	MQTT Broker — IoT Hub	21	2	{"bytes": 847370.4711248637, "connections": 156.02927941298856}	2026-04-18 13:32:38.636164
407	3	MQTT Broker — IoT Hub	22	2	{"bytes": 943716.0613386979, "connections": 138.51178869692936}	2026-04-18 13:32:38.636165
408	3	MQTT Broker — IoT Hub	23	2	{"bytes": 267000.0, "connections": 130.79438231872163}	2026-04-18 13:32:38.636165
409	3	MQTT Broker — IoT Hub	0	3	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636166
410	3	MQTT Broker — IoT Hub	1	3	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636166
411	3	MQTT Broker — IoT Hub	2	3	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636166
412	3	MQTT Broker — IoT Hub	3	3	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636167
413	3	MQTT Broker — IoT Hub	4	3	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636167
414	3	MQTT Broker — IoT Hub	5	3	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636167
415	3	MQTT Broker — IoT Hub	6	3	{"bytes": 1009632.7082664672, "connections": 132.9827758967826}	2026-04-18 13:32:38.636168
416	3	MQTT Broker — IoT Hub	7	3	{"bytes": 948759.9353158199, "connections": 144.66875755861483}	2026-04-18 13:32:38.636168
417	3	MQTT Broker — IoT Hub	8	3	{"bytes": 958929.9624798186, "connections": 150.52767084394918}	2026-04-18 13:32:38.636168
418	3	MQTT Broker — IoT Hub	9	3	{"bytes": 928956.0742308343, "connections": 144.733818717279}	2026-04-18 13:32:38.636169
419	3	MQTT Broker — IoT Hub	10	3	{"bytes": 968213.0757913288, "connections": 133.1985471660855}	2026-04-18 13:32:38.636169
420	3	MQTT Broker — IoT Hub	11	3	{"bytes": 815666.2389261655, "connections": 150.56182750356086}	2026-04-18 13:32:38.63617
421	3	MQTT Broker — IoT Hub	12	3	{"bytes": 838257.0100447335, "connections": 147.36511197463864}	2026-04-18 13:32:38.63617
422	3	MQTT Broker — IoT Hub	13	3	{"bytes": 882860.5504987931, "connections": 145.89673600322726}	2026-04-18 13:32:38.636171
423	3	MQTT Broker — IoT Hub	14	3	{"bytes": 870109.5179922924, "connections": 152.13212766469465}	2026-04-18 13:32:38.636171
424	3	MQTT Broker — IoT Hub	15	3	{"bytes": 844821.2763513133, "connections": 150.8827933233873}	2026-04-18 13:32:38.636171
425	3	MQTT Broker — IoT Hub	16	3	{"bytes": 828834.6860026445, "connections": 137.7907066098273}	2026-04-18 13:32:38.636172
426	3	MQTT Broker — IoT Hub	17	3	{"bytes": 788715.1212288656, "connections": 136.084944510094}	2026-04-18 13:32:38.636172
427	3	MQTT Broker — IoT Hub	18	3	{"bytes": 788421.115915099, "connections": 146.04005499612876}	2026-04-18 13:32:38.636172
428	3	MQTT Broker — IoT Hub	19	3	{"bytes": 960004.6257322555, "connections": 135.8693454306922}	2026-04-18 13:32:38.636173
429	3	MQTT Broker — IoT Hub	20	3	{"bytes": 814274.6988475878, "connections": 144.54175902916856}	2026-04-18 13:32:38.636173
430	3	MQTT Broker — IoT Hub	21	3	{"bytes": 949964.1952918448, "connections": 158.82160366360864}	2026-04-18 13:32:38.636173
431	3	MQTT Broker — IoT Hub	22	3	{"bytes": 896578.0440519984, "connections": 138.7069623949737}	2026-04-18 13:32:38.636174
432	3	MQTT Broker — IoT Hub	23	3	{"bytes": 267000.0, "connections": 133.41525713463292}	2026-04-18 13:32:38.636174
433	3	MQTT Broker — IoT Hub	0	4	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636174
434	3	MQTT Broker — IoT Hub	1	4	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636175
435	3	MQTT Broker — IoT Hub	2	4	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636175
436	3	MQTT Broker — IoT Hub	3	4	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636175
437	3	MQTT Broker — IoT Hub	4	4	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636176
438	3	MQTT Broker — IoT Hub	5	4	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636176
439	3	MQTT Broker — IoT Hub	6	4	{"bytes": 808329.3933503166, "connections": 137.09701174099408}	2026-04-18 13:32:38.636176
440	3	MQTT Broker — IoT Hub	7	4	{"bytes": 804410.8921640028, "connections": 130.91030265042585}	2026-04-18 13:32:38.636177
441	3	MQTT Broker — IoT Hub	8	4	{"bytes": 899114.068834466, "connections": 138.45502847671474}	2026-04-18 13:32:38.636177
442	3	MQTT Broker — IoT Hub	9	4	{"bytes": 1016636.7466044311, "connections": 146.54741003715964}	2026-04-18 13:32:38.636177
443	3	MQTT Broker — IoT Hub	10	4	{"bytes": 942710.4439070219, "connections": 134.16210529579385}	2026-04-18 13:32:38.636178
444	3	MQTT Broker — IoT Hub	11	4	{"bytes": 988379.139669206, "connections": 144.73548214118958}	2026-04-18 13:32:38.636178
445	3	MQTT Broker — IoT Hub	12	4	{"bytes": 989516.1692446087, "connections": 147.14786236916362}	2026-04-18 13:32:38.636178
446	3	MQTT Broker — IoT Hub	13	4	{"bytes": 881828.9842964462, "connections": 143.27359514594428}	2026-04-18 13:32:38.636179
447	3	MQTT Broker — IoT Hub	14	4	{"bytes": 805725.0999941519, "connections": 131.98992479832376}	2026-04-18 13:32:38.636179
448	3	MQTT Broker — IoT Hub	15	4	{"bytes": 1007763.9803370836, "connections": 144.35414643070493}	2026-04-18 13:32:38.63618
449	3	MQTT Broker — IoT Hub	16	4	{"bytes": 976004.8772949479, "connections": 142.12051582530626}	2026-04-18 13:32:38.63618
450	3	MQTT Broker — IoT Hub	17	4	{"bytes": 776279.9394582559, "connections": 148.75392550160794}	2026-04-18 13:32:38.63618
451	3	MQTT Broker — IoT Hub	18	4	{"bytes": 770813.6228361063, "connections": 134.826729949736}	2026-04-18 13:32:38.63618
452	3	MQTT Broker — IoT Hub	19	4	{"bytes": 906778.1724215787, "connections": 139.3112298434246}	2026-04-18 13:32:38.636181
453	3	MQTT Broker — IoT Hub	20	4	{"bytes": 1021876.1387636288, "connections": 133.93509530413237}	2026-04-18 13:32:38.636181
454	3	MQTT Broker — IoT Hub	21	4	{"bytes": 960606.3999020939, "connections": 148.08321188604592}	2026-04-18 13:32:38.636182
455	3	MQTT Broker — IoT Hub	22	4	{"bytes": 967627.801568193, "connections": 137.044926974886}	2026-04-18 13:32:38.636182
456	3	MQTT Broker — IoT Hub	23	4	{"bytes": 267000.0, "connections": 145.6546035187763}	2026-04-18 13:32:38.636182
457	3	MQTT Broker — IoT Hub	0	5	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636182
458	3	MQTT Broker — IoT Hub	1	5	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636183
459	3	MQTT Broker — IoT Hub	2	5	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636183
460	3	MQTT Broker — IoT Hub	3	5	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636184
461	3	MQTT Broker — IoT Hub	4	5	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636184
462	3	MQTT Broker — IoT Hub	5	5	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636184
463	3	MQTT Broker — IoT Hub	6	5	{"bytes": 876787.3621252973, "connections": 143.33890911656053}	2026-04-18 13:32:38.636185
464	3	MQTT Broker — IoT Hub	7	5	{"bytes": 986164.4997755901, "connections": 159.21090655353714}	2026-04-18 13:32:38.636185
465	3	MQTT Broker — IoT Hub	8	5	{"bytes": 838036.5252332692, "connections": 148.50979231109233}	2026-04-18 13:32:38.636185
466	3	MQTT Broker — IoT Hub	9	5	{"bytes": 919271.4535694498, "connections": 151.96258985905183}	2026-04-18 13:32:38.636186
467	3	MQTT Broker — IoT Hub	10	5	{"bytes": 1009506.5834868759, "connections": 136.52584926888298}	2026-04-18 13:32:38.636186
468	3	MQTT Broker — IoT Hub	11	5	{"bytes": 812843.72714654, "connections": 149.65241597856908}	2026-04-18 13:32:38.636186
469	3	MQTT Broker — IoT Hub	12	5	{"bytes": 798434.2439326942, "connections": 135.5405929014666}	2026-04-18 13:32:38.636193
470	3	MQTT Broker — IoT Hub	13	5	{"bytes": 776542.3199966118, "connections": 130.57759595548367}	2026-04-18 13:32:38.636194
471	3	MQTT Broker — IoT Hub	14	5	{"bytes": 876784.4891329266, "connections": 147.72052465846733}	2026-04-18 13:32:38.636194
472	3	MQTT Broker — IoT Hub	15	5	{"bytes": 834266.2301712844, "connections": 137.21281080212475}	2026-04-18 13:32:38.636195
473	3	MQTT Broker — IoT Hub	16	5	{"bytes": 945257.206577702, "connections": 150.88663918471778}	2026-04-18 13:32:38.636195
474	3	MQTT Broker — IoT Hub	17	5	{"bytes": 877726.3641506805, "connections": 150.43416268206605}	2026-04-18 13:32:38.636195
475	3	MQTT Broker — IoT Hub	18	5	{"bytes": 1003184.2488768405, "connections": 153.34701277275522}	2026-04-18 13:32:38.636196
476	3	MQTT Broker — IoT Hub	19	5	{"bytes": 923390.4879128473, "connections": 149.67430824274766}	2026-04-18 13:32:38.636196
477	3	MQTT Broker — IoT Hub	20	5	{"bytes": 1005789.478404952, "connections": 142.82903001702215}	2026-04-18 13:32:38.636196
478	3	MQTT Broker — IoT Hub	21	5	{"bytes": 901898.1551157247, "connections": 149.28140697867195}	2026-04-18 13:32:38.636197
479	3	MQTT Broker — IoT Hub	22	5	{"bytes": 999045.8558717659, "connections": 154.47230362985172}	2026-04-18 13:32:38.636197
480	3	MQTT Broker — IoT Hub	23	5	{"bytes": 267000.0, "connections": 132.5708852688186}	2026-04-18 13:32:38.636198
481	3	MQTT Broker — IoT Hub	0	6	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636198
482	3	MQTT Broker — IoT Hub	1	6	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636198
483	3	MQTT Broker — IoT Hub	2	6	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636199
484	3	MQTT Broker — IoT Hub	3	6	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636199
485	3	MQTT Broker — IoT Hub	4	6	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.636199
486	3	MQTT Broker — IoT Hub	5	6	{"bytes": 267000.0, "connections": 29.0}	2026-04-18 13:32:38.6362
487	3	MQTT Broker — IoT Hub	6	6	{"bytes": 800801.3847219335, "connections": 139.42074256581273}	2026-04-18 13:32:38.6362
488	3	MQTT Broker — IoT Hub	7	6	{"bytes": 956471.7117925894, "connections": 147.00700443025366}	2026-04-18 13:32:38.6362
489	3	MQTT Broker — IoT Hub	8	6	{"bytes": 833559.0270776597, "connections": 134.10625608706653}	2026-04-18 13:32:38.636201
490	3	MQTT Broker — IoT Hub	9	6	{"bytes": 940377.0236536291, "connections": 150.7922768642958}	2026-04-18 13:32:38.636201
491	3	MQTT Broker — IoT Hub	10	6	{"bytes": 1008194.5562786588, "connections": 145.01369313641982}	2026-04-18 13:32:38.636201
492	3	MQTT Broker — IoT Hub	11	6	{"bytes": 888343.3235651376, "connections": 132.83281370507973}	2026-04-18 13:32:38.636201
493	3	MQTT Broker — IoT Hub	12	6	{"bytes": 767142.8293770247, "connections": 143.0288312606624}	2026-04-18 13:32:38.636202
494	3	MQTT Broker — IoT Hub	13	6	{"bytes": 842559.8627566661, "connections": 137.7606691699481}	2026-04-18 13:32:38.636202
495	3	MQTT Broker — IoT Hub	14	6	{"bytes": 780884.2787304731, "connections": 158.39542196359227}	2026-04-18 13:32:38.636202
496	3	MQTT Broker — IoT Hub	15	6	{"bytes": 979700.9499129504, "connections": 147.18077416737796}	2026-04-18 13:32:38.636203
497	3	MQTT Broker — IoT Hub	16	6	{"bytes": 1010359.936174296, "connections": 159.4876000894461}	2026-04-18 13:32:38.636203
498	3	MQTT Broker — IoT Hub	17	6	{"bytes": 935999.1830089649, "connections": 138.31581975304456}	2026-04-18 13:32:38.636203
499	3	MQTT Broker — IoT Hub	18	6	{"bytes": 767241.8567296125, "connections": 152.43179608196417}	2026-04-18 13:32:38.636204
500	3	MQTT Broker — IoT Hub	19	6	{"bytes": 882123.7198081862, "connections": 149.39377519357691}	2026-04-18 13:32:38.636204
501	3	MQTT Broker — IoT Hub	20	6	{"bytes": 1001091.4343764469, "connections": 135.76318526947065}	2026-04-18 13:32:38.636204
502	3	MQTT Broker — IoT Hub	21	6	{"bytes": 912783.0099491872, "connections": 148.9087568641685}	2026-04-18 13:32:38.636205
503	3	MQTT Broker — IoT Hub	22	6	{"bytes": 887790.7891850006, "connections": 133.146029782521}	2026-04-18 13:32:38.636205
504	3	MQTT Broker — IoT Hub	23	6	{"bytes": 267000.0, "connections": 140.59087063254486}	2026-04-18 13:32:38.636206
\.


--
-- Data for Name: ca_assessments; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ca_assessments (id, framework_id, score, passed, failed, partial, triggered_by, created_at) FROM stdin;
1	1	45	7	7	2	automated	2026-03-21 12:51:32.054058
2	1	52	8	6	2	automated	2026-03-28 12:51:32.054058
3	1	58	9	5	2	automated	2026-04-04 13:51:32.054058
4	1	63	10	4	2	automated	2026-04-11 13:51:32.054058
5	1	67	10	4	2	automated	2026-04-18 13:51:32.054058
6	2	55	9	7	2	automated	2026-03-21 12:51:32.054058
7	2	60	10	6	2	automated	2026-03-28 12:51:32.054058
8	2	65	11	5	2	automated	2026-04-04 13:51:32.054058
9	2	70	12	4	2	automated	2026-04-11 13:51:32.054058
10	2	72	12	4	2	automated	2026-04-18 13:51:32.054058
11	3	60	9	5	2	automated	2026-03-21 12:51:32.054058
12	3	65	10	4	2	automated	2026-03-28 12:51:32.054058
13	3	70	11	3	2	automated	2026-04-04 13:51:32.054058
14	3	75	12	2	2	automated	2026-04-11 13:51:32.054058
15	3	78	12	2	2	automated	2026-04-18 13:51:32.054058
16	4	65	11	5	2	automated	2026-03-21 12:51:32.054058
17	4	70	12	4	2	automated	2026-03-28 12:51:32.054058
18	4	75	13	3	2	automated	2026-04-04 13:51:32.054058
19	4	78	14	2	2	automated	2026-04-11 13:51:32.054058
20	4	81	14	2	2	automated	2026-04-18 13:51:32.054058
21	1	53	2	1	13	manual	2026-04-18 14:02:08.776068
22	2	52	1	0	17	manual	2026-04-18 14:03:13.66688
23	3	65	5	0	11	manual	2026-04-22 00:00:55.725948
24	1	53	2	1	13	manual	2026-04-22 00:01:05.04584
25	3	65	5	0	11	manual	2026-04-22 00:01:09.536023
\.


--
-- Data for Name: ca_controls; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ca_controls (id, framework_id, control_id, title, description, category, status, evidence, gap, remediation, severity, automated, last_tested) FROM stdin;
17	2	A.5.1	Policies for Information Security	\N	Governance	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
18	2	A.5.2	Information Security Roles	\N	Governance	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
19	2	A.6.1	Screening	\N	HR	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
20	2	A.6.3	Information Security Awareness Training	\N	HR	partial	Security awareness training records not available in AIPET	Training completion records not integrated	\N	Medium	t	2026-04-18 14:03:13.66623
21	2	A.7.1	Physical Security Perimeters	\N	Physical	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
22	2	A.8.1	User Endpoint Devices	\N	Assets	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
23	2	A.8.2	Privileged Access Rights	\N	Access	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	High	t	2026-04-18 14:03:13.66623
24	2	A.8.3	Information Access Restriction	\N	Access	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
25	2	A.8.4	Access to Source Code	\N	Development	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
26	2	A.8.5	Secure Authentication	\N	Access	partial	MFA not enforced on all privileged accounts (Identity Graph finding)	3 privileged accounts lack MFA enforcement	\N	Medium	t	2026-04-18 14:03:13.66623
27	2	A.8.6	Capacity Management	\N	Operations	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
28	2	A.8.7	Protection Against Malware	\N	Protection	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
29	2	A.8.8	Management of Technical Vulnerabilities	\N	Vulnerability	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	High	t	2026-04-18 14:03:13.66623
30	2	A.8.12	Data Leakage Prevention	\N	Data	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
35	3	CC1.1	Control Environment — Integrity & Ethics	\N	Common	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:09.535434
36	3	CC2.1	Communication and Information	\N	Common	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:09.535434
37	3	CC3.1	Risk Assessment Process	\N	Common	pass	Risk assessment performed via AIPET X automated scanning	\N	\N	Medium	t	2026-04-22 00:01:09.535434
38	3	CC4.1	Monitoring Controls	\N	Common	pass	AIPET SIEM active with 5 events monitored	\N	\N	Medium	t	2026-04-22 00:01:09.535434
39	3	CC5.1	Control Activities — Policies	\N	Common	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:09.535434
40	3	CC6.1	Logical and Physical Access Controls	\N	Access	partial	MFA not enforced on all privileged accounts (Identity Graph finding)	3 privileged accounts lack MFA enforcement	\N	Medium	t	2026-04-22 00:01:09.535434
41	3	CC6.2	Prior to Issuing System Credentials	\N	Access	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:09.535434
42	3	CC6.3	Role-Based Access Control	\N	Access	partial	MFA not enforced on all privileged accounts (Identity Graph finding)	3 privileged accounts lack MFA enforcement	\N	Medium	t	2026-04-22 00:01:09.535434
43	3	CC6.6	Logical Access — External Threats	\N	Access	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:09.535434
44	3	CC7.1	System Operations — Detection	\N	Monitoring	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:09.535434
45	3	CC7.2	Monitoring for Indicators of Compromise	\N	Monitoring	pass	AIPET SIEM active with 5 events monitored	\N	\N	Medium	t	2026-04-22 00:01:09.535434
46	3	CC7.3	Evaluation of Security Events	\N	Monitoring	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:09.535434
47	3	CC7.4	Incident Response	\N	Response	partial	Incident response plan exists in AIPET X — manual procedures not documented	Formal IR procedures not yet documented outside platform	\N	Medium	t	2026-04-22 00:01:09.535434
51	4	ID.AM-1	Asset Inventory	\N	Identify	pass	All IoT assets inventoried via AIPET	\N	\N	Medium	t	2026-04-18 08:51:32.054058
52	4	ID.AM-2	Software Inventory	\N	Identify	pass	Software inventory maintained	\N	\N	Medium	t	2026-04-18 08:51:32.054058
53	4	ID.GV-1	Organisational Cybersecurity Policy	\N	Identify	pass	Security policies in place	\N	\N	Medium	t	2026-04-18 08:51:32.054058
54	4	ID.RA-1	Asset Vulnerabilities Identified	\N	Identify	pass	Continuous vulnerability scanning active	\N	\N	Medium	t	2026-04-18 08:51:32.054058
55	4	ID.RA-3	Threats Identified	\N	Identify	pass	Threat intelligence feeds active	\N	\N	Medium	t	2026-04-18 08:51:32.054058
56	4	PR.AC-1	Identities and Credentials Managed	\N	Protect	partial	Identity management active — ghost accounts detected	Ghost accounts require remediation	\N	Medium	t	2026-04-18 08:51:32.054058
57	4	PR.AC-3	Remote Access Managed	\N	Protect	pass	Remote access controlled via Zero-Trust	\N	\N	Medium	t	2026-04-18 08:51:32.054058
58	4	PR.DS-1	Data-at-Rest Protected	\N	Protect	partial	Some data stores not encrypted at rest	IoT data encryption at rest incomplete	\N	Medium	t	2026-04-18 08:51:32.054058
59	4	PR.DS-2	Data-in-Transit Protected	\N	Protect	partial	7 unencrypted OT connections detected	OT protocols transmitting without encryption	\N	Medium	t	2026-04-18 08:51:32.054058
60	4	PR.IP-1	Baseline Configuration	\N	Protect	pass	Device baselines established via Behavioral AI	\N	\N	Medium	t	2026-04-18 08:51:32.054058
61	4	DE.AE-1	Baseline of Network Operations	\N	Detect	pass	Network baselines established — anomalies detected	\N	\N	Medium	t	2026-04-18 08:51:32.054058
62	4	DE.CM-1	Network Monitored	\N	Detect	pass	Full network monitoring via AIPET SIEM	\N	\N	Medium	t	2026-04-18 08:51:32.054058
63	4	DE.CM-7	Unauthorised Personnel Monitored	\N	Detect	pass	Identity Graph monitoring all access	\N	\N	Medium	t	2026-04-18 08:51:32.054058
64	4	RS.RP-1	Response Plan Executed	\N	Respond	partial	Response plans in AIPET — not formally tested	IR plan testing required	\N	Medium	t	2026-04-18 08:51:32.054058
65	4	RS.CO-2	Incidents Reported	\N	Respond	fail	No formal incident reporting to authorities	Regulatory reporting process required	\N	High	t	2026-04-18 08:51:32.054058
66	4	RC.RP-1	Recovery Plan Executed	\N	Recover	partial	Recovery procedures not formally documented	DR plan documentation incomplete	\N	Medium	t	2026-04-18 08:51:32.054058
67	4	RC.IM-1	Recovery Plan Incorporates Lessons	\N	Recover	pass	Post-mortem reports generated by AIPET X	\N	\N	Medium	t	2026-04-18 08:51:32.054058
68	4	RC.CO-1	Reputation Restored	\N	Recover	pass	Communication procedures in place	\N	\N	Medium	t	2026-04-18 08:51:32.054058
31	2	A.8.16	Monitoring Activities	\N	Monitoring	pass	AIPET SIEM active with 5 events monitored	\N	\N	Medium	t	2026-04-18 14:03:13.66623
32	2	A.8.20	Networks Security	\N	Network	partial	Network segmentation detected — Zero-Trust policies active	OT/IT segmentation requires strengthening	\N	Medium	t	2026-04-18 14:03:13.66623
33	2	A.8.23	Web Filtering	\N	Network	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
34	2	A.8.28	Secure Coding	\N	Development	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-18 14:03:13.66623
1	1	NIS2-1	Risk Management Policy	\N	Governance	pass	Risk assessment performed via AIPET X automated scanning	\N	\N	Medium	t	2026-04-22 00:01:05.045219
2	1	NIS2-2	Incident Handling Procedures	\N	Response	partial	Incident response plan exists in AIPET X — manual procedures not documented	Formal IR procedures not yet documented outside platform	\N	Medium	t	2026-04-22 00:01:05.045219
3	1	NIS2-3	Business Continuity Management	\N	Resilience	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:05.045219
4	1	NIS2-4	Supply Chain Security	\N	Supply Chain	partial	SBOM analysis pending — third-party components not fully inventoried	Supply chain security assessment incomplete	\N	Medium	t	2026-04-22 00:01:05.045219
49	3	CC9.1	Risk Mitigation	\N	Risk	pass	Risk assessment performed via AIPET X automated scanning	\N	\N	Medium	t	2026-04-22 00:01:09.535434
50	3	CC9.2	Vendor Risk Management	\N	Supply Chain	pass	Risk assessment performed via AIPET X automated scanning	\N	\N	High	t	2026-04-22 00:01:09.535434
5	1	NIS2-5	Network Security Controls	\N	Network	partial	Network segmentation detected — Zero-Trust policies active	OT/IT segmentation requires strengthening	\N	Medium	t	2026-04-22 00:01:05.045219
6	1	NIS2-6	Vulnerability Handling	\N	Vulnerability	fail	3 critical vulnerabilities unpatched	Critical CVEs require immediate remediation	\N	High	t	2026-04-22 00:01:05.045219
7	1	NIS2-7	Cryptography and Encryption	\N	Cryptography	partial	Encryption checks: 5 unencrypted services found	Some services transmitting data without encryption	\N	Medium	t	2026-04-22 00:01:05.045219
8	1	NIS2-8	Human Resources Security	\N	HR	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:05.045219
9	1	NIS2-9	Access Control Policy	\N	Access	partial	MFA not enforced on all privileged accounts (Identity Graph finding)	3 privileged accounts lack MFA enforcement	\N	Medium	t	2026-04-22 00:01:05.045219
10	1	NIS2-10	Asset Management	\N	Assets	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:05.045219
11	1	NIS2-11	Physical Security	\N	Physical	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:05.045219
12	1	NIS2-12	Security Monitoring and Logging	\N	Monitoring	pass	AIPET SIEM active with 5 events monitored	\N	\N	Medium	t	2026-04-22 00:01:05.045219
13	1	NIS2-13	Security Testing	\N	Testing	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:05.045219
14	1	NIS2-14	Multi-factor Authentication	\N	Access	partial	MFA not enforced on all privileged accounts (Identity Graph finding)	3 privileged accounts lack MFA enforcement	\N	High	t	2026-04-22 00:01:05.045219
15	1	NIS2-15	Secure Communication	\N	Network	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:05.045219
16	1	NIS2-16	Incident Reporting to Authorities	\N	Governance	partial	Incident response plan exists in AIPET X — manual procedures not documented	Formal IR procedures not yet documented outside platform	\N	High	t	2026-04-22 00:01:05.045219
48	3	CC8.1	Change Management	\N	Change	partial	Automated assessment based on 5 findings	Manual verification recommended	\N	Medium	t	2026-04-22 00:01:09.535434
\.


--
-- Data for Name: ca_frameworks; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ca_frameworks (id, name, version, description, total_controls, passed, failed, partial, score, last_assessed, created_at) FROM stdin;
4	NIST CSF	2.0	NIST Cybersecurity Framework — identify, protect, detect, respond, recover	18	13	1	4	81	2026-04-18 08:51:32.054058	2026-04-18 13:51:32.061931
2	ISO 27001	2022	International standard for information security management systems	18	1	0	17	52	2026-04-18 14:03:13.66623	2026-04-18 13:51:32.061929
1	NIS2 Directive	2022/2555	EU Network and Information Security Directive 2 — mandatory for operators of essential services	16	2	1	13	53	2026-04-22 00:01:05.045219	2026-04-18 13:51:32.061923
3	SOC 2 Type II	2017	Service Organization Control 2 — security, availability, confidentiality	16	5	0	11	65	2026-04-22 00:01:09.535434	2026-04-18 13:51:32.061931
\.


--
-- Data for Name: cloud_accounts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_accounts (id, name, provider, account_id, region, status, asset_count, finding_count, last_scan, created_by, created_at) FROM stdin;
2	Azure NHS IoT Platform	azure	a1b2c3d4-e5f6-7890-abcd-ef1234567890	uksouth	connected	5	3	2026-04-16 19:54:02.215596	\N	2026-04-16 19:54:02.186342
3	GCP Analytics Platform	gcp	aipet-analytics-prod	europe-west2	connected	4	2	2026-04-16 19:54:02.223421	\N	2026-04-16 19:54:02.186343
4	On-Premise Data Centre	onprem	dc-london-01	London DC	connected	3	2	2026-04-16 19:54:02.233074	\N	2026-04-16 19:54:02.186344
1	AWS Production — EU West	aws	123456789012	eu-west-2	connected	6	3	2026-04-16 19:57:50.488421	\N	2026-04-16 19:54:02.186336
\.


--
-- Data for Name: cloud_assets; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_assets (id, account_id, asset_id, name, asset_type, provider, region, ip_address, tags, risk_score, public, encrypted, created_at) FROM stdin;
7	2	azure-iot_hub-001	Azure IoT Hub Production	iot_hub	azure	uksouth	\N	\N	53	t	t	2026-04-16 19:54:02.208377
8	2	azure-vm-002	IoT Edge Gateway VM	vm	azure	uksouth	\N	\N	53	t	t	2026-04-16 19:54:02.208383
9	2	azure-storage-003	Blob IoT Firmware Store	storage	azure	uksouth	\N	\N	43	f	f	2026-04-16 19:54:02.208383
10	2	azure-function-004	Azure IoT Function App	function	azure	uksouth	\N	\N	23	f	t	2026-04-16 19:54:02.208384
11	2	azure-kubernetes-005	AKS IoT Processing Cluster	kubernetes	azure	uksouth	\N	\N	23	f	t	2026-04-16 19:54:02.208384
12	3	gcp-iot_hub-001	Cloud IoT Core	iot_hub	gcp	europe-west2	\N	\N	53	t	t	2026-04-16 19:54:02.220034
13	3	gcp-storage-002	GCS IoT Certs Backup	storage	gcp	europe-west2	\N	\N	53	t	t	2026-04-16 19:54:02.22004
14	3	gcp-vm-003	IoT Gateway GCE Instance	vm	gcp	europe-west2	\N	\N	53	t	t	2026-04-16 19:54:02.220041
15	3	gcp-function-004	Cloud Functions IoT	function	gcp	europe-west2	\N	\N	23	f	t	2026-04-16 19:54:02.220041
16	4	onprem-vm-001	VMware IoT Management	vm	onprem	London DC	\N	\N	23	f	t	2026-04-16 19:54:02.230544
17	4	onprem-storage-002	NAS IoT Logs	storage	onprem	London DC	\N	\N	43	f	f	2026-04-16 19:54:02.230549
18	4	onprem-network-003	IoT VLAN Gateway	network	onprem	London DC	\N	\N	23	f	t	2026-04-16 19:54:02.230549
19	1	aws-vm-001	IoT Management Server	vm	aws	eu-west-2	\N	\N	68	t	t	2026-04-16 19:57:50.48561
20	1	aws-iot_hub-002	AWS IoT Core	iot_hub	aws	eu-west-2	\N	\N	68	t	t	2026-04-16 19:57:50.485615
21	1	aws-storage-003	S3 IoT Config Bucket	storage	aws	eu-west-2	\N	\N	88	t	f	2026-04-16 19:57:50.485616
22	1	aws-database-004	IoT Telemetry RDS	database	aws	eu-west-2	\N	\N	58	f	f	2026-04-16 19:57:50.485616
23	1	aws-function-005	IoT Lambda Processor	function	aws	eu-west-2	\N	\N	38	f	t	2026-04-16 19:57:50.485617
24	1	aws-container-006	ECS IoT Gateway	container	aws	eu-west-2	\N	\N	38	f	t	2026-04-16 19:57:50.485617
\.


--
-- Data for Name: cloud_dashboard_snapshots; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_dashboard_snapshots (id, user_id, overall_score, aws_score, azure_score, gcp_score, total_resources, exposed_resources, critical_findings, high_findings, medium_findings, compliance_score, trend_data, created_at, node_meta) FROM stdin;
6ee8549e-a5fd-4272-ad6b-02237b0389bc	1	78.3	90.5	88.1	56.2	489	35	17	29	26	55.3	[{"date": "2026-04-16", "score": 79.3, "critical": 0}, {"date": "2026-04-17", "score": 73.1, "critical": 4}, {"date": "2026-04-18", "score": 66.4, "critical": 5}, {"date": "2026-04-19", "score": 63.8, "critical": 1}, {"date": "2026-04-20", "score": 60.1, "critical": 5}, {"date": "2026-04-21", "score": 60.5, "critical": 1}, {"date": "2026-04-22", "score": 66.3, "critical": 3}]	2026-04-22 18:01:41.601816	{}
e95238b2-92bb-4962-b6e3-d44af38bb547	1	78.7	66.8	79.3	90	746	26	3	28	34	56.2	[{"date": "2026-04-16", "score": 79.4, "critical": 5}, {"date": "2026-04-17", "score": 85.9, "critical": 5}, {"date": "2026-04-18", "score": 87.4, "critical": 0}, {"date": "2026-04-19", "score": 92.7, "critical": 4}, {"date": "2026-04-20", "score": 88.4, "critical": 3}, {"date": "2026-04-21", "score": 95.9, "critical": 0}, {"date": "2026-04-22", "score": 100, "critical": 3}]	2026-04-22 18:01:53.333048	{}
b93f482b-7a75-4a09-8d83-59a5fad23347	1	64.8	60.9	92.5	40.9	319	32	3	6	22	86.4	[{"date": "2026-04-16", "score": 65.1, "critical": 4}, {"date": "2026-04-17", "score": 63.9, "critical": 0}, {"date": "2026-04-18", "score": 63.3, "critical": 5}, {"date": "2026-04-19", "score": 70.0, "critical": 2}, {"date": "2026-04-20", "score": 66.5, "critical": 0}, {"date": "2026-04-21", "score": 70.8, "critical": 4}, {"date": "2026-04-22", "score": 78.0, "critical": 0}]	2026-04-22 18:01:54.607886	{}
2b0b6925-7649-4065-865b-433080820349	1	59	50.2	82.4	44.3	265	15	10	21	29	59.9	[{"date": "2026-04-16", "score": 59.0, "critical": 2}, {"date": "2026-04-17", "score": 63.0, "critical": 1}, {"date": "2026-04-18", "score": 62.6, "critical": 3}, {"date": "2026-04-19", "score": 63.2, "critical": 0}, {"date": "2026-04-20", "score": 63.3, "critical": 5}, {"date": "2026-04-21", "score": 58.1, "critical": 2}, {"date": "2026-04-22", "score": 54.8, "critical": 1}]	2026-04-22 18:01:55.901535	{}
82ab1f05-fb4b-4164-9a4b-65ebdc362a05	1	67.6	68.9	63.7	70.3	650	75	10	28	22	90.2	[{"date": "2026-04-16", "score": 71.3, "critical": 5}, {"date": "2026-04-17", "score": 71.2, "critical": 2}, {"date": "2026-04-18", "score": 67.3, "critical": 0}, {"date": "2026-04-19", "score": 65.4, "critical": 0}, {"date": "2026-04-20", "score": 71.8, "critical": 2}, {"date": "2026-04-21", "score": 67.0, "critical": 0}, {"date": "2026-04-22", "score": 63.1, "critical": 4}]	2026-04-22 18:01:57.33873	{}
10622d61-f24e-4c7c-b7bd-4dd0798088ab	1	73.4	83.4	71.9	65	836	115	2	18	24	88.4	[{"date": "2026-04-16", "score": 80.8, "critical": 3}, {"date": "2026-04-17", "score": 83.4, "critical": 2}, {"date": "2026-04-18", "score": 91.1, "critical": 5}, {"date": "2026-04-19", "score": 89.0, "critical": 4}, {"date": "2026-04-20", "score": 91.7, "critical": 4}, {"date": "2026-04-21", "score": 84.2, "critical": 5}, {"date": "2026-04-22", "score": 89.1, "critical": 5}]	2026-04-22 18:02:01.296731	{}
e04eaadc-b699-41d9-b06d-a05c52351f47	1	73.1	89.8	72.3	57.3	122	13	18	23	49	61.1	[{"date": "2026-04-16", "score": 74.0, "critical": 1}, {"date": "2026-04-17", "score": 81.2, "critical": 2}, {"date": "2026-04-18", "score": 77.4, "critical": 4}, {"date": "2026-04-19", "score": 84.9, "critical": 1}, {"date": "2026-04-20", "score": 80.0, "critical": 2}, {"date": "2026-04-21", "score": 84.1, "critical": 3}, {"date": "2026-04-22", "score": 80.6, "critical": 3}]	2026-04-22 18:02:02.817641	{}
7e952c0e-cfd7-47bc-b090-5e85c77fb75c	1	44.8	44.8	44.4	45.1	439	39	4	35	17	83.2	[{"date": "2026-04-16", "score": 48.6, "critical": 4}, {"date": "2026-04-17", "score": 54.6, "critical": 3}, {"date": "2026-04-18", "score": 55.8, "critical": 4}, {"date": "2026-04-19", "score": 62.2, "critical": 2}, {"date": "2026-04-20", "score": 55.3, "critical": 2}, {"date": "2026-04-21", "score": 54.2, "critical": 0}, {"date": "2026-04-22", "score": 52.6, "critical": 3}]	2026-04-22 18:07:34.674338	{}
3b17a286-5fa5-47a7-aa0a-3e7857d202db	1	75.8	85.3	83.7	58.3	803	89	18	11	42	66.1	[{"date": "2026-04-16", "score": 81.6, "critical": 5}, {"date": "2026-04-17", "score": 84.4, "critical": 5}, {"date": "2026-04-18", "score": 83.0, "critical": 5}, {"date": "2026-04-19", "score": 75.8, "critical": 1}, {"date": "2026-04-20", "score": 75.6, "critical": 4}, {"date": "2026-04-21", "score": 78.5, "critical": 1}, {"date": "2026-04-22", "score": 83.7, "critical": 4}]	2026-04-22 18:23:00.391649	{}
\.


--
-- Data for Name: cloud_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_findings (id, account_id, asset_id, provider, finding_type, severity, title, description, resource, remediation, mitre_id, created_at) FROM stdin;
5	2	\N	azure	iot_hub_exposed	Critical	Azure IoT Hub management API publicly accessible	The Azure IoT Hub service endpoint is accessible from the internet without IP restrictions. Device registration and management APIs are exposed.	iot-hub-production.azure-devices.net	Configure IoT Hub IP filter rules. Use Private Endpoint for IoT Hub. Restrict management API to VNet only.	T1190	2026-04-16 19:54:02.221502
6	2	\N	azure	unencrypted_storage	High	Azure Blob Storage container with HTTP access enabled	A storage container allows HTTP (unencrypted) access. IoT device firmware and configuration files can be intercepted in transit.	storageaccount.blob.core.windows.net/iot-firmware	Enable 'Secure transfer required' on storage account. Disable HTTP access and enforce HTTPS only.	T1557	2026-04-16 19:54:02.221505
7	2	\N	azure	no_logging	Medium	Azure Monitor diagnostic logs not configured	Azure IoT Hub and Key Vault resources have no diagnostic logging configured. Security events, access attempts, and configuration changes are not captured.	IoT Hub + Key Vault — diagnostic settings missing	Enable diagnostic settings on all resources. Send logs to Log Analytics workspace. Configure alerts for critical events.	T1562	2026-04-16 19:54:02.221506
8	3	\N	gcp	public_storage	Critical	GCS bucket allUsers has storage.objects.get permission	A Google Cloud Storage bucket grants read access to allUsers (public internet). IoT device certificates and private keys may be exposed.	gs://iot-certs-backup	Remove allUsers and allAuthenticatedUsers from IAM. Enable uniform bucket-level access. Audit bucket contents for sensitive files.	T1530	2026-04-16 19:54:02.231831
9	3	\N	gcp	overprivileged_role	High	GCP service account has project Owner role	A service account used by IoT processing pipelines has project Owner IAM role. Compromise of this account gives full control of the entire GCP project.	iot-processor@project.iam.gserviceaccount.com	Replace Owner role with specific roles (e.g., pubsub.publisher). Apply principle of least privilege to all service accounts.	T1078.004	2026-04-16 19:54:02.231834
10	4	\N	onprem	weak_credentials	Critical	On-premise management server using default credentials	VMware vCenter server is accessible with default administrator credentials. All virtual machines hosting IoT workloads can be compromised.	vcenter.internal — admin/vmware (default)	Change all default credentials immediately. Enable vCenter SSO with AD integration. Implement privileged access workstation (PAW) policy.	T1078	2026-04-16 19:54:02.236788
11	4	\N	onprem	unencrypted_storage	High	On-premise NAS share without encryption	Network Attached Storage share containing IoT device logs and configurations is accessible over SMB without encryption. Traffic visible on internal network.	\\\\nas01\\iot-logs (SMBv1 without signing)	Disable SMBv1. Enable SMB signing and encryption. Migrate to SMBv3 with AES-128-CCM encryption.	T1557	2026-04-16 19:54:02.236794
12	1	\N	aws	public_storage	Critical	S3 bucket publicly accessible — data exposure risk	An S3 bucket has public read access enabled. Any internet user can list and download bucket contents including IoT device configurations and certificates.	s3://iot-device-configs-prod	Remove public ACL from S3 bucket. Enable S3 Block Public Access at account level. Review bucket policy for overly permissive rules.	T1530	2026-04-16 19:57:50.497602
13	1	\N	aws	open_security_group	Critical	EC2 security group allows all inbound traffic (0.0.0.0/0)	An EC2 security group has an inbound rule permitting all traffic from any IP address on all ports. IoT management server is exposed to the entire internet.	sg-0abc123def456789 (IoT Management Server)	Remove 0.0.0.0/0 inbound rules. Restrict access to specific IP ranges or VPC CIDRs only.	T1190	2026-04-16 19:57:50.497608
14	1	\N	aws	no_logging	High	AWS CloudTrail logging disabled in IoT region	CloudTrail is not enabled in the eu-west-2 region. All API calls, configuration changes, and user actions in this region are unaudited and undetectable.	CloudTrail — eu-west-2	Enable CloudTrail in all active regions. Enable log file validation. Send CloudTrail logs to CloudWatch for alerting.	T1562.008	2026-04-16 19:57:50.497609
\.


--
-- Data for Name: cloud_hardener_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_hardener_findings (id, scan_id, check_id, category, title, status, severity, description, remediation, cis_ref, auto_fix, node_meta, created_at) FROM stdin;
84360201-2cde-4791-a8f2-b7593aaa874a	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-IAM-001	Identity & Access	Root account MFA not enabled	PASS	INFO	CIS check AWS-IAM-001 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 1.5	\N	{}	2026-04-22 11:44:44.26189
3076cc6f-0dab-412b-8af1-e0440c1d2a27	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-IAM-002	Identity & Access	IAM users with console access and no MFA	FAIL	CRITICAL	CIS check AWS-IAM-002 evaluated. Misconfiguration detected.	Enforce MFA for all IAM users with console access via IAM policy.	CIS AWS 1.10	aws iam create-virtual-mfa-device	{}	2026-04-22 11:44:44.261903
17093f3a-5ba8-46c0-93dd-bfae566e7d49	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-IAM-003	Identity & Access	Overly permissive IAM policies (wildcards)	FAIL	HIGH	CIS check AWS-IAM-003 evaluated. Misconfiguration detected.	Replace wildcard IAM policies with least-privilege granular policies.	CIS AWS 1.16	aws iam create-policy --policy-document <least-privilege-policy>	{}	2026-04-22 11:44:44.261908
de06605d-592d-4e58-9e26-ca49e6906d0a	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-IAM-004	Identity & Access	Access keys not rotated in 90 days	PASS	INFO	CIS check AWS-IAM-004 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 1.14	\N	{}	2026-04-22 11:44:44.261913
83c64732-9707-43a1-889e-8d1b12e8491e	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-S3-001	Storage Security	S3 bucket publicly accessible	FAIL	CRITICAL	CIS check AWS-S3-001 evaluated. Misconfiguration detected.	Enable S3 Block Public Access at account and bucket level.	CIS AWS 2.1.5	aws s3api put-public-access-block --bucket <bucket> --public-access-block-configuration BlockPublicAcls=true	{}	2026-04-22 11:44:44.261917
169106cb-3c44-4af1-b09e-3bc2085c2cfb	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-S3-002	Storage Security	S3 bucket encryption disabled	PASS	INFO	CIS check AWS-S3-002 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 2.1.1	\N	{}	2026-04-22 11:44:44.261922
2506c1d6-d788-474f-bd08-dfb002fbcf3d	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-S3-003	Storage Security	S3 bucket versioning disabled	PASS	INFO	CIS check AWS-S3-003 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 2.1.3	\N	{}	2026-04-22 11:44:44.261925
d6e1a550-1355-44be-86f8-3e7e0dfe62c3	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-NET-001	Network Security	Security group allows 0.0.0.0/0 ingress	FAIL	CRITICAL	CIS check AWS-NET-001 evaluated. Misconfiguration detected.	Restrict security group ingress rules to specific known IP ranges only.	CIS AWS 5.2	aws ec2 revoke-security-group-ingress --group-id <sg-id> --cidr 0.0.0.0/0	{}	2026-04-22 11:44:44.261929
37fd404a-8209-4f36-9d13-4d71574bc299	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-NET-002	Network Security	VPC Flow Logs disabled	PASS	INFO	CIS check AWS-NET-002 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 3.9	\N	{}	2026-04-22 11:44:44.261932
a2b5cfef-56e6-4e38-99d7-f088b7af4c30	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-LOG-001	Logging & Monitoring	CloudTrail not enabled	PASS	INFO	CIS check AWS-LOG-001 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 3.1	\N	{}	2026-04-22 11:44:44.261936
95e43732-bab9-43bc-bc39-c83ab9f49532	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-LOG-002	Logging & Monitoring	CloudTrail log file validation disabled	PASS	INFO	CIS check AWS-LOG-002 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 3.2	\N	{}	2026-04-22 11:44:44.26194
6b900a68-a836-4bde-9a4a-b1abff226abe	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-ENC-001	Encryption	EBS volumes not encrypted	PASS	INFO	CIS check AWS-ENC-001 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 2.2.1	\N	{}	2026-04-22 11:44:44.261944
d4eeda8e-d7e7-41c7-80df-c31aaf50edfe	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-ENC-002	Encryption	RDS encryption disabled	PASS	INFO	CIS check AWS-ENC-002 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 2.3.1	\N	{}	2026-04-22 11:44:44.261948
0a0ca4b4-6bb7-4342-93ae-2d76ebdda511	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-MON-001	Monitoring & Alerting	No CloudWatch alarms for root login	PASS	INFO	CIS check AWS-MON-001 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 4.3	\N	{}	2026-04-22 11:44:44.261953
9da7ff4c-5f8e-497c-9b76-e2c4e34565d6	e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	AWS-CONFIG-001	Configuration	AWS Config not enabled	PASS	INFO	CIS check AWS-CONFIG-001 evaluated. Control appears satisfied.	Control satisfied — no action required.	CIS AWS 3.5	\N	{}	2026-04-22 11:44:44.261956
\.


--
-- Data for Name: cloud_hardener_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_hardener_scans (id, user_id, cloud_provider, environment, risk_score, severity, total_checks, passed, failed, summary, created_at, node_meta) FROM stdin;
e113bdb1-637d-4b3a-abd9-eb0bd9184b6a	1	aws	production	72	CRITICAL	15	11	4	Cloud Hardener scan complete for AWS production. Score: 72/100. 4 misconfiguration(s) detected across 15 CIS checks.	2026-04-22 11:44:44.251257	{}
\.


--
-- Data for Name: cloud_runtime_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_runtime_findings (id, scan_id, category, title, severity, description, resource, remediation, wiz_ref, node_meta, created_at) FROM stdin;
1578c8fa-c8a8-481c-b048-7338d25aff35	00defe1e-f0af-4c31-a6a0-8bcfe3956050	Container Runtime	Privileged Container Running	CRITICAL	Runtime risk detected: Privileged Container Running. Matched pattern in submitted cloud configuration.	AWS Runtime Resource	Remove --privileged flag. Use specific Linux capabilities instead. Apply seccomp and AppArmor profiles.	WIZ-CRT-001	{}	2026-04-22 17:34:34.796404
7a9bf08f-ad0f-484f-b94e-a3403a326f4f	00defe1e-f0af-4c31-a6a0-8bcfe3956050	Container Runtime	Container Running as Root	HIGH	Runtime risk detected: Container Running as Root. Matched pattern in submitted cloud configuration.	AWS Runtime Resource	Add USER directive in Dockerfile. Run containers as non-root user (UID > 1000).	WIZ-CRT-002	{}	2026-04-22 17:34:34.796414
bccfb8eb-6560-46f6-9936-bafeaf888f70	00defe1e-f0af-4c31-a6a0-8bcfe3956050	Container Runtime	No Resource Limits Set	MEDIUM	Runtime risk detected: No Resource Limits Set. Matched pattern in submitted cloud configuration.	AWS Runtime Resource	Set CPU and memory requests and limits on all containers to prevent resource exhaustion.	WIZ-CRT-004	{}	2026-04-22 17:34:34.796419
cb4ade05-619f-471d-9871-b6ca06fdbe3c	00defe1e-f0af-4c31-a6a0-8bcfe3956050	Network Exposure	Exposed Database Port	CRITICAL	Runtime risk detected: Exposed Database Port. Matched pattern in submitted cloud configuration.	AWS Runtime Resource	Move database to private subnet. Block public access. Use VPC endpoints and security groups.	WIZ-NET-002	{}	2026-04-22 17:34:34.796423
7a59b791-f426-427b-822c-575865ca0baa	00defe1e-f0af-4c31-a6a0-8bcfe3956050	IAM Runtime	Long-lived Credentials in Runtime	CRITICAL	Runtime risk detected: Long-lived Credentials in Runtime. Matched pattern in submitted cloud configuration.	AWS Runtime Resource	Replace static credentials with dynamic short-lived tokens via IRSA/Workload Identity. Rotate all keys.	WIZ-IAM-002	{}	2026-04-22 17:34:34.796426
09b39994-93e3-43aa-861a-05b187dcb161	00defe1e-f0af-4c31-a6a0-8bcfe3956050	Data Exposure	Unencrypted Data in Transit	CRITICAL	Runtime risk detected: Unencrypted Data in Transit. Matched pattern in submitted cloud configuration.	AWS Runtime Resource	Enforce TLS 1.2+ on all endpoints. Redirect HTTP to HTTPS. Use HSTS headers.	WIZ-DAT-001	{}	2026-04-22 17:34:34.79643
7e3bc2cc-31e3-4b67-8c01-6f4f24ffc77c	00defe1e-f0af-4c31-a6a0-8bcfe3956050	Vulnerability	Critical CVE in Running Image	CRITICAL	Runtime risk detected: Critical CVE in Running Image. Matched pattern in submitted cloud configuration.	AWS Runtime Resource	Rebuild image with patched base. Implement image scanning in CI/CD. Enforce admission control.	WIZ-VUL-001	{}	2026-04-22 17:34:34.796433
\.


--
-- Data for Name: cloud_runtime_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_runtime_scans (id, user_id, cloud_provider, environment, risk_score, severity, total_findings, critical_count, summary, created_at, node_meta) FROM stdin;
00defe1e-f0af-4c31-a6a0-8bcfe3956050	1	aws	production	100	CRITICAL	7	5	Cloud Runtime Scan complete for AWS production. Risk: 100.0/100. 7 finding(s) — 5 critical.	2026-04-22 17:34:34.786606	{}
\.


--
-- Data for Name: code_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.code_findings (id, scan_id, engine, severity, category, title, description, file_path, line_number, recommendation, cwe_id, node_meta, created_at) FROM stdin;
b24a7edd-3af7-42cb-875c-b1d16bbb9891	2fded742-165e-4112-a34c-6cdfbda71e38	SAST	CRITICAL	Hardcoded Secrets	Hardcoded Password	Line 1: password = "supersecret123"	unnamed	1	Move credentials to environment variables.	CWE-798	{}	2026-04-22 02:03:02.285326
a0b79907-2e27-4d85-95db-bebec0556c2e	2fded742-165e-4112-a34c-6cdfbda71e38	SAST	HIGH	Code Injection	Dangerous eval()	Line 3: eval(user_data)	unnamed	3	Use ast.literal_eval() instead.	CWE-95	{}	2026-04-22 02:03:02.285339
d3454b15-d730-4ba4-9d93-41710b40c9c2	2fded742-165e-4112-a34c-6cdfbda71e38	SAST	HIGH	Command Injection	Shell Injection via os.system	Line 2: os.system("ls " + user_input)	unnamed	2	Use subprocess.run() with shell=False.	CWE-78	{}	2026-04-22 02:03:02.285345
17343a2e-0442-43e7-9766-b6bfa1cc2e4a	2fded742-165e-4112-a34c-6cdfbda71e38	SAST	HIGH	Deserialization	Insecure Deserialization	Line 4: import pickle; pickle.loads(data)	unnamed	4	Avoid pickle for untrusted data.	CWE-502	{}	2026-04-22 02:03:02.28535
ac42228a-c01e-4a61-91de-0cd698bf5ef1	2fded742-165e-4112-a34c-6cdfbda71e38	SAST	MEDIUM	Cryptography	Weak Hash Algorithm	Line 5: import hashlib; hashlib.md5(secret)	unnamed	5	Use SHA-256 or SHA-3.	CWE-327	{}	2026-04-22 02:03:02.285354
93992195-f730-4631-b32c-0c92afe6c36f	fadc02fd-7b47-4523-bb97-7e55b4f93572	SAST	CRITICAL	Hardcoded Secrets	Hardcoded Password	Line 1: password = "supersecret123"	unnamed	1	Move credentials to environment variables.	CWE-798	{}	2026-04-22 02:06:06.969332
b3b92ecb-3245-493e-b250-90383d2815b5	fadc02fd-7b47-4523-bb97-7e55b4f93572	SAST	HIGH	Code Injection	Dangerous eval()	Line 3: eval(user_data)	unnamed	3	Use ast.literal_eval() instead.	CWE-95	{}	2026-04-22 02:06:06.969343
dd873322-8955-491c-b6f1-9a484f7b6b86	fadc02fd-7b47-4523-bb97-7e55b4f93572	SAST	HIGH	Command Injection	Shell Injection via os.system	Line 2: os.system("ls " + user_input)	unnamed	2	Use subprocess.run() with shell=False.	CWE-78	{}	2026-04-22 02:06:06.969346
534e8150-d69c-4b2d-afda-72f7b59ce954	fadc02fd-7b47-4523-bb97-7e55b4f93572	SAST	HIGH	Deserialization	Insecure Deserialization	Line 4: import pickle; pickle.loads(data)	unnamed	4	Avoid pickle for untrusted data.	CWE-502	{}	2026-04-22 02:06:06.969349
5c8e6b84-ab0d-4083-8f53-c7f5600b61a1	fadc02fd-7b47-4523-bb97-7e55b4f93572	SAST	MEDIUM	Cryptography	Weak Hash Algorithm	Line 5: import hashlib; hashlib.md5(secret)	unnamed	5	Use SHA-256 or SHA-3.	CWE-327	{}	2026-04-22 02:06:06.969351
\.


--
-- Data for Name: code_sbom; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.code_sbom (id, scan_id, component, version, ecosystem, license, is_vulnerable, vuln_summary, node_meta, created_at) FROM stdin;
\.


--
-- Data for Name: code_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.code_scans (id, user_id, target_type, target_name, status, risk_score, total_findings, created_at, completed_at, node_meta) FROM stdin;
2fded742-165e-4112-a34c-6cdfbda71e38	1	snippet	unnamed	complete	62	5	2026-04-22 02:03:02.268827	2026-04-22 02:03:02.27276	{}
fadc02fd-7b47-4523-bb97-7e55b4f93572	1	snippet	unnamed	complete	62	5	2026-04-22 02:06:06.962711	2026-04-22 02:06:06.96538	{}
\.


--
-- Data for Name: compliance_assessments; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.compliance_assessments (id, user_id, framework, organisation, overall_score, passed, failed, partial, critical_gaps, status, summary, controls, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: compliance_fabric_controls; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.compliance_fabric_controls (id, report_id, control_id, title, status, severity, description, remediation, node_meta, created_at) FROM stdin;
4fb9ebc6-17b4-41e1-8f07-10082ebb4120	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-1	Risk Management Policy	PASS	CRITICAL	Control evaluated against submitted system description. Keywords matched: 3/4.	Control satisfied.	{}	2026-04-22 02:48:01.980332
1436230a-34f6-4b3f-b4d1-543e389f90b6	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-2	Incident Handling Procedures	PASS	CRITICAL	Control evaluated against submitted system description. Keywords matched: 4/5.	Control satisfied.	{}	2026-04-22 02:48:01.980344
05bb312e-8a7f-4385-8837-3c7a5e44b5f0	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-3	Business Continuity & Disaster Recovery	PARTIAL	HIGH	Control evaluated against submitted system description. Keywords matched: 3/7.	Implement and test business continuity and DR plans annually.	{}	2026-04-22 02:48:01.980351
9a3b87fc-0d70-4ea1-b5a6-c0be04755029	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-4	Supply Chain Security	PASS	HIGH	Control evaluated against submitted system description. Keywords matched: 3/5.	Control satisfied.	{}	2026-04-22 02:48:01.980356
6642e978-4eaa-4a9d-9b68-41ef424c37b7	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-5	Network Security Controls	PARTIAL	HIGH	Control evaluated against submitted system description. Keywords matched: 3/7.	Deploy network segmentation, firewalls, and intrusion detection systems.	{}	2026-04-22 02:48:01.98036
49cf0ead-a0cd-4f54-be5b-624b8af48510	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-6	Access Control & MFA	PARTIAL	CRITICAL	Control evaluated against submitted system description. Keywords matched: 3/6.	Enforce MFA for all privileged accounts and implement RBAC.	{}	2026-04-22 02:48:01.980364
d7a76648-bcd0-476f-892f-47e410b0763c	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-7	Encryption of Data	PASS	HIGH	Control evaluated against submitted system description. Keywords matched: 5/6.	Control satisfied.	{}	2026-04-22 02:48:01.980368
9939e597-214e-4cc7-a80a-f50db847515b	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-8	Vulnerability Management	PARTIAL	HIGH	Control evaluated against submitted system description. Keywords matched: 3/6.	Implement a vulnerability management programme with monthly scanning.	{}	2026-04-22 02:48:01.980372
778a06df-3e39-40a1-814c-f9d2da519a3c	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-9	Security Awareness Training	PASS	MEDIUM	Control evaluated against submitted system description. Keywords matched: 3/5.	Control satisfied.	{}	2026-04-22 02:48:01.980376
b7bedd12-a1e5-4f37-b2e9-9f8969de2985	0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	NIS2-10	Logging & Monitoring	PARTIAL	HIGH	Control evaluated against submitted system description. Keywords matched: 3/6.	Enable centralised logging and 24/7 monitoring with alerting.	{}	2026-04-22 02:48:01.98038
\.


--
-- Data for Name: compliance_fabric_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.compliance_fabric_reports (id, user_id, framework, score, status, total_controls, passed, failed, partial, summary, created_at, node_meta) FROM stdin;
0ccc4cb4-7c46-47ef-81ca-58f5ea78f1f7	1	NIS2	75	complete	10	5	0	5	NIS2 Directive assessment complete. Score: 75.0/100 (Good). 5 controls passed, 5 partial, 0 failed.	2026-04-22 02:48:01.935025	{}
\.


--
-- Data for Name: compliance_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.compliance_results (id, user_id, scan_id, framework, score, total, controls, created_at) FROM stdin;
1	1	12	nis2	100	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "pass", "impact": "low"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "pass", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "pass", "impact": "low"}]	2026-04-05 03:37:48.07048
2	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:00.935568
3	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:24.900825
4	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-05 03:45:36.414102
5	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:49.845372
6	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-05 04:30:40.252263
7	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-06 02:29:56.849636
8	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-06 02:30:04.723787
9	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-06 02:30:09.185256
10	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-06 02:30:51.437074
11	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-09 16:09:07.467959
12	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-09 16:33:08.107816
\.


--
-- Data for Name: cs_recommendations; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cs_recommendations (id, resource_id, category, priority, title, description, action, monthly_saving, security_gain, effort, status, created_at) FROM stdin;
1	4	decommission	critical	Decommission orphaned ML GPU instance — £2,340/month waste	EC2 p3.8xlarge GPU instance with no owner, last used 127 days ago. Admin IAM role attached. Security risk + 100% waste.	1. Remove admin IAM role immediately\n2. Snapshot instance\n3. Terminate instance\n4. Archive snapshot to S3 Glacier	2340	Remove admin IAM role exposure	low	open	2026-04-18 14:22:50.077761
2	2	rightsizing	critical	Rightsize patient DB + fix encryption — £625/month saving	RDS db.r5.4xlarge at 12% average CPU. Downsize to db.r5.xlarge and enable encryption simultaneously.	1. Enable RDS encryption (requires snapshot restore)\n2. Downsize to db.r5.xlarge\n3. Enable Performance Insights\n4. Set up automated backups	625	Encryption at rest for 125,000 PHI records	medium	open	2026-04-18 14:22:50.077767
3	3	storage_tier	critical	Fix S3 public access + intelligent tiering — £247/month saving	S3 bucket publicly accessible and missing encryption. 89% of objects not accessed in 90 days.	1. Remove public access block immediately\n2. Enable S3 SSE-KMS encryption\n3. Enable Intelligent Tiering\n4. Set lifecycle policy for 90-day transition	247.8	Remove public data exposure + encryption	low	open	2026-04-18 14:22:50.077768
4	1	rightsizing	high	Rightsize over-provisioned web server — £580/month saving	EC2 c5.9xlarge at 8% average CPU. Rightsize to c5.2xlarge. Also remove unused security group rules.	1. Remove overly permissive security group rules\n2. Create new c5.2xlarge from AMI\n3. Test behind load balancer\n4. Terminate old instance	580	Remove 0.0.0.0/0 inbound rules	medium	open	2026-04-18 14:22:50.077769
5	5	rightsizing	high	Rightsize SCADA VM + enable disk encryption — £228/month saving	Azure D8s_v3 SCADA VM at 15% CPU. Downsize to D4s_v3. Enable Azure Disk Encryption.	1. Enable Azure Disk Encryption\n2. Resize to D4s_v3\n3. Configure NSG to restrict OT network only	228	Disk encryption + network restriction	medium	open	2026-04-18 14:22:50.07777
6	11	decommission	high	Decommission dev database running in production — £189/month saving	Azure SQL database tagged as 'dev' running in production subscription with production data access.	1. Audit data in dev DB immediately\n2. Remove production data\n3. Move to dev subscription\n4. Reduce to dev-tier pricing	189	Remove dev environment from production	low	open	2026-04-18 14:22:50.07777
7	9	rightsizing	medium	Replace oversized NAT Gateway with VPC endpoint — £111/month saving	NAT Gateway charges for S3 and DynamoDB traffic. VPC endpoints eliminate this cost.	1. Create S3 VPC endpoint\n2. Create DynamoDB VPC endpoint\n3. Update route tables\n4. Monitor NAT Gateway data transfer	111	Eliminate internet routing for S3/DynamoDB	low	open	2026-04-18 14:22:50.077771
8	6	storage_tier	medium	Enable Azure Blob lifecycle tiering — £145/month saving	Log data in hot tier — 78% of blobs not accessed in 30 days. Move to cool/archive tiers.	1. Define lifecycle management policy\n2. Move 30+ day data to cool tier\n3. Move 90+ day data to archive tier	145.5	None — cost optimisation only	low	open	2026-04-18 14:22:50.077771
9	12	rightsizing	medium	Reduce Lambda memory allocation + fix IAM — £55/month saving	Lambda over-allocated at 3GB memory. Profiling shows 512MB sufficient. Also has overly broad IAM role.	1. Reduce Lambda memory to 512MB\n2. Restrict IAM role to minimum required permissions\n3. Enable X-Ray tracing	55	Remove excessive Lambda IAM permissions	low	open	2026-04-18 14:22:50.077772
10	10	reserved_instance	medium	Commit to GKE CUD — £566/month saving	GKE cluster running 100% of time. 1-year Committed Use Discount saves 37%.	1. Analyse 3-month usage pattern\n2. Purchase 1-year CUD for base capacity\n3. Enable cluster autoscaler for peak demand	566	None — cost optimisation only	low	open	2026-04-18 14:22:50.077772
\.


--
-- Data for Name: cs_resources; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cs_resources (id, name, resource_type, cloud_provider, region, monthly_cost, optimised_cost, waste_pct, security_score, security_issues, status, tags, created_at) FROM stdin;
1	prod-web-ec2-xl	ec2	AWS	eu-west-1	892.5	312.5	65	25	5	active	["production", "web", "over-provisioned"]	2026-04-18 14:22:50.065887
2	patient-rds-db	rds	AWS	us-east-1	1245	620	50	10	6	active	["production", "phi", "unencrypted"]	2026-04-18 14:22:50.065894
3	iot-telemetry-s3	s3	AWS	eu-west-1	342.8	95	72	40	4	active	["iot", "public", "unencrypted"]	2026-04-18 14:22:50.065896
4	orphaned-ml-gpu	ec2	AWS	us-east-1	2340	0	100	25	5	orphaned	["ml", "gpu", "orphaned", "unused"]	2026-04-18 14:22:50.069362
5	scada-azure-vm	virtual_machine	Azure	UK South	456	228	50	55	3	active	["scada", "ot", "over-provisioned"]	2026-04-18 14:22:50.07096
6	log-analytics-blob	blob_storage	Azure	UK South	234.5	89	62	85	1	active	["logs", "analytics"]	2026-04-18 14:22:50.070965
7	gcp-bigquery-prod	bigquery	GCP	europe-west2	678	420	38	85	1	active	["analytics", "production"]	2026-04-18 14:22:50.070966
8	redis-cache-cluster	elasticache	AWS	eu-west-1	189	95	50	100	0	active	["cache", "session"]	2026-04-18 14:22:50.070967
9	nat-gateway-prod	nat_gateway	AWS	eu-west-1	156	45	71	85	1	active	["network", "nat"]	2026-04-18 14:22:50.070967
10	gcp-gke-cluster	kubernetes	GCP	europe-west2	1456	890	39	70	2	active	["kubernetes", "production"]	2026-04-18 14:22:50.070968
11	azure-sql-dev	sql_database	Azure	UK South	234	45	81	70	2	dev_in_prod	["dev", "database", "running-in-prod"]	2026-04-18 14:22:50.072742
12	lambda-iot-processor	lambda	AWS	eu-west-1	89	34	62	70	2	active	["lambda", "iot", "serverless"]	2026-04-18 14:22:50.073948
\.


--
-- Data for Name: dd_baselines; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.dd_baselines (id, identity_name, identity_type, provider, environment, permissions, permission_count, drift_score, drift_count, status, last_scanned, baseline_set_at, created_at) FROM stdin;
1	aws-admin-role-prod	role	aws	production	["aws:*", "iam:*", "ec2:*", "s3:*", "rds:*"]	5	85	3	active	2026-04-22 00:15:02.519169	2026-01-19 13:54:38.195651	2026-04-19 14:54:38.19876
3	ci-cd-service-principal	service_account	azure	production	["Microsoft.Compute/virtualMachines/read", "Microsoft.Storage/storageAccounts/read", "Microsoft.Web/sites/deploy/action"]	3	60	2	active	2026-04-22 00:15:02.519169	2026-03-05 13:54:38.195651	2026-04-19 14:54:38.198766
4	john.smith@company.com	user	aws	production	["ec2:Describe*", "s3:GetObject", "cloudwatch:GetMetricData"]	3	0	2	active	2026-04-22 00:15:02.519169	2025-12-20 13:54:38.195651	2026-04-19 14:54:38.198767
5	lambda-iot-processor	role	aws	production	["iot:Publish", "iot:Subscribe", "logs:CreateLogGroup", "dynamodb:PutItem"]	4	30	1	active	2026-04-22 00:15:02.519169	2026-03-20 13:54:38.195651	2026-04-19 14:54:38.198768
6	azure-monitor-sp	service_account	azure	production	["Microsoft.Monitor/*/read", "Microsoft.Insights/*/read"]	2	0	0	active	2026-04-22 00:15:02.519169	2025-10-21 14:54:38.195651	2026-04-19 14:54:38.198768
7	gcp-storage-sa	service_account	gcp	production	["storage.objects.get", "storage.objects.list", "storage.buckets.get"]	3	0	0	active	2026-04-22 00:15:02.519169	2025-10-01 14:54:38.195651	2026-04-19 14:54:38.198769
8	developer-iam-group	role	aws	staging	["ec2:*", "s3:*", "rds:Describe*", "lambda:*", "apigateway:*"]	5	55	2	active	2026-04-22 00:15:02.519169	2026-02-03 13:54:38.195651	2026-04-19 14:54:38.198769
9	backup-service-account	service_account	aws	production	["s3:GetObject", "s3:PutObject", "rds:CreateDBSnapshot", "rds:DescribeDBSnapshots"]	4	0	2	active	2026-04-22 00:15:02.519169	2025-11-20 13:54:38.195651	2026-04-19 14:54:38.19877
10	contractor-external-01	user	azure	production	["Microsoft.Compute/virtualMachines/read"]	1	90	4	active	2026-04-22 00:15:02.519169	2026-03-20 13:54:38.195651	2026-04-19 14:54:38.19877
2	svc-scanner@aipet.io	service_account	gcp	production	["compute.instances.list", "compute.networks.list", "iam.serviceAccounts.get"]	3	0	0	active	2026-04-22 00:15:02.519169	2026-04-19 15:01:11.096792	2026-04-19 14:54:38.198765
\.


--
-- Data for Name: dd_drifts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.dd_drifts (id, baseline_id, identity_name, drift_type, severity, title, description, old_value, new_value, remediation, regulation, status, detected_at, resolved_at) FROM stdin;
1	1	aws-admin-role-prod	wildcard_permission	Critical	Wildcard aws:* permission added to production admin role	Full AWS account access wildcard added outside change window. Not in original baseline of 5 specific permissions.	ec2:*, s3:*, rds:*, iam:Read*, cloudwatch:*	aws:* (full account access wildcard)	Remove aws:* immediately. Restore specific permission set from baseline. Audit all actions taken with wildcard.	NIS2 Art.21, ISO 27001 A.8.2, CIS AWS v1.5	open	2026-04-19 12:54:38.195651	\N
2	1	aws-admin-role-prod	cross_account_access	Critical	Cross-account trust policy added — unknown account 123456789	IAM role trust policy modified to allow external AWS account 123456789 to assume this role. Account not in approved vendor list.	Trust: arn:aws:iam::111111111:root (own account only)	Trust: arn:aws:iam::123456789:root (unknown external account)	Remove external account trust immediately. Investigate who added it and when. Check CloudTrail for assumption events.	NIS2 Art.21, ISO 27001 A.8.3	open	2026-04-19 11:54:38.195651	\N
3	10	contractor-external-01	privilege_escalation	Critical	Contractor account escalated from read-only to Contributor role	External contractor account had read-only VM access at baseline. Now has Azure Contributor role — can create, modify, delete all resources.	Reader role — Microsoft.Compute/virtualMachines/read	Contributor role — Microsoft.*/write, Microsoft.*/delete	Revert to Reader role immediately. Investigate who granted Contributor. Raise security incident.	ISO 27001 A.8.2, SOC 2 CC6.3, NIS2 Art.21	open	2026-04-19 13:54:38.195651	\N
4	10	contractor-external-01	mfa_disabled	Critical	MFA disabled on contractor account with elevated privileges	Multi-factor authentication was active at baseline. MFA has been disabled on this account which now has Contributor access.	MFA: Enabled (Microsoft Authenticator)	MFA: Disabled	Re-enable MFA immediately. Block account login until MFA restored. Review all actions since MFA was disabled.	NIS2 Art.21, ISO 27001 A.8.5, CIS Azure v2.0	open	2026-04-19 13:54:38.195651	\N
6	3	ci-cd-service-principal	role_added	High	CI/CD service principal granted Owner role on subscription	Azure subscription Owner role assigned to CI/CD principal. Baseline shows deploy-only access. Full subscription control possible.	Contributor on resource group only	Owner on subscription (all resources)	Remove Owner role. Restore resource-group-level Contributor. Require PAM approval for subscription-level roles.	ISO 27001 A.8.2, Azure CIS Benchmark	open	2026-04-19 09:54:38.195651	\N
7	8	developer-iam-group	permission_added	High	Developer group gained iam:PassRole permission	iam:PassRole added to developer group policy. Allows developers to pass any IAM role to services — potential privilege escalation.	ec2:*, s3:*, rds:Describe*, lambda:*, apigateway:*	+ iam:PassRole added to group policy	Remove iam:PassRole from developer group. Create specific PassRole condition with approved roles only.	AWS CIS Benchmark, ISO 27001 A.8.2	open	2026-04-19 08:54:38.195651	\N
8	4	john.smith@company.com	permission_added	Medium	User gained S3 PutObject permission outside change window	s3:PutObject added to user permissions. Baseline shows read-only S3 access. User can now write to all S3 buckets.	s3:GetObject (read-only)	s3:GetObject, s3:PutObject, s3:DeleteObject	Review if PutObject is business-justified. If not, remove. Enforce change management for permission additions.	ISO 27001 A.8.3	investigating	2026-04-17 14:54:38.195651	\N
9	5	lambda-iot-processor	policy_changed	Medium	Lambda execution role policy version updated	Attached managed policy updated to version 3. Change not recorded in change management. Net 2 new permissions added.	PolicyVersion: v1 — 4 permissions	PolicyVersion: v3 — 6 permissions (+sqs:SendMessage, sns:Publish)	Review policy changes. Document justification. Ensure new permissions follow least-privilege.	ISO 27001 A.8.3, SOC 2 CC6.1	open	2026-04-16 14:54:38.195651	\N
10	9	backup-service-account	permission_removed	Low	Backup service account lost rds:DescribeDBSnapshots	RDS describe permission removed from backup service account. May cause backup verification failures.	s3:GetObject, s3:PutObject, rds:CreateDBSnapshot, rds:DescribeDBSnapshots	s3:GetObject, s3:PutObject, rds:CreateDBSnapshot (DescribeDBSnapshots removed)	Restore rds:DescribeDBSnapshots permission. Verify backup jobs are still completing successfully.	ISO 27001 A.8.3	resolved	2026-04-14 14:54:38.195651	2026-04-15 14:54:38.195651
5	2	svc-scanner@aipet.io	permission_added	High	GCP service account gained iam.serviceAccounts.actAs permission	Service account can now impersonate other service accounts — not in baseline. Creates privilege escalation path.	compute.instances.list, compute.networks.list, iam.serviceAccounts.get	+ iam.serviceAccounts.actAs (impersonation permission added)	Remove iam.serviceAccounts.actAs. Audit all impersonation events. Review who granted this permission.	ISO 27001 A.8.2, GCP CIS Benchmark	accepted	2026-04-19 10:54:38.195651	\N
12	9	backup-service-account	policy_changed	Medium	IAM policy modified — backup-service-account	Attached IAM policy was modified. Change not recorded in change management system.	Policy version 1 (baseline)	Policy version 2 (modified)	Review policy changes. Update change management records. Verify with policy owner.	ISO 27001 A.8.3	accepted	2026-04-19 14:58:45.526472	\N
11	4	john.smith@company.com	permission_added	High	New permissions added outside change window — john.smith@company.com	3 new permissions added to identity outside approved change management window.	3 permissions	6 permissions	Review added permissions. Raise change request. Remove if not approved.	ISO 27001 A.8.3, SOC 2 CC6.3	resolved	2026-04-19 14:58:45.503107	2026-04-22 00:14:46.804034
\.


--
-- Data for Name: dd_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.dd_scans (id, identities_scanned, drifts_found, critical_drifts, duration_sec, created_at) FROM stdin;
1	10	2	0	0	2026-04-19 14:58:45.535533
2	10	0	0	0	2026-04-22 00:15:02.57224
\.


--
-- Data for Name: defense_actions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.defense_actions (id, playbook_id, playbook_name, action_type, target, status, reason, outcome, triggered_by, created_at) FROM stdin;
1	1	Auto-quarantine critical devices	quarantine_device	192.168.1.1	executed	Auto-response to Critical SIEM event: Telnet exposed	Device 192.168.1.1 quarantined in Zero-Trust	event:2	2026-04-16 14:14:49.710418
2	1	Auto-quarantine critical devices	create_incident	192.168.1.1	executed	Auto-response to Critical SIEM event: Telnet exposed	SIEM incident created for 192.168.1.1	event:2	2026-04-16 14:14:49.710418
3	1	Auto-quarantine critical devices	send_alert	192.168.1.2	executed	Auto-response to Critical SIEM event: Default credentials	Critical alert pushed to SIEM for 192.168.1.2	event:1	2026-04-16 14:09:49.710418
4	2	Block malicious IP on detection	block_ip	91.219.28.12	executed	Threat Intel match: C2 server detected	Block event logged for IP 91.219.28.12	event:5	2026-04-16 11:14:49.710418
5	3	Reassess trust on scan findings	reassess_trust	192.168.1.3	executed	New scan finding on 192.168.1.3	Trust reassessed: 192.168.1.3 score=72 status=monitored	event:3	2026-04-16 15:14:49.710418
6	1	Auto-quarantine critical devices	quarantine_device	192.168.1.2	executed	Manual trigger of playbook: Auto-quarantine critical devices	Device 192.168.1.2 quarantined in Zero-Trust	manual:user:1	2026-04-16 16:20:46.289825
7	1	Auto-quarantine critical devices	create_incident	192.168.1.2	executed	Manual trigger of playbook: Auto-quarantine critical devices	SIEM incident created for 192.168.1.2	manual:user:1	2026-04-16 16:20:46.289832
8	1	Auto-quarantine critical devices	send_alert	192.168.1.2	executed	Manual trigger of playbook: Auto-quarantine critical devices	Critical alert pushed to SIEM for 192.168.1.2	manual:user:1	2026-04-16 16:20:46.289833
9	4	Respond to brute force attacks	quarantine_device	manual	executed	Manual trigger of playbook: Respond to brute force attacks	Device manual auto-registered and quarantined	manual:user:1	2026-04-21 23:19:03.288046
10	4	Respond to brute force attacks	block_ip	manual	executed	Manual trigger of playbook: Respond to brute force attacks	Block event logged for IP manual	manual:user:1	2026-04-21 23:19:03.288052
11	4	Respond to brute force attacks	create_incident	manual	executed	Manual trigger of playbook: Respond to brute force attacks	SIEM incident created for manual	manual:user:1	2026-04-21 23:19:03.288053
\.


--
-- Data for Name: defense_mesh_pillars; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.defense_mesh_pillars (id, report_id, pillar_name, score, status, gap_count, description, node_meta, created_at) FROM stdin;
56c746e1-a10e-4427-8b0f-413ed7dc7d25	70a1982e-1099-494b-82b0-e3b2d80aa0df	Identity & Access Management	90	Strong	0	Strength of identity verification, access controls, MFA enforcement and privileged access management.	{}	2026-04-22 14:30:43.319135
6f5e8099-9dc2-488d-aa60-ada88e60531a	70a1982e-1099-494b-82b0-e3b2d80aa0df	Endpoint & Device Security	87.5	Strong	0	Coverage and effectiveness of endpoint detection, device management and patch compliance.	{}	2026-04-22 14:30:43.319145
8b9b6571-a203-42a7-a155-2ed7b41d1aeb	70a1982e-1099-494b-82b0-e3b2d80aa0df	Network Security	90	Strong	0	Network segmentation, traffic inspection, intrusion detection and secure remote access controls.	{}	2026-04-22 14:30:43.319149
01a54820-d230-43c6-b8d3-79642ef2fc79	70a1982e-1099-494b-82b0-e3b2d80aa0df	Cloud Security Posture	87.5	Strong	0	Cloud configuration hygiene, CSPM coverage, and compliance with CIS cloud benchmarks.	{}	2026-04-22 14:30:43.319153
d93ed755-e245-48b6-b49a-bc0de4604e91	70a1982e-1099-494b-82b0-e3b2d80aa0df	Application Security	61.8	Developing	1	Secure development practices, SAST/DAST coverage, dependency management and API security.	{}	2026-04-22 14:30:43.319156
07bdff35-b29a-4268-a318-c1c8d9ceab0b	70a1982e-1099-494b-82b0-e3b2d80aa0df	Threat Detection & SIEM	88.6	Strong	0	Visibility, detection capability, log coverage and mean time to detect (MTTD) across the environment.	{}	2026-04-22 14:30:43.319159
14b9901e-0717-4427-91f9-f701531dce6d	70a1982e-1099-494b-82b0-e3b2d80aa0df	Incident Response	66.7	Developing	1	Maturity of incident response plans, playbooks, team readiness and mean time to respond (MTTR).	{}	2026-04-22 14:30:43.319162
8f80b75e-4827-471a-99bf-b4a6665d6165	70a1982e-1099-494b-82b0-e3b2d80aa0df	Data Protection	58	Developing	1	Data classification, encryption coverage, DLP controls and regulatory compliance posture.	{}	2026-04-22 14:30:43.319165
a3bb323e-fcc8-4df6-a9e6-ae5008014a02	70a1982e-1099-494b-82b0-e3b2d80aa0df	OT/ICS & Physical Security	61.8	Developing	1	Operational technology security, OT/IT segmentation and physical security controls.	{}	2026-04-22 14:30:43.319168
6ae75edb-12d3-4340-a48a-5946f3d08f17	70a1982e-1099-494b-82b0-e3b2d80aa0df	Compliance & Governance	58	Developing	1	Regulatory compliance posture, security governance maturity and risk management programme.	{}	2026-04-22 14:30:43.319171
\.


--
-- Data for Name: defense_mesh_recommendations; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.defense_mesh_recommendations (id, report_id, priority, pillar, title, description, effort, impact, timeframe, node_meta, created_at) FROM stdin;
\.


--
-- Data for Name: defense_mesh_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.defense_mesh_reports (id, user_id, organisation, defense_score, maturity_level, total_gaps, critical_gaps, summary, created_at, node_meta) FROM stdin;
70a1982e-1099-494b-82b0-e3b2d80aa0df	1	Your Organisation	77	Managed	5	0	Global Defense Mesh assessment complete for Your Organisation. Overall Defense Score: 77.0/100. Maturity: Managed. 0 critical gap(s) across 10 defense pillars. 0 prioritised remediation action(s) generated.	2026-04-22 14:30:43.311759	{}
\.


--
-- Data for Name: defense_playbooks; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.defense_playbooks (id, name, description, enabled, trigger_field, trigger_op, trigger_value, actions, cooldown_minutes, trigger_count, last_triggered, created_by, created_at) FROM stdin;
2	Block malicious IP on detection	Block and alert when a Threat Intel match is found in the SIEM feed	t	event_type	eq	threat_intel	["block_ip", "create_incident", "send_alert"]	5	2	2026-04-16 11:14:49.704342	\N	2026-04-16 16:14:49.705759
3	Reassess trust on scan findings	Recalculate Zero-Trust score for a device when new scan findings arrive	t	event_type	eq	scan_finding	["reassess_trust", "send_alert"]	15	5	2026-04-16 15:14:49.704342	\N	2026-04-16 16:14:49.70576
5	Alert on Zero-Trust policy violations	Send alert when a Zero-Trust block or quarantine action is logged	t	event_type	eq	zero_trust	["send_alert", "create_incident"]	5	2	2026-04-16 13:14:49.704342	\N	2026-04-16 16:14:49.705761
1	Auto-quarantine critical devices	Immediately quarantine any device that generates a Critical SIEM event	t	severity	eq	Critical	["quarantine_device", "create_incident", "send_alert"]	10	4	2026-04-16 16:20:46.286197	\N	2026-04-16 16:14:49.705756
4	Respond to brute force attacks	Quarantine source device and create incident when brute force is detected	t	title	contains	failed login	["quarantine_device", "block_ip", "create_incident"]	30	2	2026-04-21 23:19:03.285595	\N	2026-04-16 16:14:49.705761
\.


--
-- Data for Name: device_tags; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.device_tags (id, user_id, device_ip, business_function, industry, created_at, updated_at) FROM stdin;
1	1	192.168.1.1	Infrastructure / Network	Education	2026-04-04 03:40:12.604108	2026-04-04 03:40:12.604111
2	1	192.168.1.2	Customer Data	Education	2026-04-04 03:40:12.606089	2026-04-04 03:40:12.606091
3	1	192.168.1.3	Operations / Manufacturing	Education	2026-04-04 03:40:12.607352	2026-04-04 03:40:12.607354
4	1	192.168.1.4	Financial / Payment	Education	2026-04-04 03:40:12.609235	2026-04-04 03:40:12.609237
\.


--
-- Data for Name: digital_twin_v2_anomalies; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.digital_twin_v2_anomalies (id, env_id, device_name, anomaly_type, severity, description, recommendation, mitre_tactic, detected_at, node_meta) FROM stdin;
ed3d0525-4916-4245-beb1-319c75783177	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 01	Unexpected firmware change	CRITICAL	Cognitive Twin detected: Unexpected firmware change on PLC / Controller 01. Automated analysis triggered.	Isolate device immediately. Verify firmware integrity. Roll back to known-good version.	T1542 — Pre-OS Boot	2026-04-22 14:49:53.582411	{}
bc5f062e-157d-40bb-9846-fbdb328b82af	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 01	ARP spoofing detected	HIGH	Cognitive Twin detected: ARP spoofing detected on PLC / Controller 01. Automated analysis triggered.	Enable Dynamic ARP Inspection on switches. Investigate source MAC address.	T1557.002 — ARP Cache Poisoning	2026-04-22 14:49:53.58242	{}
78bb0af9-ce6c-427b-b96f-71c13651ed18	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 01	New device joined network	MEDIUM	Cognitive Twin detected: New device joined network on PLC / Controller 01. Automated analysis triggered.	Verify device identity. Apply NAC policy. Block if unrecognised.	T1200 — Hardware Additions	2026-04-22 14:49:53.582425	{}
5480179b-6c10-4600-961e-c0e34b50bbe0	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 04	Offline beyond threshold	LOW	PLC / Controller 04 is offline. Last seen recently.	Check device connectivity and physical integrity.	\N	2026-04-22 14:49:53.582428	{}
54b80514-c341-461c-a4c1-80095a2e2add	ee1877c1-731c-4b24-9772-675c131b3280	HMI Terminal 01	Offline beyond threshold	LOW	HMI Terminal 01 is offline. Last seen recently.	Check device connectivity and physical integrity.	\N	2026-04-22 14:49:53.582431	{}
b3939b7b-18b5-4a8e-9db7-9513cfd941d2	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 02	Offline beyond threshold	LOW	IoT Sensor 02 is offline. Last seen recently.	Check device connectivity and physical integrity.	\N	2026-04-22 14:49:53.582433	{}
887b0566-b8a5-4a23-bc2a-caf5694421c1	ee1877c1-731c-4b24-9772-675c131b3280	Network Switch 01	Traffic volume anomaly	MEDIUM	High CPU usage (83.2%) detected on Network Switch 01.	Investigate high load. Check for malicious processes or resource exhaustion attack.	T1499 — Endpoint Denial of Service	2026-04-22 14:49:53.582436	{}
\.


--
-- Data for Name: digital_twin_v2_devices; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.digital_twin_v2_devices (id, env_id, device_name, device_type, ip_address, status, risk_level, cpu_usage, memory_usage, last_seen, node_meta, created_at) FROM stdin;
6dd725c9-f5e3-4237-816d-ee2c0d2b70b7	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 01	plc	192.168.1.10	online	LOW	49.5	48.3	2026-04-22 14:49:53.588798	{}	2026-04-22 14:49:53.588803
8fd3d5f4-79ac-4685-8d1e-a88c7b8b767d	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 02	plc	192.168.1.11	online	MEDIUM	66.2	23	2026-04-22 14:49:53.58881	{}	2026-04-22 14:49:53.588811
88cf76f4-e9a9-4cd0-854d-cad5ee205a2d	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 03	plc	192.168.1.12	online	LOW	22.2	69.3	2026-04-22 14:49:53.588815	{}	2026-04-22 14:49:53.588816
4d0b48d6-5204-4642-86f4-678be30b9abf	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 04	plc	192.168.1.13	offline	MEDIUM	73.2	32.2	2026-04-22 14:49:53.588818	{}	2026-04-22 14:49:53.588819
549100bc-ab58-4f26-9319-c8fceb4094ec	ee1877c1-731c-4b24-9772-675c131b3280	PLC / Controller 05	plc	192.168.1.14	online	MEDIUM	71	28.2	2026-04-22 14:49:53.588822	{}	2026-04-22 14:49:53.588822
727f95ab-a24c-4056-a5ec-5d84ca159c21	ee1877c1-731c-4b24-9772-675c131b3280	HMI Terminal 01	hmi	192.168.2.10	offline	MEDIUM	14.1	72.3	2026-04-22 14:49:53.588825	{}	2026-04-22 14:49:53.588826
5c99f6c0-c632-4d24-ba78-a3372c1312be	ee1877c1-731c-4b24-9772-675c131b3280	HMI Terminal 02	hmi	192.168.2.11	online	MEDIUM	69.3	34.4	2026-04-22 14:49:53.588828	{}	2026-04-22 14:49:53.588828
cdf439e9-f90f-4dbf-9f52-78988f4ec0a0	ee1877c1-731c-4b24-9772-675c131b3280	HMI Terminal 03	hmi	192.168.2.12	online	LOW	14.1	34.2	2026-04-22 14:49:53.588831	{}	2026-04-22 14:49:53.588832
d57002dd-33e3-4e7e-98c8-ddcb1babf37c	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 01	sensor	192.168.3.10	online	MEDIUM	73.4	46.6	2026-04-22 14:49:53.588835	{}	2026-04-22 14:49:53.588836
be1dd98c-ab5a-47cf-8ef4-2d3fe43505dc	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 02	sensor	192.168.3.11	offline	LOW	43.8	67.1	2026-04-22 14:49:53.588838	{}	2026-04-22 14:49:53.588839
f641a90a-c468-48cc-8477-9c2b04ceb3bb	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 03	sensor	192.168.3.12	online	LOW	46.4	69.3	2026-04-22 14:49:53.588842	{}	2026-04-22 14:49:53.588843
abcc0a1e-69a6-4e98-bd5f-db55f7aff388	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 04	sensor	192.168.3.13	online	LOW	53.3	57.6	2026-04-22 14:49:53.588846	{}	2026-04-22 14:49:53.588846
2cb5e40c-41b5-4600-afea-8b063004e5e0	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 05	sensor	192.168.3.14	online	MEDIUM	78.8	83.3	2026-04-22 14:49:53.588849	{}	2026-04-22 14:49:53.58885
e55c291f-2d89-4b4a-8e73-65451c9c32b8	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 06	sensor	192.168.3.15	online	LOW	14.5	31.7	2026-04-22 14:49:53.588852	{}	2026-04-22 14:49:53.588853
a31e7d4a-3207-4be4-900d-45bd8a45500f	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 07	sensor	192.168.3.16	online	MEDIUM	74.2	39.6	2026-04-22 14:49:53.588856	{}	2026-04-22 14:49:53.588857
275b6c38-bede-4e86-93e0-c82a4d6cb96a	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 08	sensor	192.168.3.17	online	MEDIUM	68.9	62	2026-04-22 14:49:53.588859	{}	2026-04-22 14:49:53.58886
75841184-66b9-43e3-af50-ddd48629c9fa	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 09	sensor	192.168.3.18	online	MEDIUM	73.8	39.4	2026-04-22 14:49:53.588862	{}	2026-04-22 14:49:53.588863
8298f072-c460-4126-bf8e-2ab0ea0cee23	ee1877c1-731c-4b24-9772-675c131b3280	IoT Sensor 10	sensor	192.168.3.19	online	LOW	22	67.1	2026-04-22 14:49:53.588865	{}	2026-04-22 14:49:53.588866
a4fdd508-ea71-4e6d-92cc-626e71b94ff0	ee1877c1-731c-4b24-9772-675c131b3280	Network Switch 01	switch	192.168.4.10	online	HIGH	83.2	48.2	2026-04-22 14:49:53.588868	{}	2026-04-22 14:49:53.588869
05bd0902-29df-4a01-91f0-befe1760e104	ee1877c1-731c-4b24-9772-675c131b3280	Industrial Robot 01	robot	192.168.5.10	online	LOW	38.5	43.9	2026-04-22 14:49:53.588872	{}	2026-04-22 14:49:53.588873
\.


--
-- Data for Name: digital_twin_v2_environments; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.digital_twin_v2_environments (id, user_id, name, env_type, device_count, risk_score, health_score, anomaly_count, status, summary, created_at, node_meta) FROM stdin;
ee1877c1-731c-4b24-9772-675c131b3280	1	My Digital Twin	industrial	20	68	76.6	7	active	Digital Twin created with 20 device(s) across industrial environment. Health score: 76.6/100. Risk score: 68/100. 7 anomaly(s) detected.	2026-04-22 14:49:53.56523	{}
\.


--
-- Data for Name: dspm_datastores; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.dspm_datastores (id, name, store_type, location, cloud_provider, sensitivity, data_types, size_gb, record_count, encrypted_at_rest, encrypted_in_transit, access_control, publicly_accessible, risk_score, finding_count, last_scanned, created_at) FROM stdin;
1	patient-records-db	database	AWS RDS us-east-1	AWS	restricted	["PHI", "PII"]	45.2	125000	f	t	rbac	f	100	2	2026-04-18 14:18:01.146878	2026-04-18 14:10:58.105288
2	iot-telemetry-bucket	object_storage	AWS S3 eu-west-1	AWS	confidential	["OT", "LOG"]	892.5	0	f	t	public	t	100	3	2026-04-18 14:18:01.157139	2026-04-18 14:10:58.105296
3	scada-historian-db	database	On-premise — Server Room Rack 2	On-Premise	secret	["OT", "IP"]	234	8500000	f	f	basic	f	100	3	2026-04-18 14:18:01.165896	2026-04-18 14:10:58.105298
4	payment-api-cache	cache	Azure Redis — UK South	Azure	restricted	["PCI", "CRED"]	2.1	45000	t	t	rbac	f	80	0	2026-04-18 14:18:01.170273	2026-04-18 14:10:58.105298
5	mqtt-telemetry-stream	message_queue	192.168.1.5 — MQTT Broker	On-Premise	confidential	["OT", "LOG"]	0.5	0	f	f	none	f	100	2	2026-04-18 14:18:01.181663	2026-04-18 14:10:58.105299
6	employee-hr-sharepoint	file_share	Microsoft 365 SharePoint	Azure	confidential	["PII"]	12.8	3200	t	t	rbac	f	60	0	2026-04-18 14:18:01.187668	2026-04-18 14:10:58.1053
7	api-gateway-logs	object_storage	GCP Cloud Storage — europe-west2	GCP	internal	["LOG", "CRED"]	156.3	0	t	t	iam	f	30	0	2026-04-18 14:18:01.192307	2026-04-18 14:10:58.1053
8	backup-archive-s3	object_storage	AWS S3 eu-central-1	AWS	restricted	["PHI", "PII", "OT"]	4521	0	f	t	iam	f	100	1	2026-04-18 14:18:01.195902	2026-04-18 14:10:58.105301
9	plc-config-fileshare	file_share	10.0.1.20 — OT Network NAS	On-Premise	secret	["CFG", "IP", "OT"]	3.2	450	f	f	none	f	100	3	2026-04-18 14:18:01.199325	2026-04-18 14:10:58.105302
10	analytics-warehouse	database	GCP BigQuery — europe-west2	GCP	internal	["LOG", "OT"]	2341.5	45000000	t	t	iam	f	30	0	2026-04-18 14:18:01.202336	2026-04-18 14:10:58.105302
\.


--
-- Data for Name: dspm_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.dspm_findings (id, datastore_id, finding_type, severity, title, description, remediation, regulation, status, created_at) FROM stdin;
1	1	unencrypted_at_rest	Critical	Patient records DB not encrypted at rest — 125,000 PHI records at risk	AWS RDS instance storing Protected Health Information without encryption at rest. GDPR Art.32 violation.	Enable RDS encryption using AWS KMS. Snapshot, restore encrypted. Estimated 2-hour downtime.	GDPR Art.32, HIPAA §164.312, DSPT v6	open	2026-04-18 14:10:58.114242
2	1	sensitive_data_retention	High	Patient records retained beyond required period	Records older than 8 years present — NHS data retention policy requires deletion after 8 years	Implement automated data retention policy. Archive or delete records exceeding retention period.	NHS Records Management Code of Practice	open	2026-04-18 14:10:58.11425
3	2	public_exposure	Critical	IoT telemetry S3 bucket publicly accessible — OT data exposed	S3 bucket containing operational technology telemetry data has public read access. 892GB of OT data exposed.	Remove public access block immediately. Apply bucket policy restricting to authorised IAM roles only.	NIS2 Art.21, IEC 62443	open	2026-04-18 14:10:58.114251
4	2	unencrypted_at_rest	High	S3 bucket encryption not enabled	OT telemetry data stored without server-side encryption	Enable S3 SSE-KMS encryption. Apply bucket encryption policy.	NIS2 Art.21, ISO 27001 A.8.24	open	2026-04-18 14:10:58.114252
5	2	no_access_logging	Medium	S3 access logging not enabled	No audit trail of who accessed the telemetry bucket	Enable S3 server access logging. Forward logs to AIPET SIEM.	SOC 2 CC7.2, ISO 27001 A.8.15	open	2026-04-18 14:10:58.114253
6	3	unencrypted_at_rest	Critical	SCADA historian database storing 8.5M OT records without encryption	On-premise database containing 5 years of operational process data unencrypted	Implement TDE (Transparent Data Encryption) on SQL Server. Encrypt backup files.	NIS2 Art.21, IEC 62443-3-3	open	2026-04-18 14:10:58.114253
7	3	unencrypted_transit	Critical	SCADA historian transmitting data without TLS	Database connections from HMI and SCADA server use unencrypted TCP	Configure SSL/TLS on all database connections. Force encrypted connections only.	NIS2 Art.21, IEC 62443	open	2026-04-18 14:10:58.114254
8	3	weak_access_control	High	SCADA historian using basic authentication	Database using username/password only — no MFA, no certificate auth	Implement certificate-based authentication. Enforce MFA for privileged access.	ISO 27001 A.8.5, NIS2 Art.21	open	2026-04-18 14:10:58.114255
9	5	no_access_control	Critical	MQTT broker has no authentication — all topics accessible	MQTT broker running without authentication. Any device on the network can publish/subscribe to all topics including control commands.	Enable MQTT username/password authentication. Implement ACL restricting topics per device. Enable TLS.	NIS2 Art.21, IEC 62443-3-3	open	2026-04-18 14:10:58.114256
10	5	unencrypted_transit	High	MQTT traffic unencrypted — OT commands visible on network	MQTT broker using port 1883 (unencrypted). Control commands transmitted in plaintext.	Migrate to MQTT over TLS (port 8883). Disable unencrypted port 1883.	NIS2 Art.21, IEC 62443	open	2026-04-18 14:10:58.114256
11	8	unencrypted_at_rest	High	4.5TB backup archive containing PHI/PII not encrypted	Disaster recovery backup containing patient and employee data stored without encryption	Enable S3 SSE-KMS on backup bucket. Re-encrypt existing objects.	GDPR Art.32, HIPAA §164.312	open	2026-04-18 14:10:58.114257
12	9	no_access_control	Critical	PLC configuration files accessible with no authentication	OT NAS share containing PLC ladder logic, setpoints, and safety configurations has no access control	Implement SMB authentication. Apply NTFS permissions. Restrict to OT engineers only.	NIS2 Art.21, IEC 62443, NERC CIP	open	2026-04-18 14:10:58.114257
13	9	unencrypted_at_rest	Critical	PLC configuration files containing safety setpoints stored unencrypted	Critical safety parameters for industrial processes accessible in plaintext	Encrypt NAS volume. Implement file-level encryption for configuration files.	IEC 62443-3-3, NIS2 Art.21	open	2026-04-18 14:10:58.114258
14	9	unencrypted_transit	High	PLC configuration data transferred via SMB without encryption	File transfers to/from OT NAS use SMBv1 without signing	Upgrade to SMB3 with encryption. Disable SMBv1. Enable SMB signing.	NIS2 Art.21, ISO 27001 A.8.20	open	2026-04-18 14:10:58.114258
\.


--
-- Data for Name: dspm_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.dspm_scans (id, datastores_found, findings_found, critical_count, duration_sec, created_at) FROM stdin;
1	10	0	0	0	2026-04-18 14:18:01.207899
\.


--
-- Data for Name: endpoint_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.endpoint_findings (id, scan_id, category, title, severity, tactic, technique, description, remediation, ioc, node_meta, created_at) FROM stdin;
21e4539a-4e34-4ddd-a31a-57911f32c86b	6577e0a5-6caa-422b-b59b-b6d73866078a	Patch Management	Critical OS Patches Missing	CRITICAL	Initial Access	T1190 — Exploit Public-Facing Application	Endpoint threat detected on WORKSTATION-01 (Windows): Critical OS Patches Missing. MITRE ATT&CK: Initial Access.	Apply all critical OS patches immediately. Enable automatic security updates. Patch within 48 hours of release.	OS patch gap > 30 days	{}	2026-04-22 18:25:25.008872
0fc4dd97-b063-44d5-a91c-5ece37211a7d	6577e0a5-6caa-422b-b59b-b6d73866078a	Malware Detection	Suspicious Process Execution	CRITICAL	Execution	T1059 — Command and Scripting Interpreter	Endpoint threat detected on WORKSTATION-01 (Windows): Suspicious Process Execution. MITRE ATT&CK: Execution.	Terminate process immediately. Isolate endpoint. Perform full forensic investigation. Check for persistence.	Suspicious process hash detected	{}	2026-04-22 18:25:25.008885
0a7a73f3-f3b5-4812-9b15-694cccc6b16d	6577e0a5-6caa-422b-b59b-b6d73866078a	Malware Detection	Ransomware Behaviour Detected	CRITICAL	Impact	T1486 — Data Encrypted for Impact	Endpoint threat detected on WORKSTATION-01 (Windows): Ransomware Behaviour Detected. MITRE ATT&CK: Impact.	Isolate endpoint from network immediately. Do not restart. Preserve memory for forensics. Restore from backup.	Mass file encryption activity	{}	2026-04-22 18:25:25.00889
4083a2b6-d51d-43a5-9098-273af7998309	6577e0a5-6caa-422b-b59b-b6d73866078a	Persistence	Suspicious Registry Autorun	HIGH	Persistence	T1547.001 — Registry Run Keys	Endpoint threat detected on WORKSTATION-01 (Windows): Suspicious Registry Autorun. MITRE ATT&CK: Persistence.	Remove malicious registry entries. Audit all Run/RunOnce keys. Enable registry monitoring.	Unexpected registry autorun entry	{}	2026-04-22 18:25:25.008894
d3992f94-b624-4666-978e-0c82d64015e6	6577e0a5-6caa-422b-b59b-b6d73866078a	Persistence	New Admin Account Created	CRITICAL	Persistence	T1136 — Create Account	Endpoint threat detected on WORKSTATION-01 (Windows): New Admin Account Created. MITRE ATT&CK: Persistence.	Disable and investigate the account immediately. Audit all account creation events. Enable alerting on privileged account creation.	Unexpected admin account creation	{}	2026-04-22 18:25:25.008899
278d4676-015c-4cfe-9890-7a9a8e4b002d	6577e0a5-6caa-422b-b59b-b6d73866078a	Credential Theft	LSASS Memory Access Detected	CRITICAL	Credential Access	T1003.001 — LSASS Memory	Endpoint threat detected on WORKSTATION-01 (Windows): LSASS Memory Access Detected. MITRE ATT&CK: Credential Access.	Enable Credential Guard. Deploy EDR with LSASS protection. Enable Protected Users security group.	LSASS process access detected	{}	2026-04-22 18:25:25.008904
280979f4-e426-4799-84d6-b629b85ae173	6577e0a5-6caa-422b-b59b-b6d73866078a	Lateral Movement	Pass-the-Hash Attempt	CRITICAL	Lateral Movement	T1550.002 — Pass the Hash	Endpoint threat detected on WORKSTATION-01 (Windows): Pass-the-Hash Attempt. MITRE ATT&CK: Lateral Movement.	Enable Protected Users group. Disable NTLM where possible. Deploy PAM and privileged access workstations.	NTLM hash used for lateral movement	{}	2026-04-22 18:25:25.008908
8ed4adcd-98a6-48c3-bf0a-b959713a7059	6577e0a5-6caa-422b-b59b-b6d73866078a	Defence Evasion	Antivirus Disabled or Tampered	CRITICAL	Defense Evasion	T1562.001 — Disable or Modify Tools	Endpoint threat detected on WORKSTATION-01 (Windows): Antivirus Disabled or Tampered. MITRE ATT&CK: Defense Evasion.	Re-enable security tools immediately. Isolate endpoint. Investigate how AV was disabled — likely active compromise.	Security tool termination detected	{}	2026-04-22 18:25:25.008912
4588fac7-6857-4bd1-af10-6d1d87b9cd3b	6577e0a5-6caa-422b-b59b-b6d73866078a	Security Posture	No EDR Agent Installed	CRITICAL	Defense Evasion	T1562 — Impair Defenses	Endpoint threat detected on WORKSTATION-01 (Windows): No EDR Agent Installed. MITRE ATT&CK: Defense Evasion.	Deploy EDR agent immediately. Prioritise servers and privileged workstations. Ensure 100% EDR coverage.	No EDR telemetry from endpoint	{}	2026-04-22 18:25:25.008916
1932f4da-ae3f-4ad6-aa10-deede453b237	6577e0a5-6caa-422b-b59b-b6d73866078a	Security Posture	Disk Encryption Not Enabled	HIGH	Collection	T1005 — Data from Local System	Endpoint threat detected on WORKSTATION-01 (Windows): Disk Encryption Not Enabled. MITRE ATT&CK: Collection.	Enable BitLocker (Windows) or FileVault (macOS) on all endpoints. Escrow recovery keys to IT.	Unencrypted disk detected	{}	2026-04-22 18:25:25.00892
\.


--
-- Data for Name: endpoint_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.endpoint_scans (id, user_id, hostname, os_type, os_version, risk_score, severity, total_findings, critical_count, health_score, summary, created_at, node_meta) FROM stdin;
6577e0a5-6caa-422b-b59b-b6d73866078a	1	WORKSTATION-01	Windows	Windows 11	100	CRITICAL	10	8	0	Endpoint Agent scan complete for WORKSTATION-01 (Windows Windows 11). Risk: 100.0/100. Health: 0/100. 10 finding(s) — 8 critical. Threat categories: 7.	2026-04-22 18:25:25.000098	{}
\.


--
-- Data for Name: enterprise_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.enterprise_reports (id, user_id, report_type, organisation, period, risk_score, status, content, created_at, node_meta) FROM stdin;
e2a60e70-2d02-4c1d-b050-f6b8bc83b22d	1	executive	NHS Trust London	Q1 2026	38.3	GENERATED	{"title": "Executive Security Summary \\u2014 NHS Trust London", "period": "Q1 2026", "classification": "CONFIDENTIAL", "sections": [{"title": "Overall Security Posture", "content": "During Q1 2026, NHS Trust London maintained a security risk score of 41.8/100. The platform identified and remediated 54 security findings across cloud, endpoint and identity systems.", "score": 41.8, "trend": "improving"}, {"title": "Top Business Risks", "items": [{"risk": "Cloud Misconfiguration Exposure", "impact": "HIGH", "status": "Remediated"}, {"risk": "Identity & Credential Threats", "impact": "CRITICAL", "status": "In Progress"}, {"risk": "Supply Chain Vulnerabilities", "impact": "HIGH", "status": "Monitored"}, {"risk": "Ransomware Threat Surface", "impact": "CRITICAL", "status": "Remediated"}]}, {"title": "Compliance Status", "items": [{"framework": "NIS2", "score": 85.3, "status": "SUBSTANTIALLY_COMPLIANT"}, {"framework": "ISO 27001", "score": 69.1, "status": "PARTIALLY_COMPLIANT"}, {"framework": "GDPR", "score": 91.2, "status": "SUBSTANTIALLY_COMPLIANT"}]}, {"title": "Key Achievements", "items": ["Deployed AI-powered threat detection across 5 cloud environments", "Reduced mean detection time to 11.2 minutes", "Achieved 96.0% uptime across all monitored services", "Completed 3 compliance framework assessments"]}, {"title": "Recommended Board Actions", "items": ["Approve budget for Zero Trust implementation", "Mandate MFA across all business units", "Commission external penetration test", "Review cyber insurance policy limits"]}]}	2026-04-23 00:21:28.112894	{}
\.


--
-- Data for Name: explain_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.explain_results (id, scan_id, finding_id, explain_type, content, model_used, tokens_used, created_at) FROM stdin;
1	9	2	finding	WHY THIS IS DANGEROUS\nYour device is essentially leaving its front door wide open with a welcome mat for attackers. Anyone on your network can remotely take complete control of this device, access all its data, and use it as a launching pad to attack other systems in your organization. In the worst case, criminals could shut down your operations, steal sensitive information, or hold your entire network hostage for ransom.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour confidential data, customer information, and business operations are all at serious risk of being compromised or completely disrupted. If you handle sensitive information like patient records or financial data, this vulnerability could lead to massive regulatory fines and legal liability when that information gets stolen.	claude-sonnet-4-20250514	155	2026-04-03 19:03:53.670008
3	9	3	finding	WHY THIS IS DANGEROUS\nThis device is still using the factory-set username and password that came with it, which means anyone can look up these credentials online and gain complete control of the device. An attacker could use this access to spy on your operations, steal sensitive information, or use the device as a stepping stone to break into other systems on your network. In the worst case, they could shut down critical operations, steal customer data, or plant malicious software that spreads throughout your entire organization.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour confidential business data, customer information, and operational systems are all at immediate risk of unauthorized access and theft. Depending on your industry, this could result in expensive regulatory fines, legal liability, and complete shutdown of business operations until the security breach is contained.	claude-sonnet-4-20250514	172	2026-04-03 19:08:29.903672
4	9	5	finding	WHY THIS IS DANGEROUS\nThis device is like having a building with no security guards or locked doors - anyone on your network can walk right in and take control of it. An attacker could use this device as their base of operations to spy on your network, steal sensitive information, or launch attacks against other systems in your organization. In the worst case, they could shut down critical operations, access patient records or financial data, or use your network to attack other businesses.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour business operations could be disrupted if someone gains unauthorized access to this device and uses it to interfere with other connected systems or steal confidential information. Depending on your industry, this security gap could also put you at risk of failing compliance audits or facing regulatory penalties for not properly protecting sensitive data.	claude-sonnet-4-20250514	172	2026-04-03 23:06:06.17326
5	9	4	finding	WHY THIS IS DANGEROUS\n\nThis device is sending and receiving messages without any protection, like having phone conversations on a loudspeaker that anyone nearby can hear. An attacker on your network could intercept sensitive information being transmitted, spy on your operations, or even send fake commands to control connected equipment. In the worst case, this could allow someone to manipulate your IoT devices, steal confidential data, or disrupt critical business processes.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\n\nYour organization faces potential data breaches where sensitive operational information could be stolen, and there's a risk that attackers could interfere with or take control of connected devices and systems. This vulnerability could lead to compliance violations, regulatory fines, operational downtime, and loss of customer trust if security incidents occur.	claude-sonnet-4-20250514	168	2026-04-03 23:07:12.799799
6	1	1	finding	WHY THIS IS DANGEROUS\nYour IoT device is essentially leaving its front door wide open with no lock, allowing anyone on your network to walk right in and take complete control. An attacker could use this device as a launching pad to access your entire network, steal sensitive data like customer information or financial records, or completely shut down your operations. In the worst case, they could hold your entire business hostage by encrypting all your files and demanding payment to get them back.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour business operations could be completely disrupted if an attacker gains access, potentially costing thousands in lost revenue and emergency IT repairs. Any sensitive customer data, employee records, or financial information stored on your network could be stolen, leading to regulatory fines and serious damage to your company's reputation.	claude-sonnet-4-20250514	172	2026-04-03 23:16:25.73228
48	9	\N	executive_report	EXECUTIVE SUMMARY\n\nOur cybersecurity team conducted a comprehensive assessment of the organization's network infrastructure, evaluating 4 critical business systems. The assessment reveals a HIGH risk security posture with 4 significant vulnerabilities identified, including 2 critical-severity issues that require immediate remediation.\n\nKEY RISKS IDENTIFIED\n\n• Unsecured remote access channels allow attackers to gain direct control of core network equipment, potentially causing complete system shutdown or data theft\n\n• Default login credentials on critical systems provide easy entry points for cybercriminals, who commonly exploit these well-known password combinations to access sensitive business data\n\n• Unprotected data transmission channels expose confidential business communications and customer information as it travels across the network, making interception simple for malicious actors\n\n• Missing network security barriers leave systems vulnerable to both external attacks and internal threats, with no mechanism to detect or prevent unauthorized access attempts\n\nIMMEDIATE ACTIONS REQUIRED\n\n1. Disable all remote access services on the primary network router (192.168.1.1) immediately and replace with secure encrypted alternatives within 48 hours\n\n2. Change all default usernames and passwords on the secondary system (192.168.1.2) to complex, unique credentials and implement mandatory password changes every 90 days\n\n3. Install and configure network firewall protection on the unprotected system (192.168.1.4) and establish baseline security rules to block unauthorized traffic\n\nOVERALL SECURITY ASSESSMENT\n\nThe organization's current security posture presents serious operational and financial risks that demand urgent executive attention. With 2 critical vulnerabilities providing direct pathways for cybercriminals to access our systems, the likelihood of a successful attack is extremely high if no action is taken. The absence of basic security controls across multiple systems indicates systemic security gaps that could result in significant business disruption, regulatory penalties, and reputational damage. However, the identified vulnerabilities are well-understood issues with proven solutions, meaning rapid improvement is achievable with proper resource allocation and management commitment to implementing the recommended security measures.	claude-sonnet-4-20250514	435	2026-04-04 12:39:20.605739
\.


--
-- Data for Name: findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.findings (id, scan_id, module, attack, severity, description, target, created_at, fix_status, fix_notes) FROM stdin;
1	1	network	open_telnet	Critical	Telnet service detected on port 23	192.168.1.1	\N	fixed	Telnet disabled and removed on 3 April 2026
2	9	network	open_telnet	Critical	Telnet service detected on port 23	192.168.1.1	\N	open	\N
3	9	network	default_credentials	Critical	Default credentials accepted on admin panel	192.168.1.2	\N	open	\N
4	9	mqtt	unencrypted_mqtt	High	MQTT broker running without TLS on port 1883	192.168.1.3	\N	open	\N
5	9	network	no_firewall	Medium	No firewall rules configured on device	192.168.1.4	\N	open	\N
\.


--
-- Data for Name: forensic_artifacts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.forensic_artifacts (id, case_id, artifact_type, value, source, confidence, node_meta, created_at) FROM stdin;
740e3c24-73ec-4134-acac-ed5253037529	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	IP	192.168.1.50	manual	HIGH	{}	2026-04-22 02:32:49.840024
efbc3ee8-759b-449d-b799-c833548c4a48	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	IP	10.0.0.1	manual	HIGH	{}	2026-04-22 02:32:49.840039
2cdafd9e-9d10-48f7-a3d5-212f7939f73e	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	IP	10.0.0.5	manual	HIGH	{}	2026-04-22 02:32:49.840044
76a22290-ff10-4d76-a2eb-66aadaaf3261	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	IP	10.0.0.20	manual	HIGH	{}	2026-04-22 02:32:49.840049
b65fca39-5c32-4cb6-9185-119a2c955cdd	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	DOMAIN	evil.com	manual	MEDIUM	{}	2026-04-22 02:32:49.840053
98ed7205-202e-433c-8e1f-dae4e20d8ce1	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	CVE	CVE-2023-44271	manual	HIGH	{}	2026-04-22 02:32:49.840058
\.


--
-- Data for Name: forensic_cases; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.forensic_cases (id, user_id, title, severity, status, risk_score, summary, created_at, completed_at, node_meta) FROM stdin;
e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	1	Untitled Investigation	CRITICAL	complete	100	Forensic analysis identified 6 IOC(s) and 7 MITRE ATT&CK stage(s). Risk score: 100.0/100. Severity: CRITICAL.	2026-04-22 02:32:49.834824	2026-04-22 02:32:49.829041	{"source": "manual"}
\.


--
-- Data for Name: forensic_timeline; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.forensic_timeline (id, case_id, step, stage, description, mitre_tactic, mitre_technique, severity, node_meta, created_at) FROM stdin;
912b872e-e7a5-4299-916a-f928dd94415d	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	1	Reconnaissance	Attack stage detected: Reconnaissance — T1595 — Active Scanning. Keywords matched in submitted evidence.	Reconnaissance	T1595 — Active Scanning	LOW	{}	2026-04-22 02:32:49.84591
02e97a46-9a02-4700-8644-e4c9795ee588	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	2	Initial Access	Attack stage detected: Initial Access — T1190 — Exploit Public-Facing Application. Keywords matched in submitted evidence.	Initial Access	T1190 — Exploit Public-Facing Application	CRITICAL	{}	2026-04-22 02:32:49.845922
6bdb9e9d-72aa-4d9c-a64d-2d29fb5836a9	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	3	Execution	Attack stage detected: Execution — T1059 — Command and Scripting Interpreter. Keywords matched in submitted evidence.	Execution	T1059 — Command and Scripting Interpreter	CRITICAL	{}	2026-04-22 02:32:49.845927
b00b24d9-96f8-4163-9239-18554c06d3d1	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	4	Defense Evasion	Attack stage detected: Defense Evasion — T1070 — Indicator Removal. Keywords matched in submitted evidence.	Defense Evasion	T1070 — Indicator Removal	HIGH	{}	2026-04-22 02:32:49.845932
89e009ba-f16d-4226-84ca-97bb891c4398	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	5	Credential Access	Attack stage detected: Credential Access — T1003 — OS Credential Dumping. Keywords matched in submitted evidence.	Credential Access	T1003 — OS Credential Dumping	CRITICAL	{}	2026-04-22 02:32:49.845936
fbace826-fcab-4b6e-b9bc-8cc2af303b66	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	6	Lateral Movement	Attack stage detected: Lateral Movement — T1021 — Remote Services. Keywords matched in submitted evidence.	Lateral Movement	T1021 — Remote Services	HIGH	{}	2026-04-22 02:32:49.845939
5cc8ec9c-bfc3-44d5-b7be-a76ed4bd8740	e9e7eb5e-5ea7-4cfb-ba48-abcfbc2a2ac2	7	Exfiltration	Attack stage detected: Exfiltration — T1041 — Exfiltration Over C2 Channel. Keywords matched in submitted evidence.	Exfiltration	T1041 — Exfiltration Over C2 Channel	CRITICAL	{}	2026-04-22 02:32:49.845942
\.


--
-- Data for Name: iam_exposure_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.iam_exposure_findings (id, scan_id, category, title, severity, identity_type, identity_name, description, remediation, blast_radius, node_meta, created_at) FROM stdin;
f2789b84-193e-47f5-8212-dd68d735b92f	2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	Privilege Escalation	PassRole Permission Allows Privilege Escalation	CRITICAL	IAM Role	AWS Identity	IAM exposure detected: PassRole Permission Allows Privilege Escalation. This creates a HIGH blast radius risk in your AWS environment.	Restrict iam:PassRole to specific roles. Never allow PassRole with wildcard resources.	HIGH	{}	2026-04-22 17:54:31.461182
219eb3a7-bb64-463c-90a6-ab36aabc7830	2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	Excessive Permissions	Administrator Access Policy Attached	CRITICAL	IAM User/Role	AWS Identity	IAM exposure detected: Administrator Access Policy Attached. This creates a CRITICAL blast radius risk in your AWS environment.	Remove AdministratorAccess. Replace with least-privilege policies scoped to required services.	CRITICAL	{}	2026-04-22 17:54:31.461192
28199aed-e37f-4572-b8c6-5b88157f9d17	2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	Excessive Permissions	Wildcard Resource in IAM Policy	HIGH	IAM Policy	AWS Identity	IAM exposure detected: Wildcard Resource in IAM Policy. This creates a HIGH blast radius risk in your AWS environment.	Replace wildcard resources with specific ARNs. Scope all policies to minimum required resources.	HIGH	{}	2026-04-22 17:54:31.461195
bc642609-8e0a-4986-aaa5-937294f062df	2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	Excessive Permissions	Cross-Account Admin Access	CRITICAL	IAM Role	AWS Identity	IAM exposure detected: Cross-Account Admin Access. This creates a CRITICAL blast radius risk in your AWS environment.	Review all cross-account trust relationships. Require ExternalId condition. Enforce MFA.	CRITICAL	{}	2026-04-22 17:54:31.461199
902aa3b4-ec66-4ed0-a8dd-fb4837093c32	2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	Credential Security	MFA Not Enabled on Privileged Account	CRITICAL	IAM User	AWS Identity	IAM exposure detected: MFA Not Enabled on Privileged Account. This creates a HIGH blast radius risk in your AWS environment.	Enforce MFA via IAM policy condition aws:MultiFactorAuthPresent. Block console without MFA.	HIGH	{}	2026-04-22 17:54:31.461202
7ceba11f-0665-43ea-ad86-c6bc4fa0c9ca	2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	Credential Security	Inactive IAM Users with Active Credentials	HIGH	IAM User	AWS Identity	IAM exposure detected: Inactive IAM Users with Active Credentials. This creates a MEDIUM blast radius risk in your AWS environment.	Disable inactive users after 90 days. Implement automated deprovisioning. Review quarterly.	MEDIUM	{}	2026-04-22 17:54:31.461205
1d08e227-1b7a-400f-a5ba-f4d992d5ec60	2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	Service Account Risk	Static Service Account Key in Use	HIGH	Service Account	AWS Identity	IAM exposure detected: Static Service Account Key in Use. This creates a HIGH blast radius risk in your AWS environment.	Replace static keys with Workload Identity Federation. Rotate existing keys every 90 days.	HIGH	{}	2026-04-22 17:54:31.461208
cd2603c1-3f23-4bf2-941a-4b1256c1ad57	2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	Federation Risk	OIDC Provider Trusted Without Conditions	HIGH	OIDC Provider	AWS Identity	IAM exposure detected: OIDC Provider Trusted Without Conditions. This creates a HIGH blast radius risk in your AWS environment.	Add sub, aud and iss conditions to all OIDC trust policies. Restrict to specific repositories/subjects.	HIGH	{}	2026-04-22 17:54:31.46121
\.


--
-- Data for Name: iam_exposure_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.iam_exposure_scans (id, user_id, cloud_provider, risk_score, severity, total_findings, critical_count, identities_at_risk, summary, created_at, node_meta) FROM stdin;
2f0a65d5-7562-4ca9-80ea-6d4bc2f1bd06	1	aws	100	CRITICAL	8	4	6	IAM Exposure Analysis complete for AWS. Risk: 100.0/100. 8 finding(s) — 4 critical. 6 identity type(s) at risk.	2026-04-22 17:54:31.450573	{}
\.


--
-- Data for Name: identity_guardian_alerts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.identity_guardian_alerts (id, user_id, subject, risk_score, severity, status, summary, created_at, node_meta) FROM stdin;
447f5c6c-e87a-492d-b830-64c1ab52c0b9	1	Unknown Identity	100	CRITICAL	open	Identity risk analysis for Unknown Identity complete. Risk score: 100.0/100. Severity: CRITICAL. 10 signal(s) detected (5 critical, 5 high, 0 medium).	2026-04-22 03:02:13.019489	{}
7e138bd9-cf03-430c-a0be-405da3b6d3b0	1	Unknown Identity	100	CRITICAL	open	Identity risk analysis for Unknown Identity complete. Risk score: 100.0/100. Severity: CRITICAL. 10 signal(s) detected (5 critical, 5 high, 0 medium).	2026-04-22 03:03:22.688853	{}
aeedcef1-68cc-4bd6-b46f-4d32264ec3df	1	Unknown Identity	100	CRITICAL	open	Identity risk analysis for Unknown Identity complete. Risk score: 100.0/100. Severity: CRITICAL. 12 signal(s) detected (6 critical, 6 high, 0 medium).	2026-04-22 03:05:57.366338	{}
\.


--
-- Data for Name: identity_guardian_signals; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.identity_guardian_signals (id, alert_id, signal_type, title, description, severity, recommendation, node_meta, created_at) FROM stdin;
cc29690a-31ed-4574-b0db-f41521c3debb	447f5c6c-e87a-492d-b830-64c1ab52c0b9	PRIVILEGE	Admin Account Sprawl	Risk signal detected based on submitted identity profile. Matched pattern: Admin Account Sprawl.	CRITICAL	Reduce admin accounts to minimum. Use just-in-time privileged access management.	{}	2026-04-22 03:02:13.02429
69168462-dbbe-4a8b-bdae-11b63484061d	447f5c6c-e87a-492d-b830-64c1ab52c0b9	PRIVILEGE	Over-Privileged Service Account	Risk signal detected based on submitted identity profile. Matched pattern: Over-Privileged Service Account.	HIGH	Apply least-privilege to all service accounts. Rotate credentials every 90 days.	{}	2026-04-22 03:02:13.024303
1bc98058-790a-402c-aa40-1d2e194a7019	447f5c6c-e87a-492d-b830-64c1ab52c0b9	PRIVILEGE	Excessive Cloud IAM Permissions	Risk signal detected based on submitted identity profile. Matched pattern: Excessive Cloud IAM Permissions.	HIGH	Replace wildcard IAM policies with granular least-privilege policies.	{}	2026-04-22 03:02:13.024309
8f616bbb-cd9c-4469-a088-36394396a5d0	447f5c6c-e87a-492d-b830-64c1ab52c0b9	BEHAVIOUR	Impossible Travel Detected	Risk signal detected based on submitted identity profile. Matched pattern: Impossible Travel Detected.	CRITICAL	Block session and require re-authentication. Investigate with user and manager immediately.	{}	2026-04-22 03:02:13.024313
1c5c6900-1a92-4a32-ab94-2a3ab64b9534	447f5c6c-e87a-492d-b830-64c1ab52c0b9	BEHAVIOUR	Unusual Login Time	Risk signal detected based on submitted identity profile. Matched pattern: Unusual Login Time.	HIGH	Enforce time-based access policies. Alert security team for off-hours privileged access.	{}	2026-04-22 03:02:13.024318
c1170447-da91-41bc-b6da-af878c9f6fe4	447f5c6c-e87a-492d-b830-64c1ab52c0b9	BEHAVIOUR	Brute Force / Password Spray	Risk signal detected based on submitted identity profile. Matched pattern: Brute Force / Password Spray.	CRITICAL	Lock account after 5 failed attempts. Implement CAPTCHA and IP-based rate limiting.	{}	2026-04-22 03:02:13.024322
adcb3ac2-1595-412e-bd5d-5fd864f20ef4	447f5c6c-e87a-492d-b830-64c1ab52c0b9	CREDENTIAL	No MFA Enforced	Risk signal detected based on submitted identity profile. Matched pattern: No MFA Enforced.	CRITICAL	Enforce MFA immediately for all accounts, especially privileged users.	{}	2026-04-22 03:02:13.024326
0148c945-25ae-4b74-9cf6-8a1252a2fc17	447f5c6c-e87a-492d-b830-64c1ab52c0b9	CREDENTIAL	Weak Password Policy	Risk signal detected based on submitted identity profile. Matched pattern: Weak Password Policy.	HIGH	Enforce minimum 16-character passwords with complexity. Use a password manager.	{}	2026-04-22 03:02:13.024331
f05725da-c50f-4029-b683-32e1bd1910d6	447f5c6c-e87a-492d-b830-64c1ab52c0b9	CREDENTIAL	Hardcoded Credentials Detected	Risk signal detected based on submitted identity profile. Matched pattern: Hardcoded Credentials Detected.	CRITICAL	Remove hardcoded credentials immediately. Rotate all exposed secrets and use a vault.	{}	2026-04-22 03:02:13.024335
7ad44fcc-b696-4df1-aa54-5be7efac29a7	447f5c6c-e87a-492d-b830-64c1ab52c0b9	CREDENTIAL	Long-lived Access Tokens	Risk signal detected based on submitted identity profile. Matched pattern: Long-lived Access Tokens.	HIGH	Rotate all access tokens every 90 days. Use short-lived tokens via OIDC where possible.	{}	2026-04-22 03:02:13.02434
1c5ca2b5-a386-4ae7-a47b-667b9d3b8d0e	7e138bd9-cf03-430c-a0be-405da3b6d3b0	PRIVILEGE	Admin Account Sprawl	Risk signal detected based on submitted identity profile. Matched pattern: Admin Account Sprawl.	CRITICAL	Reduce admin accounts to minimum. Use just-in-time privileged access management.	{}	2026-04-22 03:03:22.720702
68ebd7e0-10aa-4758-8064-bdba386c1654	7e138bd9-cf03-430c-a0be-405da3b6d3b0	PRIVILEGE	Over-Privileged Service Account	Risk signal detected based on submitted identity profile. Matched pattern: Over-Privileged Service Account.	HIGH	Apply least-privilege to all service accounts. Rotate credentials every 90 days.	{}	2026-04-22 03:03:22.720725
9e36265f-9e21-4c43-a99d-27875a23f6d7	7e138bd9-cf03-430c-a0be-405da3b6d3b0	PRIVILEGE	Excessive Cloud IAM Permissions	Risk signal detected based on submitted identity profile. Matched pattern: Excessive Cloud IAM Permissions.	HIGH	Replace wildcard IAM policies with granular least-privilege policies.	{}	2026-04-22 03:03:22.72073
62c0a686-a866-4ea1-9c9e-7f4a0e129fcc	7e138bd9-cf03-430c-a0be-405da3b6d3b0	BEHAVIOUR	Impossible Travel Detected	Risk signal detected based on submitted identity profile. Matched pattern: Impossible Travel Detected.	CRITICAL	Block session and require re-authentication. Investigate with user and manager immediately.	{}	2026-04-22 03:03:22.720734
91dddc82-1823-4559-9718-d32a109cea9a	7e138bd9-cf03-430c-a0be-405da3b6d3b0	BEHAVIOUR	Unusual Login Time	Risk signal detected based on submitted identity profile. Matched pattern: Unusual Login Time.	HIGH	Enforce time-based access policies. Alert security team for off-hours privileged access.	{}	2026-04-22 03:03:22.720738
240db33e-d28f-40c5-94c6-1657c3906bba	7e138bd9-cf03-430c-a0be-405da3b6d3b0	BEHAVIOUR	Brute Force / Password Spray	Risk signal detected based on submitted identity profile. Matched pattern: Brute Force / Password Spray.	CRITICAL	Lock account after 5 failed attempts. Implement CAPTCHA and IP-based rate limiting.	{}	2026-04-22 03:03:22.720742
c155c151-01af-4310-a10d-9c7008d7540e	7e138bd9-cf03-430c-a0be-405da3b6d3b0	CREDENTIAL	No MFA Enforced	Risk signal detected based on submitted identity profile. Matched pattern: No MFA Enforced.	CRITICAL	Enforce MFA immediately for all accounts, especially privileged users.	{}	2026-04-22 03:03:22.720747
8160a9e4-ac14-4ac8-8681-35d22721b1b2	7e138bd9-cf03-430c-a0be-405da3b6d3b0	CREDENTIAL	Weak Password Policy	Risk signal detected based on submitted identity profile. Matched pattern: Weak Password Policy.	HIGH	Enforce minimum 16-character passwords with complexity. Use a password manager.	{}	2026-04-22 03:03:22.720751
080fcb00-6643-46c8-ae36-2ffaa57a491f	7e138bd9-cf03-430c-a0be-405da3b6d3b0	CREDENTIAL	Hardcoded Credentials Detected	Risk signal detected based on submitted identity profile. Matched pattern: Hardcoded Credentials Detected.	CRITICAL	Remove hardcoded credentials immediately. Rotate all exposed secrets and use a vault.	{}	2026-04-22 03:03:22.720757
fd449259-a309-4c3f-b6f7-26c2e012110f	7e138bd9-cf03-430c-a0be-405da3b6d3b0	CREDENTIAL	Long-lived Access Tokens	Risk signal detected based on submitted identity profile. Matched pattern: Long-lived Access Tokens.	HIGH	Rotate all access tokens every 90 days. Use short-lived tokens via OIDC where possible.	{}	2026-04-22 03:03:22.720762
c053c01f-c68f-48ac-ac77-2c834d9c77fe	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	PRIVILEGE	Admin Account Sprawl	Risk signal detected based on submitted identity profile. Matched pattern: Admin Account Sprawl.	CRITICAL	Reduce admin accounts to minimum. Use just-in-time privileged access management.	{}	2026-04-22 03:05:57.370384
eda65ac1-7cbe-4bfa-9ec5-2ee234f58f53	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	PRIVILEGE	Stale/Dormant Account Detected	Risk signal detected based on submitted identity profile. Matched pattern: Stale/Dormant Account Detected.	HIGH	Disable or remove accounts inactive for more than 90 days. Implement automated deprovisioning.	{}	2026-04-22 03:05:57.370394
d766745a-c49e-496c-90d2-aa2105a08b02	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	PRIVILEGE	Over-Privileged Service Account	Risk signal detected based on submitted identity profile. Matched pattern: Over-Privileged Service Account.	HIGH	Apply least-privilege to all service accounts. Rotate credentials every 90 days.	{}	2026-04-22 03:05:57.370399
5c0389a4-a088-4330-8d01-3f2c3892ccd4	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	PRIVILEGE	Shared Account Usage	Risk signal detected based on submitted identity profile. Matched pattern: Shared Account Usage.	CRITICAL	Eliminate shared accounts. Assign individual accounts for full audit trail.	{}	2026-04-22 03:05:57.370403
9086614a-ed06-4147-a239-d12010670dba	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	PRIVILEGE	Excessive Cloud IAM Permissions	Risk signal detected based on submitted identity profile. Matched pattern: Excessive Cloud IAM Permissions.	HIGH	Replace wildcard IAM policies with granular least-privilege policies.	{}	2026-04-22 03:05:57.370407
b4f72401-5ca1-454e-8edb-a5f72d1f8b72	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	BEHAVIOUR	Impossible Travel Detected	Risk signal detected based on submitted identity profile. Matched pattern: Impossible Travel Detected.	CRITICAL	Block session and require re-authentication. Investigate with user and manager immediately.	{}	2026-04-22 03:05:57.370412
66abea56-58e1-48a7-8a28-6a2a643fd022	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	BEHAVIOUR	Unusual Login Time	Risk signal detected based on submitted identity profile. Matched pattern: Unusual Login Time.	HIGH	Enforce time-based access policies. Alert security team for off-hours privileged access.	{}	2026-04-22 03:05:57.370416
245e0ae7-96f7-4670-b6ea-06196af31437	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	BEHAVIOUR	Brute Force / Password Spray	Risk signal detected based on submitted identity profile. Matched pattern: Brute Force / Password Spray.	CRITICAL	Lock account after 5 failed attempts. Implement CAPTCHA and IP-based rate limiting.	{}	2026-04-22 03:05:57.37042
3c3268ce-5610-49c2-8288-94cb95befee6	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	CREDENTIAL	No MFA Enforced	Risk signal detected based on submitted identity profile. Matched pattern: No MFA Enforced.	CRITICAL	Enforce MFA immediately for all accounts, especially privileged users.	{}	2026-04-22 03:05:57.370423
a5577b4b-f476-4648-9ca1-338cc6ef7ef5	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	CREDENTIAL	Weak Password Policy	Risk signal detected based on submitted identity profile. Matched pattern: Weak Password Policy.	HIGH	Enforce minimum 16-character passwords with complexity. Use a password manager.	{}	2026-04-22 03:05:57.370426
e10690e1-c6cd-4ffb-81ec-fdc7e6c4279c	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	CREDENTIAL	Hardcoded Credentials Detected	Risk signal detected based on submitted identity profile. Matched pattern: Hardcoded Credentials Detected.	CRITICAL	Remove hardcoded credentials immediately. Rotate all exposed secrets and use a vault.	{}	2026-04-22 03:05:57.37043
695947d8-a135-4d20-8cd2-d7b2eb811472	aeedcef1-68cc-4bd6-b46f-4d32264ec3df	CREDENTIAL	Long-lived Access Tokens	Risk signal detected based on submitted identity profile. Matched pattern: Long-lived Access Tokens.	HIGH	Rotate all access tokens every 90 days. Use short-lived tokens via OIDC where possible.	{}	2026-04-22 03:05:57.370434
\.


--
-- Data for Name: ig_edges; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ig_edges (id, source_id, target_id, relationship, weight, is_risky, created_at) FROM stdin;
1	1	5	manages	3	f	2026-04-17 20:48:17.400787
2	2	5	uses	2	f	2026-04-17 20:48:17.400791
3	3	10	assumes	5	t	2026-04-17 20:48:17.400792
4	4	7	accesses	5	t	2026-04-17 20:48:17.400793
5	5	7	scans	1	f	2026-04-17 20:48:17.400793
6	7	8	communicates	4	t	2026-04-17 20:48:17.400794
7	9	10	assumes	5	t	2026-04-17 20:48:17.400794
8	10	8	accesses	5	t	2026-04-17 20:48:17.400795
9	12	10	member_of	5	t	2026-04-17 20:48:17.400795
10	1	11	manages	2	f	2026-04-17 20:48:17.400796
11	6	8	accesses	3	t	2026-04-17 20:48:17.400796
\.


--
-- Data for Name: ig_identities; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ig_identities (id, name, identity_type, email, source, risk_score, blast_radius, is_privileged, is_dormant, is_overprivileged, last_active, permissions, tags, created_at) FROM stdin;
1	admin@aipet.io	human	admin@aipet.io	Active Directory	25	0	t	f	f	2026-04-17 18:48:17.334624	["platform.admin", "scan.run", "users.manage"]	["admin", "privileged", "mfa"]	2026-04-17 20:48:17.383353
2	john.smith@aipet.io	human	john.smith@aipet.io	Active Directory	15	0	t	f	f	2026-04-17 15:48:17.334624	["scan.run", "findings.view", "siem.view"]	["analyst", "soc", "mfa"]	2026-04-17 20:48:17.383362
3	sarah.jones@aipet.io	human	sarah.jones@aipet.io	Active Directory	72	0	t	t	t	2026-03-03 19:48:17.334624	["aws.prod.assume", "platform.admin"]	["manager", "no-mfa", "dormant"]	2026-04-17 20:48:17.389604
4	contractor_01	human	contractor@external.com	Manual	88	0	f	t	f	2026-01-15 19:48:17.334624	["iot.gateway.access"]	["contractor", "external", "no-mfa", "dormant"]	2026-04-17 20:48:17.391643
5	svc-scanner	service	\N	AIPET Platform	45	0	t	f	f	2026-04-17 20:18:17.334624	["network.scan", "device.read"]	["service", "automation", "scanner"]	2026-04-17 20:48:17.391648
6	svc-backup	service	\N	Infrastructure	30	0	f	f	f	2026-04-17 14:48:17.334624	["data.read", "storage.write"]	["service", "backup"]	2026-04-17 20:48:17.391649
7	iot-gateway-01	device	\N	IoT Discovery	60	0	f	f	f	2026-04-17 20:43:17.334624	["plc.communicate", "mqtt.publish"]	["device", "iot", "gateway"]	2026-04-17 20:48:17.391649
8	plc-controller-01	device	\N	OT Discovery	90	0	f	f	f	2026-04-17 20:47:17.334624	["process.control", "register.write"]	["device", "ot", "critical", "plc"]	2026-04-17 20:48:17.39165
9	api-key-ci-cd	api_key	\N	DevOps	55	0	t	f	t	2026-04-17 19:48:17.334624	["aws.prod.assume", "deploy.run"]	["api-key", "cicd", "devops"]	2026-04-17 20:48:17.39489
10	aws-iam-role-prod	cloud_role	\N	AWS IAM	70	0	t	f	t	2026-04-17 17:48:17.334624	["aws.ec2.*", "aws.s3.*", "aws.iam.read"]	["cloud", "aws", "iam", "privileged"]	2026-04-17 20:48:17.394893
11	azure-sp-monitoring	cloud_role	\N	Azure AD	20	0	f	f	f	2026-04-17 12:48:17.334624	["azure.monitor.read", "azure.logs.read"]	["cloud", "azure", "monitoring"]	2026-04-17 20:48:17.396515
12	ghost-account-2023	human	former.employee@aipet.io	Active Directory	95	0	t	t	f	2025-04-02 20:48:17.334624	["aws.prod.assume", "platform.admin"]	["ghost", "former-employee", "critical", "dormant"]	2026-04-17 20:48:17.396519
\.


--
-- Data for Name: ig_risks; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ig_risks (id, identity_id, risk_type, severity, description, remediation, resolved, created_at) FROM stdin;
1	12	ghost_account	Critical	Former employee account inactive 380 days still has AWS Production Role access. Immediate deprovisioning required.	Disable account immediately. Revoke all permissions. Audit last 90 days of activity.	f	2026-04-17 20:48:17.407076
2	4	dormant_privileged	Critical	External contractor inactive 92 days still has IoT Gateway access. Violates least-privilege and contractor off-boarding policy.	Disable account. Revoke IoT gateway access. Review contractor off-boarding process.	f	2026-04-17 20:48:17.407082
3	3	no_mfa_privileged	High	Privileged IT Manager with AWS Production Role has no MFA. Single-factor auth on privileged account.	Enforce MFA immediately. Block AWS console access until MFA enrolled.	f	2026-04-17 20:48:17.407083
4	10	privilege_escalation	Critical	AWS Production IAM role accessible from OT network segment. Cloud-to-OT privilege escalation path confirmed.	Implement network-based IAM conditions. Restrict role assumption to corporate network only.	f	2026-04-17 20:48:17.407084
5	9	excessive_privilege	High	CI/CD pipeline API key can assume AWS Production role. Build system compromise = full production access.	Create dedicated limited CI/CD role. Apply least-privilege. Rotate API key immediately.	f	2026-04-17 20:48:17.407085
6	8	lateral_movement	Critical	Critical OT asset reachable via 4 separate identity paths including ghost account and cloud role.	Implement OT network segmentation. Allow only svc-scanner read access. Block all other identity paths.	f	2026-04-17 20:48:17.407086
\.


--
-- Data for Name: ioc_entries; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ioc_entries (id, feed_id, ioc_type, value, threat_type, confidence, severity, description, source_ref, active, created_at, expires_at) FROM stdin;
1	1	ip	185.220.101.45	tor_exit_node	95	High	Known Tor exit node — frequently used for anonymous scanning and attacks	https://www.dan.me.uk/torlist/	t	2026-04-16 15:36:54.69434	\N
3	1	ip	45.142.212.100	scanner	85	Medium	Mass internet scanner — performs automated IoT vulnerability scanning on port 23, 2323, 8080	https://www.shodan.io	t	2026-04-16 15:36:54.694351	\N
4	1	ip	194.165.16.78	botnet	92	Critical	Active botnet C2 — recruiting vulnerable IoT devices via default credential brute force	https://threatfox.abuse.ch	t	2026-04-16 15:36:54.694352	\N
5	1	domain	malware-c2.duckdns.org	c2	99	Critical	Dynamic DNS domain used as C2 for IoT malware — seen in Mozi botnet traffic	https://abuse.ch	t	2026-04-16 15:36:54.694353	\N
6	1	ip	5.188.206.14	malware	88	High	Malware distribution server — hosts IoT exploit payloads targeting CVE-2023-1389	https://threatfox.abuse.ch	t	2026-04-16 15:36:54.694353	\N
7	1	ip	80.82.77.33	scanner	78	Medium	Shodan crawler — automated internet-wide scanning. Not malicious but indicates your device is visible	https://www.shodan.io	t	2026-04-16 15:36:54.694354	\N
8	1	hash	d41d8cd98f00b204e9800998ecf8427e	malware	100	Critical	Known IoT malware hash — Mirai variant targeting MIPS architecture devices	https://www.virustotal.com	t	2026-04-16 15:36:54.694354	\N
\.


--
-- Data for Name: ioc_feeds; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ioc_feeds (id, name, feed_type, description, enabled, api_key, last_sync, entry_count, created_at) FROM stdin;
2	AbuseIPDB	abuseipdb	Crowdsourced malicious IP database — 3M+ reported IPs, 1,000 free lookups/day	t	\N	\N	0	2026-04-16 15:36:54.680814
1	Local IOC Database	local	Manually curated indicators — your own threat hunting, IR findings, ISAC sharing	t	\N	2026-04-16 15:36:54.678626	8	2026-04-16 15:36:54.680809
\.


--
-- Data for Name: ir_incidents; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ir_incidents (id, title, description, status, priority, affected, attack_vector, mitre_id, assigned_to, timeline_ref, resolution, lessons, created_by, created_at, resolved_at, sla_hours) FROM stdin;
2	Default Credentials Found on PLC Controller	Red team campaign discovered admin:admin credentials valid on PLC Controller 10.0.1.10. Critical OT asset at risk.	containing	P2	10.0.1.10 (PLC Controller)	Valid Accounts — Default Credentials	T1078	OT Security Team	\N	\N	\N	\N	2026-04-17 04:24:50.964992	\N	24
1	Ransomware C2 Communication Detected — Production Network	SIEM detected outbound communication to known ransomware C2 server from device 192.168.1.45. Immediate isolation required.	open	P1	192.168.1.45, 192.168.1.0/24	Command and Control via HTTPS	T1071	SOC Team	\N	\N	\N	\N	2026-04-17 14:24:50.964992	2026-04-17 16:49:52.060682	4
3	Anomalous Traffic Spike on IoT Gateway	IoT Gateway generating 400% above baseline traffic. Investigation revealed misconfigured device sending duplicate telemetry.	containing	P3	192.168.1.5 (IoT Gateway)	Misconfiguration — not malicious	\N	IT Team	\N	Device firmware updated to v2.3.1. Duplicate telemetry bug fixed. Traffic returned to normal baseline.	Implement automated traffic baseline monitoring. Set alerts at 150% threshold.	\N	2026-04-14 16:24:50.964992	2026-04-15 16:24:50.964992	72
\.


--
-- Data for Name: ir_tasks; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ir_tasks (id, incident_id, title, description, status, assigned_to, created_at, completed_at) FROM stdin;
1	1	Isolate device 192.168.1.45 from network	\N	completed	\N	2026-04-17 16:24:50.976711	2026-04-17 15:24:50.964992
2	1	Capture memory dump and forensic image	\N	completed	\N	2026-04-17 16:24:50.976718	2026-04-17 15:24:50.964992
4	1	Scan all devices for lateral movement	\N	pending	\N	2026-04-17 16:24:50.97672	\N
5	1	Notify stakeholders and management	\N	pending	\N	2026-04-17 16:24:50.976721	\N
6	1	Restore device from clean backup	\N	pending	\N	2026-04-17 16:24:50.976722	\N
7	1	Review and update firewall rules	\N	pending	\N	2026-04-17 16:24:50.976722	\N
8	1	Document full incident timeline	\N	pending	\N	2026-04-17 16:24:50.976723	\N
9	2	Change default credentials immediately	\N	completed	\N	2026-04-17 16:24:50.982852	2026-04-17 08:24:50.964992
10	2	Audit all OT devices for default credentials	\N	completed	\N	2026-04-17 16:24:50.982858	2026-04-17 08:24:50.964992
11	2	Review PLC access logs for unauthorized access	\N	in_progress	\N	2026-04-17 16:24:50.982859	\N
12	2	Implement network segmentation for OT zone	\N	pending	\N	2026-04-17 16:24:50.982859	\N
13	2	Update password policy for OT devices	\N	pending	\N	2026-04-17 16:24:50.98286	\N
14	2	Document remediation steps	\N	pending	\N	2026-04-17 16:24:50.98286	\N
15	2	Verify fix with follow-up scan	\N	pending	\N	2026-04-17 16:24:50.982861	\N
16	2	Update asset inventory	\N	pending	\N	2026-04-17 16:24:50.982861	\N
17	3	Isolate IoT Gateway for investigation	\N	completed	\N	2026-04-17 16:24:50.985546	2026-04-15 16:24:50.964992
18	3	Capture and analyse traffic packets	\N	completed	\N	2026-04-17 16:24:50.985551	2026-04-15 16:24:50.964992
19	3	Identify root cause of traffic spike	\N	completed	\N	2026-04-17 16:24:50.985552	2026-04-15 16:24:50.964992
20	3	Apply firmware update	\N	completed	\N	2026-04-17 16:24:50.985552	2026-04-15 16:24:50.964992
21	3	Verify traffic returned to normal	\N	completed	\N	2026-04-17 16:24:50.985553	2026-04-15 16:24:50.964992
22	3	Update monitoring thresholds	\N	completed	\N	2026-04-17 16:24:50.985553	2026-04-15 16:24:50.964992
23	3	Document incident for lessons learned	\N	completed	\N	2026-04-17 16:24:50.985554	2026-04-15 16:24:50.964992
24	3	Brief team on findings	\N	completed	\N	2026-04-17 16:24:50.985554	2026-04-15 16:24:50.964992
3	1	Identify C2 server and block at firewall	\N	completed	\N	2026-04-17 16:24:50.976719	2026-04-17 16:48:47.198206
\.


--
-- Data for Name: itdr_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.itdr_findings (id, scan_id, attack_type, title, severity, affected_identity, mitre_tactic, mitre_technique, description, remediation, urgency, node_meta, created_at) FROM stdin;
b34b2987-c8a6-451b-b734-71fbc867aedd	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	Kerberos Attack	Golden Ticket Attack Detected	CRITICAL	Active Directory Identity	Lateral Movement	T1550.003 — Use Alternate Authentication Material	Identity threat detected: Golden Ticket Attack Detected. This is an active IMMEDIATE priority threat requiring immediate investigation.	Reset krbtgt password TWICE with 10-hour gap. Invalidate all Kerberos tickets. Audit all domain admin activity immediately.	IMMEDIATE	{}	2026-04-22 18:44:55.686672
33e19bff-27cd-4ca0-bdeb-453d469636f0	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	Kerberos Attack	Kerberoasting Attack Detected	HIGH	Active Directory Identity	Credential Access	T1558.003 — Kerberoasting	Identity threat detected: Kerberoasting Attack Detected. This is an active HIGH priority threat requiring immediate investigation.	Use strong 25+ char passwords for service accounts. Enable AES encryption. Audit SPN accounts. Use gMSA where possible.	HIGH	{}	2026-04-22 18:44:55.686683
2997dd7b-80ee-4829-a0d3-fdc813322716	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	NTLM Attack	Pass-the-Hash Attack Detected	CRITICAL	Active Directory Identity	Lateral Movement	T1550.002 — Pass the Hash	Identity threat detected: Pass-the-Hash Attack Detected. This is an active IMMEDIATE priority threat requiring immediate investigation.	Enable Protected Users group. Disable NTLM where possible. Deploy PAM. Enable Windows Defender Credential Guard.	IMMEDIATE	{}	2026-04-22 18:44:55.686688
8d69b552-77b3-4788-b8b9-3e2a00c2f41a	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	NTLM Attack	NTLM Relay Attack	CRITICAL	Active Directory Identity	Credential Access	T1557.001 — LLMNR/NBT-NS Poisoning	Identity threat detected: NTLM Relay Attack. This is an active IMMEDIATE priority threat requiring immediate investigation.	Disable LLMNR and NBT-NS. Enable SMB signing. Deploy EPA (Extended Protection for Authentication).	IMMEDIATE	{}	2026-04-22 18:44:55.686692
f0ca4fc1-7fa5-4390-985b-abeb8b8da067	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	MFA Attack	MFA Fatigue Attack Detected	CRITICAL	Active Directory Identity	Credential Access	T1621 — Multi-Factor Authentication Request Generation	Identity threat detected: MFA Fatigue Attack Detected. This is an active IMMEDIATE priority threat requiring immediate investigation.	Enable number matching in MFA. Limit MFA push notifications. Block after 3 failed MFA attempts. Switch to FIDO2.	IMMEDIATE	{}	2026-04-22 18:44:55.686695
d492e6b3-db62-42c6-a26c-08795f5e4150	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	Privilege Escalation	DCSync Attack Detected	CRITICAL	Active Directory Identity	Credential Access	T1003.006 — DCSync	Identity threat detected: DCSync Attack Detected. This is an active IMMEDIATE priority threat requiring immediate investigation.	Remove unauthorised replication rights. Audit DCSync permissions. Monitor for DS-Replication-Get-Changes events.	IMMEDIATE	{}	2026-04-22 18:44:55.686699
aa41da07-56fa-4095-9c97-cce95abc88b7	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	Privilege Escalation	Domain Admin Account Compromise	CRITICAL	Active Directory Identity	Privilege Escalation	T1078.002 — Domain Accounts	Identity threat detected: Domain Admin Account Compromise. This is an active IMMEDIATE priority threat requiring immediate investigation.	Reset domain admin credentials. Rotate krbtgt. Audit all actions by compromised account. Implement PAW model.	IMMEDIATE	{}	2026-04-22 18:44:55.686702
b42c3517-9d47-43d2-9b40-ed7cc5b5641b	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	Identity Reconnaissance	LDAP Enumeration Detected	HIGH	Active Directory Identity	Discovery	T1087.002 — Domain Account Discovery	Identity threat detected: LDAP Enumeration Detected. This is an active HIGH priority threat requiring immediate investigation.	Enable LDAP signing and channel binding. Monitor for bulk LDAP queries. Restrict AD enumeration permissions.	HIGH	{}	2026-04-22 18:44:55.686705
642bf950-ad73-42a3-a7ce-28ac27fb2407	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	Identity Reconnaissance	BloodHound AD Reconnaissance	HIGH	Active Directory Identity	Discovery	T1087 — Account Discovery	Identity threat detected: BloodHound AD Reconnaissance. This is an active HIGH priority threat requiring immediate investigation.	Monitor for BloodHound collection patterns. Enable advanced audit policies. Restrict AD read permissions.	HIGH	{}	2026-04-22 18:44:55.686708
57117074-9a39-4505-a363-258fdbce0e90	c11e99c9-cd80-4235-9df8-a31a0bdb38fa	Account Manipulation	Unauthorized Group Membership Change	CRITICAL	Active Directory Identity	Persistence	T1098 — Account Manipulation	Identity threat detected: Unauthorized Group Membership Change. This is an active IMMEDIATE priority threat requiring immediate investigation.	Revert group membership. Investigate who made the change. Enable alerting on privileged group modifications.	IMMEDIATE	{}	2026-04-22 18:44:55.686712
\.


--
-- Data for Name: itdr_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.itdr_scans (id, user_id, environment, identity_store, risk_score, severity, total_findings, critical_count, identities_compromised, summary, created_at, node_meta) FROM stdin;
c11e99c9-cd80-4235-9df8-a31a0bdb38fa	1	production	active_directory	100	CRITICAL	10	7	6	ITDR scan complete for production Active Directory. Risk: 100.0/100. 10 identity threat(s) — 7 critical, 7 immediate. 6 attack type(s) detected.	2026-04-22 18:44:55.680413	{}
\.


--
-- Data for Name: k8s_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.k8s_findings (id, scan_id, category, title, severity, resource_type, namespace, description, remediation, cis_ref, node_meta, created_at) FROM stdin;
ecaa4efd-c1aa-4e6d-8265-cadab3772c03	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	Pod Security	Privileged Pod Running	CRITICAL	Pod	default	Kubernetes misconfiguration detected: Privileged Pod Running in cluster my-cluster.	Set privileged: false and allowPrivilegeEscalation: false in securityContext.	CIS K8s 5.2.1	{}	2026-04-22 17:41:16.629776
ea497b60-ca74-4852-9b98-bcec9ee16845	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	RBAC	ClusterAdmin Role Binding	CRITICAL	ClusterRoleBinding	default	Kubernetes misconfiguration detected: ClusterAdmin Role Binding in cluster my-cluster.	Remove cluster-admin bindings. Apply least-privilege RBAC. Use namespace-scoped roles.	CIS K8s 5.1.1	{}	2026-04-22 17:41:16.629789
966acb54-e4c7-431d-b694-ae44c04936d3	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	RBAC	Service Account with Excessive Permissions	HIGH	ServiceAccount	default	Kubernetes misconfiguration detected: Service Account with Excessive Permissions in cluster my-cluster.	Set automountServiceAccountToken: false. Bind only required permissions to service accounts.	CIS K8s 5.1.6	{}	2026-04-22 17:41:16.629792
358bcf46-3bd0-413f-a418-ed8770e1400d	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	RBAC	Default Service Account Used	MEDIUM	ServiceAccount	default	Kubernetes misconfiguration detected: Default Service Account Used in cluster my-cluster.	Create dedicated service accounts per workload. Disable default service account token mounting.	CIS K8s 5.1.5	{}	2026-04-22 17:41:16.629797
6e8a8c1b-8b90-49b2-be91-39a6c9fd5cff	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	RBAC	Wildcard Permissions in Role	CRITICAL	Role	default	Kubernetes misconfiguration detected: Wildcard Permissions in Role in cluster my-cluster.	Replace wildcard permissions with explicit resource and verb lists. Apply principle of least privilege.	CIS K8s 5.1.3	{}	2026-04-22 17:41:16.6298
958a6d00-22b7-4a33-a8ab-336d357dc5e3	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	Secrets Management	Secrets Not Encrypted at Rest	CRITICAL	Secret	default	Kubernetes misconfiguration detected: Secrets Not Encrypted at Rest in cluster my-cluster.	Enable EncryptionConfiguration for etcd. Use KMS provider for envelope encryption of secrets.	CIS K8s 1.2.33	{}	2026-04-22 17:41:16.629803
c1b8da27-ee91-442b-b3fa-5339d71ed23d	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	Secrets Management	Secret Mounted as Environment Variable	HIGH	Pod	default	Kubernetes misconfiguration detected: Secret Mounted as Environment Variable in cluster my-cluster.	Mount secrets as files via CSI driver, not environment variables. Use Vault agent injector.	CIS K8s 5.4.1	{}	2026-04-22 17:41:16.629806
df652a50-6f5b-48cf-9117-55be54a107fe	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	Control Plane	API Server Anonymous Auth Enabled	CRITICAL	APIServer	default	Kubernetes misconfiguration detected: API Server Anonymous Auth Enabled in cluster my-cluster.	Set --anonymous-auth=false on API server. Require authentication for all API requests.	CIS K8s 1.2.1	{}	2026-04-22 17:41:16.629808
f33d8ba8-376e-494d-97ed-756c281ced56	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	Control Plane	Admission Controllers Not Configured	HIGH	APIServer	default	Kubernetes misconfiguration detected: Admission Controllers Not Configured in cluster my-cluster.	Enable Pod Security Admission. Deploy OPA Gatekeeper for policy enforcement.	CIS K8s 1.2.10	{}	2026-04-22 17:41:16.630002
5f445f6b-f6d9-4076-a568-94cd6cc37c1e	cf3187c8-668f-4337-9f6a-9c9ea4f131bf	Image Security	Image Pulled Without Digest	MEDIUM	Pod	default	Kubernetes misconfiguration detected: Image Pulled Without Digest in cluster my-cluster.	Pin all images to specific SHA256 digest. Never use :latest tag in production.	CIS K8s 5.5.1	{}	2026-04-22 17:41:16.630014
\.


--
-- Data for Name: k8s_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.k8s_scans (id, user_id, cluster_name, k8s_version, risk_score, severity, total_findings, critical_count, summary, created_at, node_meta) FROM stdin;
cf3187c8-668f-4337-9f6a-9c9ea4f131bf	1	my-cluster	1.28	100	CRITICAL	10	5	K8s Runtime Analysis complete for cluster my-cluster (v1.28). Risk: 100.0/100. 10 finding(s) — 5 critical across 5 categories.	2026-04-22 17:41:16.624862	{}
\.


--
-- Data for Name: log_analysis_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.log_analysis_reports (id, user_id, log_source, total_lines, error_count, warning_count, anomaly_count, security_events, risk_score, summary, findings, patterns, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: metrics_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.metrics_reports (id, user_id, service_name, trace_id, total_spans, error_spans, total_duration_ms, bottleneck, anomalies, summary, spans_data, metrics_data, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: mp_installs; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.mp_installs (id, plugin_id, user_id, config, enabled, installed_at) FROM stdin;
1	4	1	{}	t	2026-04-16 20:33:32.41759
\.


--
-- Data for Name: mp_plugins; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.mp_plugins (id, name, slug, description, long_desc, category, publisher, version, icon, tags, verified, free, price_gbp, install_count, avg_rating, review_count, active, created_at) FROM stdin;
1	Jira Security Tickets	jira-security-tickets	Automatically create Jira issues for every AIPET finding. Assign to teams, set priorities, track remediation.	Full bidirectional sync between AIPET findings and Jira. When AIPET discovers a Critical vulnerability, a P1 Jira ticket is created instantly with full context, CVSS score, and remediation steps. When the ticket is resolved in Jira, AIPET marks the finding as remediated.	integration	AIPET Official	2.1.0	🎫	["jira", "ticketing", "remediation", "devops"]	t	t	0	847	4.8	124	t	2026-01-16 19:30:21.764667
2	PagerDuty Incident Alerts	pagerduty-incidents	Route Critical AIPET SIEM events to PagerDuty. Wake up your on-call engineer when it matters.	Maps AIPET severity levels to PagerDuty urgency. Critical = P1 page. High = P2 alert. Includes escalation policies and acknowledgement sync.	integration	AIPET Official	1.3.2	📟	["pagerduty", "oncall", "alerting", "sre"]	t	t	0	612	4.7	89	t	2026-01-31 19:30:21.764667
3	ServiceNow ITSM Bridge	servicenow-itsm	Enterprise ITSM integration. Sync AIPET findings with ServiceNow incidents, change requests, and CMDB.	Connects AIPET X to ServiceNow via REST API. Findings become incidents. Device inventory syncs to CMDB. Compliance results trigger change requests. Full audit trail maintained in both systems.	integration	SecureOps Ltd	1.0.5	🔧	["servicenow", "itsm", "cmdb", "enterprise"]	t	f	29	234	4.5	41	t	2026-02-15 19:30:21.764667
5	Splunk HEC Forwarder	splunk-hec-forwarder	Forward all AIPET events to Splunk via HTTP Event Collector. Full JSON schema with sourcetype mappings included.	Streams AIPET SIEM events, scan findings, and compliance results to Splunk HEC in real time. Includes pre-built Splunk dashboards, saved searches, and alert configurations.	integration	Splunk Community	3.0.1	📊	["splunk", "siem", "log-management", "analytics"]	t	t	0	489	4.6	67	t	2026-01-26 19:30:21.764667
6	Zigbee Security Scanner	zigbee-scanner	Scan Zigbee mesh networks for security issues. Detects unencrypted traffic, weak keys, and rogue devices.	Full Zigbee security assessment including network key extraction, device enumeration, traffic capture, and replay attack detection. Requires Zigbee USB adapter (CC2531 or similar).	scan_module	IoTSec Research	1.2.0	📡	["zigbee", "wireless", "iot", "mesh"]	t	f	49	156	4.4	28	t	2026-03-02 19:30:21.764667
7	LoRaWAN Security Audit	lorawan-audit	Assess LoRaWAN network security. Tests join procedure, frame counter, and ABP vs OTAA configuration.	Comprehensive LoRaWAN security assessment covering AppKey/NwkKey exposure, DevEUI enumeration, frame counter replay, and ADR manipulation. Essential for smart city and industrial IoT deployments.	scan_module	IoTSec Research	1.0.3	📻	["lorawan", "lpwan", "wireless", "smart-city"]	t	f	49	98	4.3	19	t	2026-03-17 19:30:21.764667
8	CVE Auto-Enricher	cve-auto-enricher	Automatically enrich every finding with EPSS scores, PoC availability, and active exploitation status from multiple threat intel sources.	Integrates with NVD, ExploitDB, CISA KEV, and AttackerKB to provide real-time exploit availability scores. Shows whether a CVE has active exploits in the wild, EPSS probability scores, and CISA Known Exploited status.	scan_module	AIPET Official	2.0.0	🔍	["cve", "enrichment", "threat-intel", "epss"]	t	t	0	723	4.9	145	t	2026-01-06 19:30:21.764667
9	ISO 27001 Compliance Report	iso-27001-report	Generate audit-ready ISO 27001 compliance reports from AIPET scan data. Maps all findings to Annex A controls.	Professional ISO 27001 report template with automatic control mapping, gap analysis, risk register, and statement of applicability. Accepted by major certification bodies including BSI, Lloyd's Register, and Bureau Veritas.	report_template	CompliancePro	3.1.0	📋	["iso27001", "compliance", "audit", "certification"]	t	f	79	312	4.7	54	t	2025-11-17 19:30:21.764667
10	NHS DSPT Assessment Template	nhs-dspt-template	Data Security and Protection Toolkit report template. Maps AIPET findings to DSPT assertions for NHS organisations.	Specifically designed for NHS trusts and healthcare organisations. Automatically maps IoT security findings to DSPT mandatory evidence items. Includes supporting evidence documentation and board-level summary.	report_template	HealthTech Security	2.0.1	🏥	["nhs", "dspt", "healthcare", "uk-compliance"]	t	f	99	187	4.8	38	t	2026-02-15 19:30:21.764667
11	NHS Cybersecurity AI Pack	nhs-ai-pack	Custom AI SOC analyst trained on NHS cybersecurity frameworks, DSPT requirements, and healthcare IoT threats.	Extends the AIPET AI SOC with NHS-specific knowledge including DSPT v6 requirements, NHS Digital security standards, clinical network segmentation best practices, and medical device cybersecurity guidance.	ai_pack	HealthTech Security	1.1.0	🤖	["nhs", "healthcare", "ai", "compliance"]	t	f	39	143	4.6	27	t	2026-03-07 19:30:21.764667
12	ICS/OT Specialist AI Pack	ics-ot-ai-pack	AI SOC analyst specialised in industrial control systems — Purdue Model, IEC 62443, NERC CIP, and OT incident response.	Deep expertise in industrial cybersecurity including IEC 62443 zone and conduit model, NERC CIP compliance for power utilities, ISA/IEC standards, and OT-specific incident response playbooks.	ai_pack	IndustrialCyber Ltd	1.0.2	🏭	["ics", "ot", "ai", "industrial"]	t	f	49	89	4.5	18	t	2026-03-22 19:30:21.764667
13	IoT Threat Intelligence Feed	iot-threat-feed	Daily updated IOC feed specifically for IoT devices — Mirai C2s, IoT botnet IPs, vulnerable firmware hashes.	Curated threat intelligence feed focused entirely on IoT threats. Updated daily with C2 servers, botnet infrastructure, known malicious IoT firmware hashes, and IP ranges associated with IoT-targeting threat actors.	threat_feed	ThreatFox Community	live	🎯	["threat-intel", "ioc", "iot", "botnet"]	t	t	0	534	4.7	92	t	2025-09-28 20:30:21.764667
14	CISA KEV Sync	cisa-kev-sync	Automatically flag AIPET findings that match CISA Known Exploited Vulnerabilities catalogue. Updated daily.	Syncs with CISA Known Exploited Vulnerabilities (KEV) catalogue daily. Any AIPET CVE finding that appears in the KEV catalogue is immediately flagged as actively exploited and escalated to Critical priority.	threat_feed	AIPET Official	1.4.0	🇺🇸	["cisa", "kev", "cve", "government"]	t	t	0	891	4.9	167	t	2025-10-18 20:30:21.764667
15	Executive Risk Dashboard	exec-risk-dashboard	Board-level security metrics widget. Clean, visual risk summary designed for non-technical executives.	A single-page executive dashboard widget showing: overall risk trend (30 days), top 3 risks in plain English, compliance status traffic lights, and financial exposure estimate. Designed to be shared at board meetings.	dashboard_widget	AIPET Official	1.2.0	📈	["executive", "dashboard", "reporting", "board"]	t	t	0	445	4.6	78	t	2026-01-16 19:30:21.764667
4	Microsoft Teams Alerts	ms-teams-alerts	Rich adaptive card notifications to Teams channels. Critical findings include device context, risk score, and one-click remediation links.	Beautiful adaptive cards with colour-coded severity, device details, MITRE ATT&CK mappings, and direct links to the AIPET dashboard. Supports multiple channel routing based on severity or device type.	integration	AIPET Official	1.5.0	💬	["teams", "microsoft", "notifications", "collaboration"]	t	t	0	1204	4.9	201	t	2025-12-17 19:30:21.764667
\.


--
-- Data for Name: mp_reviews; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.mp_reviews (id, plugin_id, user_id, rating, review, created_at) FROM stdin;
\.


--
-- Data for Name: multicloud_scale_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.multicloud_scale_reports (id, user_id, total_providers, total_regions, total_workloads, security_score, cost_risk_score, scale_issues, summary, recommendations, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: network_exposure_assets; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.network_exposure_assets (id, scan_id, asset_type, asset_name, exposure_level, public_ip, open_ports, risk_level, node_meta, created_at) FROM stdin;
7a2913e1-d7ce-43b3-b873-30cdbc72fe3a	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Web Server	Web Server (production)	PUBLIC — EXPOSED	0.0.0.0	80,443	MEDIUM	{}	2026-04-22 17:47:53.038648
47e91ac8-10c0-4bae-b775-52c6e7be1742	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Database Server	Database Server (production)	PUBLIC — EXPOSED	0.0.0.0	3306,5432,27017,6379	CRITICAL	{}	2026-04-22 17:47:53.038657
c5ee8bb0-c97a-44c1-ad28-2d094cc3a861	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Admin Console	Admin Console (production)	PUBLIC — EXPOSED	0.0.0.0	22,3389,8443	MEDIUM	{}	2026-04-22 17:47:53.038661
e968b70f-ca8d-473f-b2f9-710d8c0e2334	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Storage Bucket	Storage Bucket (production)	PUBLIC — EXPOSED	0.0.0.0	443	CRITICAL	{}	2026-04-22 17:47:53.038664
872a155b-4b83-46ac-a152-0ac04e716fe6	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Message Queue	Message Queue (production)	PUBLIC — EXPOSED	0.0.0.0	9092,5672	CRITICAL	{}	2026-04-22 17:47:53.038666
ddf0aa0b-95e4-47be-aa1d-329a62d297c2	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Cache Layer	Cache Layer (production)	PUBLIC — EXPOSED	0.0.0.0	6379,11211	CRITICAL	{}	2026-04-22 17:47:53.038669
\.


--
-- Data for Name: network_exposure_paths; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.network_exposure_paths (id, scan_id, path_type, source, destination, severity, protocol, port, description, remediation, node_meta, created_at) FROM stdin;
3186c9f9-cc10-4cf8-bac9-14e549502646	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Internet Exposure	Internet	Storage Bucket	CRITICAL	HTTPS	443	Exposure path detected: Storage Bucket Publicly Readable in production AWS environment.	Enable Block Public Access. Remove public ACLs. Use pre-signed URLs for authorized access.	{}	2026-04-22 17:47:53.041115
88733d99-068e-419b-910e-7fbd42231c64	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Lateral Movement	Compromised Host	Internal Services	HIGH	ANY	ANY	Exposure path detected: Unrestricted East-West Traffic in production AWS environment.	Implement micro-segmentation. Deploy Zero Trust network policies. Restrict service-to-service communication.	{}	2026-04-22 17:47:53.041123
0cf6a26f-0381-456d-ba72-563636ebd6bc	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Data Exfiltration	Internal Network	Internet	HIGH	ANY	ANY	Exposure path detected: Unrestricted Outbound Internet Access in production AWS environment.	Implement egress filtering via NAT Gateway with restricted routes. Block unexpected outbound connections.	{}	2026-04-22 17:47:53.041127
27740dc5-b2b2-4979-a5a8-baabd54c5764	d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	Privilege Path	Internet	Admin/Root Access	CRITICAL	HTTPS	443	Exposure path detected: Public-to-Admin Privilege Escalation Path in production AWS environment.	Break the escalation path. Enforce MFA on all privileged access. Deploy PAM solution.	{}	2026-04-22 17:47:53.04113
\.


--
-- Data for Name: network_exposure_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.network_exposure_scans (id, user_id, environment, cloud_provider, risk_score, severity, total_paths, critical_paths, exposed_assets, summary, created_at, node_meta) FROM stdin;
d4e39fb2-260d-4784-83f5-d6f0c4ea81f2	1	production	aws	69	HIGH	4	2	6	Network Exposure Graph scan complete for AWS production. Risk: 69.0/100. 4 exposure path(s) — 2 critical. 6 asset(s) mapped.	2026-04-22 17:47:53.033438	{}
\.


--
-- Data for Name: nv_edges; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.nv_edges (id, source_id, target_id, protocol, port, encrypted, risk_level, cross_zone, bidirectional, traffic_gbday, created_at) FROM stdin;
1	1	2	HTTPS	443	t	low	t	t	45.2	2026-04-18 20:17:41.591551
2	1	4	IPSec	500	t	low	t	t	12.1	2026-04-18 20:17:41.591557
3	1	8	SMTP	25	t	medium	t	t	5.3	2026-04-18 20:17:41.591558
4	1	10	HTTP	80	f	critical	t	t	89.4	2026-04-18 20:17:41.591559
5	2	5	HTTPS	443	t	low	t	t	23.4	2026-04-18 20:17:41.59156
6	3	5	HTTP	8080	f	high	t	t	8.9	2026-04-18 20:17:41.59156
7	4	7	IPSec	4500	t	low	t	t	4.2	2026-04-18 20:17:41.591561
8	5	9	PostgreSQL	5432	f	critical	t	t	12.3	2026-04-18 20:17:41.591561
9	5	12	TCP	6379	t	low	f	t	3.4	2026-04-18 20:17:41.591562
10	5	11	HTTPS	443	t	low	t	f	7.8	2026-04-18 20:17:41.591562
11	6	13	LDAP	389	f	critical	t	t	0.5	2026-04-18 20:17:41.591563
12	7	16	TCP	443	t	medium	t	t	2.1	2026-04-18 20:17:41.591563
13	13	14	OPC-UA	4840	f	medium	f	t	15.6	2026-04-18 20:17:41.591564
14	13	15	RDP	3389	f	high	f	t	1.2	2026-04-18 20:17:41.591564
15	16	17	TCP	1883	f	high	t	t	8.9	2026-04-18 20:17:41.591564
16	17	18	Modbus	502	f	critical	f	t	2.3	2026-04-18 20:17:41.591565
17	17	19	RTSP	554	f	medium	f	f	45	2026-04-18 20:17:41.591565
18	17	20	DNP3	20000	f	critical	f	t	0.8	2026-04-18 20:17:41.591566
19	17	10	HTTP	80	f	critical	t	f	12.4	2026-04-18 20:17:41.591566
20	14	11	HTTPS	443	t	low	t	f	5.6	2026-04-18 20:17:41.591567
\.


--
-- Data for Name: nv_issues; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.nv_issues (id, node_id, edge_id, severity, title, description, remediation, status, created_at) FROM stdin;
1	9	\N	Critical	Patient database unencrypted at rest — 125K PHI records exposed	RDS storing PHI without encryption. Cross-zone connection also unencrypted.	Enable RDS encryption via KMS. Force SSL on all connections.	open	2026-04-18 20:17:41.597266
2	10	\N	Critical	S3 bucket with OT telemetry publicly accessible	IoT telemetry S3 bucket has public read access. 892GB exposed.	Block public access. Apply bucket policy. Enable SSE-KMS.	open	2026-04-18 20:17:41.597271
3	18	\N	Critical	PLC Controller reachable via 3 unencrypted network hops	Critical infrastructure accessible via Internet to PLC. All connections unencrypted.	Implement network segmentation. Encrypt all OT traffic.	open	2026-04-18 20:17:41.597272
4	20	\N	Critical	Water treatment controller connected to internet via unencrypted path	DNP3 traffic flows to internet-accessible S3 bucket unencrypted.	Isolate controller. Implement unidirectional gateway.	open	2026-04-18 20:17:41.597273
5	13	\N	Critical	SCADA server connected to corporate AD via unencrypted LDAP	AD communicating with SCADA using unencrypted LDAP. IT/OT boundary violation.	Replace LDAP with LDAPS. Implement OT-specific authentication.	open	2026-04-18 20:17:41.597274
6	5	\N	High	API Gateway to web server using HTTP (unencrypted)	Internal traffic using HTTP port 8080 — credentials exposed.	Configure HTTPS between API Gateway and origin.	open	2026-04-18 20:17:41.597274
7	6	\N	High	Active Directory bridging IT and OT networks	AD connected to both corporate and SCADA — bypasses OT firewall.	Separate OT authentication from corporate AD.	open	2026-04-18 20:17:41.597275
8	19	\N	High	24 IP cameras streaming over unencrypted RTSP	Camera footage transmitted without encryption.	Enable RTSPS. Segment camera VLAN.	open	2026-04-18 20:17:41.597275
9	15	\N	High	HMI terminal accessible via unencrypted RDP	RDP without NLA — session hijacking possible.	Enable NLA on RDP. Restrict to management VLAN.	open	2026-04-18 20:17:41.597276
10	17	\N	High	IoT Gateway routing OT data directly to public S3	Field device data bypassing controls flowing to internet-accessible storage.	Route IoT data through internal proxy.	open	2026-04-18 20:17:41.597276
\.


--
-- Data for Name: nv_nodes; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.nv_nodes (id, name, node_type, zone, cloud_provider, ip_address, region, risk_score, internet_facing, encrypted, issue_count, status, node_meta, created_at) FROM stdin;
3	API Gateway	gateway	dmz	AWS	52.45.123.20	eu-west-1	40	t	t	0	active	{"service": "AWS API Gateway"}	2026-04-18 20:17:41.577946
1	Internet	internet	internet	\N	0.0.0.0/0	\N	60	t	f	0	active	{"description": "Public internet"}	2026-04-18 20:17:41.577939
2	WAF / CDN	gateway	dmz	AWS	52.45.123.10	eu-west-1	30	t	t	0	active	{"service": "CloudFront+WAF"}	2026-04-18 20:17:41.577945
4	VPN Gateway	gateway	dmz	Azure	51.140.45.67	UK South	30	t	t	0	active	{"service": "Azure VPN"}	2026-04-18 20:17:41.577948
5	Web Application Server	server	corporate	AWS	10.0.1.10	eu-west-1	35	f	t	1	active	{"os": "Ubuntu 22.04"}	2026-04-18 20:17:41.577949
6	Active Directory	server	corporate	On-Premise	192.168.1.5	\N	25	f	t	1	active	{"os": "Windows Server 2019"}	2026-04-18 20:17:41.57795
7	Corporate Firewall	firewall	corporate	On-Premise	192.168.1.1	\N	0	f	t	0	active	{"vendor": "Palo Alto"}	2026-04-18 20:17:41.577951
8	Email Gateway	server	corporate	Azure	10.0.1.30	UK South	30	t	t	0	active	{"service": "Exchange Online"}	2026-04-18 20:17:41.577951
9	Patient Database (RDS)	database	cloud_private	AWS	10.0.2.10	us-east-1	45	f	f	1	active	{"engine": "PostgreSQL 14", "records": 125000}	2026-04-18 20:17:41.577952
10	IoT Data Lake (S3)	storage	cloud_private	AWS	s3.amazonaws.com	eu-west-1	85	t	f	1	active	{"size_gb": 892, "public": true}	2026-04-18 20:17:41.577953
11	Analytics Warehouse	database	cloud_private	GCP	10.0.3.10	europe-west2	0	f	t	0	active	{"service": "BigQuery"}	2026-04-18 20:17:41.577953
12	Redis Cache	server	cloud_private	AWS	10.0.2.20	eu-west-1	0	f	t	0	active	{"service": "ElastiCache"}	2026-04-18 20:17:41.577954
13	SCADA Server	server	ot	On-Premise	10.0.10.5	\N	45	f	f	1	active	{"software": "Wonderware"}	2026-04-18 20:17:41.577955
14	Historian Server	database	ot	On-Premise	10.0.10.6	\N	20	f	f	0	active	{"software": "OSIsoft PI"}	2026-04-18 20:17:41.577956
15	HMI Terminal	server	ot	On-Premise	10.0.10.10	\N	35	f	f	1	active	{"os": "Windows 10 LTSC"}	2026-04-18 20:17:41.577956
16	OT Firewall	firewall	ot	On-Premise	10.0.10.1	\N	10	f	t	0	active	{"vendor": "Fortinet"}	2026-04-18 20:17:41.577957
17	IoT Gateway	gateway	field	On-Premise	192.168.2.1	\N	55	f	f	1	active	{"protocols": ["MQTT", "Modbus"]}	2026-04-18 20:17:41.577957
18	PLC Controller	iot_device	field	On-Premise	192.168.2.10	\N	35	f	f	1	active	{"vendor": "Siemens", "model": "S7-1500"}	2026-04-18 20:17:41.577958
19	IP Camera Array	iot_device	field	On-Premise	192.168.2.20	\N	35	f	f	1	active	{"count": 24, "vendor": "Hikvision"}	2026-04-18 20:17:41.577959
20	Water Treatment Controller	iot_device	field	On-Premise	192.168.2.30	\N	35	f	f	1	active	{"vendor": "ABB", "safety": "critical"}	2026-04-18 20:17:41.57796
\.


--
-- Data for Name: ot_devices; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ot_devices (id, device_ip, device_name, protocol, port, vendor, model, firmware, zone, criticality, location, last_seen, online, created_at) FROM stdin;
1	10.0.1.10	Main Production PLC	modbus	502	Schneider Electric	Modicon M340	2.60	field	critical	Production Floor — Zone A	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889598
2	10.0.1.11	Water Treatment RTU	dnp3	20000	ABB	RTU560	11.7.3	field	critical	Water Treatment Plant — Building 3	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889602
3	10.0.2.20	Substation Protection IED	iec61850	102	Siemens	SIPROTEC 5	9.20	control	critical	Electrical Substation — Room 1	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889602
4	10.0.2.21	Assembly Line Controller	ethernetip	44818	Rockwell Automation	ControlLogix 5580	20.011	control	high	Assembly Line — Station 4	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889603
5	10.0.3.30	HVAC Building Controller	bacnet	47808	Johnson Controls	Metasys NAE55	10.0.5	supervisory	medium	Facilities — BMS Room	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889603
6	10.0.3.31	Pump Station RTU	modbus	502	Emerson	ROC800	3.80	field	high	Pump Station — Outbuilding 2	2026-04-16 17:38:20.887992	t	2026-04-16 19:38:20.889603
\.


--
-- Data for Name: ot_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ot_findings (id, scan_id, device_ip, protocol, finding_type, severity, title, description, evidence, mitre_ics_id, remediation, created_at) FROM stdin;
1	1	10.0.1.10	modbus	unauthenticated_access	Critical	Modbus TCP has no authentication — any device can send commands	Modbus TCP accepts commands without credentials. Main Production PLC (Schneider Modicon M340) is fully exposed.	Function code 0x01 accepted without credentials on Unit ID 1	T0817	Deploy Modbus firewall. Implement network segmentation.	2026-04-16 16:38:20.895533
2	1	10.0.1.10	modbus	coil_write_enabled	Critical	Modbus coil writing enabled — production line physically controllable	Write Multiple Coils (FC 0x0F) accepted. An attacker can directly start/stop the production line.	Function code 0x0F accepted on Unit ID 1, Coils 0-15	T0831	Block write function codes at firewall. Implement read-only Modbus proxy.	2026-04-16 16:38:20.895533
3	1	10.0.1.10	modbus	network_exposure	High	Modbus PLC reachable from corporate IT network	Production PLC TCP port 502 responds to connections from the corporate IT subnet — OT/IT boundary not enforced.	TCP port 502 responding from 10.0.1.10 to IT subnet 192.168.1.0/24	T0886	Implement industrial DMZ. Deploy data diode.	2026-04-16 16:38:20.895533
4	2	10.0.1.11	dnp3	unauthenticated_access	Critical	DNP3 Secure Authentication not enabled on water treatment RTU	DNP3 SA v5 not configured on Water Treatment RTU. Spoofed commands could open/close water treatment valves.	DNP3 master-outstation handshake without SA challenge	T0817	Enable DNP3 SA v5 with HMAC-SHA256.	2026-04-16 17:38:20.895533
5	2	10.0.1.11	dnp3	unencrypted_comms	High	DNP3 water treatment SCADA commands transmitted unencrypted	All commands to Water Treatment RTU transmitted in cleartext. Sensor readings and valve commands visible to network observers.	DNP3 application layer captured without decryption required	T0885	Tunnel DNP3 over TLS.	2026-04-16 17:38:20.895533
6	3	10.0.2.20	iec61850	network_exposure	Critical	IEC 61850 MMS server exposed — substation circuit breakers accessible	MMS service on Siemens SIPROTEC 5 accessible without restriction. Circuit breaker control and protection relay settings readable.	MMS connection established on TCP 102 from test host	T0886	Restrict MMS to engineering workstations. Implement IEC 62351-4 TLS.	2026-04-16 18:38:20.895533
7	3	10.0.2.20	iec61850	insecure_config	High	IEC 61850 GOOSE messages unsigned — protection relay bypass risk	GOOSE messages not cryptographically signed. Attacker on substation LAN could trigger false protection trips.	GOOSE PDU captured without signature field	T0820	Implement IEC 62351-6 GOOSE signing.	2026-04-16 18:38:20.895533
8	4	10.0.2.21	ethernetip	unauthenticated_access	Critical	EtherNet/IP CIP device accessible without authentication	Common Industrial Protocol (CIP) service accepts connections without authentication. Rockwell/Allen-Bradley PLCs with unauthenticated CIP access can have their logic read and potentially modified by any network host.	CIP Forward Open service accepted connection without identity challenge	T0817	Enable CIP Security using TLS and DTLS. Configure device-level firewall on managed switches. Upgrade to controllers supporting CIP Security.	2026-04-16 19:43:15.817626
9	4	10.0.2.21	ethernetip	firmware_outdated	High	EtherNet/IP device firmware has known vulnerabilities	The detected firmware version is affected by published CVEs including buffer overflow vulnerabilities in the CIP stack that could allow remote code execution.	Firmware version 20.011 — affects CVE-2020-6998, CVE-2021-27478	T0857	Update firmware to latest vendor release. Apply vendor security patches immediately. Isolate device until patching is complete.	2026-04-16 19:43:15.817628
10	5	10.0.1.10	modbus	unauthenticated_access	Critical	Modbus TCP has no authentication — any device can send commands	Modbus TCP protocol has no built-in authentication mechanism. Any host on the network can read sensor data and write control commands to connected PLCs and field devices.	Function code 0x01 (Read Coils) accepted without credentials	T0817	Deploy Modbus firewall or application-aware gateway. Implement network segmentation to isolate Modbus devices. Use VPN for any remote access to Modbus networks.	2026-04-16 19:44:19.9946
11	5	10.0.1.10	modbus	coil_write_enabled	Critical	Modbus coil writing enabled — physical control registers writable	Modbus Function Code 0x0F (Write Multiple Coils) is enabled. An attacker can write to coil registers to directly control connected physical equipment such as motors, valves, and relays.	Function code 0x0F accepted on Unit ID 1	T0831	Disable write function codes at the firewall level. Implement read-only Modbus proxy for monitoring systems. Require explicit authorisation for any write operations.	2026-04-16 19:44:19.994602
12	6	10.0.2.21	ethernetip	unauthenticated_access	Critical	EtherNet/IP CIP device accessible without authentication	Common Industrial Protocol (CIP) service accepts connections without authentication. Rockwell/Allen-Bradley PLCs with unauthenticated CIP access can have their logic read and potentially modified by any network host.	CIP Forward Open service accepted connection without identity challenge	T0817	Enable CIP Security using TLS and DTLS. Configure device-level firewall on managed switches. Upgrade to controllers supporting CIP Security.	2026-04-19 17:21:15.241991
13	6	10.0.2.21	ethernetip	firmware_outdated	High	EtherNet/IP device firmware has known vulnerabilities	The detected firmware version is affected by published CVEs including buffer overflow vulnerabilities in the CIP stack that could allow remote code execution.	Firmware version 20.011 — affects CVE-2020-6998, CVE-2021-27478	T0857	Update firmware to latest vendor release. Apply vendor security patches immediately. Isolate device until patching is complete.	2026-04-19 17:21:15.241996
14	7	10.0.2.21	ethernetip	unauthenticated_access	Critical	EtherNet/IP CIP device accessible without authentication	Common Industrial Protocol (CIP) service accepts connections without authentication. Rockwell/Allen-Bradley PLCs with unauthenticated CIP access can have their logic read and potentially modified by any network host.	CIP Forward Open service accepted connection without identity challenge	T0817	Enable CIP Security using TLS and DTLS. Configure device-level firewall on managed switches. Upgrade to controllers supporting CIP Security.	2026-04-21 23:45:57.621491
\.


--
-- Data for Name: ot_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ot_scans (id, target, protocol, status, findings_count, risk_level, scan_duration, user_id, created_at, completed_at) FROM stdin;
1	10.0.1.10	modbus	completed	3	CRITICAL	2.4	\N	2026-04-16 16:38:20.895533	2026-04-16 16:38:20.895533
2	10.0.1.11	dnp3	completed	2	HIGH	1.8	\N	2026-04-16 17:38:20.895533	2026-04-16 17:38:20.895533
3	10.0.2.20	iec61850	completed	2	CRITICAL	3.1	\N	2026-04-16 18:38:20.895533	2026-04-16 18:38:20.895533
4	10.0.2.21	ethernetip	completed	2	CRITICAL	0	1	2026-04-16 19:43:15.814686	2026-04-16 19:43:15.816096
5	10.0.1.10	modbus	completed	2	CRITICAL	0	2	2026-04-16 19:44:19.993357	2026-04-16 19:44:19.994293
6	10.0.2.21	ethernetip	completed	2	CRITICAL	0.01	1	2026-04-19 17:21:15.227893	2026-04-19 17:21:15.240483
7	10.0.2.21	ethernetip	completed	1	CRITICAL	0.02	1	2026-04-21 23:45:57.607819	2026-04-21 23:45:57.619709
\.


--
-- Data for Name: patch_brain_items; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.patch_brain_items (id, session_id, cve_id, component, current_version, fixed_version, severity, cvss_score, priority, patch_action, deadline, exploited, node_meta, created_at) FROM stdin;
24cbe2ff-7278-422d-8631-c3240f18b724	3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	CVE-2020-14343	PyYAML	5.3.0	6.0.0	CRITICAL	9.8	1	pip install --upgrade pyyaml>=6.0.0	Immediate	1	{}	2026-04-22 11:51:52.841625
d5a988b7-0e6d-4691-8d59-db8444d1570a	3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	CVE-2023-36053	Django	3.2.0	4.2.1	HIGH	7.5	2	pip install --upgrade django>=4.2.1	7 days	0	{}	2026-04-22 11:51:52.841637
3d377aef-ec7e-40fa-ab9f-35d2b412dd14	3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	CVE-2023-44271	Pillow	9.0.0	10.0.1	HIGH	7.5	3	pip install --upgrade pillow>=10.0.1	7 days	0	{}	2026-04-22 11:51:52.841641
4e9cf05d-f595-4b67-8b09-f9238eaa7a54	3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	CVE-2023-49083	cryptography	40.0.0	41.0.6	HIGH	7.4	4	pip install --upgrade cryptography>=41.0.6	7 days	0	{}	2026-04-22 11:51:52.841644
f95562f3-c5eb-4026-85d1-9bc76abef789	3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	CVE-2023-32681	Requests	2.28.0	2.31.0	MEDIUM	6.1	5	pip install --upgrade requests>=2.31.0	30 days	0	{}	2026-04-22 11:51:52.841649
7ce365fe-bbbb-41d3-8c35-f5c8fc2caf3b	3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	CVE-2023-30861	Flask	2.0.0	2.3.2	MEDIUM	5.9	6	pip install --upgrade flask>=2.3.2	30 days	0	{}	2026-04-22 11:51:52.841652
17ad8ef3-0588-4137-ac81-7a51c7b30c5a	3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	CVE-2023-48795	Paramiko	2.11.0	3.4.0	MEDIUM	5.9	7	pip install --upgrade paramiko>=3.4.0	30 days	0	{}	2026-04-22 11:51:52.841655
ddca7e26-92b2-47ec-83bd-c1b3e24e02d4	3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	CVE-2019-7164	SQLAlchemy	1.3.0	2.0.0	MEDIUM	5.3	8	pip install --upgrade sqlalchemy>=2.0.0	30 days	0	{}	2026-04-22 11:51:52.841658
\.


--
-- Data for Name: patch_brain_sessions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.patch_brain_sessions (id, user_id, environment, risk_score, severity, total_patches, critical_count, high_count, summary, created_at, node_meta) FROM stdin;
3f3394a3-63d7-49d2-9e74-4b9afa0dc8c4	1	production	81	CRITICAL	8	1	3	Patch Brain analysis complete. 8 patch(es) required. 1 critical, 3 high. 1 actively exploited in the wild. Risk score: 81.0/100.	2026-04-22 11:51:52.83691	{"ecosystem": "pip"}
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.permissions (id, name, description, resource, action) FROM stdin;
ea1f061a-72b4-44d8-98ff-27772e4e3a5c	scan:create	\N	scan	create
fb831269-5756-4f99-926e-afa8b1522f63	scan:read	\N	scan	read
93d83973-dffa-4161-9578-8c27f3e2f914	findings:read	\N	findings	read
bfaa1ebc-53a0-4103-bb03-7237bf6e7039	reports:read	\N	reports	read
65b4317a-f419-4f27-94a8-a5eb6a045ef6	reports:create	\N	reports	create
f2b473c1-7b25-424b-826e-f54b3784fe44	billing:manage	\N	billing	manage
dbe2ae73-ae4a-4a2b-85c4-e6812372fdf5	iam:manage	\N	iam	manage
8fdd6eb5-721e-4155-bb67-b9a85032abae	audit:read	\N	audit	read
9d93093f-db1f-4b6e-955a-ae668d6dac9b	sso:manage	\N	sso	manage
5c3e003c-ae91-4834-babc-27b36afb3257	terminal:use	\N	terminal	use
\.


--
-- Data for Name: policy_brain_policies; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.policy_brain_policies (id, user_id, title, policy_type, framework_map, coverage_score, word_count, created_at, node_meta) FROM stdin;
38d4e49c-1fa6-422e-b255-08dea3351fb5	1	Password and Authentication Policy	password	["ISO 27001 A.9", "NIS2 Article 21", "PCI DSS Requirement 8", "SOC2 CC6"]	90	255	2026-04-22 03:25:40.004468	{"org_name": "Your Organisation"}
\.


--
-- Data for Name: policy_brain_sections; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.policy_brain_sections (id, policy_id, section_number, section_title, content, node_meta, created_at) FROM stdin;
ec3f261a-2995-4370-9776-2b0e29798d68	38d4e49c-1fa6-422e-b255-08dea3351fb5	1	1. Purpose	This policy establishes requirements for password creation, management, and authentication to protect Your Organisation systems and data from unauthorised access.	{}	2026-04-22 03:25:40.007459
0ac4c397-3a7e-4bf4-9515-429de3ea0d3a	38d4e49c-1fa6-422e-b255-08dea3351fb5	2	2. Password Requirements	All passwords must meet the following minimum requirements: Minimum length of 16 characters. Must contain uppercase, lowercase, numbers and special characters. Must not contain the username or common dictionary words. Must not be reused from the last 12 passwords. Must not be shared with anyone under any circumstances.	{}	2026-04-22 03:25:40.007469
81fa3652-3ca1-4d16-bbc6-dcbcdbf77543	38d4e49c-1fa6-422e-b255-08dea3351fb5	3	3. Multi-Factor Authentication	MFA is mandatory for: All privileged and administrative accounts. All remote access including VPN. All cloud service access. All access to systems containing sensitive or personal data. Approved MFA methods: authenticator apps (TOTP), hardware security keys (FIDO2). SMS-based MFA is discouraged due to SIM-swapping risks.	{}	2026-04-22 03:25:40.007473
46358c2d-129b-4cff-a51c-2eb53d41b93d	38d4e49c-1fa6-422e-b255-08dea3351fb5	4	4. Password Management	All staff must use the organisation-approved password manager. Passwords must never be stored in plaintext, spreadsheets or documents. Default passwords on all systems and devices must be changed immediately upon deployment. Vendor and service account passwords must be rotated every 90 days.	{}	2026-04-22 03:25:40.007476
e76e34bb-679b-4dd7-97c0-7969f0a1d27f	38d4e49c-1fa6-422e-b255-08dea3351fb5	5	5. Account Lockout	Accounts will be locked after 5 consecutive failed login attempts. Locked accounts must be unlocked by the IT helpdesk after identity verification. Repeated lockouts will trigger a security review.	{}	2026-04-22 03:25:40.00748
ac64f79c-c6c6-4c13-9aba-e9c482b257fa	38d4e49c-1fa6-422e-b255-08dea3351fb5	6	6. Privileged Accounts	Privileged accounts must be used only for administrative tasks. Day-to-day work must use standard user accounts. Privileged access must be logged and reviewed monthly. Just-in-time (JIT) access is the preferred model for privileged operations.	{}	2026-04-22 03:25:40.007482
089fa9bb-a673-4e72-aec1-3e832a5fdc97	38d4e49c-1fa6-422e-b255-08dea3351fb5	7	7. Incident Response	Immediately report suspected password compromise to the IT Security team. Compromised passwords must be changed immediately across all affected systems. If credentials are exposed in a data breach, a full audit of affected systems must be conducted.	{}	2026-04-22 03:25:40.007485
\.


--
-- Data for Name: predict_alerts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.predict_alerts (id, user_id, cve_id, title, description, severity, cvss_score, affected_devices, weaponisation_pct, published_date, nvd_url, is_reviewed, created_at) FROM stdin;
\.


--
-- Data for Name: protocol_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.protocol_scans (id, user_id, protocol, target, status, findings, device_count, risk_level, created_at, completed_at) FROM stdin;
1	1	modbus	192.168.1.100	completed	[{"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-001", "title": "No authentication required", "severity": "critical", "description": "Modbus TCP endpoint accepts commands from any source without authentication."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}]	3	critical	2026-04-05 04:05:52.170882	2026-04-05 04:05:52.169904
2	1	modbus	10.0.2.15	completed	[{"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}, {"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}]	3	high	2026-04-05 04:10:06.396635	2026-04-05 04:10:06.396281
3	1	modbus	192.168.1.50	completed	[{"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}]	5	high	2026-04-05 04:11:24.833174	2026-04-05 04:11:24.83276
4	1	modbus	192.168.1.50	completed	[{"id": "MB-002", "title": "Coil write access exposed", "severity": "critical", "description": "Write access to output coils allows direct control of physical devices."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}, {"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}]	5	critical	2026-04-05 04:11:40.976058	2026-04-05 04:11:40.97572
5	1	modbus	192.168.56.101	completed	[{"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}, {"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}, {"id": "MB-002", "title": "Coil write access exposed", "severity": "critical", "description": "Write access to output coils allows direct control of physical devices."}, {"id": "MB-001", "title": "No authentication required", "severity": "critical", "description": "Modbus TCP endpoint accepts commands from any source without authentication."}]	5	critical	2026-04-09 16:25:31.22255	2026-04-09 16:25:31.221427
6	1	modbus	192.168.56.101	completed	[{"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}, {"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-002", "title": "Coil write access exposed", "severity": "critical", "description": "Write access to output coils allows direct control of physical devices."}, {"id": "MB-001", "title": "No authentication required", "severity": "critical", "description": "Modbus TCP endpoint accepts commands from any source without authentication."}, {"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}]	1	critical	2026-04-21 23:05:29.524752	2026-04-21 23:05:29.522697
7	1	zigbee	192.168.56.101	completed	[{"id": "ZB-002", "title": "Default trust centre key", "severity": "high", "description": "Device using default Zigbee trust centre link key."}, {"id": "ZB-004", "title": "Replay attack vulnerability", "severity": "medium", "description": "No frame counter validation \\u2014 replay attacks possible."}, {"id": "ZB-006", "title": "Weak network key rotation", "severity": "low", "description": "Network key has not been rotated in over 90 days."}, {"id": "ZB-005", "title": "Insecure OTA update", "severity": "medium", "description": "Over-the-air firmware update lacks signature verification."}, {"id": "ZB-003", "title": "Rogue device detected", "severity": "high", "description": "Unauthorised device joined the Zigbee network."}, {"id": "ZB-001", "title": "Unencrypted network key", "severity": "critical", "description": "Network key transmitted in plaintext during join procedure."}]	5	critical	2026-04-21 23:06:02.47411	2026-04-21 23:06:02.473603
8	1	lorawan	192.168.56.101	completed	[{"id": "LW-004", "title": "Unconfirmed uplinks only", "severity": "medium", "description": "Device sends only unconfirmed uplinks \\u2014 no delivery guarantee or tampering detection."}, {"id": "LW-003", "title": "Weak DevEUI entropy", "severity": "high", "description": "Device EUI has insufficient entropy \\u2014 predictable device identity."}, {"id": "LW-005", "title": "ADR manipulation risk", "severity": "medium", "description": "Adaptive Data Rate can be manipulated to drain device battery."}, {"id": "LW-006", "title": "Missing MAC layer encryption", "severity": "low", "description": "MAC commands transmitted without encryption on some channels."}, {"id": "LW-002", "title": "ABP activation vulnerability", "severity": "high", "description": "Device uses ABP activation \\u2014 frame counter reset on reboot enables replay."}, {"id": "LW-001", "title": "Hardcoded AppKey detected", "severity": "critical", "description": "Application key is hardcoded and matches known default values."}]	1	critical	2026-04-21 23:06:20.016237	2026-04-21 23:06:20.01565
\.


--
-- Data for Name: rbac_assessments; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.rbac_assessments (id, user_id, organisation, total_roles, over_privileged, sso_configured, mfa_enforced, risk_score, issues, summary, findings, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: rbac_roles; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.rbac_roles (id, user_id, role_name, role_type, permissions, description, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: re_assets; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.re_assets (id, name, asset_type, criticality, location, rto_target, rpo_target, rto_actual, rpo_actual, has_dr_plan, has_backup, backup_tested, failover_ready, readiness_score, last_tested, created_at) FROM stdin;
3	IoT Gateway	gateway	High	On-Premise — Building A	4	1	3.5	0.5	t	t	t	t	90	2026-04-04 05:53:05.833172	2026-04-19 05:53:05.837048
5	PLC Controller	iot_device	Critical	On-Premise — Production Floor	0.5	0	\N	\N	f	f	f	f	0	\N	2026-04-19 05:53:05.83705
6	Water Treatment Controller	iot_device	Critical	On-Premise — Treatment Plant	0.25	0	\N	\N	f	f	f	f	0	\N	2026-04-19 05:53:05.837051
7	Active Directory	server	High	On-Premise — Server Room	2	0.5	2.5	0.5	t	t	f	f	50	2026-01-19 04:53:05.833172	2026-04-19 05:53:05.837051
8	MQTT Broker	server	High	On-Premise — Server Room	1	0.25	\N	\N	f	t	f	f	25	\N	2026-04-19 05:53:05.837052
9	Analytics Warehouse (BigQuery)	database	Medium	GCP europe-west2	24	4	6	2	t	t	t	f	75	2026-03-20 04:53:05.833172	2026-04-19 05:53:05.837052
10	Redis Cache	cache	Medium	AWS ElastiCache eu-west-1	0.5	0	0.3	0	t	f	f	t	60	2026-03-05 04:53:05.833172	2026-04-19 05:53:05.837053
4	Web Application Server	server	High	AWS EC2 eu-west-1	2	0.5	1.6	0.6	t	t	t	t	100	2026-04-19 14:58:15.639556	2026-04-19 05:53:05.837049
2	SCADA Server	server	Critical	On-Premise — Server Room	2	0.5	6	1.2	f	f	f	f	10	2026-04-22 00:13:46.975848	2026-04-19 05:53:05.837046
1	Patient Database (RDS)	database	Critical	AWS RDS us-east-1	1	0.25	1.5	0.3	f	t	f	f	35	2026-04-22 00:14:13.781593	2026-04-19 05:53:05.837037
\.


--
-- Data for Name: re_plans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.re_plans (id, asset_id, title, description, steps, contacts, status, last_reviewed, created_at) FROM stdin;
1	3	IoT Gateway Failover Plan	Automated failover to secondary IoT Gateway in Building B. RTO target: 4 hours.	["Detect primary gateway failure via monitoring alert", "Activate secondary gateway (Building B) \\u2014 pre-configured", "Update DNS/MQTT broker to point to secondary gateway", "Verify all IoT devices reconnect to secondary", "Notify OT team and log incident", "Schedule primary gateway repair", "Fail back to primary after repair and testing"]	[{"name": "OT Team Lead", "phone": "+44 7700 900123"}, {"name": "Network Engineer", "phone": "+44 7700 900456"}]	active	2026-04-04 05:53:05.833172	2026-04-19 05:53:05.844389
2	4	Web Application Server DR Plan	Auto-scaling group with multi-AZ deployment. RTO: 2 hours, RPO: 30 minutes.	["CloudWatch alarm triggers SNS notification", "Auto Scaling Group launches replacement EC2", "Load balancer health check detects new instance", "Route 53 health check updates DNS if needed", "Verify application health endpoint returns 200", "Restore from latest RDS snapshot if DB affected", "Post-incident review within 24 hours"]	[{"name": "DevOps Lead", "phone": "+44 7700 900789"}, {"name": "AWS Support", "phone": "Enterprise Support"}]	active	2026-04-12 05:53:05.833172	2026-04-19 05:53:05.844396
3	7	Active Directory Recovery Plan	Restore AD from daily backup. Secondary DC available but untested.	["Identify failed DC and scope of impact", "Promote secondary DC to primary role", "Verify FSMO roles transferred correctly", "Test user authentication across all systems", "Restore from Azure AD Connect backup if needed", "Update DNS to point to new primary DC"]	[{"name": "IT Manager", "phone": "+44 7700 900012"}]	draft	2026-01-19 04:53:05.833172	2026-04-19 05:53:05.844397
4	9	Analytics Warehouse Recovery Plan	GCP BigQuery with daily exports to Cloud Storage. Recovery via dataset restore.	["Assess scope of data loss or corruption", "Restore from latest Cloud Storage export", "Verify data integrity with row count validation", "Re-run any failed pipeline jobs", "Notify analytics team of recovery window"]	[{"name": "Data Engineering Lead", "phone": "+44 7700 900345"}]	active	2026-03-20 04:53:05.833172	2026-04-19 05:53:05.844398
\.


--
-- Data for Name: re_tests; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.re_tests (id, asset_id, test_type, result, rto_achieved, rpo_achieved, notes, conducted_by, created_at) FROM stdin;
1	3	failover	passed	3.5	0.5	Failover to secondary gateway completed in 3.5 hours. All IoT devices reconnected successfully.	OT Security Team	2026-04-04 05:53:05.833172
2	4	simulation	passed	1.8	0.3	Auto-scaling group launched replacement in 1.8 hours. RTO target met.	DevOps Team	2026-04-12 05:53:05.833172
3	7	tabletop	partial	2.5	0.5	Tabletop exercise revealed gaps in FSMO role transfer procedure. RTO target missed by 30 minutes.	IT Team	2026-01-19 04:53:05.833172
4	9	backup_restore	passed	6	2	BigQuery dataset restored from Cloud Storage in 6 hours. Within 24-hour RTO target.	Data Engineering	2026-03-20 04:53:05.833172
5	1	backup_restore	failed	4.5	1	RDS restore failed first attempt — snapshot corruption. Second attempt succeeded. RTO target of 1 hour severely missed.	DBA Team	2025-10-21 05:53:05.833172
6	4	simulation	failed	1.6	0.6	Automated simulation — DR plan needs improvement — consider automated failover	AIPET X Resilience Engine	2026-04-19 14:58:15.645337
7	2	simulation	failed	6	1.2	Automated simulation — CRITICAL: No backup or DR plan — immediate action required	AIPET X Resilience Engine	2026-04-22 00:13:46.978197
8	1	simulation	failed	1.5	0.3	Automated simulation — DR plan needs improvement — consider automated failover	AIPET X Resilience Engine	2026-04-22 00:14:13.782689
\.


--
-- Data for Name: realtime_snapshots; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.realtime_snapshots (id, user_id, security_score, threat_level, active_threats, open_incidents, compliance_pct, uptime_pct, events_per_min, widgets_data, created_at, node_meta) FROM stdin;
224ffa30-0e58-4f02-b4b2-33ac91b0f13d	1	85.6	MEDIUM	8	3	70	97.26	2988	{"timeline": [{"hour": "23:00", "score": 86.5, "threats": 8, "events": 1436.0}, {"hour": "00:00", "score": 80.1, "threats": 11, "events": 2424.0}, {"hour": "01:00", "score": 80.0, "threats": 1, "events": 2329.0}, {"hour": "02:00", "score": 84.2, "threats": 9, "events": 1502.0}, {"hour": "03:00", "score": 87.0, "threats": 11, "events": 2165.0}, {"hour": "04:00", "score": 91.9, "threats": 4, "events": 1140.0}, {"hour": "05:00", "score": 87.4, "threats": 1, "events": 691.0}, {"hour": "06:00", "score": 83.5, "threats": 1, "events": 2809.0}, {"hour": "07:00", "score": 84.4, "threats": 11, "events": 2846.0}, {"hour": "08:00", "score": 82.9, "threats": 4, "events": 1883.0}, {"hour": "09:00", "score": 77.9, "threats": 2, "events": 2296.0}, {"hour": "10:00", "score": 78.5, "threats": 9, "events": 942.0}, {"hour": "11:00", "score": 73.3, "threats": 4, "events": 718.0}, {"hour": "12:00", "score": 67.3, "threats": 9, "events": 1464.0}, {"hour": "13:00", "score": 68.3, "threats": 7, "events": 2769.0}, {"hour": "14:00", "score": 64.8, "threats": 10, "events": 2885.0}, {"hour": "15:00", "score": 70.7, "threats": 11, "events": 525.0}, {"hour": "16:00", "score": 67.0, "threats": 3, "events": 781.0}, {"hour": "17:00", "score": 66.1, "threats": 2, "events": 2688.0}, {"hour": "18:00", "score": 70.1, "threats": 3, "events": 2327.0}, {"hour": "19:00", "score": 77.7, "threats": 7, "events": 2672.0}, {"hour": "20:00", "score": 85.3, "threats": 3, "events": 1490.0}, {"hour": "21:00", "score": 92.7, "threats": 7, "events": 572.0}, {"hour": "22:00", "score": 86.1, "threats": 3, "events": 1819.0}], "top_threats": [{"type": "Brute Force", "count": 11, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 97, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 7, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 28, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 32, "findings": 12}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 27, "findings": 1}, {"name": "ITDR", "status": "ACTIVE", "scans": 11, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 89, "findings": 4}, {"name": "SIEM", "status": "ACTIVE", "scans": 280, "findings": 16}, {"name": "APM", "status": "ACTIVE", "scans": 18, "findings": 5}], "geo_attacks": 28, "blocked_today": 3241, "mean_detect_min": 7.3}	2026-04-22 22:46:54.899549	{}
a80aee47-4a02-4918-a657-a77e9db2c0d5	1	61.4	MEDIUM	4	0	84.3	99.59	1562	{"timeline": [{"hour": "23:00", "score": 55.9, "threats": 3, "events": 807.0}, {"hour": "00:00", "score": 50.8, "threats": 0, "events": 549.0}, {"hour": "01:00", "score": 44.0, "threats": 4, "events": 619.0}, {"hour": "02:00", "score": 50.7, "threats": 0, "events": 69.0}, {"hour": "03:00", "score": 56.9, "threats": 0, "events": 111.0}, {"hour": "04:00", "score": 55.1, "threats": 3, "events": 965.0}, {"hour": "05:00", "score": 54.4, "threats": 7, "events": 683.0}, {"hour": "06:00", "score": 55.2, "threats": 3, "events": 481.0}, {"hour": "07:00", "score": 48.5, "threats": 1, "events": 787.0}, {"hour": "08:00", "score": 55.3, "threats": 4, "events": 1243.0}, {"hour": "09:00", "score": 53.2, "threats": 5, "events": 1314.0}, {"hour": "10:00", "score": 58.9, "threats": 2, "events": 832.0}, {"hour": "11:00", "score": 63.0, "threats": 0, "events": 332.0}, {"hour": "12:00", "score": 56.3, "threats": 2, "events": 1498.0}, {"hour": "13:00", "score": 64.2, "threats": 4, "events": 1154.0}, {"hour": "14:00", "score": 64.2, "threats": 6, "events": 1125.0}, {"hour": "15:00", "score": 64.9, "threats": 0, "events": 1368.0}, {"hour": "16:00", "score": 69.8, "threats": 5, "events": 1429.0}, {"hour": "17:00", "score": 73.5, "threats": 0, "events": 308.0}, {"hour": "18:00", "score": 79.1, "threats": 0, "events": 1276.0}, {"hour": "19:00", "score": 79.5, "threats": 7, "events": 967.0}, {"hour": "20:00", "score": 85.8, "threats": 0, "events": 60.0}, {"hour": "21:00", "score": 79.4, "threats": 0, "events": 1343.0}, {"hour": "22:00", "score": 72.1, "threats": 5, "events": 1484.0}], "top_threats": [{"type": "Brute Force", "count": 45, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 73, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 9, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 8, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 5, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 38, "findings": 2}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 9, "findings": 0}, {"name": "ITDR", "status": "ACTIVE", "scans": 3, "findings": 4}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 34, "findings": 12}, {"name": "SIEM", "status": "ACTIVE", "scans": 775, "findings": 16}, {"name": "APM", "status": "ACTIVE", "scans": 12, "findings": 1}], "geo_attacks": 33, "blocked_today": 4162, "mean_detect_min": 4.6}	2026-04-22 22:47:23.310314	{}
2eae9438-f50d-4b6e-9c1a-36c4af72c5f6	1	46.9	CRITICAL	25	0	94.7	97.16	3182	{"timeline": [{"hour": "23:00", "score": 48.4, "threats": 1, "events": 1254.0}, {"hour": "00:00", "score": 55.9, "threats": 14, "events": 1505.0}, {"hour": "01:00", "score": 63.5, "threats": 28, "events": 2837.0}, {"hour": "02:00", "score": 56.4, "threats": 22, "events": 2293.0}, {"hour": "03:00", "score": 58.1, "threats": 27, "events": 2116.0}, {"hour": "04:00", "score": 58.5, "threats": 21, "events": 732.0}, {"hour": "05:00", "score": 62.5, "threats": 20, "events": 1554.0}, {"hour": "06:00", "score": 70.0, "threats": 16, "events": 2338.0}, {"hour": "07:00", "score": 75.3, "threats": 9, "events": 2085.0}, {"hour": "08:00", "score": 81.5, "threats": 14, "events": 3174.0}, {"hour": "09:00", "score": 85.9, "threats": 15, "events": 167.0}, {"hour": "10:00", "score": 90.8, "threats": 18, "events": 1079.0}, {"hour": "11:00", "score": 88.9, "threats": 28, "events": 1597.0}, {"hour": "12:00", "score": 95.7, "threats": 21, "events": 545.0}, {"hour": "13:00", "score": 91.4, "threats": 9, "events": 2117.0}, {"hour": "14:00", "score": 94.6, "threats": 2, "events": 2328.0}, {"hour": "15:00", "score": 93.5, "threats": 15, "events": 593.0}, {"hour": "16:00", "score": 92.7, "threats": 14, "events": 1300.0}, {"hour": "17:00", "score": 89.4, "threats": 22, "events": 2726.0}, {"hour": "18:00", "score": 96.2, "threats": 23, "events": 3051.0}, {"hour": "19:00", "score": 95.7, "threats": 25, "events": 2741.0}, {"hour": "20:00", "score": 92.1, "threats": 9, "events": 824.0}, {"hour": "21:00", "score": 92.2, "threats": 3, "events": 359.0}, {"hour": "22:00", "score": 90.1, "threats": 23, "events": 1791.0}], "top_threats": [{"type": "Brute Force", "count": 19, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 100, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 7, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 17, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 4, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 47, "findings": 14}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 13, "findings": 9}, {"name": "ITDR", "status": "ACTIVE", "scans": 12, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 62, "findings": 18}, {"name": "SIEM", "status": "ACTIVE", "scans": 221, "findings": 3}, {"name": "APM", "status": "ACTIVE", "scans": 25, "findings": 7}], "geo_attacks": 28, "blocked_today": 4965, "mean_detect_min": 12.7}	2026-04-22 22:47:32.962773	{}
5ddd592a-8817-4a00-9ad6-86bd32e4c8da	1	67.8	MEDIUM	4	2	90.9	98.87	2551	{"timeline": [{"hour": "23:00", "score": 60.2, "threats": 4, "events": 608.0}, {"hour": "00:00", "score": 63.5, "threats": 7, "events": 563.0}, {"hour": "01:00", "score": 61.2, "threats": 3, "events": 2345.0}, {"hour": "02:00", "score": 53.7, "threats": 4, "events": 506.0}, {"hour": "03:00", "score": 53.2, "threats": 4, "events": 534.0}, {"hour": "04:00", "score": 54.3, "threats": 4, "events": 1597.0}, {"hour": "05:00", "score": 46.7, "threats": 4, "events": 700.0}, {"hour": "06:00", "score": 38.9, "threats": 3, "events": 2317.0}, {"hour": "07:00", "score": 34.4, "threats": 7, "events": 118.0}, {"hour": "08:00", "score": 29.9, "threats": 2, "events": 2165.0}, {"hour": "09:00", "score": 33.5, "threats": 0, "events": 709.0}, {"hour": "10:00", "score": 40.4, "threats": 0, "events": 1572.0}, {"hour": "11:00", "score": 48.3, "threats": 1, "events": 87.0}, {"hour": "12:00", "score": 55.0, "threats": 4, "events": 132.0}, {"hour": "13:00", "score": 60.5, "threats": 2, "events": 1067.0}, {"hour": "14:00", "score": 65.9, "threats": 4, "events": 1742.0}, {"hour": "15:00", "score": 73.5, "threats": 1, "events": 1399.0}, {"hour": "16:00", "score": 77.1, "threats": 3, "events": 2351.0}, {"hour": "17:00", "score": 76.4, "threats": 6, "events": 1826.0}, {"hour": "18:00", "score": 70.9, "threats": 1, "events": 1277.0}, {"hour": "19:00", "score": 66.7, "threats": 1, "events": 1203.0}, {"hour": "20:00", "score": 61.5, "threats": 5, "events": 557.0}, {"hour": "21:00", "score": 63.8, "threats": 5, "events": 704.0}, {"hour": "22:00", "score": 68.5, "threats": 7, "events": 2520.0}], "top_threats": [{"type": "Brute Force", "count": 11, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 68, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 9, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 19, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 21, "findings": 19}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 8, "findings": 4}, {"name": "ITDR", "status": "ACTIVE", "scans": 11, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 85, "findings": 47}, {"name": "SIEM", "status": "ACTIVE", "scans": 720, "findings": 3}, {"name": "APM", "status": "ACTIVE", "scans": 21, "findings": 5}], "geo_attacks": 48, "blocked_today": 2803, "mean_detect_min": 13.4}	2026-04-22 22:47:34.667393	{}
392a3046-6548-4cd0-bccd-6ce24106e11d	1	73	CRITICAL	18	0	69.3	98.73	740	{"timeline": [{"hour": "23:00", "score": 70.2, "threats": 11, "events": 260.0}, {"hour": "00:00", "score": 71.3, "threats": 4, "events": 436.0}, {"hour": "01:00", "score": 66.1, "threats": 21, "events": 510.0}, {"hour": "02:00", "score": 68.1, "threats": 16, "events": 504.0}, {"hour": "03:00", "score": 61.2, "threats": 16, "events": 330.0}, {"hour": "04:00", "score": 55.2, "threats": 2, "events": 176.0}, {"hour": "05:00", "score": 47.2, "threats": 4, "events": 113.0}, {"hour": "06:00", "score": 51.2, "threats": 8, "events": 540.0}, {"hour": "07:00", "score": 48.2, "threats": 17, "events": 51.0}, {"hour": "08:00", "score": 54.5, "threats": 18, "events": 340.0}, {"hour": "09:00", "score": 58.9, "threats": 17, "events": 654.0}, {"hour": "10:00", "score": 61.1, "threats": 1, "events": 593.0}, {"hour": "11:00", "score": 65.2, "threats": 18, "events": 470.0}, {"hour": "12:00", "score": 65.6, "threats": 21, "events": 463.0}, {"hour": "13:00", "score": 59.3, "threats": 20, "events": 393.0}, {"hour": "14:00", "score": 53.1, "threats": 3, "events": 358.0}, {"hour": "15:00", "score": 55.6, "threats": 3, "events": 384.0}, {"hour": "16:00", "score": 48.2, "threats": 5, "events": 469.0}, {"hour": "17:00", "score": 53.3, "threats": 18, "events": 456.0}, {"hour": "18:00", "score": 58.1, "threats": 14, "events": 167.0}, {"hour": "19:00", "score": 63.6, "threats": 8, "events": 421.0}, {"hour": "20:00", "score": 55.9, "threats": 3, "events": 219.0}, {"hour": "21:00", "score": 63.9, "threats": 4, "events": 555.0}, {"hour": "22:00", "score": 58.8, "threats": 11, "events": 164.0}], "top_threats": [{"type": "Brute Force", "count": 42, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 34, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 14, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 18, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 1, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 10, "findings": 11}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 14, "findings": 14}, {"name": "ITDR", "status": "ACTIVE", "scans": 3, "findings": 5}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 43, "findings": 48}, {"name": "SIEM", "status": "ACTIVE", "scans": 117, "findings": 3}, {"name": "APM", "status": "ACTIVE", "scans": 11, "findings": 0}], "geo_attacks": 45, "blocked_today": 3632, "mean_detect_min": 14.8}	2026-04-22 22:47:35.729566	{}
ef884ae7-f30f-4e05-93ec-edfaef50ba6e	1	64.6	LOW	3	8	67.3	97.6	2980	{"timeline": [{"hour": "23:00", "score": 65.8, "threats": 0, "events": 1711.0}, {"hour": "00:00", "score": 65.1, "threats": 5, "events": 243.0}, {"hour": "01:00", "score": 67.8, "threats": 5, "events": 619.0}, {"hour": "02:00", "score": 70.4, "threats": 4, "events": 927.0}, {"hour": "03:00", "score": 68.0, "threats": 2, "events": 1254.0}, {"hour": "04:00", "score": 63.1, "threats": 1, "events": 1481.0}, {"hour": "05:00", "score": 58.2, "threats": 2, "events": 1261.0}, {"hour": "06:00", "score": 50.6, "threats": 3, "events": 1420.0}, {"hour": "07:00", "score": 44.3, "threats": 1, "events": 289.0}, {"hour": "08:00", "score": 43.3, "threats": 3, "events": 1862.0}, {"hour": "09:00", "score": 40.1, "threats": 5, "events": 636.0}, {"hour": "10:00", "score": 34.8, "threats": 6, "events": 2001.0}, {"hour": "11:00", "score": 26.8, "threats": 4, "events": 863.0}, {"hour": "12:00", "score": 32.0, "threats": 5, "events": 2683.0}, {"hour": "13:00", "score": 39.1, "threats": 4, "events": 2393.0}, {"hour": "14:00", "score": 44.4, "threats": 5, "events": 1293.0}, {"hour": "15:00", "score": 43.0, "threats": 2, "events": 1027.0}, {"hour": "16:00", "score": 45.1, "threats": 0, "events": 2319.0}, {"hour": "17:00", "score": 46.2, "threats": 6, "events": 2791.0}, {"hour": "18:00", "score": 53.3, "threats": 0, "events": 2076.0}, {"hour": "19:00", "score": 57.1, "threats": 6, "events": 309.0}, {"hour": "20:00", "score": 62.9, "threats": 3, "events": 1905.0}, {"hour": "21:00", "score": 55.3, "threats": 5, "events": 52.0}, {"hour": "22:00", "score": 62.1, "threats": 5, "events": 2273.0}], "top_threats": [{"type": "Brute Force", "count": 27, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 59, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 10, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 19, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 5, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 10, "findings": 9}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 26, "findings": 0}, {"name": "ITDR", "status": "ACTIVE", "scans": 6, "findings": 5}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 89, "findings": 19}, {"name": "SIEM", "status": "ACTIVE", "scans": 266, "findings": 15}, {"name": "APM", "status": "ACTIVE", "scans": 24, "findings": 4}], "geo_attacks": 37, "blocked_today": 222, "mean_detect_min": 5.8}	2026-04-22 22:47:37.535911	{}
3d3d88fb-9bed-4e8a-9b79-60758b92633b	1	67.9	CRITICAL	17	8	67.1	98.46	1521	{"timeline": [{"hour": "23:00", "score": 68.8, "threats": 1, "events": 1409.0}, {"hour": "00:00", "score": 66.1, "threats": 14, "events": 751.0}, {"hour": "01:00", "score": 64.1, "threats": 19, "events": 676.0}, {"hour": "02:00", "score": 56.8, "threats": 1, "events": 1291.0}, {"hour": "03:00", "score": 52.5, "threats": 14, "events": 1457.0}, {"hour": "04:00", "score": 47.6, "threats": 17, "events": 870.0}, {"hour": "05:00", "score": 46.3, "threats": 12, "events": 1485.0}, {"hour": "06:00", "score": 38.9, "threats": 15, "events": 394.0}, {"hour": "07:00", "score": 38.6, "threats": 17, "events": 1062.0}, {"hour": "08:00", "score": 45.6, "threats": 19, "events": 187.0}, {"hour": "09:00", "score": 49.7, "threats": 15, "events": 1411.0}, {"hour": "10:00", "score": 50.5, "threats": 12, "events": 1160.0}, {"hour": "11:00", "score": 52.4, "threats": 11, "events": 1025.0}, {"hour": "12:00", "score": 55.4, "threats": 1, "events": 54.0}, {"hour": "13:00", "score": 59.1, "threats": 11, "events": 1308.0}, {"hour": "14:00", "score": 65.9, "threats": 19, "events": 390.0}, {"hour": "15:00", "score": 72.0, "threats": 18, "events": 1144.0}, {"hour": "16:00", "score": 78.5, "threats": 10, "events": 1307.0}, {"hour": "17:00", "score": 84.7, "threats": 19, "events": 1207.0}, {"hour": "18:00", "score": 84.6, "threats": 3, "events": 203.0}, {"hour": "19:00", "score": 88.7, "threats": 11, "events": 750.0}, {"hour": "20:00", "score": 90.5, "threats": 3, "events": 350.0}, {"hour": "21:00", "score": 88.9, "threats": 1, "events": 1076.0}, {"hour": "22:00", "score": 91.7, "threats": 18, "events": 351.0}], "top_threats": [{"type": "Brute Force", "count": 22, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 17, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 9, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 19, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 4, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 31, "findings": 2}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 8, "findings": 2}, {"name": "ITDR", "status": "ACTIVE", "scans": 5, "findings": 0}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 71, "findings": 9}, {"name": "SIEM", "status": "ACTIVE", "scans": 584, "findings": 5}, {"name": "APM", "status": "ACTIVE", "scans": 21, "findings": 7}], "geo_attacks": 17, "blocked_today": 2910, "mean_detect_min": 1.0}	2026-04-22 22:47:38.31077	{}
0c692c80-4a45-44d0-ab85-c2ea8afdcbed	1	79.3	MEDIUM	8	0	84	97.93	598	{"timeline": [{"hour": "23:00", "score": 80.6, "threats": 1, "events": 197.0}, {"hour": "00:00", "score": 75.0, "threats": 8, "events": 68.0}, {"hour": "01:00", "score": 69.2, "threats": 3, "events": 132.0}, {"hour": "02:00", "score": 73.4, "threats": 5, "events": 537.0}, {"hour": "03:00", "score": 71.9, "threats": 2, "events": 286.0}, {"hour": "04:00", "score": 77.8, "threats": 10, "events": 447.0}, {"hour": "05:00", "score": 80.7, "threats": 0, "events": 195.0}, {"hour": "06:00", "score": 84.7, "threats": 7, "events": 566.0}, {"hour": "07:00", "score": 83.8, "threats": 4, "events": 283.0}, {"hour": "08:00", "score": 83.5, "threats": 3, "events": 168.0}, {"hour": "09:00", "score": 89.9, "threats": 11, "events": 468.0}, {"hour": "10:00", "score": 89.6, "threats": 7, "events": 520.0}, {"hour": "11:00", "score": 92.5, "threats": 5, "events": 172.0}, {"hour": "12:00", "score": 86.0, "threats": 8, "events": 407.0}, {"hour": "13:00", "score": 85.0, "threats": 11, "events": 419.0}, {"hour": "14:00", "score": 85.5, "threats": 7, "events": 170.0}, {"hour": "15:00", "score": 90.3, "threats": 9, "events": 525.0}, {"hour": "16:00", "score": 84.6, "threats": 6, "events": 502.0}, {"hour": "17:00", "score": 87.3, "threats": 4, "events": 209.0}, {"hour": "18:00", "score": 90.9, "threats": 6, "events": 330.0}, {"hour": "19:00", "score": 86.6, "threats": 8, "events": 427.0}, {"hour": "20:00", "score": 89.4, "threats": 11, "events": 242.0}, {"hour": "21:00", "score": 90.0, "threats": 10, "events": 150.0}, {"hour": "22:00", "score": 86.4, "threats": 0, "events": 594.0}], "top_threats": [{"type": "Brute Force", "count": 39, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 36, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 20, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 25, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 31, "findings": 16}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 22, "findings": 0}, {"name": "ITDR", "status": "ACTIVE", "scans": 10, "findings": 4}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 36, "findings": 15}, {"name": "SIEM", "status": "ACTIVE", "scans": 848, "findings": 28}, {"name": "APM", "status": "ACTIVE", "scans": 7, "findings": 3}], "geo_attacks": 33, "blocked_today": 3033, "mean_detect_min": 9.0}	2026-04-22 22:47:53.312844	{}
41ad42df-23f8-4b3d-8487-bc85c4f1a3a0	1	78.1	HIGH	13	2	76.8	99.69	3968	{"timeline": [{"hour": "23:00", "score": 75.3, "threats": 9, "events": 1423.0}, {"hour": "00:00", "score": 73.9, "threats": 7, "events": 891.0}, {"hour": "01:00", "score": 71.3, "threats": 7, "events": 2577.0}, {"hour": "02:00", "score": 66.2, "threats": 2, "events": 3118.0}, {"hour": "03:00", "score": 63.9, "threats": 9, "events": 1534.0}, {"hour": "04:00", "score": 63.3, "threats": 0, "events": 3492.0}, {"hour": "05:00", "score": 70.1, "threats": 12, "events": 1839.0}, {"hour": "06:00", "score": 72.5, "threats": 10, "events": 832.0}, {"hour": "07:00", "score": 66.9, "threats": 15, "events": 904.0}, {"hour": "08:00", "score": 69.5, "threats": 7, "events": 1353.0}, {"hour": "09:00", "score": 77.1, "threats": 10, "events": 1374.0}, {"hour": "10:00", "score": 78.2, "threats": 2, "events": 3066.0}, {"hour": "11:00", "score": 76.4, "threats": 0, "events": 735.0}, {"hour": "12:00", "score": 82.3, "threats": 13, "events": 2838.0}, {"hour": "13:00", "score": 89.0, "threats": 11, "events": 3462.0}, {"hour": "14:00", "score": 87.0, "threats": 12, "events": 1747.0}, {"hour": "15:00", "score": 86.1, "threats": 11, "events": 2782.0}, {"hour": "16:00", "score": 85.6, "threats": 5, "events": 2267.0}, {"hour": "17:00", "score": 81.8, "threats": 1, "events": 2423.0}, {"hour": "18:00", "score": 82.0, "threats": 11, "events": 1480.0}, {"hour": "19:00", "score": 76.4, "threats": 6, "events": 241.0}, {"hour": "20:00", "score": 75.5, "threats": 16, "events": 3339.0}, {"hour": "21:00", "score": 80.7, "threats": 5, "events": 702.0}, {"hour": "22:00", "score": 86.8, "threats": 15, "events": 1427.0}], "top_threats": [{"type": "Brute Force", "count": 35, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 23, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 19, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 2, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 4, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 44, "findings": 16}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 17, "findings": 8}, {"name": "ITDR", "status": "ACTIVE", "scans": 14, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 46, "findings": 46}, {"name": "SIEM", "status": "ACTIVE", "scans": 397, "findings": 12}, {"name": "APM", "status": "ACTIVE", "scans": 12, "findings": 8}], "geo_attacks": 9, "blocked_today": 1465, "mean_detect_min": 12.0}	2026-04-22 22:48:08.316068	{}
62a0ee86-9ff3-45b9-ab52-5943179086c8	1	46.3	HIGH	13	6	73.2	98.1	3474	{"timeline": [{"hour": "23:00", "score": 50.0, "threats": 9, "events": 2384.0}, {"hour": "00:00", "score": 54.6, "threats": 0, "events": 1952.0}, {"hour": "01:00", "score": 61.9, "threats": 16, "events": 2773.0}, {"hour": "02:00", "score": 63.4, "threats": 6, "events": 596.0}, {"hour": "03:00", "score": 63.1, "threats": 14, "events": 2230.0}, {"hour": "04:00", "score": 69.2, "threats": 16, "events": 1218.0}, {"hour": "05:00", "score": 73.5, "threats": 14, "events": 290.0}, {"hour": "06:00", "score": 69.3, "threats": 13, "events": 406.0}, {"hour": "07:00", "score": 68.1, "threats": 14, "events": 797.0}, {"hour": "08:00", "score": 64.0, "threats": 9, "events": 3153.0}, {"hour": "09:00", "score": 59.8, "threats": 1, "events": 1812.0}, {"hour": "10:00", "score": 59.1, "threats": 4, "events": 1791.0}, {"hour": "11:00", "score": 57.8, "threats": 14, "events": 701.0}, {"hour": "12:00", "score": 52.5, "threats": 2, "events": 1926.0}, {"hour": "13:00", "score": 48.5, "threats": 1, "events": 724.0}, {"hour": "14:00", "score": 53.3, "threats": 11, "events": 559.0}, {"hour": "15:00", "score": 49.8, "threats": 10, "events": 1498.0}, {"hour": "16:00", "score": 49.8, "threats": 12, "events": 565.0}, {"hour": "17:00", "score": 48.3, "threats": 6, "events": 420.0}, {"hour": "18:00", "score": 53.7, "threats": 9, "events": 322.0}, {"hour": "19:00", "score": 60.2, "threats": 3, "events": 999.0}, {"hour": "20:00", "score": 56.8, "threats": 3, "events": 1133.0}, {"hour": "21:00", "score": 58.4, "threats": 10, "events": 208.0}, {"hour": "22:00", "score": 53.4, "threats": 12, "events": 3380.0}], "top_threats": [{"type": "Brute Force", "count": 10, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 53, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 8, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 8, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 0, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 50, "findings": 2}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 30, "findings": 13}, {"name": "ITDR", "status": "ACTIVE", "scans": 19, "findings": 7}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 23, "findings": 22}, {"name": "SIEM", "status": "ACTIVE", "scans": 107, "findings": 25}, {"name": "APM", "status": "ACTIVE", "scans": 9, "findings": 3}], "geo_attacks": 46, "blocked_today": 1343, "mean_detect_min": 9.8}	2026-04-22 22:48:38.333795	{}
fe176063-2e51-401d-ad6e-62e3098e276d	1	60.6	HIGH	11	4	66.1	98.42	2730	{"timeline": [{"hour": "23:00", "score": 55.3, "threats": 5, "events": 1876.0}, {"hour": "00:00", "score": 63.3, "threats": 13, "events": 1252.0}, {"hour": "01:00", "score": 65.4, "threats": 8, "events": 1544.0}, {"hour": "02:00", "score": 61.8, "threats": 0, "events": 1110.0}, {"hour": "03:00", "score": 57.0, "threats": 2, "events": 1055.0}, {"hour": "04:00", "score": 54.3, "threats": 13, "events": 2208.0}, {"hour": "05:00", "score": 48.9, "threats": 11, "events": 1159.0}, {"hour": "06:00", "score": 44.8, "threats": 2, "events": 875.0}, {"hour": "07:00", "score": 38.3, "threats": 3, "events": 1155.0}, {"hour": "08:00", "score": 39.7, "threats": 5, "events": 425.0}, {"hour": "09:00", "score": 32.6, "threats": 14, "events": 2612.0}, {"hour": "10:00", "score": 29.9, "threats": 5, "events": 1437.0}, {"hour": "11:00", "score": 26.1, "threats": 6, "events": 785.0}, {"hour": "12:00", "score": 25.1, "threats": 10, "events": 2511.0}, {"hour": "13:00", "score": 21.7, "threats": 7, "events": 330.0}, {"hour": "14:00", "score": 27.1, "threats": 4, "events": 1637.0}, {"hour": "15:00", "score": 33.4, "threats": 8, "events": 2246.0}, {"hour": "16:00", "score": 32.0, "threats": 0, "events": 2650.0}, {"hour": "17:00", "score": 33.2, "threats": 0, "events": 393.0}, {"hour": "18:00", "score": 31.3, "threats": 9, "events": 523.0}, {"hour": "19:00", "score": 24.8, "threats": 11, "events": 2228.0}, {"hour": "20:00", "score": 20, "threats": 9, "events": 691.0}, {"hour": "21:00", "score": 23.7, "threats": 12, "events": 798.0}, {"hour": "22:00", "score": 25.2, "threats": 5, "events": 533.0}], "top_threats": [{"type": "Brute Force", "count": 30, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 19, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 12, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 16, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 14, "findings": 16}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 26, "findings": 10}, {"name": "ITDR", "status": "ACTIVE", "scans": 5, "findings": 6}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 86, "findings": 2}, {"name": "SIEM", "status": "ACTIVE", "scans": 381, "findings": 22}, {"name": "APM", "status": "ACTIVE", "scans": 22, "findings": 2}], "geo_attacks": 17, "blocked_today": 2364, "mean_detect_min": 2.2}	2026-04-22 22:49:08.329024	{}
9ab476bd-b72d-4971-ac2a-1d4cb29767d3	1	57.6	CRITICAL	20	2	65.8	99.45	2028	{"timeline": [{"hour": "23:00", "score": 57.4, "threats": 11, "events": 1567.0}, {"hour": "00:00", "score": 58.1, "threats": 3, "events": 1286.0}, {"hour": "01:00", "score": 61.4, "threats": 15, "events": 1327.0}, {"hour": "02:00", "score": 54.3, "threats": 2, "events": 1505.0}, {"hour": "03:00", "score": 59.8, "threats": 22, "events": 66.0}, {"hour": "04:00", "score": 61.7, "threats": 22, "events": 448.0}, {"hour": "05:00", "score": 61.3, "threats": 15, "events": 916.0}, {"hour": "06:00", "score": 60.0, "threats": 6, "events": 212.0}, {"hour": "07:00", "score": 66.3, "threats": 3, "events": 1762.0}, {"hour": "08:00", "score": 70.3, "threats": 2, "events": 1518.0}, {"hour": "09:00", "score": 68.7, "threats": 19, "events": 716.0}, {"hour": "10:00", "score": 70.8, "threats": 3, "events": 1993.0}, {"hour": "11:00", "score": 78.7, "threats": 18, "events": 1794.0}, {"hour": "12:00", "score": 74.8, "threats": 12, "events": 658.0}, {"hour": "13:00", "score": 69.2, "threats": 16, "events": 1095.0}, {"hour": "14:00", "score": 73.0, "threats": 19, "events": 907.0}, {"hour": "15:00", "score": 70.0, "threats": 10, "events": 1032.0}, {"hour": "16:00", "score": 77.9, "threats": 0, "events": 1327.0}, {"hour": "17:00", "score": 77.4, "threats": 8, "events": 1048.0}, {"hour": "18:00", "score": 70.0, "threats": 20, "events": 1528.0}, {"hour": "19:00", "score": 72.3, "threats": 23, "events": 677.0}, {"hour": "20:00", "score": 76.9, "threats": 11, "events": 1879.0}, {"hour": "21:00", "score": 69.6, "threats": 6, "events": 1222.0}, {"hour": "22:00", "score": 65.3, "threats": 7, "events": 1464.0}], "top_threats": [{"type": "Brute Force", "count": 25, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 33, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 16, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 7, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 0, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 13, "findings": 20}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 5, "findings": 2}, {"name": "ITDR", "status": "ACTIVE", "scans": 5, "findings": 6}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 51, "findings": 50}, {"name": "SIEM", "status": "ACTIVE", "scans": 198, "findings": 20}, {"name": "APM", "status": "ACTIVE", "scans": 24, "findings": 2}], "geo_attacks": 45, "blocked_today": 2152, "mean_detect_min": 3.0}	2026-04-22 22:49:38.341953	{}
b108b704-e326-47be-aa34-1b0c9734dec8	1	89.4	CRITICAL	24	3	90.2	97.34	1700	{"timeline": [{"hour": "23:00", "score": 87.1, "threats": 11, "events": 1643.0}, {"hour": "00:00", "score": 86.2, "threats": 25, "events": 1451.0}, {"hour": "01:00", "score": 81.1, "threats": 3, "events": 91.0}, {"hour": "02:00", "score": 83.9, "threats": 2, "events": 428.0}, {"hour": "03:00", "score": 76.0, "threats": 3, "events": 1209.0}, {"hour": "04:00", "score": 75.8, "threats": 18, "events": 1160.0}, {"hour": "05:00", "score": 71.5, "threats": 24, "events": 1001.0}, {"hour": "06:00", "score": 70.4, "threats": 8, "events": 734.0}, {"hour": "07:00", "score": 64.2, "threats": 18, "events": 399.0}, {"hour": "08:00", "score": 67.6, "threats": 22, "events": 1663.0}, {"hour": "09:00", "score": 65.1, "threats": 27, "events": 503.0}, {"hour": "10:00", "score": 70.9, "threats": 5, "events": 1463.0}, {"hour": "11:00", "score": 64.7, "threats": 0, "events": 473.0}, {"hour": "12:00", "score": 70.9, "threats": 18, "events": 744.0}, {"hour": "13:00", "score": 75.6, "threats": 6, "events": 352.0}, {"hour": "14:00", "score": 77.9, "threats": 12, "events": 1064.0}, {"hour": "15:00", "score": 83.2, "threats": 1, "events": 626.0}, {"hour": "16:00", "score": 77.0, "threats": 13, "events": 1477.0}, {"hour": "17:00", "score": 76.4, "threats": 27, "events": 841.0}, {"hour": "18:00", "score": 70.9, "threats": 20, "events": 1699.0}, {"hour": "19:00", "score": 74.1, "threats": 8, "events": 214.0}, {"hour": "20:00", "score": 74.2, "threats": 11, "events": 207.0}, {"hour": "21:00", "score": 69.6, "threats": 17, "events": 713.0}, {"hour": "22:00", "score": 62.5, "threats": 11, "events": 1339.0}], "top_threats": [{"type": "Brute Force", "count": 50, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 48, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 15, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 27, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 37, "findings": 8}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 24, "findings": 3}, {"name": "ITDR", "status": "ACTIVE", "scans": 13, "findings": 6}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 50, "findings": 13}, {"name": "SIEM", "status": "ACTIVE", "scans": 785, "findings": 16}, {"name": "APM", "status": "ACTIVE", "scans": 21, "findings": 6}], "geo_attacks": 14, "blocked_today": 1106, "mean_detect_min": 10.6}	2026-04-22 22:50:08.367221	{}
02a55d59-be86-4dc1-acd5-c6499a73ad17	1	91.1	LOW	0	7	89.5	99.82	1430	{"timeline": [{"hour": "23:00", "score": 83.7, "threats": 2, "events": 993.0}, {"hour": "00:00", "score": 83.1, "threats": 0, "events": 860.0}, {"hour": "01:00", "score": 84.4, "threats": 0, "events": 856.0}, {"hour": "02:00", "score": 90.6, "threats": 3, "events": 290.0}, {"hour": "03:00", "score": 95.3, "threats": 2, "events": 1007.0}, {"hour": "04:00", "score": 100, "threats": 2, "events": 69.0}, {"hour": "05:00", "score": 96.6, "threats": 0, "events": 160.0}, {"hour": "06:00", "score": 100, "threats": 1, "events": 275.0}, {"hour": "07:00", "score": 96.0, "threats": 3, "events": 1331.0}, {"hour": "08:00", "score": 96.9, "threats": 0, "events": 221.0}, {"hour": "09:00", "score": 99.5, "threats": 2, "events": 758.0}, {"hour": "10:00", "score": 100, "threats": 1, "events": 74.0}, {"hour": "11:00", "score": 98.6, "threats": 0, "events": 496.0}, {"hour": "12:00", "score": 98.6, "threats": 1, "events": 1059.0}, {"hour": "13:00", "score": 94.4, "threats": 1, "events": 986.0}, {"hour": "14:00", "score": 88.1, "threats": 0, "events": 439.0}, {"hour": "15:00", "score": 89.3, "threats": 0, "events": 594.0}, {"hour": "16:00", "score": 92.2, "threats": 0, "events": 692.0}, {"hour": "17:00", "score": 86.1, "threats": 2, "events": 183.0}, {"hour": "18:00", "score": 88.9, "threats": 1, "events": 1081.0}, {"hour": "19:00", "score": 83.1, "threats": 3, "events": 1404.0}, {"hour": "20:00", "score": 81.5, "threats": 0, "events": 1268.0}, {"hour": "21:00", "score": 88.0, "threats": 1, "events": 283.0}, {"hour": "22:00", "score": 87.0, "threats": 0, "events": 691.0}], "top_threats": [{"type": "Brute Force", "count": 32, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 91, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 4, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 15, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 1, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 12, "findings": 15}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 21, "findings": 1}, {"name": "ITDR", "status": "ACTIVE", "scans": 8, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 28, "findings": 44}, {"name": "SIEM", "status": "ACTIVE", "scans": 399, "findings": 27}, {"name": "APM", "status": "ACTIVE", "scans": 18, "findings": 7}], "geo_attacks": 12, "blocked_today": 4859, "mean_detect_min": 2.6}	2026-04-22 22:50:38.345181	{}
f3536324-d3ff-4b83-aba3-cbef045fd216	1	75.5	MEDIUM	5	6	86.7	99.4	4131	{"timeline": [{"hour": "23:00", "score": 81.2, "threats": 2, "events": 4044.0}, {"hour": "00:00", "score": 87.3, "threats": 1, "events": 2925.0}, {"hour": "01:00", "score": 83.8, "threats": 8, "events": 562.0}, {"hour": "02:00", "score": 91.3, "threats": 1, "events": 3790.0}, {"hour": "03:00", "score": 87.7, "threats": 0, "events": 1318.0}, {"hour": "04:00", "score": 83.6, "threats": 1, "events": 317.0}, {"hour": "05:00", "score": 80.7, "threats": 7, "events": 2350.0}, {"hour": "06:00", "score": 82.4, "threats": 5, "events": 3138.0}, {"hour": "07:00", "score": 89.2, "threats": 1, "events": 943.0}, {"hour": "08:00", "score": 94.4, "threats": 3, "events": 2898.0}, {"hour": "09:00", "score": 88.9, "threats": 2, "events": 2112.0}, {"hour": "10:00", "score": 82.0, "threats": 3, "events": 215.0}, {"hour": "11:00", "score": 87.8, "threats": 6, "events": 1390.0}, {"hour": "12:00", "score": 84.2, "threats": 7, "events": 1296.0}, {"hour": "13:00", "score": 87.3, "threats": 8, "events": 2925.0}, {"hour": "14:00", "score": 92.9, "threats": 0, "events": 1356.0}, {"hour": "15:00", "score": 97.9, "threats": 7, "events": 3699.0}, {"hour": "16:00", "score": 93.9, "threats": 6, "events": 325.0}, {"hour": "17:00", "score": 86.1, "threats": 0, "events": 253.0}, {"hour": "18:00", "score": 90.1, "threats": 7, "events": 1525.0}, {"hour": "19:00", "score": 94.8, "threats": 1, "events": 2396.0}, {"hour": "20:00", "score": 100, "threats": 0, "events": 3234.0}, {"hour": "21:00", "score": 100, "threats": 1, "events": 3152.0}, {"hour": "22:00", "score": 98.4, "threats": 6, "events": 1361.0}], "top_threats": [{"type": "Brute Force", "count": 17, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 50, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 15, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 14, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 1, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 44, "findings": 7}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 14, "findings": 7}, {"name": "ITDR", "status": "ACTIVE", "scans": 20, "findings": 0}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 38, "findings": 16}, {"name": "SIEM", "status": "ACTIVE", "scans": 568, "findings": 23}, {"name": "APM", "status": "ACTIVE", "scans": 6, "findings": 1}], "geo_attacks": 17, "blocked_today": 2574, "mean_detect_min": 6.2}	2026-04-22 22:48:23.338332	{}
84ff2ddb-6730-4082-91b0-e84c8a1b19f0	1	74.7	CRITICAL	18	1	70.2	98.61	4227	{"timeline": [{"hour": "23:00", "score": 78.0, "threats": 14, "events": 1013.0}, {"hour": "00:00", "score": 72.2, "threats": 5, "events": 115.0}, {"hour": "01:00", "score": 64.3, "threats": 21, "events": 3322.0}, {"hour": "02:00", "score": 61.2, "threats": 3, "events": 500.0}, {"hour": "03:00", "score": 56.2, "threats": 9, "events": 1070.0}, {"hour": "04:00", "score": 55.0, "threats": 16, "events": 2819.0}, {"hour": "05:00", "score": 60.5, "threats": 17, "events": 918.0}, {"hour": "06:00", "score": 66.7, "threats": 11, "events": 3919.0}, {"hour": "07:00", "score": 71.7, "threats": 13, "events": 1577.0}, {"hour": "08:00", "score": 63.8, "threats": 6, "events": 2739.0}, {"hour": "09:00", "score": 62.0, "threats": 16, "events": 3981.0}, {"hour": "10:00", "score": 55.3, "threats": 13, "events": 367.0}, {"hour": "11:00", "score": 49.7, "threats": 3, "events": 3538.0}, {"hour": "12:00", "score": 44.1, "threats": 11, "events": 1486.0}, {"hour": "13:00", "score": 48.5, "threats": 4, "events": 392.0}, {"hour": "14:00", "score": 49.4, "threats": 8, "events": 2846.0}, {"hour": "15:00", "score": 45.5, "threats": 15, "events": 820.0}, {"hour": "16:00", "score": 42.4, "threats": 8, "events": 681.0}, {"hour": "17:00", "score": 45.6, "threats": 7, "events": 680.0}, {"hour": "18:00", "score": 53.4, "threats": 20, "events": 3537.0}, {"hour": "19:00", "score": 46.1, "threats": 14, "events": 2808.0}, {"hour": "20:00", "score": 47.1, "threats": 20, "events": 3116.0}, {"hour": "21:00", "score": 48.0, "threats": 5, "events": 249.0}, {"hour": "22:00", "score": 48.2, "threats": 12, "events": 2378.0}], "top_threats": [{"type": "Brute Force", "count": 21, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 43, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 13, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 15, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 1, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 21, "findings": 14}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 5, "findings": 0}, {"name": "ITDR", "status": "ACTIVE", "scans": 7, "findings": 5}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 30, "findings": 10}, {"name": "SIEM", "status": "ACTIVE", "scans": 824, "findings": 30}, {"name": "APM", "status": "ACTIVE", "scans": 6, "findings": 0}], "geo_attacks": 45, "blocked_today": 655, "mean_detect_min": 12.3}	2026-04-22 22:52:08.42492	{}
59939757-a044-4561-ae90-24bc6efc688e	1	48.3	CRITICAL	19	6	73.8	99.37	4490	{"timeline": [{"hour": "23:00", "score": 53.0, "threats": 0, "events": 3933.0}, {"hour": "00:00", "score": 52.9, "threats": 12, "events": 1062.0}, {"hour": "01:00", "score": 52.0, "threats": 2, "events": 2803.0}, {"hour": "02:00", "score": 44.9, "threats": 15, "events": 3775.0}, {"hour": "03:00", "score": 46.7, "threats": 4, "events": 235.0}, {"hour": "04:00", "score": 45.6, "threats": 18, "events": 4388.0}, {"hour": "05:00", "score": 39.3, "threats": 15, "events": 277.0}, {"hour": "06:00", "score": 46.0, "threats": 1, "events": 2657.0}, {"hour": "07:00", "score": 48.6, "threats": 21, "events": 989.0}, {"hour": "08:00", "score": 56.1, "threats": 17, "events": 2827.0}, {"hour": "09:00", "score": 56.8, "threats": 16, "events": 74.0}, {"hour": "10:00", "score": 60.3, "threats": 11, "events": 2161.0}, {"hour": "11:00", "score": 53.6, "threats": 11, "events": 998.0}, {"hour": "12:00", "score": 59.0, "threats": 18, "events": 1938.0}, {"hour": "13:00", "score": 56.0, "threats": 15, "events": 3737.0}, {"hour": "14:00", "score": 53.5, "threats": 19, "events": 3196.0}, {"hour": "15:00", "score": 49.6, "threats": 11, "events": 1960.0}, {"hour": "16:00", "score": 53.5, "threats": 21, "events": 2479.0}, {"hour": "17:00", "score": 58.5, "threats": 14, "events": 4232.0}, {"hour": "18:00", "score": 51.6, "threats": 12, "events": 4398.0}, {"hour": "19:00", "score": 50.6, "threats": 1, "events": 3501.0}, {"hour": "20:00", "score": 57.3, "threats": 4, "events": 470.0}, {"hour": "21:00", "score": 58.3, "threats": 22, "events": 1754.0}, {"hour": "22:00", "score": 51.6, "threats": 17, "events": 462.0}], "top_threats": [{"type": "Brute Force", "count": 21, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 17, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 7, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 7, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 48, "findings": 18}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 22, "findings": 8}, {"name": "ITDR", "status": "ACTIVE", "scans": 3, "findings": 9}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 61, "findings": 36}, {"name": "SIEM", "status": "ACTIVE", "scans": 907, "findings": 19}, {"name": "APM", "status": "ACTIVE", "scans": 22, "findings": 2}], "geo_attacks": 30, "blocked_today": 734, "mean_detect_min": 12.8}	2026-04-22 22:48:53.342256	{}
8f51b251-d513-4157-a133-daa15fdeea13	1	55.6	CRITICAL	25	8	95.1	98.45	3902	{"timeline": [{"hour": "23:00", "score": 61.3, "threats": 0, "events": 3736.0}, {"hour": "00:00", "score": 53.7, "threats": 7, "events": 1755.0}, {"hour": "01:00", "score": 53.8, "threats": 23, "events": 165.0}, {"hour": "02:00", "score": 46.2, "threats": 19, "events": 2356.0}, {"hour": "03:00", "score": 50.4, "threats": 15, "events": 2290.0}, {"hour": "04:00", "score": 55.9, "threats": 15, "events": 111.0}, {"hour": "05:00", "score": 57.2, "threats": 13, "events": 584.0}, {"hour": "06:00", "score": 52.7, "threats": 9, "events": 1453.0}, {"hour": "07:00", "score": 46.2, "threats": 5, "events": 1818.0}, {"hour": "08:00", "score": 44.1, "threats": 27, "events": 768.0}, {"hour": "09:00", "score": 41.7, "threats": 10, "events": 551.0}, {"hour": "10:00", "score": 37.2, "threats": 19, "events": 2101.0}, {"hour": "11:00", "score": 42.1, "threats": 12, "events": 588.0}, {"hour": "12:00", "score": 48.0, "threats": 10, "events": 1717.0}, {"hour": "13:00", "score": 48.3, "threats": 28, "events": 2107.0}, {"hour": "14:00", "score": 44.5, "threats": 26, "events": 2092.0}, {"hour": "15:00", "score": 51.9, "threats": 2, "events": 3209.0}, {"hour": "16:00", "score": 52.7, "threats": 0, "events": 3660.0}, {"hour": "17:00", "score": 48.5, "threats": 10, "events": 3039.0}, {"hour": "18:00", "score": 46.6, "threats": 16, "events": 2711.0}, {"hour": "19:00", "score": 50.0, "threats": 3, "events": 2397.0}, {"hour": "20:00", "score": 50.9, "threats": 5, "events": 3067.0}, {"hour": "21:00", "score": 46.3, "threats": 24, "events": 1730.0}, {"hour": "22:00", "score": 51.9, "threats": 19, "events": 889.0}], "top_threats": [{"type": "Brute Force", "count": 9, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 43, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 5, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 9, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 4, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 39, "findings": 2}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 27, "findings": 9}, {"name": "ITDR", "status": "ACTIVE", "scans": 7, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 43, "findings": 22}, {"name": "SIEM", "status": "ACTIVE", "scans": 261, "findings": 28}, {"name": "APM", "status": "ACTIVE", "scans": 19, "findings": 5}], "geo_attacks": 41, "blocked_today": 1219, "mean_detect_min": 4.7}	2026-04-22 22:49:23.369027	{}
3ef056a1-7eea-41b9-941a-d0c89f6a6a64	1	46	CRITICAL	23	3	92.3	98.49	1017	{"timeline": [{"hour": "23:00", "score": 42.0, "threats": 7, "events": 77.0}, {"hour": "00:00", "score": 45.9, "threats": 12, "events": 935.0}, {"hour": "01:00", "score": 43.8, "threats": 1, "events": 889.0}, {"hour": "02:00", "score": 42.0, "threats": 11, "events": 648.0}, {"hour": "03:00", "score": 43.7, "threats": 21, "events": 410.0}, {"hour": "04:00", "score": 49.5, "threats": 19, "events": 70.0}, {"hour": "05:00", "score": 48.5, "threats": 23, "events": 362.0}, {"hour": "06:00", "score": 46.5, "threats": 22, "events": 652.0}, {"hour": "07:00", "score": 54.3, "threats": 3, "events": 554.0}, {"hour": "08:00", "score": 52.0, "threats": 23, "events": 709.0}, {"hour": "09:00", "score": 49.0, "threats": 15, "events": 971.0}, {"hour": "10:00", "score": 53.9, "threats": 25, "events": 118.0}, {"hour": "11:00", "score": 52.5, "threats": 18, "events": 82.0}, {"hour": "12:00", "score": 55.0, "threats": 16, "events": 990.0}, {"hour": "13:00", "score": 60.2, "threats": 17, "events": 725.0}, {"hour": "14:00", "score": 67.9, "threats": 4, "events": 579.0}, {"hour": "15:00", "score": 63.3, "threats": 17, "events": 259.0}, {"hour": "16:00", "score": 56.0, "threats": 9, "events": 442.0}, {"hour": "17:00", "score": 63.8, "threats": 25, "events": 877.0}, {"hour": "18:00", "score": 70.0, "threats": 9, "events": 162.0}, {"hour": "19:00", "score": 67.0, "threats": 23, "events": 51.0}, {"hour": "20:00", "score": 63.2, "threats": 22, "events": 397.0}, {"hour": "21:00", "score": 59.2, "threats": 7, "events": 391.0}, {"hour": "22:00", "score": 53.7, "threats": 25, "events": 252.0}], "top_threats": [{"type": "Brute Force", "count": 7, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 88, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 10, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 12, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 0, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 11, "findings": 9}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 29, "findings": 6}, {"name": "ITDR", "status": "ACTIVE", "scans": 8, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 30, "findings": 27}, {"name": "SIEM", "status": "ACTIVE", "scans": 385, "findings": 6}, {"name": "APM", "status": "ACTIVE", "scans": 15, "findings": 4}], "geo_attacks": 45, "blocked_today": 186, "mean_detect_min": 14.0}	2026-04-22 22:49:53.369169	{}
7013d69d-ee6e-4eaf-9f1a-749484ce12ce	1	66.5	LOW	2	3	78.5	97.47	1309	{"timeline": [{"hour": "23:00", "score": 59.6, "threats": 3, "events": 895.0}, {"hour": "00:00", "score": 52.1, "threats": 1, "events": 720.0}, {"hour": "01:00", "score": 45.0, "threats": 5, "events": 1061.0}, {"hour": "02:00", "score": 38.0, "threats": 1, "events": 108.0}, {"hour": "03:00", "score": 37.9, "threats": 5, "events": 578.0}, {"hour": "04:00", "score": 44.2, "threats": 1, "events": 462.0}, {"hour": "05:00", "score": 46.1, "threats": 5, "events": 713.0}, {"hour": "06:00", "score": 47.1, "threats": 1, "events": 213.0}, {"hour": "07:00", "score": 49.9, "threats": 4, "events": 709.0}, {"hour": "08:00", "score": 43.2, "threats": 3, "events": 851.0}, {"hour": "09:00", "score": 36.9, "threats": 2, "events": 198.0}, {"hour": "10:00", "score": 35.2, "threats": 4, "events": 74.0}, {"hour": "11:00", "score": 32.4, "threats": 3, "events": 198.0}, {"hour": "12:00", "score": 26.8, "threats": 3, "events": 790.0}, {"hour": "13:00", "score": 30.1, "threats": 0, "events": 696.0}, {"hour": "14:00", "score": 23.0, "threats": 4, "events": 701.0}, {"hour": "15:00", "score": 21.6, "threats": 2, "events": 354.0}, {"hour": "16:00", "score": 28.9, "threats": 4, "events": 889.0}, {"hour": "17:00", "score": 27.6, "threats": 1, "events": 1289.0}, {"hour": "18:00", "score": 27.2, "threats": 4, "events": 1214.0}, {"hour": "19:00", "score": 28.6, "threats": 4, "events": 1012.0}, {"hour": "20:00", "score": 32.2, "threats": 5, "events": 468.0}, {"hour": "21:00", "score": 28.2, "threats": 1, "events": 80.0}, {"hour": "22:00", "score": 23.9, "threats": 5, "events": 239.0}], "top_threats": [{"type": "Brute Force", "count": 15, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 55, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 16, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 30, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 36, "findings": 19}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 26, "findings": 5}, {"name": "ITDR", "status": "ACTIVE", "scans": 5, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 41, "findings": 32}, {"name": "SIEM", "status": "ACTIVE", "scans": 721, "findings": 19}, {"name": "APM", "status": "ACTIVE", "scans": 11, "findings": 6}], "geo_attacks": 5, "blocked_today": 228, "mean_detect_min": 5.2}	2026-04-22 22:50:23.351271	{}
f08b618f-bac4-43dd-ac49-9896b110abcd	1	78.8	MEDIUM	6	4	74.3	97.77	442	{"timeline": [{"hour": "23:00", "score": 71.0, "threats": 9, "events": 264.0}, {"hour": "00:00", "score": 70.1, "threats": 2, "events": 181.0}, {"hour": "01:00", "score": 68.1, "threats": 8, "events": 324.0}, {"hour": "02:00", "score": 69.2, "threats": 5, "events": 175.0}, {"hour": "03:00", "score": 76.4, "threats": 3, "events": 196.0}, {"hour": "04:00", "score": 72.4, "threats": 5, "events": 104.0}, {"hour": "05:00", "score": 70.2, "threats": 8, "events": 396.0}, {"hour": "06:00", "score": 78.0, "threats": 8, "events": 207.0}, {"hour": "07:00", "score": 78.3, "threats": 6, "events": 251.0}, {"hour": "08:00", "score": 74.4, "threats": 3, "events": 75.0}, {"hour": "09:00", "score": 78.7, "threats": 8, "events": 217.0}, {"hour": "10:00", "score": 74.9, "threats": 9, "events": 105.0}, {"hour": "11:00", "score": 78.4, "threats": 5, "events": 374.0}, {"hour": "12:00", "score": 83.5, "threats": 2, "events": 68.0}, {"hour": "13:00", "score": 79.2, "threats": 2, "events": 238.0}, {"hour": "14:00", "score": 72.3, "threats": 2, "events": 225.0}, {"hour": "15:00", "score": 76.4, "threats": 5, "events": 253.0}, {"hour": "16:00", "score": 82.0, "threats": 5, "events": 440.0}, {"hour": "17:00", "score": 78.0, "threats": 5, "events": 398.0}, {"hour": "18:00", "score": 79.8, "threats": 3, "events": 332.0}, {"hour": "19:00", "score": 73.3, "threats": 5, "events": 141.0}, {"hour": "20:00", "score": 81.2, "threats": 9, "events": 52.0}, {"hour": "21:00", "score": 76.9, "threats": 9, "events": 400.0}, {"hour": "22:00", "score": 79.2, "threats": 9, "events": 322.0}], "top_threats": [{"type": "Brute Force", "count": 12, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 77, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 5, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 6, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 19, "findings": 19}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 5, "findings": 4}, {"name": "ITDR", "status": "ACTIVE", "scans": 3, "findings": 9}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 51, "findings": 46}, {"name": "SIEM", "status": "ACTIVE", "scans": 949, "findings": 29}, {"name": "APM", "status": "ACTIVE", "scans": 22, "findings": 2}], "geo_attacks": 43, "blocked_today": 1122, "mean_detect_min": 10.0}	2026-04-22 22:50:53.355425	{}
318d301e-f4e4-4cfa-9985-a660f72c9438	1	75.8	CRITICAL	24	0	87.1	97.45	2627	{"timeline": [{"hour": "23:00", "score": 77.9, "threats": 5, "events": 1102.0}, {"hour": "00:00", "score": 72.4, "threats": 3, "events": 139.0}, {"hour": "01:00", "score": 65.2, "threats": 5, "events": 2346.0}, {"hour": "02:00", "score": 61.6, "threats": 23, "events": 1246.0}, {"hour": "03:00", "score": 64.5, "threats": 8, "events": 985.0}, {"hour": "04:00", "score": 64.2, "threats": 24, "events": 2199.0}, {"hour": "05:00", "score": 66.0, "threats": 22, "events": 2266.0}, {"hour": "06:00", "score": 60.8, "threats": 4, "events": 2098.0}, {"hour": "07:00", "score": 66.0, "threats": 10, "events": 644.0}, {"hour": "08:00", "score": 65.5, "threats": 11, "events": 2285.0}, {"hour": "09:00", "score": 65.5, "threats": 27, "events": 658.0}, {"hour": "10:00", "score": 65.6, "threats": 1, "events": 812.0}, {"hour": "11:00", "score": 67.1, "threats": 23, "events": 2599.0}, {"hour": "12:00", "score": 66.4, "threats": 5, "events": 2313.0}, {"hour": "13:00", "score": 72.4, "threats": 21, "events": 1888.0}, {"hour": "14:00", "score": 79.9, "threats": 23, "events": 801.0}, {"hour": "15:00", "score": 71.9, "threats": 11, "events": 2414.0}, {"hour": "16:00", "score": 71.5, "threats": 23, "events": 1198.0}, {"hour": "17:00", "score": 78.3, "threats": 25, "events": 1598.0}, {"hour": "18:00", "score": 76.5, "threats": 26, "events": 825.0}, {"hour": "19:00", "score": 71.3, "threats": 25, "events": 2409.0}, {"hour": "20:00", "score": 65.0, "threats": 18, "events": 2413.0}, {"hour": "21:00", "score": 67.8, "threats": 6, "events": 591.0}, {"hour": "22:00", "score": 63.2, "threats": 27, "events": 1098.0}], "top_threats": [{"type": "Brute Force", "count": 31, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 45, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 11, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 21, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 5, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 30, "findings": 3}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 30, "findings": 13}, {"name": "ITDR", "status": "ACTIVE", "scans": 18, "findings": 1}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 36, "findings": 0}, {"name": "SIEM", "status": "ACTIVE", "scans": 259, "findings": 23}, {"name": "APM", "status": "ACTIVE", "scans": 20, "findings": 2}], "geo_attacks": 24, "blocked_today": 4860, "mean_detect_min": 3.9}	2026-04-22 22:51:23.470376	{}
10c002a9-1f1a-4763-9d52-75e1ef7a215a	1	89.4	CRITICAL	19	0	67.1	99.73	1286	{"timeline": [{"hour": "23:00", "score": 95.3, "threats": 2, "events": 1275.0}, {"hour": "00:00", "score": 100, "threats": 10, "events": 373.0}, {"hour": "01:00", "score": 92.7, "threats": 9, "events": 975.0}, {"hour": "02:00", "score": 86.8, "threats": 12, "events": 1110.0}, {"hour": "03:00", "score": 88.2, "threats": 1, "events": 529.0}, {"hour": "04:00", "score": 86.0, "threats": 4, "events": 461.0}, {"hour": "05:00", "score": 80.9, "threats": 19, "events": 194.0}, {"hour": "06:00", "score": 82.6, "threats": 4, "events": 1243.0}, {"hour": "07:00", "score": 85.7, "threats": 18, "events": 934.0}, {"hour": "08:00", "score": 79.7, "threats": 6, "events": 889.0}, {"hour": "09:00", "score": 74.2, "threats": 7, "events": 848.0}, {"hour": "10:00", "score": 73.5, "threats": 21, "events": 1087.0}, {"hour": "11:00", "score": 70.3, "threats": 19, "events": 867.0}, {"hour": "12:00", "score": 68.8, "threats": 1, "events": 157.0}, {"hour": "13:00", "score": 67.8, "threats": 6, "events": 136.0}, {"hour": "14:00", "score": 61.6, "threats": 21, "events": 848.0}, {"hour": "15:00", "score": 54.0, "threats": 3, "events": 419.0}, {"hour": "16:00", "score": 48.1, "threats": 21, "events": 610.0}, {"hour": "17:00", "score": 46.3, "threats": 21, "events": 1097.0}, {"hour": "18:00", "score": 51.8, "threats": 9, "events": 1082.0}, {"hour": "19:00", "score": 51.0, "threats": 3, "events": 1173.0}, {"hour": "20:00", "score": 49.2, "threats": 3, "events": 1062.0}, {"hour": "21:00", "score": 41.6, "threats": 3, "events": 1076.0}, {"hour": "22:00", "score": 35.7, "threats": 16, "events": 410.0}], "top_threats": [{"type": "Brute Force", "count": 33, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 25, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 4, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 2, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 5, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 50, "findings": 18}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 20, "findings": 4}, {"name": "ITDR", "status": "ACTIVE", "scans": 15, "findings": 0}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 98, "findings": 10}, {"name": "SIEM", "status": "ACTIVE", "scans": 736, "findings": 30}, {"name": "APM", "status": "ACTIVE", "scans": 18, "findings": 7}], "geo_attacks": 17, "blocked_today": 4820, "mean_detect_min": 5.7}	2026-04-22 22:51:08.33536	{}
9b1a0aaf-d8a3-4989-a219-e3f9e57a2964	1	92.3	MEDIUM	6	8	78.5	97.13	2300	{"timeline": [{"hour": "23:00", "score": 99.1, "threats": 6, "events": 1054.0}, {"hour": "00:00", "score": 100, "threats": 4, "events": 1244.0}, {"hour": "01:00", "score": 94.5, "threats": 7, "events": 2105.0}, {"hour": "02:00", "score": 89.3, "threats": 7, "events": 367.0}, {"hour": "03:00", "score": 83.4, "threats": 4, "events": 1627.0}, {"hour": "04:00", "score": 84.6, "threats": 1, "events": 1629.0}, {"hour": "05:00", "score": 83.1, "threats": 1, "events": 1027.0}, {"hour": "06:00", "score": 78.9, "threats": 6, "events": 484.0}, {"hour": "07:00", "score": 82.1, "threats": 6, "events": 1579.0}, {"hour": "08:00", "score": 86.8, "threats": 8, "events": 1350.0}, {"hour": "09:00", "score": 81.3, "threats": 7, "events": 446.0}, {"hour": "10:00", "score": 82.8, "threats": 3, "events": 651.0}, {"hour": "11:00", "score": 78.2, "threats": 3, "events": 999.0}, {"hour": "12:00", "score": 83.1, "threats": 3, "events": 1396.0}, {"hour": "13:00", "score": 87.2, "threats": 0, "events": 1982.0}, {"hour": "14:00", "score": 84.5, "threats": 1, "events": 2088.0}, {"hour": "15:00", "score": 87.5, "threats": 7, "events": 1701.0}, {"hour": "16:00", "score": 86.0, "threats": 4, "events": 701.0}, {"hour": "17:00", "score": 78.6, "threats": 3, "events": 1275.0}, {"hour": "18:00", "score": 81.0, "threats": 2, "events": 636.0}, {"hour": "19:00", "score": 82.6, "threats": 0, "events": 2029.0}, {"hour": "20:00", "score": 81.0, "threats": 4, "events": 1945.0}, {"hour": "21:00", "score": 77.4, "threats": 2, "events": 2159.0}, {"hour": "22:00", "score": 76.9, "threats": 4, "events": 1416.0}], "top_threats": [{"type": "Brute Force", "count": 12, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 83, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 6, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 7, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 13, "findings": 20}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 29, "findings": 11}, {"name": "ITDR", "status": "ACTIVE", "scans": 12, "findings": 6}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 44, "findings": 40}, {"name": "SIEM", "status": "ACTIVE", "scans": 592, "findings": 29}, {"name": "APM", "status": "ACTIVE", "scans": 18, "findings": 6}], "geo_attacks": 10, "blocked_today": 1995, "mean_detect_min": 3.6}	2026-04-22 22:51:38.426	{}
8795d480-b39f-4ea8-a51b-0e76da71760a	1	87.3	MEDIUM	4	8	65.2	98.34	3325	{"timeline": [{"hour": "23:00", "score": 81.6, "threats": 7, "events": 3043.0}, {"hour": "00:00", "score": 89.5, "threats": 4, "events": 2396.0}, {"hour": "01:00", "score": 90.2, "threats": 0, "events": 2489.0}, {"hour": "02:00", "score": 82.5, "threats": 3, "events": 2138.0}, {"hour": "03:00", "score": 82.1, "threats": 6, "events": 70.0}, {"hour": "04:00", "score": 80.9, "threats": 4, "events": 1609.0}, {"hour": "05:00", "score": 81.0, "threats": 2, "events": 2540.0}, {"hour": "06:00", "score": 83.8, "threats": 6, "events": 2696.0}, {"hour": "07:00", "score": 78.9, "threats": 0, "events": 2156.0}, {"hour": "08:00", "score": 86.0, "threats": 5, "events": 2567.0}, {"hour": "09:00", "score": 89.2, "threats": 1, "events": 2487.0}, {"hour": "10:00", "score": 95.1, "threats": 1, "events": 1150.0}, {"hour": "11:00", "score": 98.2, "threats": 1, "events": 125.0}, {"hour": "12:00", "score": 92.5, "threats": 5, "events": 2013.0}, {"hour": "13:00", "score": 84.8, "threats": 2, "events": 1975.0}, {"hour": "14:00", "score": 86.1, "threats": 2, "events": 1902.0}, {"hour": "15:00", "score": 80.8, "threats": 2, "events": 351.0}, {"hour": "16:00", "score": 86.5, "threats": 2, "events": 779.0}, {"hour": "17:00", "score": 78.7, "threats": 6, "events": 711.0}, {"hour": "18:00", "score": 79.8, "threats": 4, "events": 3165.0}, {"hour": "19:00", "score": 75.1, "threats": 1, "events": 3051.0}, {"hour": "20:00", "score": 74.6, "threats": 7, "events": 1307.0}, {"hour": "21:00", "score": 68.7, "threats": 7, "events": 2923.0}, {"hour": "22:00", "score": 62.0, "threats": 0, "events": 864.0}], "top_threats": [{"type": "Brute Force", "count": 9, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 40, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 1, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 5, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 29, "findings": 19}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 7, "findings": 0}, {"name": "ITDR", "status": "ACTIVE", "scans": 5, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 96, "findings": 16}, {"name": "SIEM", "status": "ACTIVE", "scans": 270, "findings": 19}, {"name": "APM", "status": "ACTIVE", "scans": 21, "findings": 1}], "geo_attacks": 37, "blocked_today": 3575, "mean_detect_min": 14.5}	2026-04-22 22:51:53.327479	{}
d541c55e-c127-47d1-9ae6-6d64c764d246	1	45.7	CRITICAL	19	0	78.3	98	976	{"timeline": [{"hour": "23:00", "score": 39.3, "threats": 10, "events": 884.0}, {"hour": "00:00", "score": 38.9, "threats": 7, "events": 967.0}, {"hour": "01:00", "score": 44.9, "threats": 7, "events": 613.0}, {"hour": "02:00", "score": 48.6, "threats": 1, "events": 852.0}, {"hour": "03:00", "score": 53.8, "threats": 0, "events": 943.0}, {"hour": "04:00", "score": 58.6, "threats": 7, "events": 587.0}, {"hour": "05:00", "score": 56.6, "threats": 19, "events": 203.0}, {"hour": "06:00", "score": 62.6, "threats": 11, "events": 574.0}, {"hour": "07:00", "score": 63.7, "threats": 6, "events": 338.0}, {"hour": "08:00", "score": 63.7, "threats": 7, "events": 326.0}, {"hour": "09:00", "score": 69.3, "threats": 19, "events": 76.0}, {"hour": "10:00", "score": 63.7, "threats": 14, "events": 407.0}, {"hour": "11:00", "score": 67.2, "threats": 17, "events": 538.0}, {"hour": "12:00", "score": 70.3, "threats": 3, "events": 295.0}, {"hour": "13:00", "score": 70.8, "threats": 7, "events": 425.0}, {"hour": "14:00", "score": 74.2, "threats": 8, "events": 108.0}, {"hour": "15:00", "score": 77.2, "threats": 17, "events": 638.0}, {"hour": "16:00", "score": 81.7, "threats": 16, "events": 334.0}, {"hour": "17:00", "score": 85.3, "threats": 12, "events": 250.0}, {"hour": "18:00", "score": 90.6, "threats": 4, "events": 820.0}, {"hour": "19:00", "score": 89.3, "threats": 11, "events": 656.0}, {"hour": "20:00", "score": 95.5, "threats": 1, "events": 765.0}, {"hour": "21:00", "score": 91.6, "threats": 0, "events": 241.0}, {"hour": "22:00", "score": 91.4, "threats": 21, "events": 695.0}], "top_threats": [{"type": "Brute Force", "count": 20, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 96, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 19, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 22, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 50, "findings": 9}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 16, "findings": 9}, {"name": "ITDR", "status": "ACTIVE", "scans": 6, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 44, "findings": 36}, {"name": "SIEM", "status": "ACTIVE", "scans": 651, "findings": 0}, {"name": "APM", "status": "ACTIVE", "scans": 21, "findings": 7}], "geo_attacks": 38, "blocked_today": 2330, "mean_detect_min": 11.5}	2026-04-22 22:57:21.140527	{}
60af043f-c48e-49cb-8216-766c5b9ab326	1	87.6	HIGH	14	1	69.4	99.05	497	{"timeline": [{"hour": "00:00", "score": 82.5, "threats": 6, "events": 361.0}, {"hour": "01:00", "score": 86.8, "threats": 1, "events": 184.0}, {"hour": "02:00", "score": 81.1, "threats": 16, "events": 182.0}, {"hour": "03:00", "score": 73.5, "threats": 0, "events": 215.0}, {"hour": "04:00", "score": 79.0, "threats": 1, "events": 214.0}, {"hour": "05:00", "score": 82.3, "threats": 13, "events": 177.0}, {"hour": "06:00", "score": 87.9, "threats": 12, "events": 453.0}, {"hour": "07:00", "score": 90.2, "threats": 7, "events": 279.0}, {"hour": "08:00", "score": 95.1, "threats": 14, "events": 397.0}, {"hour": "09:00", "score": 87.5, "threats": 10, "events": 199.0}, {"hour": "10:00", "score": 82.2, "threats": 14, "events": 460.0}, {"hour": "11:00", "score": 79.7, "threats": 10, "events": 382.0}, {"hour": "12:00", "score": 73.0, "threats": 12, "events": 94.0}, {"hour": "13:00", "score": 65.0, "threats": 10, "events": 468.0}, {"hour": "14:00", "score": 61.9, "threats": 15, "events": 238.0}, {"hour": "15:00", "score": 66.9, "threats": 12, "events": 176.0}, {"hour": "16:00", "score": 65.1, "threats": 5, "events": 310.0}, {"hour": "17:00", "score": 58.7, "threats": 17, "events": 293.0}, {"hour": "18:00", "score": 52.7, "threats": 3, "events": 234.0}, {"hour": "19:00", "score": 57.8, "threats": 11, "events": 344.0}, {"hour": "20:00", "score": 50.6, "threats": 0, "events": 94.0}, {"hour": "21:00", "score": 44.1, "threats": 8, "events": 241.0}, {"hour": "22:00", "score": 48.0, "threats": 7, "events": 135.0}, {"hour": "23:00", "score": 44.9, "threats": 16, "events": 294.0}], "top_threats": [{"type": "Brute Force", "count": 39, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 10, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 7, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 17, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 16, "findings": 19}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 22, "findings": 5}, {"name": "ITDR", "status": "ACTIVE", "scans": 19, "findings": 9}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 66, "findings": 14}, {"name": "SIEM", "status": "ACTIVE", "scans": 375, "findings": 19}, {"name": "APM", "status": "ACTIVE", "scans": 18, "findings": 8}], "geo_attacks": 40, "blocked_today": 832, "mean_detect_min": 1.9}	2026-04-22 23:47:51.696361	{}
d3158e23-3945-4f4d-a7a8-a03dd5d6c62c	1	90.6	CRITICAL	23	4	86.3	99.91	3340	{"timeline": [{"hour": "00:00", "score": 88.4, "threats": 23, "events": 2132.0}, {"hour": "01:00", "score": 86.3, "threats": 26, "events": 987.0}, {"hour": "02:00", "score": 82.4, "threats": 18, "events": 689.0}, {"hour": "03:00", "score": 76.5, "threats": 6, "events": 2481.0}, {"hour": "04:00", "score": 70.7, "threats": 10, "events": 1468.0}, {"hour": "05:00", "score": 74.2, "threats": 13, "events": 731.0}, {"hour": "06:00", "score": 66.5, "threats": 10, "events": 840.0}, {"hour": "07:00", "score": 73.3, "threats": 1, "events": 127.0}, {"hour": "08:00", "score": 69.4, "threats": 9, "events": 2418.0}, {"hour": "09:00", "score": 67.3, "threats": 15, "events": 1857.0}, {"hour": "10:00", "score": 67.0, "threats": 18, "events": 2382.0}, {"hour": "11:00", "score": 70.5, "threats": 0, "events": 593.0}, {"hour": "12:00", "score": 74.1, "threats": 18, "events": 1969.0}, {"hour": "13:00", "score": 81.9, "threats": 18, "events": 2307.0}, {"hour": "14:00", "score": 81.0, "threats": 6, "events": 2103.0}, {"hour": "15:00", "score": 86.5, "threats": 5, "events": 391.0}, {"hour": "16:00", "score": 91.7, "threats": 10, "events": 1991.0}, {"hour": "17:00", "score": 93.0, "threats": 3, "events": 2361.0}, {"hour": "18:00", "score": 88.8, "threats": 6, "events": 1354.0}, {"hour": "19:00", "score": 83.4, "threats": 2, "events": 2155.0}, {"hour": "20:00", "score": 78.2, "threats": 13, "events": 2329.0}, {"hour": "21:00", "score": 79.7, "threats": 1, "events": 129.0}, {"hour": "22:00", "score": 84.6, "threats": 18, "events": 3291.0}, {"hour": "23:00", "score": 92.5, "threats": 2, "events": 1251.0}], "top_threats": [{"type": "Brute Force", "count": 46, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 93, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 8, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 22, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 21, "findings": 18}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 15, "findings": 7}, {"name": "ITDR", "status": "ACTIVE", "scans": 6, "findings": 3}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 79, "findings": 45}, {"name": "SIEM", "status": "ACTIVE", "scans": 497, "findings": 25}, {"name": "APM", "status": "ACTIVE", "scans": 17, "findings": 8}], "geo_attacks": 9, "blocked_today": 2472, "mean_detect_min": 2.0}	2026-04-22 23:48:09.490304	{}
4eeb35c4-88ac-4b5e-a003-04a935c3a4bc	1	93.5	HIGH	13	2	95.6	98.79	2854	{"timeline": [{"hour": "00:00", "score": 89.2, "threats": 7, "events": 1532.0}, {"hour": "01:00", "score": 84.5, "threats": 15, "events": 198.0}, {"hour": "02:00", "score": 80.9, "threats": 13, "events": 601.0}, {"hour": "03:00", "score": 83.5, "threats": 15, "events": 960.0}, {"hour": "04:00", "score": 91.2, "threats": 3, "events": 2365.0}, {"hour": "05:00", "score": 93.5, "threats": 14, "events": 872.0}, {"hour": "06:00", "score": 90.9, "threats": 3, "events": 463.0}, {"hour": "07:00", "score": 94.3, "threats": 4, "events": 1542.0}, {"hour": "08:00", "score": 94.2, "threats": 1, "events": 769.0}, {"hour": "09:00", "score": 99.8, "threats": 1, "events": 929.0}, {"hour": "10:00", "score": 100, "threats": 0, "events": 2637.0}, {"hour": "11:00", "score": 100, "threats": 16, "events": 2304.0}, {"hour": "12:00", "score": 100, "threats": 1, "events": 1572.0}, {"hour": "13:00", "score": 96.2, "threats": 5, "events": 658.0}, {"hour": "14:00", "score": 94.9, "threats": 0, "events": 1369.0}, {"hour": "15:00", "score": 95.3, "threats": 7, "events": 724.0}, {"hour": "16:00", "score": 87.8, "threats": 15, "events": 904.0}, {"hour": "17:00", "score": 85.4, "threats": 13, "events": 135.0}, {"hour": "18:00", "score": 80.0, "threats": 0, "events": 1125.0}, {"hour": "19:00", "score": 80.8, "threats": 16, "events": 2155.0}, {"hour": "20:00", "score": 88.3, "threats": 0, "events": 1504.0}, {"hour": "21:00", "score": 94.7, "threats": 5, "events": 1512.0}, {"hour": "22:00", "score": 89.5, "threats": 3, "events": 1157.0}, {"hour": "23:00", "score": 88.5, "threats": 3, "events": 738.0}], "top_threats": [{"type": "Brute Force", "count": 43, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 12, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 9, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 30, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 4, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 46, "findings": 1}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 22, "findings": 15}, {"name": "ITDR", "status": "ACTIVE", "scans": 6, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 45, "findings": 11}, {"name": "SIEM", "status": "ACTIVE", "scans": 598, "findings": 27}, {"name": "APM", "status": "ACTIVE", "scans": 11, "findings": 2}], "geo_attacks": 39, "blocked_today": 2155, "mean_detect_min": 8.2}	2026-04-22 23:48:10.856343	{}
28b4726b-1c75-432d-b779-a7f6164686ee	1	73.2	MEDIUM	6	8	81.7	99.66	2688	{"timeline": [{"hour": "00:00", "score": 77.2, "threats": 4, "events": 2144.0}, {"hour": "01:00", "score": 77.9, "threats": 9, "events": 2178.0}, {"hour": "02:00", "score": 77.5, "threats": 9, "events": 2656.0}, {"hour": "03:00", "score": 70.6, "threats": 7, "events": 882.0}, {"hour": "04:00", "score": 74.6, "threats": 4, "events": 1798.0}, {"hour": "05:00", "score": 72.1, "threats": 5, "events": 373.0}, {"hour": "06:00", "score": 71.9, "threats": 9, "events": 1272.0}, {"hour": "07:00", "score": 64.2, "threats": 7, "events": 2520.0}, {"hour": "08:00", "score": 62.2, "threats": 9, "events": 610.0}, {"hour": "09:00", "score": 59.2, "threats": 0, "events": 616.0}, {"hour": "10:00", "score": 61.4, "threats": 8, "events": 1364.0}, {"hour": "11:00", "score": 55.1, "threats": 4, "events": 1433.0}, {"hour": "12:00", "score": 59.2, "threats": 1, "events": 1984.0}, {"hour": "13:00", "score": 63.6, "threats": 9, "events": 1051.0}, {"hour": "14:00", "score": 66.6, "threats": 0, "events": 1404.0}, {"hour": "15:00", "score": 67.8, "threats": 0, "events": 2394.0}, {"hour": "16:00", "score": 64.6, "threats": 1, "events": 1854.0}, {"hour": "17:00", "score": 60.6, "threats": 2, "events": 1750.0}, {"hour": "18:00", "score": 61.5, "threats": 9, "events": 451.0}, {"hour": "19:00", "score": 65.3, "threats": 3, "events": 795.0}, {"hour": "20:00", "score": 71.0, "threats": 0, "events": 1974.0}, {"hour": "21:00", "score": 66.4, "threats": 2, "events": 1504.0}, {"hour": "22:00", "score": 70.8, "threats": 9, "events": 600.0}, {"hour": "23:00", "score": 71.4, "threats": 5, "events": 2568.0}], "top_threats": [{"type": "Brute Force", "count": 29, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 48, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 17, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 28, "findings": 1}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 17, "findings": 9}, {"name": "ITDR", "status": "ACTIVE", "scans": 15, "findings": 0}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 76, "findings": 26}, {"name": "SIEM", "status": "ACTIVE", "scans": 953, "findings": 3}, {"name": "APM", "status": "ACTIVE", "scans": 8, "findings": 8}], "geo_attacks": 5, "blocked_today": 3210, "mean_detect_min": 8.9}	2026-04-22 23:48:12.21919	{}
c6318bde-4b79-4722-8fa1-913b4920aa2b	1	74.3	MEDIUM	4	2	87.8	97.59	4165	{"timeline": [{"hour": "00:00", "score": 81.5, "threats": 4, "events": 894.0}, {"hour": "01:00", "score": 78.2, "threats": 4, "events": 1078.0}, {"hour": "02:00", "score": 84.8, "threats": 5, "events": 2310.0}, {"hour": "03:00", "score": 82.2, "threats": 1, "events": 3994.0}, {"hour": "04:00", "score": 89.8, "threats": 2, "events": 3804.0}, {"hour": "05:00", "score": 89.5, "threats": 0, "events": 3068.0}, {"hour": "06:00", "score": 83.8, "threats": 6, "events": 255.0}, {"hour": "07:00", "score": 79.9, "threats": 0, "events": 561.0}, {"hour": "08:00", "score": 85.8, "threats": 5, "events": 1544.0}, {"hour": "09:00", "score": 87.3, "threats": 1, "events": 2300.0}, {"hour": "10:00", "score": 92.7, "threats": 3, "events": 134.0}, {"hour": "11:00", "score": 85.9, "threats": 2, "events": 2052.0}, {"hour": "12:00", "score": 79.2, "threats": 0, "events": 3717.0}, {"hour": "13:00", "score": 74.5, "threats": 0, "events": 677.0}, {"hour": "14:00", "score": 68.7, "threats": 0, "events": 1745.0}, {"hour": "15:00", "score": 68.3, "threats": 4, "events": 791.0}, {"hour": "16:00", "score": 66.2, "threats": 0, "events": 2105.0}, {"hour": "17:00", "score": 64.9, "threats": 3, "events": 3377.0}, {"hour": "18:00", "score": 61.7, "threats": 0, "events": 1366.0}, {"hour": "19:00", "score": 57.8, "threats": 4, "events": 324.0}, {"hour": "20:00", "score": 56.4, "threats": 2, "events": 1789.0}, {"hour": "21:00", "score": 62.9, "threats": 6, "events": 3496.0}, {"hour": "22:00", "score": 68.4, "threats": 6, "events": 3960.0}, {"hour": "23:00", "score": 61.4, "threats": 3, "events": 870.0}], "top_threats": [{"type": "Brute Force", "count": 28, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 32, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 5, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 8, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 0, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 39, "findings": 5}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 15, "findings": 9}, {"name": "ITDR", "status": "ACTIVE", "scans": 20, "findings": 1}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 96, "findings": 9}, {"name": "SIEM", "status": "ACTIVE", "scans": 490, "findings": 22}, {"name": "APM", "status": "ACTIVE", "scans": 8, "findings": 2}], "geo_attacks": 31, "blocked_today": 313, "mean_detect_min": 1.2}	2026-04-22 23:48:14.542028	{}
fcbcee29-3a4d-45c2-aa83-0d064a3b9645	1	61.2	HIGH	14	0	94.4	99.03	2991	{"timeline": [{"hour": "00:00", "score": 54.3, "threats": 4, "events": 1849.0}, {"hour": "01:00", "score": 48.4, "threats": 0, "events": 2405.0}, {"hour": "02:00", "score": 43.1, "threats": 5, "events": 1081.0}, {"hour": "03:00", "score": 41.2, "threats": 6, "events": 2607.0}, {"hour": "04:00", "score": 40.7, "threats": 17, "events": 828.0}, {"hour": "05:00", "score": 45.7, "threats": 7, "events": 1304.0}, {"hour": "06:00", "score": 47.2, "threats": 9, "events": 201.0}, {"hour": "07:00", "score": 45.8, "threats": 3, "events": 959.0}, {"hour": "08:00", "score": 43.1, "threats": 15, "events": 132.0}, {"hour": "09:00", "score": 49.2, "threats": 3, "events": 454.0}, {"hour": "10:00", "score": 43.6, "threats": 5, "events": 1081.0}, {"hour": "11:00", "score": 44.4, "threats": 0, "events": 740.0}, {"hour": "12:00", "score": 42.3, "threats": 16, "events": 2422.0}, {"hour": "13:00", "score": 48.9, "threats": 4, "events": 1204.0}, {"hour": "14:00", "score": 43.7, "threats": 11, "events": 2376.0}, {"hour": "15:00", "score": 49.2, "threats": 5, "events": 1328.0}, {"hour": "16:00", "score": 45.4, "threats": 13, "events": 2520.0}, {"hour": "17:00", "score": 45.8, "threats": 1, "events": 1635.0}, {"hour": "18:00", "score": 39.3, "threats": 6, "events": 793.0}, {"hour": "19:00", "score": 43.2, "threats": 16, "events": 2441.0}, {"hour": "20:00", "score": 46.6, "threats": 1, "events": 2074.0}, {"hour": "21:00", "score": 51.3, "threats": 14, "events": 332.0}, {"hour": "22:00", "score": 53.3, "threats": 13, "events": 947.0}, {"hour": "23:00", "score": 50.9, "threats": 0, "events": 2964.0}], "top_threats": [{"type": "Brute Force", "count": 19, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 67, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 11, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 25, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 19, "findings": 19}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 21, "findings": 10}, {"name": "ITDR", "status": "ACTIVE", "scans": 8, "findings": 0}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 45, "findings": 37}, {"name": "SIEM", "status": "ACTIVE", "scans": 515, "findings": 6}, {"name": "APM", "status": "ACTIVE", "scans": 11, "findings": 0}], "geo_attacks": 29, "blocked_today": 4175, "mean_detect_min": 14.6}	2026-04-22 23:48:53.113712	{}
7c739355-0575-46fe-921b-56a7fec465a0	1	72.6	HIGH	11	6	68.8	99.64	599	{"timeline": [{"hour": "00:00", "score": 65.9, "threats": 13, "events": 370.0}, {"hour": "01:00", "score": 70.4, "threats": 13, "events": 165.0}, {"hour": "02:00", "score": 72.2, "threats": 6, "events": 475.0}, {"hour": "03:00", "score": 69.6, "threats": 9, "events": 203.0}, {"hour": "04:00", "score": 63.4, "threats": 3, "events": 312.0}, {"hour": "05:00", "score": 57.2, "threats": 12, "events": 508.0}, {"hour": "06:00", "score": 59.5, "threats": 7, "events": 351.0}, {"hour": "07:00", "score": 57.6, "threats": 0, "events": 480.0}, {"hour": "08:00", "score": 58.5, "threats": 7, "events": 392.0}, {"hour": "09:00", "score": 59.8, "threats": 13, "events": 160.0}, {"hour": "10:00", "score": 62.5, "threats": 10, "events": 403.0}, {"hour": "11:00", "score": 68.6, "threats": 9, "events": 175.0}, {"hour": "12:00", "score": 65.2, "threats": 5, "events": 234.0}, {"hour": "13:00", "score": 60.4, "threats": 3, "events": 75.0}, {"hour": "14:00", "score": 57.5, "threats": 9, "events": 74.0}, {"hour": "15:00", "score": 57.1, "threats": 0, "events": 579.0}, {"hour": "16:00", "score": 51.5, "threats": 9, "events": 161.0}, {"hour": "17:00", "score": 45.9, "threats": 13, "events": 433.0}, {"hour": "18:00", "score": 46.8, "threats": 13, "events": 306.0}, {"hour": "19:00", "score": 46.0, "threats": 9, "events": 234.0}, {"hour": "20:00", "score": 43.7, "threats": 11, "events": 211.0}, {"hour": "21:00", "score": 38.7, "threats": 3, "events": 74.0}, {"hour": "22:00", "score": 31.9, "threats": 12, "events": 63.0}, {"hour": "23:00", "score": 38.7, "threats": 11, "events": 224.0}], "top_threats": [{"type": "Brute Force", "count": 33, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 68, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 24, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 1, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 12, "findings": 13}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 23, "findings": 1}, {"name": "ITDR", "status": "ACTIVE", "scans": 14, "findings": 3}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 23, "findings": 5}, {"name": "SIEM", "status": "ACTIVE", "scans": 711, "findings": 0}, {"name": "APM", "status": "ACTIVE", "scans": 18, "findings": 7}], "geo_attacks": 6, "blocked_today": 3706, "mean_detect_min": 3.6}	2026-04-22 23:49:07.941073	{}
c24e81ec-8754-4ba6-ba5d-49b67e1e33ba	1	78.7	MEDIUM	6	3	73.4	99.13	236	{"timeline": [{"hour": "00:00", "score": 76.6, "threats": 4, "events": 164.0}, {"hour": "01:00", "score": 70.6, "threats": 0, "events": 166.0}, {"hour": "02:00", "score": 65.0, "threats": 3, "events": 147.0}, {"hour": "03:00", "score": 65.8, "threats": 9, "events": 222.0}, {"hour": "04:00", "score": 66.9, "threats": 2, "events": 55.0}, {"hour": "05:00", "score": 72.7, "threats": 4, "events": 230.0}, {"hour": "06:00", "score": 80.2, "threats": 3, "events": 229.0}, {"hour": "07:00", "score": 79.2, "threats": 5, "events": 129.0}, {"hour": "08:00", "score": 71.2, "threats": 7, "events": 119.0}, {"hour": "09:00", "score": 71.7, "threats": 3, "events": 235.0}, {"hour": "10:00", "score": 64.5, "threats": 0, "events": 178.0}, {"hour": "11:00", "score": 60.4, "threats": 9, "events": 194.0}, {"hour": "12:00", "score": 60.0, "threats": 7, "events": 146.0}, {"hour": "13:00", "score": 57.7, "threats": 7, "events": 98.0}, {"hour": "14:00", "score": 58.9, "threats": 3, "events": 62.0}, {"hour": "15:00", "score": 66.6, "threats": 3, "events": 87.0}, {"hour": "16:00", "score": 73.7, "threats": 8, "events": 182.0}, {"hour": "17:00", "score": 74.3, "threats": 5, "events": 66.0}, {"hour": "18:00", "score": 73.7, "threats": 5, "events": 182.0}, {"hour": "19:00", "score": 68.6, "threats": 4, "events": 83.0}, {"hour": "20:00", "score": 67.5, "threats": 3, "events": 222.0}, {"hour": "21:00", "score": 68.5, "threats": 4, "events": 78.0}, {"hour": "22:00", "score": 68.7, "threats": 5, "events": 114.0}, {"hour": "23:00", "score": 61.1, "threats": 4, "events": 164.0}], "top_threats": [{"type": "Brute Force", "count": 18, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 47, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 20, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 9, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 17, "findings": 12}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 6, "findings": 9}, {"name": "ITDR", "status": "ACTIVE", "scans": 11, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 37, "findings": 25}, {"name": "SIEM", "status": "ACTIVE", "scans": 964, "findings": 29}, {"name": "APM", "status": "ACTIVE", "scans": 19, "findings": 2}], "geo_attacks": 9, "blocked_today": 3088, "mean_detect_min": 12.3}	2026-04-22 23:49:37.986696	{}
0525e858-f57b-44b8-ae4d-9e4ca5ce0f63	1	54	CRITICAL	19	8	76.5	97.57	3527	{"timeline": [{"hour": "00:00", "score": 60.8, "threats": 9, "events": 2407.0}, {"hour": "01:00", "score": 64.2, "threats": 6, "events": 3198.0}, {"hour": "02:00", "score": 56.6, "threats": 8, "events": 575.0}, {"hour": "03:00", "score": 57.0, "threats": 15, "events": 3335.0}, {"hour": "04:00", "score": 64.9, "threats": 5, "events": 1518.0}, {"hour": "05:00", "score": 66.9, "threats": 17, "events": 425.0}, {"hour": "06:00", "score": 73.6, "threats": 3, "events": 2513.0}, {"hour": "07:00", "score": 68.8, "threats": 16, "events": 1496.0}, {"hour": "08:00", "score": 70.2, "threats": 11, "events": 1517.0}, {"hour": "09:00", "score": 63.8, "threats": 13, "events": 1485.0}, {"hour": "10:00", "score": 59.4, "threats": 11, "events": 1039.0}, {"hour": "11:00", "score": 62.7, "threats": 14, "events": 1176.0}, {"hour": "12:00", "score": 59.4, "threats": 3, "events": 941.0}, {"hour": "13:00", "score": 63.2, "threats": 3, "events": 2195.0}, {"hour": "14:00", "score": 56.1, "threats": 22, "events": 2770.0}, {"hour": "15:00", "score": 60.1, "threats": 7, "events": 3124.0}, {"hour": "16:00", "score": 59.2, "threats": 3, "events": 1808.0}, {"hour": "17:00", "score": 61.8, "threats": 22, "events": 2556.0}, {"hour": "18:00", "score": 68.1, "threats": 11, "events": 1233.0}, {"hour": "19:00", "score": 70.5, "threats": 11, "events": 3049.0}, {"hour": "20:00", "score": 72.8, "threats": 13, "events": 67.0}, {"hour": "21:00", "score": 75.8, "threats": 22, "events": 1555.0}, {"hour": "22:00", "score": 69.3, "threats": 5, "events": 2205.0}, {"hour": "23:00", "score": 70.6, "threats": 0, "events": 628.0}], "top_threats": [{"type": "Brute Force", "count": 28, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 81, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 13, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 28, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 30, "findings": 18}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 20, "findings": 13}, {"name": "ITDR", "status": "ACTIVE", "scans": 17, "findings": 8}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 66, "findings": 18}, {"name": "SIEM", "status": "ACTIVE", "scans": 896, "findings": 3}, {"name": "APM", "status": "ACTIVE", "scans": 20, "findings": 7}], "geo_attacks": 24, "blocked_today": 1255, "mean_detect_min": 7.7}	2026-04-22 23:50:37.924214	{}
cba24ccd-4c29-457f-91c9-3100e5658fe7	1	45.8	CRITICAL	19	6	84.6	98.44	2010	{"timeline": [{"hour": "00:00", "score": 45.7, "threats": 0, "events": 1605.0}, {"hour": "01:00", "score": 41.2, "threats": 14, "events": 1986.0}, {"hour": "02:00", "score": 38.3, "threats": 11, "events": 1259.0}, {"hour": "03:00", "score": 34.0, "threats": 11, "events": 882.0}, {"hour": "04:00", "score": 39.9, "threats": 8, "events": 186.0}, {"hour": "05:00", "score": 46.7, "threats": 12, "events": 591.0}, {"hour": "06:00", "score": 42.7, "threats": 11, "events": 1295.0}, {"hour": "07:00", "score": 36.7, "threats": 0, "events": 932.0}, {"hour": "08:00", "score": 29.9, "threats": 13, "events": 129.0}, {"hour": "09:00", "score": 36.2, "threats": 1, "events": 1206.0}, {"hour": "10:00", "score": 29.4, "threats": 5, "events": 859.0}, {"hour": "11:00", "score": 32.4, "threats": 6, "events": 1315.0}, {"hour": "12:00", "score": 27.4, "threats": 6, "events": 957.0}, {"hour": "13:00", "score": 28.6, "threats": 13, "events": 594.0}, {"hour": "14:00", "score": 26.5, "threats": 17, "events": 387.0}, {"hour": "15:00", "score": 26.7, "threats": 10, "events": 1625.0}, {"hour": "16:00", "score": 24.2, "threats": 2, "events": 122.0}, {"hour": "17:00", "score": 26.0, "threats": 20, "events": 1070.0}, {"hour": "18:00", "score": 27.4, "threats": 3, "events": 1979.0}, {"hour": "19:00", "score": 25.5, "threats": 3, "events": 1900.0}, {"hour": "20:00", "score": 29.1, "threats": 5, "events": 402.0}, {"hour": "21:00", "score": 25.3, "threats": 17, "events": 1935.0}, {"hour": "22:00", "score": 20.0, "threats": 11, "events": 1431.0}, {"hour": "23:00", "score": 26.2, "threats": 17, "events": 1314.0}], "top_threats": [{"type": "Brute Force", "count": 34, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 47, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 9, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 9, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 11, "findings": 10}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 13, "findings": 4}, {"name": "ITDR", "status": "ACTIVE", "scans": 12, "findings": 0}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 55, "findings": 22}, {"name": "SIEM", "status": "ACTIVE", "scans": 515, "findings": 23}, {"name": "APM", "status": "ACTIVE", "scans": 11, "findings": 4}], "geo_attacks": 11, "blocked_today": 902, "mean_detect_min": 7.8}	2026-04-22 23:51:52.895635	{}
b178a596-308b-41fa-bff0-867b3e25f392	1	71.1	CRITICAL	25	1	91.3	98.62	4093	{"timeline": [{"hour": "00:00", "score": 68.0, "threats": 12, "events": 522.0}, {"hour": "01:00", "score": 74.0, "threats": 24, "events": 316.0}, {"hour": "02:00", "score": 66.7, "threats": 3, "events": 2423.0}, {"hour": "03:00", "score": 70.9, "threats": 14, "events": 1628.0}, {"hour": "04:00", "score": 76.5, "threats": 17, "events": 2467.0}, {"hour": "05:00", "score": 83.3, "threats": 15, "events": 2148.0}, {"hour": "06:00", "score": 78.8, "threats": 6, "events": 156.0}, {"hour": "07:00", "score": 85.7, "threats": 28, "events": 3847.0}, {"hour": "08:00", "score": 88.6, "threats": 26, "events": 737.0}, {"hour": "09:00", "score": 83.2, "threats": 13, "events": 2448.0}, {"hour": "10:00", "score": 77.0, "threats": 20, "events": 3596.0}, {"hour": "11:00", "score": 71.4, "threats": 26, "events": 2871.0}, {"hour": "12:00", "score": 77.9, "threats": 19, "events": 1881.0}, {"hour": "13:00", "score": 71.4, "threats": 3, "events": 3406.0}, {"hour": "14:00", "score": 73.0, "threats": 11, "events": 2805.0}, {"hour": "15:00", "score": 76.2, "threats": 25, "events": 2004.0}, {"hour": "16:00", "score": 82.8, "threats": 16, "events": 2536.0}, {"hour": "17:00", "score": 80.8, "threats": 3, "events": 1144.0}, {"hour": "18:00", "score": 72.8, "threats": 25, "events": 389.0}, {"hour": "19:00", "score": 79.2, "threats": 3, "events": 3040.0}, {"hour": "20:00", "score": 81.1, "threats": 10, "events": 805.0}, {"hour": "21:00", "score": 82.8, "threats": 27, "events": 2838.0}, {"hour": "22:00", "score": 85.9, "threats": 23, "events": 1831.0}, {"hour": "23:00", "score": 83.2, "threats": 10, "events": 2126.0}], "top_threats": [{"type": "Brute Force", "count": 11, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 26, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 17, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 17, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 48, "findings": 20}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 22, "findings": 0}, {"name": "ITDR", "status": "ACTIVE", "scans": 20, "findings": 4}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 33, "findings": 8}, {"name": "SIEM", "status": "ACTIVE", "scans": 315, "findings": 24}, {"name": "APM", "status": "ACTIVE", "scans": 23, "findings": 2}], "geo_attacks": 44, "blocked_today": 4626, "mean_detect_min": 12.4}	2026-04-22 23:52:07.891549	{}
4713cbcc-e7c1-454d-8a35-7e59642e96a1	1	88.9	HIGH	15	0	80.9	99.63	3697	{"timeline": [{"hour": "00:00", "score": 96.1, "threats": 8, "events": 368.0}, {"hour": "01:00", "score": 100, "threats": 15, "events": 456.0}, {"hour": "02:00", "score": 100, "threats": 3, "events": 2085.0}, {"hour": "03:00", "score": 96.7, "threats": 11, "events": 2435.0}, {"hour": "04:00", "score": 100, "threats": 11, "events": 1607.0}, {"hour": "05:00", "score": 100, "threats": 0, "events": 1223.0}, {"hour": "06:00", "score": 96.5, "threats": 8, "events": 1559.0}, {"hour": "07:00", "score": 92.2, "threats": 13, "events": 1375.0}, {"hour": "08:00", "score": 88.5, "threats": 0, "events": 3028.0}, {"hour": "09:00", "score": 82.5, "threats": 3, "events": 874.0}, {"hour": "10:00", "score": 74.9, "threats": 6, "events": 1735.0}, {"hour": "11:00", "score": 70.2, "threats": 13, "events": 356.0}, {"hour": "12:00", "score": 62.7, "threats": 4, "events": 985.0}, {"hour": "13:00", "score": 62.5, "threats": 11, "events": 1975.0}, {"hour": "14:00", "score": 69.7, "threats": 6, "events": 3065.0}, {"hour": "15:00", "score": 75.4, "threats": 0, "events": 167.0}, {"hour": "16:00", "score": 80.6, "threats": 6, "events": 620.0}, {"hour": "17:00", "score": 76.6, "threats": 8, "events": 2311.0}, {"hour": "18:00", "score": 77.8, "threats": 17, "events": 1904.0}, {"hour": "19:00", "score": 73.0, "threats": 5, "events": 3560.0}, {"hour": "20:00", "score": 80.5, "threats": 14, "events": 3356.0}, {"hour": "21:00", "score": 79.8, "threats": 1, "events": 865.0}, {"hour": "22:00", "score": 77.5, "threats": 12, "events": 410.0}, {"hour": "23:00", "score": 76.7, "threats": 9, "events": 2580.0}], "top_threats": [{"type": "Brute Force", "count": 22, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 31, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 8, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 19, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 36, "findings": 16}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 10, "findings": 13}, {"name": "ITDR", "status": "ACTIVE", "scans": 6, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 76, "findings": 22}, {"name": "SIEM", "status": "ACTIVE", "scans": 387, "findings": 16}, {"name": "APM", "status": "ACTIVE", "scans": 21, "findings": 6}], "geo_attacks": 28, "blocked_today": 2800, "mean_detect_min": 4.3}	2026-04-22 23:52:37.901921	{}
68fb9bd9-a525-4590-b865-6ffc4d08dd31	1	56.3	CRITICAL	20	8	77.3	98.74	783	{"timeline": [{"hour": "00:00", "score": 53.8, "threats": 5, "events": 148.0}, {"hour": "01:00", "score": 48.4, "threats": 5, "events": 72.0}, {"hour": "02:00", "score": 52.9, "threats": 3, "events": 458.0}, {"hour": "03:00", "score": 58.8, "threats": 14, "events": 57.0}, {"hour": "04:00", "score": 54.4, "threats": 19, "events": 309.0}, {"hour": "05:00", "score": 54.6, "threats": 10, "events": 733.0}, {"hour": "06:00", "score": 54.8, "threats": 22, "events": 111.0}, {"hour": "07:00", "score": 56.4, "threats": 9, "events": 329.0}, {"hour": "08:00", "score": 61.9, "threats": 14, "events": 320.0}, {"hour": "09:00", "score": 59.4, "threats": 15, "events": 481.0}, {"hour": "10:00", "score": 65.9, "threats": 5, "events": 102.0}, {"hour": "11:00", "score": 60.1, "threats": 7, "events": 82.0}, {"hour": "12:00", "score": 56.3, "threats": 9, "events": 546.0}, {"hour": "13:00", "score": 51.4, "threats": 6, "events": 253.0}, {"hour": "14:00", "score": 55.6, "threats": 10, "events": 526.0}, {"hour": "15:00", "score": 55.9, "threats": 16, "events": 532.0}, {"hour": "16:00", "score": 56.9, "threats": 23, "events": 709.0}, {"hour": "17:00", "score": 56.9, "threats": 2, "events": 537.0}, {"hour": "18:00", "score": 50.1, "threats": 10, "events": 169.0}, {"hour": "19:00", "score": 53.4, "threats": 3, "events": 347.0}, {"hour": "20:00", "score": 49.4, "threats": 8, "events": 596.0}, {"hour": "21:00", "score": 51.8, "threats": 23, "events": 54.0}, {"hour": "22:00", "score": 51.2, "threats": 1, "events": 89.0}, {"hour": "23:00", "score": 58.4, "threats": 12, "events": 688.0}], "top_threats": [{"type": "Brute Force", "count": 50, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 31, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 16, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 29, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 41, "findings": 13}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 14, "findings": 4}, {"name": "ITDR", "status": "ACTIVE", "scans": 16, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 83, "findings": 10}, {"name": "SIEM", "status": "ACTIVE", "scans": 533, "findings": 29}, {"name": "APM", "status": "ACTIVE", "scans": 5, "findings": 3}], "geo_attacks": 20, "blocked_today": 4032, "mean_detect_min": 6.7}	2026-04-22 23:48:22.903133	{}
09e53c5d-872f-445d-aec4-4dd89620ce67	1	87	HIGH	14	6	72.7	99.15	3014	{"timeline": [{"hour": "00:00", "score": 87.3, "threats": 17, "events": 2912.0}, {"hour": "01:00", "score": 92.5, "threats": 5, "events": 502.0}, {"hour": "02:00", "score": 93.3, "threats": 11, "events": 2050.0}, {"hour": "03:00", "score": 100, "threats": 0, "events": 1491.0}, {"hour": "04:00", "score": 100, "threats": 16, "events": 2421.0}, {"hour": "05:00", "score": 92.6, "threats": 8, "events": 850.0}, {"hour": "06:00", "score": 90.5, "threats": 4, "events": 264.0}, {"hour": "07:00", "score": 89.6, "threats": 4, "events": 2958.0}, {"hour": "08:00", "score": 86.7, "threats": 10, "events": 2862.0}, {"hour": "09:00", "score": 79.2, "threats": 9, "events": 1013.0}, {"hour": "10:00", "score": 87.0, "threats": 12, "events": 1186.0}, {"hour": "11:00", "score": 89.9, "threats": 6, "events": 530.0}, {"hour": "12:00", "score": 82.9, "threats": 8, "events": 151.0}, {"hour": "13:00", "score": 89.5, "threats": 14, "events": 341.0}, {"hour": "14:00", "score": 84.4, "threats": 3, "events": 2926.0}, {"hour": "15:00", "score": 76.8, "threats": 17, "events": 1240.0}, {"hour": "16:00", "score": 74.1, "threats": 4, "events": 317.0}, {"hour": "17:00", "score": 72.3, "threats": 11, "events": 597.0}, {"hour": "18:00", "score": 74.5, "threats": 17, "events": 203.0}, {"hour": "19:00", "score": 74.1, "threats": 16, "events": 2891.0}, {"hour": "20:00", "score": 71.3, "threats": 9, "events": 2941.0}, {"hour": "21:00", "score": 65.4, "threats": 8, "events": 354.0}, {"hour": "22:00", "score": 67.7, "threats": 7, "events": 507.0}, {"hour": "23:00", "score": 74.5, "threats": 5, "events": 2037.0}], "top_threats": [{"type": "Brute Force", "count": 37, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 40, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 15, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 20, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 0, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 18, "findings": 2}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 9, "findings": 14}, {"name": "ITDR", "status": "ACTIVE", "scans": 11, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 51, "findings": 11}, {"name": "SIEM", "status": "ACTIVE", "scans": 942, "findings": 18}, {"name": "APM", "status": "ACTIVE", "scans": 7, "findings": 6}], "geo_attacks": 38, "blocked_today": 4230, "mean_detect_min": 13.4}	2026-04-22 23:48:38.041881	{}
303f943c-dd5d-43d2-9b63-fe6e56a1b1b4	1	63.9	HIGH	12	2	82.9	98.25	1542	{"timeline": [{"hour": "00:00", "score": 61.1, "threats": 13, "events": 1402.0}, {"hour": "01:00", "score": 63.0, "threats": 10, "events": 775.0}, {"hour": "02:00", "score": 56.5, "threats": 8, "events": 1048.0}, {"hour": "03:00", "score": 62.1, "threats": 5, "events": 1388.0}, {"hour": "04:00", "score": 68.0, "threats": 14, "events": 498.0}, {"hour": "05:00", "score": 70.7, "threats": 12, "events": 220.0}, {"hour": "06:00", "score": 70.1, "threats": 14, "events": 1014.0}, {"hour": "07:00", "score": 65.9, "threats": 14, "events": 875.0}, {"hour": "08:00", "score": 65.6, "threats": 15, "events": 509.0}, {"hour": "09:00", "score": 71.6, "threats": 1, "events": 866.0}, {"hour": "10:00", "score": 78.8, "threats": 0, "events": 1469.0}, {"hour": "11:00", "score": 79.1, "threats": 1, "events": 1280.0}, {"hour": "12:00", "score": 82.5, "threats": 4, "events": 949.0}, {"hour": "13:00", "score": 90.1, "threats": 7, "events": 844.0}, {"hour": "14:00", "score": 94.6, "threats": 11, "events": 1141.0}, {"hour": "15:00", "score": 95.7, "threats": 6, "events": 183.0}, {"hour": "16:00", "score": 100, "threats": 15, "events": 1067.0}, {"hour": "17:00", "score": 98.5, "threats": 12, "events": 1030.0}, {"hour": "18:00", "score": 94.2, "threats": 8, "events": 865.0}, {"hour": "19:00", "score": 95.2, "threats": 9, "events": 77.0}, {"hour": "20:00", "score": 97.3, "threats": 5, "events": 119.0}, {"hour": "21:00", "score": 93.8, "threats": 8, "events": 736.0}, {"hour": "22:00", "score": 88.3, "threats": 12, "events": 301.0}, {"hour": "23:00", "score": 84.0, "threats": 6, "events": 400.0}], "top_threats": [{"type": "Brute Force", "count": 46, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 68, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 18, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 13, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 45, "findings": 13}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 29, "findings": 6}, {"name": "ITDR", "status": "ACTIVE", "scans": 8, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 91, "findings": 47}, {"name": "SIEM", "status": "ACTIVE", "scans": 377, "findings": 4}, {"name": "APM", "status": "ACTIVE", "scans": 21, "findings": 6}], "geo_attacks": 14, "blocked_today": 4582, "mean_detect_min": 3.3}	2026-04-22 23:49:22.943045	{}
95766648-20b8-4cfa-a27b-9a798624ff30	1	68.1	CRITICAL	20	0	80.9	98.23	2789	{"timeline": [{"hour": "00:00", "score": 67.9, "threats": 10, "events": 227.0}, {"hour": "01:00", "score": 74.6, "threats": 8, "events": 144.0}, {"hour": "02:00", "score": 79.8, "threats": 14, "events": 953.0}, {"hour": "03:00", "score": 76.8, "threats": 21, "events": 2324.0}, {"hour": "04:00", "score": 82.7, "threats": 3, "events": 2555.0}, {"hour": "05:00", "score": 81.9, "threats": 10, "events": 428.0}, {"hour": "06:00", "score": 89.2, "threats": 8, "events": 1066.0}, {"hour": "07:00", "score": 95.3, "threats": 15, "events": 792.0}, {"hour": "08:00", "score": 100, "threats": 14, "events": 319.0}, {"hour": "09:00", "score": 92.5, "threats": 22, "events": 1768.0}, {"hour": "10:00", "score": 97.2, "threats": 15, "events": 515.0}, {"hour": "11:00", "score": 91.4, "threats": 11, "events": 2582.0}, {"hour": "12:00", "score": 98.2, "threats": 16, "events": 2220.0}, {"hour": "13:00", "score": 93.9, "threats": 21, "events": 2644.0}, {"hour": "14:00", "score": 92.1, "threats": 12, "events": 918.0}, {"hour": "15:00", "score": 94.0, "threats": 10, "events": 2026.0}, {"hour": "16:00", "score": 88.9, "threats": 11, "events": 2391.0}, {"hour": "17:00", "score": 93.8, "threats": 8, "events": 313.0}, {"hour": "18:00", "score": 86.1, "threats": 18, "events": 101.0}, {"hour": "19:00", "score": 78.9, "threats": 17, "events": 277.0}, {"hour": "20:00", "score": 78.0, "threats": 17, "events": 1748.0}, {"hour": "21:00", "score": 80.2, "threats": 7, "events": 117.0}, {"hour": "22:00", "score": 72.9, "threats": 17, "events": 1078.0}, {"hour": "23:00", "score": 79.5, "threats": 17, "events": 1135.0}], "top_threats": [{"type": "Brute Force", "count": 7, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 23, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 17, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 2, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 0, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 31, "findings": 8}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 12, "findings": 2}, {"name": "ITDR", "status": "ACTIVE", "scans": 7, "findings": 10}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 91, "findings": 49}, {"name": "SIEM", "status": "ACTIVE", "scans": 965, "findings": 23}, {"name": "APM", "status": "ACTIVE", "scans": 5, "findings": 4}], "geo_attacks": 16, "blocked_today": 4031, "mean_detect_min": 11.2}	2026-04-22 23:49:53.011568	{}
9d06dd1a-7972-4aaa-b31d-3485033c2266	1	76.4	HIGH	11	6	81.9	98.32	150	{"timeline": [{"hour": "00:00", "score": 83.2, "threats": 1, "events": 148.0}, {"hour": "01:00", "score": 76.6, "threats": 13, "events": 93.0}, {"hour": "02:00", "score": 78.8, "threats": 11, "events": 140.0}, {"hour": "03:00", "score": 71.4, "threats": 14, "events": 107.0}, {"hour": "04:00", "score": 63.5, "threats": 13, "events": 147.0}, {"hour": "05:00", "score": 70.7, "threats": 7, "events": 128.0}, {"hour": "06:00", "score": 73.8, "threats": 2, "events": 54.0}, {"hour": "07:00", "score": 73.9, "threats": 9, "events": 118.0}, {"hour": "08:00", "score": 72.2, "threats": 7, "events": 131.0}, {"hour": "09:00", "score": 78.9, "threats": 7, "events": 101.0}, {"hour": "10:00", "score": 80.4, "threats": 9, "events": 53.0}, {"hour": "11:00", "score": 76.4, "threats": 7, "events": 131.0}, {"hour": "12:00", "score": 81.7, "threats": 1, "events": 80.0}, {"hour": "13:00", "score": 81.4, "threats": 9, "events": 71.0}, {"hour": "14:00", "score": 79.5, "threats": 12, "events": 70.0}, {"hour": "15:00", "score": 77.5, "threats": 12, "events": 128.0}, {"hour": "16:00", "score": 74.5, "threats": 4, "events": 140.0}, {"hour": "17:00", "score": 82.1, "threats": 5, "events": 129.0}, {"hour": "18:00", "score": 80.0, "threats": 0, "events": 134.0}, {"hour": "19:00", "score": 74.7, "threats": 12, "events": 94.0}, {"hour": "20:00", "score": 73.8, "threats": 5, "events": 139.0}, {"hour": "21:00", "score": 76.0, "threats": 5, "events": 92.0}, {"hour": "22:00", "score": 79.7, "threats": 0, "events": 90.0}, {"hour": "23:00", "score": 80.8, "threats": 14, "events": 85.0}], "top_threats": [{"type": "Brute Force", "count": 18, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 72, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 17, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 15, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 19, "findings": 18}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 15, "findings": 6}, {"name": "ITDR", "status": "ACTIVE", "scans": 10, "findings": 6}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 49, "findings": 45}, {"name": "SIEM", "status": "ACTIVE", "scans": 170, "findings": 16}, {"name": "APM", "status": "ACTIVE", "scans": 18, "findings": 8}], "geo_attacks": 17, "blocked_today": 997, "mean_detect_min": 10.5}	2026-04-22 23:50:08.03608	{}
d8d7324f-93f1-4f96-b431-87501f7563f4	1	60	HIGH	13	0	80.9	97.85	4059	{"timeline": [{"hour": "00:00", "score": 64.2, "threats": 1, "events": 1942.0}, {"hour": "01:00", "score": 69.2, "threats": 14, "events": 1452.0}, {"hour": "02:00", "score": 74.5, "threats": 12, "events": 346.0}, {"hour": "03:00", "score": 78.7, "threats": 11, "events": 3859.0}, {"hour": "04:00", "score": 73.6, "threats": 1, "events": 253.0}, {"hour": "05:00", "score": 74.7, "threats": 9, "events": 425.0}, {"hour": "06:00", "score": 81.7, "threats": 8, "events": 3025.0}, {"hour": "07:00", "score": 84.9, "threats": 2, "events": 1509.0}, {"hour": "08:00", "score": 77.2, "threats": 11, "events": 839.0}, {"hour": "09:00", "score": 77.8, "threats": 2, "events": 4001.0}, {"hour": "10:00", "score": 77.9, "threats": 1, "events": 1435.0}, {"hour": "11:00", "score": 70.9, "threats": 12, "events": 760.0}, {"hour": "12:00", "score": 75.2, "threats": 15, "events": 3092.0}, {"hour": "13:00", "score": 70.1, "threats": 13, "events": 3291.0}, {"hour": "14:00", "score": 73.3, "threats": 6, "events": 903.0}, {"hour": "15:00", "score": 70.9, "threats": 2, "events": 2066.0}, {"hour": "16:00", "score": 71.0, "threats": 8, "events": 4037.0}, {"hour": "17:00", "score": 65.9, "threats": 2, "events": 2629.0}, {"hour": "18:00", "score": 73.1, "threats": 7, "events": 945.0}, {"hour": "19:00", "score": 71.6, "threats": 13, "events": 3229.0}, {"hour": "20:00", "score": 74.0, "threats": 6, "events": 244.0}, {"hour": "21:00", "score": 72.6, "threats": 1, "events": 893.0}, {"hour": "22:00", "score": 78.1, "threats": 3, "events": 1528.0}, {"hour": "23:00", "score": 84.1, "threats": 6, "events": 1581.0}], "top_threats": [{"type": "Brute Force", "count": 15, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 68, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 17, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 30, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 4, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 29, "findings": 19}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 14, "findings": 14}, {"name": "ITDR", "status": "ACTIVE", "scans": 10, "findings": 4}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 35, "findings": 24}, {"name": "SIEM", "status": "ACTIVE", "scans": 423, "findings": 14}, {"name": "APM", "status": "ACTIVE", "scans": 25, "findings": 2}], "geo_attacks": 43, "blocked_today": 350, "mean_detect_min": 12.2}	2026-04-22 23:50:22.946884	{}
92a30a82-4e4d-40f0-ada7-becd6db50032	1	76.8	CRITICAL	25	6	73.4	99.23	3964	{"timeline": [{"hour": "00:00", "score": 74.7, "threats": 4, "events": 1222.0}, {"hour": "01:00", "score": 69.7, "threats": 17, "events": 3433.0}, {"hour": "02:00", "score": 77.5, "threats": 23, "events": 1937.0}, {"hour": "03:00", "score": 72.2, "threats": 3, "events": 3710.0}, {"hour": "04:00", "score": 72.4, "threats": 10, "events": 3416.0}, {"hour": "05:00", "score": 66.5, "threats": 19, "events": 3672.0}, {"hour": "06:00", "score": 62.4, "threats": 8, "events": 1790.0}, {"hour": "07:00", "score": 54.5, "threats": 19, "events": 3203.0}, {"hour": "08:00", "score": 59.6, "threats": 15, "events": 1657.0}, {"hour": "09:00", "score": 52.5, "threats": 2, "events": 1563.0}, {"hour": "10:00", "score": 56.5, "threats": 2, "events": 3205.0}, {"hour": "11:00", "score": 58.4, "threats": 7, "events": 3362.0}, {"hour": "12:00", "score": 54.0, "threats": 5, "events": 3021.0}, {"hour": "13:00", "score": 57.1, "threats": 7, "events": 2848.0}, {"hour": "14:00", "score": 51.7, "threats": 15, "events": 1860.0}, {"hour": "15:00", "score": 53.9, "threats": 6, "events": 2636.0}, {"hour": "16:00", "score": 48.1, "threats": 19, "events": 1902.0}, {"hour": "17:00", "score": 42.4, "threats": 25, "events": 293.0}, {"hour": "18:00", "score": 49.2, "threats": 4, "events": 2120.0}, {"hour": "19:00", "score": 44.1, "threats": 16, "events": 1550.0}, {"hour": "20:00", "score": 47.3, "threats": 6, "events": 930.0}, {"hour": "21:00", "score": 54.9, "threats": 20, "events": 1856.0}, {"hour": "22:00", "score": 51.2, "threats": 4, "events": 2323.0}, {"hour": "23:00", "score": 51.2, "threats": 5, "events": 3465.0}], "top_threats": [{"type": "Brute Force", "count": 47, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 34, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 14, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 3, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 5, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 37, "findings": 11}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 12, "findings": 6}, {"name": "ITDR", "status": "ACTIVE", "scans": 7, "findings": 9}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 76, "findings": 40}, {"name": "SIEM", "status": "ACTIVE", "scans": 384, "findings": 2}, {"name": "APM", "status": "ACTIVE", "scans": 17, "findings": 1}], "geo_attacks": 8, "blocked_today": 1422, "mean_detect_min": 1.4}	2026-04-22 23:50:52.944664	{}
b995b2c1-86b7-4d27-9e87-70b905ef8177	1	87.1	CRITICAL	16	8	67	98.66	631	{"timeline": [{"hour": "00:00", "score": 91.1, "threats": 8, "events": 399.0}, {"hour": "01:00", "score": 97.4, "threats": 18, "events": 330.0}, {"hour": "02:00", "score": 93.1, "threats": 11, "events": 297.0}, {"hour": "03:00", "score": 98.3, "threats": 8, "events": 460.0}, {"hour": "04:00", "score": 92.5, "threats": 0, "events": 314.0}, {"hour": "05:00", "score": 94.7, "threats": 6, "events": 349.0}, {"hour": "06:00", "score": 94.3, "threats": 19, "events": 369.0}, {"hour": "07:00", "score": 86.7, "threats": 6, "events": 534.0}, {"hour": "08:00", "score": 84.9, "threats": 1, "events": 554.0}, {"hour": "09:00", "score": 82.7, "threats": 8, "events": 172.0}, {"hour": "10:00", "score": 76.9, "threats": 2, "events": 232.0}, {"hour": "11:00", "score": 81.4, "threats": 7, "events": 472.0}, {"hour": "12:00", "score": 81.5, "threats": 2, "events": 230.0}, {"hour": "13:00", "score": 86.0, "threats": 7, "events": 233.0}, {"hour": "14:00", "score": 89.3, "threats": 4, "events": 499.0}, {"hour": "15:00", "score": 91.9, "threats": 2, "events": 380.0}, {"hour": "16:00", "score": 92.2, "threats": 9, "events": 593.0}, {"hour": "17:00", "score": 92.5, "threats": 17, "events": 423.0}, {"hour": "18:00", "score": 94.9, "threats": 16, "events": 330.0}, {"hour": "19:00", "score": 100, "threats": 9, "events": 92.0}, {"hour": "20:00", "score": 97.2, "threats": 9, "events": 283.0}, {"hour": "21:00", "score": 98.3, "threats": 7, "events": 220.0}, {"hour": "22:00", "score": 95.7, "threats": 18, "events": 244.0}, {"hour": "23:00", "score": 100, "threats": 15, "events": 222.0}], "top_threats": [{"type": "Brute Force", "count": 7, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 97, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 17, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 6, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 1, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 14, "findings": 8}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 17, "findings": 2}, {"name": "ITDR", "status": "ACTIVE", "scans": 19, "findings": 8}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 64, "findings": 43}, {"name": "SIEM", "status": "ACTIVE", "scans": 153, "findings": 12}, {"name": "APM", "status": "ACTIVE", "scans": 18, "findings": 4}], "geo_attacks": 25, "blocked_today": 926, "mean_detect_min": 5.9}	2026-04-22 23:51:07.954492	{}
84c034a2-acbd-4aa5-ba93-13753a3b524b	1	80.4	HIGH	13	2	95.1	97.13	1728	{"timeline": [{"hour": "00:00", "score": 85.6, "threats": 15, "events": 223.0}, {"hour": "01:00", "score": 88.7, "threats": 15, "events": 1227.0}, {"hour": "02:00", "score": 81.2, "threats": 1, "events": 1194.0}, {"hour": "03:00", "score": 78.2, "threats": 11, "events": 578.0}, {"hour": "04:00", "score": 79.9, "threats": 3, "events": 1710.0}, {"hour": "05:00", "score": 72.0, "threats": 12, "events": 1609.0}, {"hour": "06:00", "score": 72.8, "threats": 6, "events": 1511.0}, {"hour": "07:00", "score": 65.1, "threats": 14, "events": 1630.0}, {"hour": "08:00", "score": 70.1, "threats": 13, "events": 293.0}, {"hour": "09:00", "score": 66.9, "threats": 16, "events": 564.0}, {"hour": "10:00", "score": 66.1, "threats": 1, "events": 575.0}, {"hour": "11:00", "score": 66.0, "threats": 9, "events": 1056.0}, {"hour": "12:00", "score": 70.4, "threats": 5, "events": 67.0}, {"hour": "13:00", "score": 70.1, "threats": 14, "events": 1164.0}, {"hour": "14:00", "score": 77.4, "threats": 10, "events": 311.0}, {"hour": "15:00", "score": 70.5, "threats": 14, "events": 178.0}, {"hour": "16:00", "score": 68.0, "threats": 1, "events": 706.0}, {"hour": "17:00", "score": 71.6, "threats": 14, "events": 308.0}, {"hour": "18:00", "score": 68.6, "threats": 9, "events": 1414.0}, {"hour": "19:00", "score": 64.1, "threats": 13, "events": 1345.0}, {"hour": "20:00", "score": 70.5, "threats": 6, "events": 1207.0}, {"hour": "21:00", "score": 72.0, "threats": 5, "events": 696.0}, {"hour": "22:00", "score": 76.3, "threats": 13, "events": 504.0}, {"hour": "23:00", "score": 76.5, "threats": 9, "events": 1699.0}], "top_threats": [{"type": "Brute Force", "count": 50, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 59, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 1, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 4, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 0, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 41, "findings": 2}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 25, "findings": 9}, {"name": "ITDR", "status": "ACTIVE", "scans": 3, "findings": 2}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 89, "findings": 8}, {"name": "SIEM", "status": "ACTIVE", "scans": 393, "findings": 15}, {"name": "APM", "status": "ACTIVE", "scans": 19, "findings": 4}], "geo_attacks": 22, "blocked_today": 2668, "mean_detect_min": 2.9}	2026-04-22 23:51:22.888806	{}
3bacef23-c3db-4581-8a33-85a4966e5886	1	46.4	HIGH	14	7	82.4	97.36	186	{"timeline": [{"hour": "00:00", "score": 42.0, "threats": 16, "events": 74.0}, {"hour": "01:00", "score": 39.8, "threats": 6, "events": 138.0}, {"hour": "02:00", "score": 44.3, "threats": 9, "events": 167.0}, {"hour": "03:00", "score": 40.8, "threats": 9, "events": 64.0}, {"hour": "04:00", "score": 48.3, "threats": 3, "events": 123.0}, {"hour": "05:00", "score": 52.5, "threats": 4, "events": 55.0}, {"hour": "06:00", "score": 55.2, "threats": 0, "events": 161.0}, {"hour": "07:00", "score": 52.1, "threats": 6, "events": 123.0}, {"hour": "08:00", "score": 58.4, "threats": 3, "events": 62.0}, {"hour": "09:00", "score": 53.5, "threats": 3, "events": 150.0}, {"hour": "10:00", "score": 55.5, "threats": 10, "events": 165.0}, {"hour": "11:00", "score": 56.4, "threats": 10, "events": 142.0}, {"hour": "12:00", "score": 56.9, "threats": 7, "events": 144.0}, {"hour": "13:00", "score": 63.8, "threats": 9, "events": 92.0}, {"hour": "14:00", "score": 60.6, "threats": 5, "events": 131.0}, {"hour": "15:00", "score": 58.4, "threats": 8, "events": 126.0}, {"hour": "16:00", "score": 53.6, "threats": 7, "events": 127.0}, {"hour": "17:00", "score": 46.6, "threats": 15, "events": 174.0}, {"hour": "18:00", "score": 41.2, "threats": 5, "events": 127.0}, {"hour": "19:00", "score": 39.8, "threats": 2, "events": 93.0}, {"hour": "20:00", "score": 34.0, "threats": 11, "events": 51.0}, {"hour": "21:00", "score": 37.6, "threats": 11, "events": 72.0}, {"hour": "22:00", "score": 39.9, "threats": 10, "events": 137.0}, {"hour": "23:00", "score": 37.5, "threats": 1, "events": 105.0}], "top_threats": [{"type": "Brute Force", "count": 45, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 49, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 18, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 22, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 36, "findings": 10}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 8, "findings": 7}, {"name": "ITDR", "status": "ACTIVE", "scans": 10, "findings": 8}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 50, "findings": 10}, {"name": "SIEM", "status": "ACTIVE", "scans": 510, "findings": 2}, {"name": "APM", "status": "ACTIVE", "scans": 13, "findings": 0}], "geo_attacks": 38, "blocked_today": 4645, "mean_detect_min": 13.4}	2026-04-22 23:52:52.984775	{}
9cdd86cd-f2e1-4689-bddd-b65f8de726b5	1	87.5	LOW	1	1	76.2	97.34	1496	{"timeline": [{"hour": "00:00", "score": 89.6, "threats": 3, "events": 591.0}, {"hour": "01:00", "score": 90.8, "threats": 0, "events": 1328.0}, {"hour": "02:00", "score": 90.5, "threats": 2, "events": 448.0}, {"hour": "03:00", "score": 98.0, "threats": 2, "events": 1371.0}, {"hour": "04:00", "score": 100, "threats": 1, "events": 1442.0}, {"hour": "05:00", "score": 93.8, "threats": 3, "events": 814.0}, {"hour": "06:00", "score": 90.0, "threats": 2, "events": 473.0}, {"hour": "07:00", "score": 97.7, "threats": 4, "events": 925.0}, {"hour": "08:00", "score": 94.3, "threats": 3, "events": 558.0}, {"hour": "09:00", "score": 88.4, "threats": 4, "events": 302.0}, {"hour": "10:00", "score": 95.9, "threats": 0, "events": 223.0}, {"hour": "11:00", "score": 89.1, "threats": 1, "events": 724.0}, {"hour": "12:00", "score": 82.1, "threats": 3, "events": 855.0}, {"hour": "13:00", "score": 86.7, "threats": 3, "events": 324.0}, {"hour": "14:00", "score": 92.5, "threats": 4, "events": 726.0}, {"hour": "15:00", "score": 91.7, "threats": 2, "events": 767.0}, {"hour": "16:00", "score": 87.9, "threats": 1, "events": 664.0}, {"hour": "17:00", "score": 85.7, "threats": 3, "events": 695.0}, {"hour": "18:00", "score": 85.8, "threats": 1, "events": 544.0}, {"hour": "19:00", "score": 77.8, "threats": 1, "events": 693.0}, {"hour": "20:00", "score": 78.0, "threats": 4, "events": 1037.0}, {"hour": "21:00", "score": 77.4, "threats": 2, "events": 915.0}, {"hour": "22:00", "score": 73.9, "threats": 1, "events": 1061.0}, {"hour": "23:00", "score": 81.5, "threats": 4, "events": 184.0}], "top_threats": [{"type": "Brute Force", "count": 47, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 48, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 6, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 2, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 26, "findings": 9}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 27, "findings": 6}, {"name": "ITDR", "status": "ACTIVE", "scans": 12, "findings": 7}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 90, "findings": 19}, {"name": "SIEM", "status": "ACTIVE", "scans": 357, "findings": 11}, {"name": "APM", "status": "ACTIVE", "scans": 6, "findings": 8}], "geo_attacks": 36, "blocked_today": 2030, "mean_detect_min": 10.2}	2026-04-22 23:53:07.9545	{}
1baa9a0c-c7ce-4a4c-9c2e-cc1084ee5ff1	1	46.8	CRITICAL	22	0	65.1	97.44	4150	{"timeline": [{"hour": "00:00", "score": 42.5, "threats": 11, "events": 3847.0}, {"hour": "01:00", "score": 45.1, "threats": 13, "events": 1369.0}, {"hour": "02:00", "score": 38.8, "threats": 16, "events": 3539.0}, {"hour": "03:00", "score": 32.9, "threats": 0, "events": 2233.0}, {"hour": "04:00", "score": 33.4, "threats": 15, "events": 3544.0}, {"hour": "05:00", "score": 27.5, "threats": 23, "events": 1544.0}, {"hour": "06:00", "score": 26.6, "threats": 19, "events": 3609.0}, {"hour": "07:00", "score": 21.9, "threats": 13, "events": 1726.0}, {"hour": "08:00", "score": 24.4, "threats": 16, "events": 2162.0}, {"hour": "09:00", "score": 21.2, "threats": 14, "events": 3760.0}, {"hour": "10:00", "score": 20, "threats": 13, "events": 88.0}, {"hour": "11:00", "score": 21.5, "threats": 10, "events": 1343.0}, {"hour": "12:00", "score": 20, "threats": 16, "events": 1148.0}, {"hour": "13:00", "score": 20, "threats": 9, "events": 3841.0}, {"hour": "14:00", "score": 20, "threats": 24, "events": 3307.0}, {"hour": "15:00", "score": 21.0, "threats": 18, "events": 2567.0}, {"hour": "16:00", "score": 21.6, "threats": 23, "events": 798.0}, {"hour": "17:00", "score": 20.2, "threats": 23, "events": 224.0}, {"hour": "18:00", "score": 20, "threats": 1, "events": 3735.0}, {"hour": "19:00", "score": 23.4, "threats": 6, "events": 654.0}, {"hour": "20:00", "score": 26.5, "threats": 22, "events": 1231.0}, {"hour": "21:00", "score": 30.7, "threats": 14, "events": 926.0}, {"hour": "22:00", "score": 25.7, "threats": 17, "events": 2114.0}, {"hour": "23:00", "score": 32.2, "threats": 23, "events": 1271.0}], "top_threats": [{"type": "Brute Force", "count": 40, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 34, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 18, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 19, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 2, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 41, "findings": 11}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 25, "findings": 12}, {"name": "ITDR", "status": "ACTIVE", "scans": 14, "findings": 3}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 30, "findings": 42}, {"name": "SIEM", "status": "ACTIVE", "scans": 463, "findings": 1}, {"name": "APM", "status": "ACTIVE", "scans": 23, "findings": 8}], "geo_attacks": 6, "blocked_today": 1105, "mean_detect_min": 3.7}	2026-04-22 23:53:22.955942	{}
08e4991d-3f4f-43e1-ad41-9d53c9c0b05a	1	71.9	CRITICAL	18	2	92.3	99.23	372	{"timeline": [{"hour": "00:00", "score": 77.9, "threats": 20, "events": 73.0}, {"hour": "01:00", "score": 85.1, "threats": 4, "events": 139.0}, {"hour": "02:00", "score": 77.9, "threats": 3, "events": 321.0}, {"hour": "03:00", "score": 81.7, "threats": 6, "events": 214.0}, {"hour": "04:00", "score": 78.5, "threats": 17, "events": 178.0}, {"hour": "05:00", "score": 78.8, "threats": 0, "events": 219.0}, {"hour": "06:00", "score": 83.3, "threats": 2, "events": 138.0}, {"hour": "07:00", "score": 76.4, "threats": 19, "events": 276.0}, {"hour": "08:00", "score": 74.7, "threats": 3, "events": 77.0}, {"hour": "09:00", "score": 67.3, "threats": 16, "events": 102.0}, {"hour": "10:00", "score": 65.7, "threats": 6, "events": 216.0}, {"hour": "11:00", "score": 65.1, "threats": 3, "events": 145.0}, {"hour": "12:00", "score": 60.2, "threats": 19, "events": 318.0}, {"hour": "13:00", "score": 56.4, "threats": 14, "events": 85.0}, {"hour": "14:00", "score": 58.2, "threats": 7, "events": 275.0}, {"hour": "15:00", "score": 51.6, "threats": 20, "events": 244.0}, {"hour": "16:00", "score": 47.5, "threats": 4, "events": 261.0}, {"hour": "17:00", "score": 43.7, "threats": 0, "events": 345.0}, {"hour": "18:00", "score": 36.5, "threats": 3, "events": 368.0}, {"hour": "19:00", "score": 28.7, "threats": 8, "events": 280.0}, {"hour": "20:00", "score": 26.7, "threats": 1, "events": 128.0}, {"hour": "21:00", "score": 32.0, "threats": 15, "events": 216.0}, {"hour": "22:00", "score": 38.5, "threats": 11, "events": 217.0}, {"hour": "23:00", "score": 42.7, "threats": 3, "events": 53.0}], "top_threats": [{"type": "Brute Force", "count": 20, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 13, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 19, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 11, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 3, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 12, "findings": 19}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 30, "findings": 0}, {"name": "ITDR", "status": "ACTIVE", "scans": 3, "findings": 9}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 83, "findings": 33}, {"name": "SIEM", "status": "ACTIVE", "scans": 607, "findings": 13}, {"name": "APM", "status": "ACTIVE", "scans": 25, "findings": 7}], "geo_attacks": 34, "blocked_today": 3376, "mean_detect_min": 12.8}	2026-04-22 23:51:37.913315	{}
55938aa8-c351-435f-8b90-7d1f48a282a2	1	56.7	CRITICAL	25	5	67.5	99.33	490	{"timeline": [{"hour": "00:00", "score": 60.1, "threats": 16, "events": 226.0}, {"hour": "01:00", "score": 52.4, "threats": 10, "events": 376.0}, {"hour": "02:00", "score": 48.3, "threats": 10, "events": 182.0}, {"hour": "03:00", "score": 46.3, "threats": 1, "events": 345.0}, {"hour": "04:00", "score": 53.6, "threats": 0, "events": 395.0}, {"hour": "05:00", "score": 53.7, "threats": 28, "events": 236.0}, {"hour": "06:00", "score": 57.4, "threats": 18, "events": 414.0}, {"hour": "07:00", "score": 60.4, "threats": 0, "events": 446.0}, {"hour": "08:00", "score": 60.5, "threats": 12, "events": 99.0}, {"hour": "09:00", "score": 67.9, "threats": 23, "events": 404.0}, {"hour": "10:00", "score": 68.9, "threats": 12, "events": 117.0}, {"hour": "11:00", "score": 62.8, "threats": 25, "events": 189.0}, {"hour": "12:00", "score": 57.0, "threats": 11, "events": 406.0}, {"hour": "13:00", "score": 61.6, "threats": 27, "events": 321.0}, {"hour": "14:00", "score": 64.2, "threats": 7, "events": 258.0}, {"hour": "15:00", "score": 57.3, "threats": 19, "events": 148.0}, {"hour": "16:00", "score": 53.2, "threats": 20, "events": 62.0}, {"hour": "17:00", "score": 54.1, "threats": 19, "events": 65.0}, {"hour": "18:00", "score": 52.6, "threats": 21, "events": 212.0}, {"hour": "19:00", "score": 53.6, "threats": 27, "events": 207.0}, {"hour": "20:00", "score": 50.7, "threats": 16, "events": 473.0}, {"hour": "21:00", "score": 55.2, "threats": 24, "events": 114.0}, {"hour": "22:00", "score": 49.6, "threats": 1, "events": 321.0}, {"hour": "23:00", "score": 48.2, "threats": 7, "events": 185.0}], "top_threats": [{"type": "Brute Force", "count": 38, "severity": "HIGH", "trend": "\\u2191"}, {"type": "Port Scan", "count": 67, "severity": "MEDIUM", "trend": "\\u2192"}, {"type": "SQL Injection", "count": 16, "severity": "CRITICAL", "trend": "\\u2191"}, {"type": "XSS Attempt", "count": 23, "severity": "HIGH", "trend": "\\u2193"}, {"type": "C2 Beacon", "count": 0, "severity": "CRITICAL", "trend": "\\u2191"}], "modules": [{"name": "Cloud Runtime", "status": "ACTIVE", "scans": 25, "findings": 14}, {"name": "Endpoint Agent", "status": "ACTIVE", "scans": 23, "findings": 10}, {"name": "ITDR", "status": "ACTIVE", "scans": 9, "findings": 3}, {"name": "Threat Intel", "status": "ACTIVE", "scans": 28, "findings": 10}, {"name": "SIEM", "status": "ACTIVE", "scans": 151, "findings": 17}, {"name": "APM", "status": "ACTIVE", "scans": 22, "findings": 0}], "geo_attacks": 8, "blocked_today": 3912, "mean_detect_min": 3.4}	2026-04-22 23:52:22.899871	{}
\.


--
-- Data for Name: remediation_kb; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.remediation_kb (id, attack_type, title, severity, explanation, fix_commands, time_estimate_minutes, difficulty, source, created_at) FROM stdin;
1	open_telnet	Telnet Open on Port 23	Critical	Telnet transmits all data including usernames and passwords in plain text. Any attacker on the same network can intercept and read everything. Telnet was designed in 1969 before security was a concern and should never be used on any modern device.	sudo systemctl stop telnet\nsudo systemctl disable telnet\nsudo apt remove telnetd -y	2	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011036
2	default_credentials	Default Credentials Not Changed	Critical	The device is using factory default username and password combinations. These are publicly listed in manufacturer documentation and are the first thing every attacker tries. Leaving default credentials is equivalent to leaving your front door unlocked.	# Access device admin panel\n# Navigate to: Settings > Security > Change Password\n# Set a strong password: minimum 12 characters, mixed case, numbers, symbols\n# Disable default admin account if possible\n# Enable account lockout after 5 failed attempts	5	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011041
3	unencrypted_mqtt	MQTT Running Without TLS Encryption	High	MQTT messages are being transmitted in plain text on port 1883. Anyone on the network can read all device messages, inject false commands, and intercept sensitive sensor data. This is especially dangerous for industrial and medical IoT devices.	# In your MQTT broker config (mosquitto.conf):\nlistener 8883\ncafile /etc/mosquitto/certs/ca.crt\ncertfile /etc/mosquitto/certs/server.crt\nkeyfile /etc/mosquitto/certs/server.key\nrequire_certificate true\n\n# Restart broker:\nsudo systemctl restart mosquitto	30	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011042
4	mqtt_no_auth	MQTT Broker Allows Anonymous Access	High	The MQTT broker accepts connections from any client without requiring a username or password. This means anyone who can reach the broker can subscribe to all topics and publish any message — including commands to connected devices.	# In mosquitto.conf:\nallow_anonymous false\npassword_file /etc/mosquitto/passwd\n\n# Create user:\nsudo mosquitto_passwd -c /etc/mosquitto/passwd your_username\n\n# Restart:\nsudo systemctl restart mosquitto	10	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011042
5	open_ftp	FTP Service Open on Port 21	High	FTP transmits files and credentials in plain text. Port 21 is one of the most commonly attacked ports on the internet. If FTP is needed for file transfers, it must be replaced with SFTP which encrypts the connection.	# Disable FTP:\nsudo systemctl stop vsftpd\nsudo systemctl disable vsftpd\n\n# Install SFTP instead (part of SSH):\nsudo apt install openssh-server -y\nsudo systemctl enable ssh	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011043
6	open_ssh_root	SSH Root Login Enabled	High	SSH is configured to allow direct root login. This means an attacker who brute-forces the SSH password immediately has full system control. Root login should always be disabled — users should SSH as a normal user and then use sudo.	# Edit SSH config:\nsudo nano /etc/ssh/sshd_config\n\n# Change this line:\nPermitRootLogin no\n\n# Also add:\nMaxAuthTries 3\nPasswordAuthentication no\n\n# Restart SSH:\nsudo systemctl restart sshd	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011043
7	http_no_https	Web Interface Running on HTTP Without HTTPS	High	The device web interface transmits login credentials and configuration data without encryption. Any attacker performing a man-in-the-middle attack on the network can capture admin passwords and take control of the device.	# Generate self-signed certificate:\nopenssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes\n\n# For Nginx:\nserver {\n    listen 443 ssl;\n    ssl_certificate /path/to/cert.pem;\n    ssl_certificate_key /path/to/key.pem;\n}\n\n# Redirect HTTP to HTTPS:\nserver {\n    listen 80;\n    return 301 https://$host$request_uri;\n}	20	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011043
8	open_vnc	VNC Remote Desktop Open Without Authentication	Critical	VNC is running and accepting connections without requiring a password. This gives any attacker on the network full graphical control of the device — they can see the screen, move the mouse, and type as if they were sitting in front of it.	# Disable VNC if not needed:\nsudo systemctl stop vncserver\nsudo systemctl disable vncserver\n\n# If VNC is needed, set a strong password:\nvncpasswd\n\n# Restrict to localhost only and use SSH tunnel:\nvncserver -localhost yes	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011044
9	open_snmp	SNMP Running with Default Community String	High	SNMP is configured with the default community string 'public' which is publicly known. This allows attackers to read all device configuration, network topology, and system information. SNMPv1 and v2c transmit this string in plain text.	# Disable SNMPv1 and v2c, use SNMPv3:\nsudo nano /etc/snmp/snmpd.conf\n\n# Remove: rocommunity public\n# Add SNMPv3 user:\ncreateUser myuser SHA mypassword AES myencryptkey\nrouser myuser\n\n# Restart:\nsudo systemctl restart snmpd	15	Moderate	CIS Benchmark	2026-04-03 00:37:29.011044
10	outdated_firmware	Device Running Outdated Firmware	High	The device firmware has not been updated and contains known, publicly documented vulnerabilities. Attackers actively scan for devices running outdated firmware because exploits are already written and publicly available for these versions.	# Check current firmware version in device admin panel\n# Navigate to: Settings > Firmware > Check for Updates\n# Download latest firmware from manufacturer website\n# Backup device configuration before updating\n# Apply firmware update\n# Verify version number after update\n# Re-apply configuration if reset occurred	30	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011044
11	weak_password_policy	No Password Policy Enforced	Medium	The device or application does not enforce minimum password requirements. Users can set passwords like '1234' or 'password' which can be cracked in seconds. Without a password policy, brute force attacks are trivial.	# For Linux systems:\nsudo nano /etc/pam.d/common-password\n\n# Add:\npassword requisite pam_pwquality.so minlen=12 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1\n\n# Install pwquality if needed:\nsudo apt install libpam-pwquality -y	10	Quick Win	NIST SP 800-63B	2026-04-03 00:37:29.011045
12	no_account_lockout	No Account Lockout After Failed Logins	Medium	The device allows unlimited login attempts without locking the account. This makes it completely vulnerable to brute force attacks where software automatically tries thousands of password combinations per second.	# For SSH using fail2ban:\nsudo apt install fail2ban -y\nsudo systemctl enable fail2ban\n\n# Configure:\nsudo nano /etc/fail2ban/jail.local\n[sshd]\nenabled = true\nmaxretry = 5\nbantime = 900\nfindtime = 600	10	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011045
13	open_redis	Redis Database Exposed Without Authentication	Critical	Redis is accessible on the network without a password. An attacker can read all cached data, write arbitrary data, and in many configurations execute system commands. Redis should never be exposed to the network without authentication.	# Bind Redis to localhost only:\nsudo nano /etc/redis/redis.conf\n\n# Change:\nbind 127.0.0.1\n\n# Set password:\nrequirepass your_strong_password_here\n\n# Disable dangerous commands:\nrename-command FLUSHALL ""\nrename-command CONFIG ""\n\n# Restart:\nsudo systemctl restart redis	10	Quick Win	OWASP Top 10	2026-04-03 00:37:29.011045
14	coap_no_dtls	CoAP Running Without DTLS Encryption	High	CoAP messages between IoT devices are transmitted without encryption. DTLS (Datagram Transport Layer Security) is the CoAP equivalent of TLS and must be enabled to prevent eavesdropping and message injection attacks.	# Generate DTLS certificates:\nopenssl ecparam -name prime256v1 -genkey -noout -out coap-key.pem\nopenssl req -new -x509 -key coap-key.pem -out coap-cert.pem -days 365\n\n# Configure your CoAP library to use DTLS\n# Refer to your specific CoAP implementation documentation\n# Common libraries: libcoap, aiocoap, californium	45	Complex	RFC 7252	2026-04-03 00:37:29.011045
15	open_database_port	Database Port Exposed to Network	Critical	The database port is accessible from outside the device or server. Databases should never be directly accessible from the network — only the application running on the same machine should be able to connect. Direct database exposure allows credential attacks and data theft.	# Block database port with firewall:\nsudo ufw deny 5432\nsudo ufw deny 3306\nsudo ufw deny 27017\n\n# Bind database to localhost:\n# PostgreSQL - in postgresql.conf:\nlisten_addresses = 'localhost'\n\n# MySQL - in my.cnf:\nbind-address = 127.0.0.1	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011046
16	ssl_expired_certificate	SSL Certificate Expired or Invalid	High	The device is using an expired or self-signed SSL certificate. Users and connecting devices receive security warnings and may disable certificate validation entirely — which makes them vulnerable to man-in-the-middle attacks that an attacker can exploit.	# Install certbot for free Let's Encrypt certificate:\nsudo apt install certbot -y\nsudo certbot certonly --standalone -d yourdomain.com\n\n# Auto-renewal:\nsudo certbot renew --dry-run\n\n# Add to crontab for auto-renewal:\n0 0 1 * * certbot renew --quiet	15	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011046
17	unnecessary_services	Unnecessary Network Services Running	Medium	The device is running services that are not required for its function. Every running service is an attack surface. A smart camera does not need an FTP server. A temperature sensor does not need a web server. Unused services should always be disabled.	# List all running services:\nsudo systemctl list-units --type=service --state=running\n\n# Disable unnecessary service:\nsudo systemctl stop service-name\nsudo systemctl disable service-name\n\n# Check open ports:\nsudo ss -tlnp	20	Moderate	CIS Benchmark	2026-04-03 00:37:29.011046
18	no_firewall	No Firewall Configured	High	The device has no firewall rules configured. All ports are accessible to anyone on the network. A firewall is the most basic network security control — it should only allow traffic on ports the device actually needs.	# Enable UFW firewall:\nsudo apt install ufw -y\nsudo ufw default deny incoming\nsudo ufw default allow outgoing\n\n# Allow only needed ports (example):\nsudo ufw allow 22/tcp\nsudo ufw allow 443/tcp\n\n# Enable:\nsudo ufw enable\nsudo ufw status verbose	10	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011047
19	insecure_api	API Endpoint Without Authentication	High	One or more API endpoints accept requests without verifying who is making them. An attacker can call these endpoints directly to read data, trigger actions, or modify device configuration without any credentials.	# Implement JWT authentication on all endpoints\n# Example for Flask:\nfrom flask_jwt_extended import jwt_required\n\n@app.route('/api/data')\n@jwt_required()\ndef get_data():\n    pass\n\n# Ensure every route that returns data\n# or triggers actions requires authentication	60	Complex	OWASP API Security Top 10	2026-04-03 00:37:29.011047
20	hardcoded_credentials	Hardcoded Credentials Found in Firmware	Critical	The device firmware contains hardcoded usernames and passwords embedded directly in the code. These cannot be changed by the user. Every device of this model ships with identical credentials — finding them once gives an attacker access to every device worldwide.	# This requires a firmware update from the manufacturer\n# Contact manufacturer immediately and report the vulnerability\n# Check manufacturer website for security patches\n# If no patch available, isolate device from network\n# Consider replacing device with one from a security-conscious vendor\n# Report to NCSC if critical infrastructure: https://www.ncsc.gov.uk	60	Complex	OWASP IoT Top 10	2026-04-03 00:37:29.011047
21	open_rsync	Rsync Service Exposed on Port 873	High	Rsync is running and accessible from the network. Without proper access controls, attackers can use rsync to download all files from the device or upload malicious files. This has been exploited in several major data breaches.	# Disable rsync if not needed:\nsudo systemctl stop rsync\nsudo systemctl disable rsync\n\n# If needed, restrict access in /etc/rsyncd.conf:\nhosts allow = 192.168.1.0/24\nhosts deny = *\n\n# Or block with firewall:\nsudo ufw deny 873	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011048
22	cleartext_storage	Sensitive Data Stored in Plaintext	High	The device stores sensitive information such as passwords, API keys, or personal data in plaintext files. If an attacker gains any access to the filesystem, they immediately have all credentials and sensitive data without needing to crack anything.	# Encrypt sensitive config files:\ngpg --symmetric --cipher-algo AES256 config.txt\n\n# For passwords, always use hashing:\n# Python example:\nfrom bcrypt import hashpw, gensalt\nhashed = hashpw(password.encode(), gensalt())\n\n# Never store passwords in plaintext\n# Use environment variables for secrets:\nexport API_KEY=your_key\n# Access in code: os.environ.get('API_KEY')	60	Complex	OWASP IoT Top 10	2026-04-03 00:37:29.011048
23	no_update_mechanism	No Secure Update Mechanism Available	Medium	The device has no way to receive security updates. Once a vulnerability is discovered, it cannot be patched remotely. This means the device will remain vulnerable forever unless physically replaced. This is a design flaw common in cheap IoT hardware.	# This requires manufacturer action for firmware updates\n# Short-term mitigations:\n# 1. Isolate device on a separate VLAN\nsudo ip link add link eth0 name eth0.10 type vlan id 10\n\n# 2. Block all inbound connections with firewall\nsudo ufw default deny incoming\n\n# 3. Monitor device traffic for anomalies\n# 4. Plan device replacement with a supported model	30	Moderate	NIST SP 800-213	2026-04-03 00:37:29.011048
24	open_upnp	UPnP Enabled and Exposed	High	Universal Plug and Play is enabled on this device. UPnP automatically opens ports in your router without any authentication. Attackers have used UPnP to punch holes in firewalls, redirect traffic, and gain access to internal networks from the internet.	# Disable UPnP on the device:\n# Navigate to device admin panel\n# Settings > Network > UPnP > Disable\n\n# Also disable on your router:\n# Router admin panel > Advanced > UPnP > Disable\n\n# Verify no unexpected port mappings exist:\n# Router admin > Port Forwarding — remove unknown entries	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011048
25	open_nfs	NFS Network File System Exposed	Critical	Network File System shares are accessible from the network, potentially without authentication. NFS was designed for trusted internal networks and has minimal security controls. Exposed NFS shares allow attackers to read and write files directly.	# Disable NFS if not needed:\nsudo systemctl stop nfs-server\nsudo systemctl disable nfs-server\n\n# If NFS is needed, restrict in /etc/exports:\n/data 192.168.1.0/24(ro,sync,no_root_squash)\n\n# Restart and verify:\nsudo exportfs -ra\nsudo showmount -e localhost	10	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011049
26	debug_interface_exposed	Debug Interface Accessible on Network	Critical	A debug or development interface is accessible on the network. Debug interfaces are designed for developers and typically bypass all authentication and security controls. They provide direct access to device internals and are never appropriate in production.	# Identify and disable the debug service:\nsudo systemctl stop debug-service\nsudo systemctl disable debug-service\n\n# Block the port:\nsudo ufw deny [debug-port]\n\n# Check for debug flags in application config\n# Ensure DEBUG=False in all production configs\n# Remove or comment out any debug endpoints in code	15	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011049
27	no_logging	Security Event Logging Not Configured	Medium	The device is not logging security events such as failed logins, configuration changes, or connection attempts. Without logs, there is no way to detect an attack in progress or investigate a breach after it occurs. Logging is essential for any device handling sensitive data.	# Enable system logging:\nsudo apt install rsyslog -y\nsudo systemctl enable rsyslog\n\n# Configure audit logging:\nsudo apt install auditd -y\nsudo systemctl enable auditd\n\n# Log failed logins:\nsudo auditctl -w /var/log/auth.log -p wa -k auth_log\n\n# View logs:\nsudo journalctl -f	15	Moderate	NIST SP 800-92	2026-04-03 00:37:29.011049
28	insecure_deserialization	Insecure Deserialization Vulnerability	Critical	The device or application deserializes data from untrusted sources without validation. Insecure deserialization can allow attackers to execute arbitrary code, manipulate application logic, or perform denial of service attacks by sending specially crafted data.	# Never deserialize data from untrusted sources\n# Use safe formats instead of pickle/Java serialization:\n# Python - use JSON instead of pickle:\nimport json\ndata = json.loads(untrusted_input)  # Safe\n# NOT: pickle.loads(untrusted_input)  # Dangerous\n\n# Validate and sanitise all input before processing\n# Implement integrity checks on serialized data\n# Use allowlists for acceptable classes during deserialization	60	Complex	OWASP Top 10	2026-04-03 00:37:29.011049
29	open_memcached	Memcached Exposed on Port 11211	Critical	Memcached is accessible from the network without authentication. This has been used in some of the largest DDoS amplification attacks in history, with attackers using exposed Memcached servers to amplify traffic by up to 51,000x. It also exposes all cached application data.	# Bind Memcached to localhost:\nsudo nano /etc/memcached.conf\n\n# Change:\n-l 127.0.0.1\n\n# Disable UDP (used in amplification attacks):\n-U 0\n\n# Restart:\nsudo systemctl restart memcached\n\n# Block with firewall:\nsudo ufw deny 11211	5	Quick Win	NCSC Advisory	2026-04-03 00:37:29.01105
30	privilege_escalation_risk	Excessive User Privileges Configured	High	User accounts or processes are running with more privileges than required. Following the principle of least privilege, every user and process should have only the minimum permissions needed to perform its function. Excessive privileges mean a compromised account can cause maximum damage.	# Audit current sudo privileges:\nsudo cat /etc/sudoers\nsudo visudo\n\n# Check user groups:\ngroups username\n\n# Remove from unnecessary groups:\nsudo deluser username groupname\n\n# Run services as dedicated low-privilege users:\nsudo useradd -r -s /bin/false serviceuser\nsudo chown serviceuser:serviceuser /opt/service	20	Moderate	CIS Benchmark	2026-04-03 00:37:29.01105
\.


--
-- Data for Name: risk_narratives; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.risk_narratives (id, audience, narrative, risk_score, findings, devices, tokens_used, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.roles (id, name, description, created_at) FROM stdin;
e9a3c585-d129-4a32-8efb-aebee4f93a0c	owner	Full platform access including billing and IAM	2026-04-15 23:56:53.728861
7d8e1906-69f7-4b40-a7cd-a55570d6334f	admin	Full security access, no billing	2026-04-15 23:56:53.732295
bfdaeb70-70c5-4954-b3af-d182259a8adc	analyst	Read, scan, and analyse — no admin settings	2026-04-15 23:56:53.734753
1b8acad3-ea4c-4a00-98b3-c9dbfe44e365	viewer	Read-only access to findings and reports	2026-04-15 23:56:53.736664
\.


--
-- Data for Name: rt_attacks; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.rt_attacks (id, campaign_id, mitre_id, tactic, technique, target, result, impact, evidence, blocked_by, severity, executed_at, created_at) FROM stdin;
69	2	T1190	Initial Access	Exploit Public-Facing Application	192.168.1.4	success	Credentials extracted from 192.168.1.4	Successful Exploit Public-Facing Application — SQL injection	\N	Critical	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.888569
70	2	T1078	Initial Access	Valid Accounts — Default Credentials	192.168.1.2	partial	Partial data access — encryption prevented full exfil	Partial Valid Accounts — Default Credentials — admin:admin (partially mitigated)	Encryption	Critical	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.892479
71	2	T1059	Execution	Command and Scripting Interpreter	192.168.1.4	partial	Some credentials found — MFA prevented full compromise	Partial Command and Scripting Interpreter — Telnet commands (partially mitigated)	Multi-Factor Authentication	High	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.895151
72	2	T1203	Execution	Exploitation for Client Execution	192.168.1.4	blocked	Zero-Trust policy denied access	Blocked attempt: Format string detected and terminated	Encryption	High	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.897289
73	2	T1505	Persistence	Server Software Component	192.168.1.2	partial	Limited access obtained — privilege escalation needed	Partial Server Software Component — Init script modification (partially mitigated)	Multi-Factor Authentication	High	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.899831
74	2	T1136	Persistence	Create Account	192.168.1.1	success	Persistent backdoor installed on 192.168.1.1	Successful Create Account — SSH key injection	\N	Medium	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.901586
75	2	T1021	Lateral Movement	Remote Services	192.168.1.3	partial	Limited access obtained — privilege escalation needed	Partial Remote Services — WMI execution (partially mitigated)	Network Segmentation	Critical	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.904653
76	2	T1210	Lateral Movement	Exploitation of Remote Services	192.168.1.2	success	Control registers read/written on 192.168.1.2	Successful Exploitation of Remote Services — Log4Shell	\N	Critical	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.906791
77	2	T1040	Collection	Network Sniffing	192.168.1.4	success	Full access gained to 192.168.1.4	Successful Network Sniffing — DNP3 interception	\N	High	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.909102
78	2	T1530	Collection	Data from Cloud Storage	192.168.1.1	partial	Partial data access — encryption prevented full exfil	Partial Data from Cloud Storage — Blob storage access (partially mitigated)	Patch Management	High	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.910658
79	2	T1071	Command and Control	Application Layer Protocol	192.168.1.1	partial	Limited access obtained — privilege escalation needed	Partial Application Layer Protocol — CoAP beaconing (partially mitigated)	Network Segmentation	High	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.911811
80	2	T1499	Impact	Endpoint Denial of Service	192.168.1.4	partial	Some credentials found — MFA prevented full compromise	Partial Endpoint Denial of Service — Config wipe (partially mitigated)	Multi-Factor Authentication	Critical	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.912883
81	2	T1565	Impact	Data Manipulation	192.168.1.1	success	Full access gained to 192.168.1.1	Successful Data Manipulation — Register manipulation	\N	Critical	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.914287
82	2	T1046	Discovery	Network Service Discovery	192.168.1.3	blocked	SIEM detection rule triggered — connection terminated	Blocked attempt: Port scanning detected and terminated	Firewall Rule	Medium	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.916996
83	2	T1083	Discovery	File and Directory Discovery	192.168.1.4	partial	Some credentials found — MFA prevented full compromise	Partial File and Directory Discovery — Config file access (partially mitigated)	Multi-Factor Authentication	Medium	2026-04-17 17:35:27.886898	2026-04-17 17:35:27.918111
144	3	T1190	Initial Access	Exploit Public-Facing Application	192.168.1.4	blocked	Attack blocked by network segmentation	Blocked attempt: RCE attempts detected and terminated	Firewall Rule	Critical	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.603576
145	3	T1078	Initial Access	Valid Accounts — Default Credentials	192.168.1.4	partial	Foothold established but detected by monitoring	Partial Valid Accounts — Default Credentials — admin:password (partially mitigated)	Autonomous Defense Playbook	Critical	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.611346
146	3	T1059	Execution	Command and Scripting Interpreter	192.168.1.2	partial	Partial data access — encryption prevented full exfil	Partial Command and Scripting Interpreter — SSH execution (partially mitigated)	Multi-Factor Authentication	High	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.613868
147	3	T1203	Execution	Exploitation for Client Execution	192.168.1.4	success	Full access gained to 192.168.1.4	Successful Exploitation for Client Execution — Buffer overflow	\N	High	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.615247
148	3	T1505	Persistence	Server Software Component	192.168.1.1	success	Control registers read/written on 192.168.1.1	Successful Server Software Component — Backdoor installation	\N	High	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.617183
149	3	T1136	Persistence	Create Account	192.168.1.2	partial	Limited access obtained — privilege escalation needed	Partial Create Account — Hidden user creation (partially mitigated)	Multi-Factor Authentication	Medium	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.619237
150	3	T1021	Lateral Movement	Remote Services	192.168.1.2	success	Control registers read/written on 192.168.1.2	Successful Remote Services — SSH pivoting	\N	Critical	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.620637
151	3	T1210	Lateral Movement	Exploitation of Remote Services	192.168.1.4	success	Control registers read/written on 192.168.1.4	Successful Exploitation of Remote Services — PrintNightmare	\N	Critical	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.622396
152	3	T1040	Collection	Network Sniffing	192.168.1.2	partial	Limited access obtained — privilege escalation needed	Partial Network Sniffing — DNP3 interception (partially mitigated)	Multi-Factor Authentication	High	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.624647
153	3	T1530	Collection	Data from Cloud Storage	192.168.1.1	success	Full access gained to 192.168.1.1	Successful Data from Cloud Storage — Blob storage access	\N	High	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.626076
154	3	T1071	Command and Control	Application Layer Protocol	192.168.1.4	partial	Foothold established but detected by monitoring	Partial Application Layer Protocol — CoAP beaconing (partially mitigated)	SIEM Detection Rule	High	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.627657
155	3	T1499	Impact	Endpoint Denial of Service	192.168.1.3	success	Sensitive data exfiltrated from 192.168.1.3	Successful Endpoint Denial of Service — Config wipe	\N	Critical	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.628815
156	3	T1565	Impact	Data Manipulation	192.168.1.1	success	Control registers read/written on 192.168.1.1	Successful Data Manipulation — Register manipulation	\N	Critical	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.630374
157	3	T1046	Discovery	Network Service Discovery	192.168.1.2	partial	Partial data access — encryption prevented full exfil	Partial Network Service Discovery — Port scanning (partially mitigated)	Encryption	Medium	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.631888
158	3	T1083	Discovery	File and Directory Discovery	192.168.1.1	partial	Limited access obtained — privilege escalation needed	Partial File and Directory Discovery — Config file access (partially mitigated)	Multi-Factor Authentication	Medium	2026-04-21 23:49:01.601203	2026-04-21 23:49:01.633037
159	1	T1190	Initial Access	Exploit Public-Facing Application	192.168.1.4	blocked	Attack blocked by network segmentation	Blocked attempt: RCE attempts detected and terminated	Firewall Rule	Critical	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.160146
160	1	T1078	Initial Access	Valid Accounts — Default Credentials	192.168.1.4	partial	Foothold established but detected by monitoring	Partial Valid Accounts — Default Credentials — admin:password (partially mitigated)	Autonomous Defense Playbook	Critical	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.161927
161	1	T1059	Execution	Command and Scripting Interpreter	192.168.1.2	partial	Partial data access — encryption prevented full exfil	Partial Command and Scripting Interpreter — SSH execution (partially mitigated)	Multi-Factor Authentication	High	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.163886
162	1	T1203	Execution	Exploitation for Client Execution	192.168.1.4	success	Full access gained to 192.168.1.4	Successful Exploitation for Client Execution — Buffer overflow	\N	High	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.165604
163	1	T1505	Persistence	Server Software Component	192.168.1.1	success	Control registers read/written on 192.168.1.1	Successful Server Software Component — Backdoor installation	\N	High	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.167866
164	1	T1136	Persistence	Create Account	192.168.1.2	partial	Limited access obtained — privilege escalation needed	Partial Create Account — Hidden user creation (partially mitigated)	Multi-Factor Authentication	Medium	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.170198
165	1	T1021	Lateral Movement	Remote Services	192.168.1.2	success	Control registers read/written on 192.168.1.2	Successful Remote Services — SSH pivoting	\N	Critical	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.176031
166	1	T1210	Lateral Movement	Exploitation of Remote Services	192.168.1.4	success	Control registers read/written on 192.168.1.4	Successful Exploitation of Remote Services — PrintNightmare	\N	Critical	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.18322
167	1	T1040	Collection	Network Sniffing	192.168.1.2	partial	Limited access obtained — privilege escalation needed	Partial Network Sniffing — DNP3 interception (partially mitigated)	Multi-Factor Authentication	High	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.186371
168	1	T1530	Collection	Data from Cloud Storage	192.168.1.1	success	Full access gained to 192.168.1.1	Successful Data from Cloud Storage — Blob storage access	\N	High	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.188609
169	1	T1071	Command and Control	Application Layer Protocol	192.168.1.4	partial	Foothold established but detected by monitoring	Partial Application Layer Protocol — CoAP beaconing (partially mitigated)	SIEM Detection Rule	High	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.192156
170	1	T1499	Impact	Endpoint Denial of Service	192.168.1.3	success	Sensitive data exfiltrated from 192.168.1.3	Successful Endpoint Denial of Service — Config wipe	\N	Critical	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.197733
171	1	T1565	Impact	Data Manipulation	192.168.1.1	success	Control registers read/written on 192.168.1.1	Successful Data Manipulation — Register manipulation	\N	Critical	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.201097
172	1	T1046	Discovery	Network Service Discovery	192.168.1.2	partial	Partial data access — encryption prevented full exfil	Partial Network Service Discovery — Port scanning (partially mitigated)	Encryption	Medium	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.205055
173	1	T1083	Discovery	File and Directory Discovery	192.168.1.1	partial	Limited access obtained — privilege escalation needed	Partial File and Directory Discovery — Config file access (partially mitigated)	Multi-Factor Authentication	Medium	2026-04-21 23:49:13.158837	2026-04-21 23:49:13.206965
\.


--
-- Data for Name: rt_campaigns; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.rt_campaigns (id, name, description, scope, objectives, status, attack_count, success_count, blocked_count, overall_score, duration_sec, created_by, created_at, completed_at) FROM stdin;
3	Cloud Attack Surface Assessment	Red team assessment targeting cloud infrastructure — AWS S3 buckets, Azure IoT Hub, GCP service accounts.	AWS Production, Azure NHS Platform, GCP Analytics	Test cloud security posture, validate IAM controls, assess data exfiltration risk.	completed	15	7	1	30	0	\N	2026-04-16 18:18:08.519523	2026-04-21 23:49:01.632901
1	Full IoT Network Assessment — Q2 2026	Comprehensive red team assessment of all IoT devices and control systems across the production network.	192.168.1.0/24, 10.0.1.0/24, 10.0.2.0/24	Identify exploitable attack paths, test defence coverage, validate Zero-Trust policies and SIEM detection rules.	completed	15	7	1	30	0	\N	2026-04-09 20:18:08.519523	2026-04-21 23:49:13.206775
2	OT/ICS Protocol Attack Simulation	Focused assessment of industrial control system security — Modbus, DNP3, and IEC 61850 attack paths.	10.0.1.0/24 (OT network)	Test industrial protocol security, validate OT segmentation, assess physical impact potential of cyber attacks.	completed	15	5	2	40	0	\N	2026-04-13 20:18:08.519523	2026-04-17 17:35:27.917946
\.


--
-- Data for Name: runtime_protection_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.runtime_protection_findings (id, scan_id, category, title, severity, technique, description, remediation, confidence, node_meta, created_at) FROM stdin;
ecf815ba-003c-4728-9ae6-219277ddfad5	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Process Injection	Reflective DLL Injection Detected	CRITICAL	T1055.001 — Reflective DLL Injection	Runtime workload threat detected in container: Reflective DLL Injection Detected.	Enable kernel-level protection. Deploy memory integrity checks. Block unsigned DLL loading.	HIGH	{}	2026-04-22 18:55:52.192167
f1a25927-f184-4a81-a190-084518ccbe57	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Process Injection	Process Hollowing Detected	CRITICAL	T1055.012 — Process Hollowing	Runtime workload threat detected in container: Process Hollowing Detected.	Enable Endpoint Detection with behavioural memory scanning. Deploy Windows Defender Credential Guard.	HIGH	{}	2026-04-22 18:55:52.192176
bac27676-d9c5-438e-882b-42c353a831fd	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Fileless Malware	PowerShell Download Cradle Detected	CRITICAL	T1059.001 — PowerShell	Runtime workload threat detected in container: PowerShell Download Cradle Detected.	Enable PowerShell Constrained Language Mode. Enable Script Block Logging. Block encoded commands.	HIGH	{}	2026-04-22 18:55:52.19218
510cbc45-28b0-49bd-97a6-9d2b65718168	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Fileless Malware	WMI Persistence for Fileless Execution	HIGH	T1546.003 — WMI Event Subscription	Runtime workload threat detected in container: WMI Persistence for Fileless Execution.	Monitor WMI event subscriptions. Disable WMI if not required. Deploy WMI activity monitoring.	HIGH	{}	2026-04-22 18:55:52.192184
7d230afc-632e-4969-9132-a915933cc84e	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Fileless Malware	Living-off-the-Land Binary Abuse	HIGH	T1218 — Signed Binary Proxy Execution	Runtime workload threat detected in container: Living-off-the-Land Binary Abuse.	Allowlist legitimate uses of LOLBins. Monitor execution of certutil, mshta, regsvr32 with unusual parameters.	MEDIUM	{}	2026-04-22 18:55:52.192187
847348ad-8f55-4ef1-a085-56d2a884fb79	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Memory Protection	Heap Spray Attack Detected	CRITICAL	T1203 — Exploitation for Client Execution	Runtime workload threat detected in container: Heap Spray Attack Detected.	Enable Data Execution Prevention (DEP). Deploy ASLR. Use memory-safe programming languages.	HIGH	{}	2026-04-22 18:55:52.19219
a560ac52-a9a2-41cd-a985-65d9044cf36e	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Memory Protection	Kernel Exploit Attempt	CRITICAL	T1068 — Exploitation for Privilege Escalation	Runtime workload threat detected in container: Kernel Exploit Attempt.	Keep kernel patched. Enable Secure Boot. Deploy kernel integrity monitoring. Restrict driver loading.	HIGH	{}	2026-04-22 18:55:52.192194
ee4e7aa9-76e4-4ee9-93f8-1d374d41ef90	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Container Escape	Container Escape via Kernel Exploit	CRITICAL	T1611 — Escape to Host	Runtime workload threat detected in container: Container Escape via Kernel Exploit.	Run containers as non-root. Disable privileged mode. Apply seccomp and AppArmor profiles. Keep kernel patched.	HIGH	{}	2026-04-22 18:55:52.192197
94af0647-ce39-4b79-8a8f-ec27bd957a1b	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Container Escape	Docker Socket Mount Exploitation	CRITICAL	T1611	Runtime workload threat detected in container: Docker Socket Mount Exploitation.	Never mount Docker socket into containers. Use rootless Docker. Implement container runtime security.	HIGH	{}	2026-04-22 18:55:52.192201
31175c08-f376-4990-95cf-afe25dc58dcd	c7b020ce-aa53-4fe4-9def-d4d64db9fec1	Cryptomining	Cryptomining Process Detected	HIGH	T1496 — Resource Hijacking	Runtime workload threat detected in container: Cryptomining Process Detected.	Monitor CPU usage anomalies. Block mining pool domains at DNS. Deploy process allowlisting.	HIGH	{}	2026-04-22 18:55:52.192204
\.


--
-- Data for Name: runtime_protection_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.runtime_protection_scans (id, user_id, workload_type, workload_name, risk_score, severity, total_findings, critical_count, summary, created_at, node_meta) FROM stdin;
c7b020ce-aa53-4fe4-9def-d4d64db9fec1	1	container	unnamed-workload	100	CRITICAL	10	7	Runtime Protection scan complete for unnamed-workload (container). Risk: 100.0/100. 10 threat(s) — 7 critical across 5 categories.	2026-04-22 18:55:52.187646	{}
\.


--
-- Data for Name: sandbox_analyses; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.sandbox_analyses (id, user_id, sample_name, file_type, sha256, verdict, malware_family, threat_score, severity, behaviours, iocs_found, summary, created_at, node_meta) FROM stdin;
6ffc703c-6e62-42f5-95ea-4002afa0226f	1	sample.bin	PE32	c970e97f92357c1df3752c5731350f843c413d6ebc96a03bc38a55c81cca75b5	MALICIOUS	Ransomware	100	CRITICAL	6	6	Malware sandbox analysis complete for sample.bin. Verdict: MALICIOUS. Threat score: 100.0/100. Family: Ransomware. 12 indicator(s) detected.	2026-04-22 22:09:47.114727	{}
e07a55d8-e385-46e6-886f-572ae3b0de0c	1	sample.bin	PE32	c970e97f92357c1df3752c5731350f843c413d6ebc96a03bc38a55c81cca75b5	MALICIOUS	Ransomware	100	CRITICAL	6	6	Malware sandbox analysis complete for sample.bin. Verdict: MALICIOUS. Threat score: 100.0/100. Family: Ransomware. 12 indicator(s) detected.	2026-04-22 22:11:25.418586	{}
\.


--
-- Data for Name: sandbox_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.sandbox_findings (id, analysis_id, category, finding_type, title, severity, description, ioc, mitre_technique, node_meta, created_at) FROM stdin;
ff8f2897-a39b-431d-ab37-022c556e2b37	6ffc703c-6e62-42f5-95ea-4002afa0226f	Process Injection	Static	Process Injection Code	CRITICAL	Static analysis detected: Process Injection Code. Pattern matched in sample.	Code Pattern: injection	T1055	{}	2026-04-22 22:09:47.118873
93991616-9529-4096-b8aa-3a59779d53ea	6ffc703c-6e62-42f5-95ea-4002afa0226f	Evasion	Static	Anti-Analysis Techniques	HIGH	Static analysis detected: Anti-Analysis Techniques. Pattern matched in sample.	Evasion: anti-debug	T1497	{}	2026-04-22 22:09:47.118885
298b4d08-e6f7-433f-9a0e-2899fdfdb0d1	6ffc703c-6e62-42f5-95ea-4002afa0226f	Credential Access	Static	Credential Harvesting Code	CRITICAL	Static analysis detected: Credential Harvesting Code. Pattern matched in sample.	Credential Theft: credential	T1003	{}	2026-04-22 22:09:47.11889
249c6109-5fba-4a69-abeb-608980458ff3	6ffc703c-6e62-42f5-95ea-4002afa0226f	Ransomware	Static	Ransomware Encryption Routine	CRITICAL	Static analysis detected: Ransomware Encryption Routine. Pattern matched in sample.	Encryption: encrypt	T1486	{}	2026-04-22 22:09:47.118894
405bb3d2-95ac-436b-a048-971bbdc041c1	6ffc703c-6e62-42f5-95ea-4002afa0226f	C2	Static	C2 Communication Pattern	CRITICAL	Static analysis detected: C2 Communication Pattern. Pattern matched in sample.	C2: beacon	T1071	{}	2026-04-22 22:09:47.118898
b06bdfeb-4c9b-4684-a658-f28a23a464bb	6ffc703c-6e62-42f5-95ea-4002afa0226f	Privilege Escalation	Static	Privilege Escalation Attempt	HIGH	Static analysis detected: Privilege Escalation Attempt. Pattern matched in sample.	Privilege Escalation: escalation	T1548	{}	2026-04-22 22:09:47.118903
9cca0dcb-15cd-4fbe-b5cd-012200f50ff3	6ffc703c-6e62-42f5-95ea-4002afa0226f	Behavioural	Dynamic	File encryption detected	CRITICAL	Behavioural analysis: File encryption detected observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:09:47.118906
529990cc-017e-406b-a071-65a597a0e734	6ffc703c-6e62-42f5-95ea-4002afa0226f	Behavioural	Dynamic	Shadow copy deletion	CRITICAL	Behavioural analysis: Shadow copy deletion observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:09:47.11891
3b944bc4-3556-4846-a29d-c9548ed8c673	6ffc703c-6e62-42f5-95ea-4002afa0226f	Behavioural	Dynamic	Ransom note creation	CRITICAL	Behavioural analysis: Ransom note creation observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:09:47.118915
3eb64ed6-3661-45e1-870f-0ccefecf08b0	6ffc703c-6e62-42f5-95ea-4002afa0226f	Behavioural	Dynamic	C2 communication	CRITICAL	Behavioural analysis: C2 communication observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:09:47.118918
c4c28a1e-c119-40d6-90b8-3a96224001b1	6ffc703c-6e62-42f5-95ea-4002afa0226f	Behavioural	Dynamic	Privilege escalation	CRITICAL	Behavioural analysis: Privilege escalation observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:09:47.118922
357ee031-1fc0-4a54-80c2-d97a7acb8f14	6ffc703c-6e62-42f5-95ea-4002afa0226f	Behavioural	Dynamic	Lateral movement	CRITICAL	Behavioural analysis: Lateral movement observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:09:47.118926
1ddf04f5-67a1-47cf-8824-9f44b50d23da	e07a55d8-e385-46e6-886f-572ae3b0de0c	Process Injection	Static	Process Injection Code	CRITICAL	Static analysis detected: Process Injection Code. Pattern matched in sample.	Code Pattern: injection	T1055	{}	2026-04-22 22:11:25.423332
662870b4-b6d7-4e3e-9298-2c927f5554ca	e07a55d8-e385-46e6-886f-572ae3b0de0c	Evasion	Static	Anti-Analysis Techniques	HIGH	Static analysis detected: Anti-Analysis Techniques. Pattern matched in sample.	Evasion: anti-debug	T1497	{}	2026-04-22 22:11:25.423341
ab541ff7-8610-4f33-8585-91347f17025a	e07a55d8-e385-46e6-886f-572ae3b0de0c	Credential Access	Static	Credential Harvesting Code	CRITICAL	Static analysis detected: Credential Harvesting Code. Pattern matched in sample.	Credential Theft: credential	T1003	{}	2026-04-22 22:11:25.423346
bdb42831-da0b-416d-9b45-2acc1b62f928	e07a55d8-e385-46e6-886f-572ae3b0de0c	Ransomware	Static	Ransomware Encryption Routine	CRITICAL	Static analysis detected: Ransomware Encryption Routine. Pattern matched in sample.	Encryption: encrypt	T1486	{}	2026-04-22 22:11:25.423349
eddd80f6-57fd-44b5-b988-b1c949663c94	e07a55d8-e385-46e6-886f-572ae3b0de0c	C2	Static	C2 Communication Pattern	CRITICAL	Static analysis detected: C2 Communication Pattern. Pattern matched in sample.	C2: beacon	T1071	{}	2026-04-22 22:11:25.423353
71f5afce-ae24-4a4c-b618-165da60975cd	e07a55d8-e385-46e6-886f-572ae3b0de0c	Privilege Escalation	Static	Privilege Escalation Attempt	HIGH	Static analysis detected: Privilege Escalation Attempt. Pattern matched in sample.	Privilege Escalation: escalation	T1548	{}	2026-04-22 22:11:25.423356
a88bdcd1-79f2-4543-86b6-c7c639eed4fc	e07a55d8-e385-46e6-886f-572ae3b0de0c	Behavioural	Dynamic	File encryption detected	CRITICAL	Behavioural analysis: File encryption detected observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:11:25.423359
79687161-b198-4a09-bb45-a55c8028037c	e07a55d8-e385-46e6-886f-572ae3b0de0c	Behavioural	Dynamic	Shadow copy deletion	CRITICAL	Behavioural analysis: Shadow copy deletion observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:11:25.423362
b444c141-3a5a-4452-b9ae-06b0976be98d	e07a55d8-e385-46e6-886f-572ae3b0de0c	Behavioural	Dynamic	Ransom note creation	CRITICAL	Behavioural analysis: Ransom note creation observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:11:25.423365
2b174ff7-3fd6-4a22-8020-1c2c2076b1b4	e07a55d8-e385-46e6-886f-572ae3b0de0c	Behavioural	Dynamic	C2 communication	CRITICAL	Behavioural analysis: C2 communication observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:11:25.423368
e1bf7917-1451-4f46-8328-20a0798a18fa	e07a55d8-e385-46e6-886f-572ae3b0de0c	Behavioural	Dynamic	Privilege escalation	CRITICAL	Behavioural analysis: Privilege escalation observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:11:25.423371
024a474f-284d-4409-8301-aec8199e129b	e07a55d8-e385-46e6-886f-572ae3b0de0c	Behavioural	Dynamic	Lateral movement	CRITICAL	Behavioural analysis: Lateral movement observed during sandbox execution.	\N	T1486	{}	2026-04-22 22:11:25.423376
\.


--
-- Data for Name: sc_components; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.sc_components (id, name, version, component_type, ecosystem, license, supplier, used_in, direct_dep, vuln_count, critical_vulns, risk_level, license_risk, last_updated, created_at) FROM stdin;
1	log4j-core	2.14.1	library	maven	Apache-2.0	Apache Software Foundation	["AIPET Backend", "SCADA Historian"]	t	3	2	critical	low	2026-04-18 13:57:11.001486	2026-04-18 14:57:11.005034
2	openssl	1.1.1n	library	system	OpenSSL	OpenSSL Project	["IoT Gateway", "MQTT Broker", "Web Server"]	t	2	1	critical	low	2026-04-18 13:57:11.001486	2026-04-18 14:57:11.005043
3	spring-framework	5.3.18	framework	maven	Apache-2.0	VMware/Pivotal	["NHS Patient API"]	t	1	1	critical	low	2026-04-18 12:57:11.001486	2026-04-18 14:57:11.005044
4	lodash	4.17.20	library	npm	MIT	OpenJS Foundation	["AIPET Dashboard", "IoT Portal"]	t	1	0	high	low	2026-04-18 12:57:11.001486	2026-04-18 14:57:11.005045
5	jackson-databind	2.13.2	library	maven	Apache-2.0	FasterXML	["AIPET Backend", "SCADA API"]	t	1	0	medium	low	2026-04-18 12:57:11.001486	2026-04-18 14:57:11.005046
6	flask	2.3.2	framework	pypi	BSD-3-Clause	Pallets	["AIPET Cloud API"]	t	0	0	safe	low	2026-04-18 11:57:11.001486	2026-04-18 14:57:11.005047
7	react	18.2.0	framework	npm	MIT	Meta	["AIPET Dashboard"]	t	0	0	safe	low	2026-04-18 11:57:11.001486	2026-04-18 14:57:11.005047
8	sqlalchemy	2.0.15	library	pypi	MIT	SQLAlchemy Authors	["AIPET Cloud API"]	t	0	0	safe	low	2026-04-18 11:57:11.001486	2026-04-18 14:57:11.005048
9	moment.js	2.29.3	library	npm	MIT	Moment.js	["AIPET Dashboard", "IoT Portal"]	f	1	0	medium	low	2026-04-18 10:57:11.001486	2026-04-18 14:57:11.005048
10	nginx	1.18.0	os_package	system	BSD-2-Clause	Nginx Inc	["Web Server", "API Gateway"]	t	1	0	medium	low	2026-04-18 10:57:11.001486	2026-04-18 14:57:11.005049
11	python-jwt	3.3.3	library	pypi	MIT	Community	["AIPET Cloud API"]	t	1	1	critical	low	2026-04-18 09:57:11.001486	2026-04-18 14:57:11.00505
12	commons-text	1.9	library	maven	Apache-2.0	Apache Software Foundation	["SCADA Historian", "NHS Patient API"]	f	1	1	critical	low	2026-04-18 09:57:11.001486	2026-04-18 14:57:11.005051
13	bcrypt	4.0.1	library	pypi	Apache-2.0	pyca	["AIPET Cloud API"]	t	0	0	safe	low	2026-04-18 09:57:11.001486	2026-04-18 14:57:11.005051
14	cryptography	41.0.0	library	pypi	Apache-2.0	pyca	["AIPET Cloud API"]	t	0	0	safe	low	2026-04-18 08:57:11.001486	2026-04-18 14:57:11.005052
15	gpl-licensed-module	2.1.0	library	npm	GPL-3.0	Unknown	["IoT Portal"]	f	0	0	safe	high	2026-04-18 08:57:11.001486	2026-04-18 14:57:11.005053
\.


--
-- Data for Name: sc_sboms; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.sc_sboms (id, name, format, version, components_count, vuln_count, content, created_at) FROM stdin;
\.


--
-- Data for Name: sc_vulns; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.sc_vulns (id, component_id, cve_id, severity, cvss_score, title, description, fixed_version, exploit_public, cisa_kev, status, created_at) FROM stdin;
1	1	CVE-2021-44228	Critical	10	Log4Shell — Remote Code Execution via JNDI injection	Apache Log4j2 JNDI features used in configuration allow attacker to execute arbitrary code	2.15.0	t	t	open	2026-04-18 14:57:11.011045
2	1	CVE-2021-45046	Critical	9	Log4Shell bypass — incomplete fix in 2.15.0	The fix for CVE-2021-44228 was incomplete and could be bypassed	2.16.0	t	t	open	2026-04-18 14:57:11.01105
3	1	CVE-2021-45105	High	7.5	Log4j2 DoS via infinite recursion	Apache Log4j2 does not protect from infinite recursion in lookup evaluation	2.17.0	f	f	open	2026-04-18 14:57:11.011051
4	2	CVE-2022-0778	Critical	7.5	OpenSSL infinite loop in BN_mod_sqrt()	OpenSSL certificate parsing triggers infinite loop causing DoS	1.1.1n	t	t	open	2026-04-18 14:57:11.011052
5	2	CVE-2023-0286	High	7.4	OpenSSL X.509 GeneralName type confusion	Type confusion in X.509 GeneralName may allow memory read or DoS	1.1.1t	f	f	open	2026-04-18 14:57:11.011052
6	3	CVE-2022-22965	Critical	9.8	Spring4Shell — RCE in Spring Framework	Spring Framework RCE via data binding on JDK9+ (Spring4Shell)	5.3.18	t	t	open	2026-04-18 14:57:11.011053
7	4	CVE-2021-23337	High	7.2	Lodash command injection via template function	Prototype pollution attack in lodash template function	4.17.21	t	f	open	2026-04-18 14:57:11.011053
8	5	CVE-2022-42004	High	7.5	Jackson-databind DoS via deeply nested arrays	Attacker can cause OutOfMemoryError via deeply nested JSON arrays	2.13.4	f	f	open	2026-04-18 14:57:11.011054
9	9	CVE-2022-31129	High	7.5	Moment.js ReDoS vulnerability	Regular expression denial of service in moment date parsing	2.29.4	f	f	open	2026-04-18 14:57:11.011054
10	10	CVE-2021-23017	High	7.7	Nginx resolver off-by-one heap write	Off-by-one error in DNS resolver may allow code execution	1.21.0	f	f	open	2026-04-18 14:57:11.011054
11	11	CVE-2022-39227	Critical	9.1	python-jwt algorithm confusion — token forgery	Attacker can forge JWT tokens by exploiting algorithm confusion	3.3.4	t	f	open	2026-04-18 14:57:11.011055
12	12	CVE-2022-42889	Critical	9.8	Text4Shell — RCE via Apache Commons Text interpolation	Apache Commons Text performs variable interpolation allowing RCE (Text4Shell)	1.10.0	t	t	open	2026-04-18 14:57:11.011055
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.scans (id, user_id, target, mode, status, result_dir, report_path, started_at, completed_at, created_at, critical, high, medium, low) FROM stdin;
1	1	localhost	demo	failed	\N	\N	\N	\N	2026-03-31 20:15:39.867425	0	0	0	0
2	1		demo	complete	\N	\N	\N	2026-04-01 09:46:47.736038	2026-04-01 09:45:46.176547	0	0	0	0
3	1		demo	failed	\N	\N	\N	\N	2026-04-01 10:01:43.288689	0	0	0	0
4	1		demo	failed	\N	\N	\N	\N	2026-04-02 01:15:29.528845	0	0	0	0
5	1	10.0.2.15	live	complete	\N	\N	\N	2026-04-02 01:44:58.017747	2026-04-02 01:44:30.971065	0	0	0	0
6	1		demo	queued	\N	\N	\N	\N	2026-04-02 01:51:46.538644	0	0	0	0
7	1	localhost	demo	complete	\N	\N	\N	2026-04-02 08:14:14.5211	2026-04-02 08:13:28.294726	0	0	0	0
8	1		demo	complete	\N	\N	\N	2026-04-02 09:10:46.959833	2026-04-02 09:09:57.733046	0	0	0	0
9	1	192.168.1.0/24	network	completed	\N	\N	\N	\N	\N	2	1	1	0
10	1		demo	failed	\N	\N	\N	\N	2026-04-03 17:06:14.043743	0	0	0	0
11	1		demo	failed	\N	\N	\N	\N	2026-04-04 08:29:12.952477	0	0	0	0
12	1		demo	queued	\N	\N	\N	\N	2026-04-05 01:35:55.509033	0	0	0	0
13	1	192.168.1.1	live	complete	\N	\N	\N	2026-04-05 06:20:23.329482	2026-04-05 06:20:12.626642	0	0	0	0
14	1		demo	queued	\N	\N	\N	\N	2026-04-06 02:24:03.255418	0	0	0	0
15	1		demo	failed	\N	\N	\N	\N	2026-04-06 02:27:46.105339	0	0	0	0
16	2		demo	queued	\N	\N	\N	\N	2026-04-09 15:31:43.276384	0	0	0	0
17	2	192.168.1.1	live	queued	\N	\N	\N	\N	2026-04-09 15:32:03.608879	0	0	0	0
18	2	192.168.1.1	live	queued	\N	\N	\N	\N	2026-04-09 15:33:02.198088	0	0	0	0
19	2	192.168.1.1	live	queued	\N	\N	\N	\N	2026-04-09 15:35:14.106329	0	0	0	0
20	2		demo	queued	\N	\N	\N	\N	2026-04-09 15:37:24.222427	0	0	0	0
21	1	192.168.56.105	live	complete	\N	\N	\N	2026-04-09 16:01:07.26435	2026-04-09 16:00:37.618773	0	0	0	0
22	1	192.168.56.101	live	complete	\N	\N	\N	2026-04-09 16:04:16.636736	2026-04-09 16:04:12.89033	0	0	0	0
23	1	192.168.56.101	live	complete	\N	\N	\N	2026-04-09 16:23:52.009325	2026-04-09 16:23:46.617861	0	0	0	0
24	1	192.168.56.101	live	complete	\N	\N	\N	2026-04-09 23:17:44.338576	2026-04-09 23:17:38.446817	0	0	0	0
25	1	192.168.1.0/24 	live	failed	\N	\N	\N	\N	2026-04-10 01:02:48.682954	0	0	0	0
26	1	192.168.1.0/24	live	failed	\N	\N	\N	\N	2026-04-22 00:19:07.103379	0	0	0	0
\.


--
-- Data for Name: score_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.score_results (id, scan_id, user_id, industry, total_exposure_gbp, findings_breakdown, created_at) FROM stdin;
7	9	1	Manufacturing	1063600	[{"attack": "default_credentials", "target": "192.168.1.2", "severity": "Critical", "finding_id": 3, "fix_status": "open", "exposure_fmt": "£544,000", "exposure_gbp": 544000, "device_function": "Customer Data", "breach_probability": 85}, {"attack": "open_telnet", "target": "192.168.1.1", "severity": "Critical", "finding_id": 2, "fix_status": "open", "exposure_fmt": "£240,000", "exposure_gbp": 240000, "device_function": "Infrastructure / Network", "breach_probability": 75}, {"attack": "unencrypted_mqtt", "target": "192.168.1.3", "severity": "High", "finding_id": 4, "fix_status": "open", "exposure_fmt": "£201,600", "exposure_gbp": 201600, "device_function": "Operations / Manufacturing", "breach_probability": 60}, {"attack": "no_firewall", "target": "192.168.1.4", "severity": "Medium", "finding_id": 5, "fix_status": "open", "exposure_fmt": "£78,000", "exposure_gbp": 78000, "device_function": "General IT", "breach_probability": 65}]	2026-04-05 00:10:13.712168
\.


--
-- Data for Name: siem_events; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.siem_events (id, event_type, source, severity, title, description, raw_payload, mitre_id, user_id, incident_id, acknowledged, created_at) FROM stdin;
2	scan_finding	AIPET Scanner	Critical	Telnet service exposed on 192.168.1.1	Unencrypted remote access protocol detected on port 23.	\N	T1021.004	\N	\N	f	2026-04-16 13:58:37.420157
3	scan_finding	AIPET Scanner	High	Unencrypted MQTT broker on 192.168.1.3	MQTT running without TLS. All messages visible in plaintext.	\N	T1040	\N	\N	f	2026-04-16 13:45:37.420157
4	scan_finding	AIPET Scanner	High	Missing firewall rules on 192.168.1.4	No ACL rules found. Unrestricted lateral movement possible.	\N	T1090	\N	\N	f	2026-04-16 13:10:37.420157
5	auth_event	AIPET Auth	Medium	Multiple failed login attempts from 10.0.0.55	5 failed login attempts in 2 minutes.	\N	T1110	\N	\N	f	2026-04-16 12:10:37.420157
6	network_anomaly	AIPET Watch	Medium	Unusual outbound traffic from 192.168.1.2	Device sent 450MB to external IP in 10 minutes.	\N	T1048	\N	\N	f	2026-04-16 11:10:37.420157
7	scan_finding	AIPET Scanner	Low	HTTP instead of HTTPS on management portal	Admin interface accessible over unencrypted HTTP.	\N	T1557	\N	\N	f	2026-04-16 09:10:37.420157
8	system	AIPET System	Info	Scheduled scan completed — 4 devices scanned	Scan ID 9 completed. 5 findings. Risk level: HIGH.	\N	\N	\N	\N	f	2026-04-16 08:10:37.420157
9	test	Manual Test	Low	SIEM ingest endpoint working	\N	{}	\N	\N	\N	t	2026-04-16 14:24:53.128652
1	scan_finding	AIPET Scanner	Critical	Default credentials detected on 192.168.1.2	Device responded to default admin:admin login attempt.	\N	T1078	\N	\N	t	2026-04-16 14:05:37.420157
10	scan_finding	AIPET Scanner	Critical	Default credentials detected on 192.168.2.10	New device found with admin:admin credentials.	{}	T1078	\N	3	f	2026-04-16 15:09:31.725969
11	auth_event	AIPET Auth	High	10 failed login attempts from 185.220.101.45	Possible brute force — attacker IP is a known Tor exit node.	{}	T1110	\N	\N	f	2026-04-16 15:10:16.202014
12	network_anomaly	Fortinet Firewall	High	Blocked connection attempt to C2 server 91.219.28.12	Device 192.168.1.3 attempted outbound connection to known malware C2.	{"blocked": true, "destination_port": 443}	T1071	\N	\N	f	2026-04-16 15:11:02.697691
13	threat_intel	AIPET Threat Intel (Local IOC Database)	Critical	Threat Intel match: 91.219.28.12	Device IP matched c2 indicator in Local IOC Database feed.	\N	T1071.001	\N	\N	f	2026-04-16 15:44:31.02512
14	threat_intel	AIPET Threat Intel (Local IOC Database)	Critical	Threat Intel match: 91.219.28.12	Device IP matched c2 indicator in Local IOC Database feed.	\N	T1071.001	\N	\N	f	2026-04-16 15:46:51.841157
15	zero_trust	AIPET Zero-Trust	Critical	Zero-Trust QUARANTINE: 192.168.1.1	Quarantined device attempted access to 8.8.8.8:53	\N	T1078	\N	\N	f	2026-04-16 16:00:58.62548
16	zero_trust	AIPET Zero-Trust	High	Zero-Trust BLOCK: 192.168.1.1	Trust score dropped to 50. Factors: 2 Critical finding(s) — -50 pts	\N	T1078	\N	\N	f	2026-04-16 16:05:35.776704
17	zero_trust	AIPET Zero-Trust	High	Zero-Trust BLOCK: 192.168.1.1	Trust score dropped to 50. Factors: 2 Critical finding(s) — -50 pts	\N	T1078	\N	\N	f	2026-04-16 16:10:27.207967
18	defense_action	AIPET Autonomous Defense	Critical	[AUTONOMOUS DEFENSE ALERT] 192.168.1.2	Manual trigger of playbook: Auto-quarantine critical devices	\N	T1078	\N	\N	f	2026-04-16 16:20:46.296623
19	ot_ics_finding	AIPET OT/ICS Scanner (ETHERNETIP)	Critical	EtherNet/IP CIP device accessible without authentication	Common Industrial Protocol (CIP) service accepts connections without authentication. Rockwell/Allen-Bradley PLCs with unauthenticated CIP access can have their logic read and potentially modified by any network host.	\N	T0817	\N	\N	f	2026-04-16 19:43:15.824967
20	ot_ics_finding	AIPET OT/ICS Scanner (MODBUS)	Critical	Modbus TCP has no authentication — any device can send commands	Modbus TCP protocol has no built-in authentication mechanism. Any host on the network can read sensor data and write control commands to connected PLCs and field devices.	\N	T0817	\N	\N	f	2026-04-16 19:44:19.996485
21	ot_ics_finding	AIPET OT/ICS Scanner (MODBUS)	Critical	Modbus coil writing enabled — physical control registers writable	Modbus Function Code 0x0F (Write Multiple Coils) is enabled. An attacker can write to coil registers to directly control connected physical equipment such as motors, valves, and relays.	\N	T0831	\N	\N	f	2026-04-16 19:44:19.996488
22	cloud_finding	AIPET Multi-Cloud (AWS)	Critical	S3 bucket publicly accessible — data exposure risk	An S3 bucket has public read access enabled. Any internet user can list and download bucket contents including IoT device configurations and certificates.	\N	T1530	\N	\N	f	2026-04-16 19:57:50.50253
23	cloud_finding	AIPET Multi-Cloud (AWS)	Critical	EC2 security group allows all inbound traffic (0.0.0.0/0)	An EC2 security group has an inbound rule permitting all traffic from any IP address on all ports. IoT management server is exposed to the entire internet.	\N	T1190	\N	\N	f	2026-04-16 19:57:50.502536
24	twin_simulation	AIPET Digital Twin	High	Attack simulation: PLC Controller compromised	Blast radius: 1 devices at risk. Simulated lateral movement from 10.0.1.10.	\N	T1021	\N	\N	f	2026-04-16 20:09:08.585394
25	twin_simulation	AIPET Digital Twin	High	Attack simulation: SCADA Server compromised	Blast radius: 6 devices at risk. Simulated lateral movement from 192.168.1.1.	\N	T1021	\N	\N	f	2026-04-16 20:10:28.899982
26	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1190	\N	\N	f	2026-04-16 20:21:45.892865
27	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Exploitation for Client Execution succeeded on 192.168.1.3	Full access gained to 192.168.1.3	\N	T1203	\N	\N	f	2026-04-16 20:21:45.908238
28	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] Create Account succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1136	\N	\N	f	2026-04-16 20:21:45.913247
29	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Remote Services succeeded on 192.168.1.2	Sensitive data exfiltrated from 192.168.1.2	\N	T1021	\N	\N	f	2026-04-16 20:21:45.918811
30	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.1	Credentials extracted from 192.168.1.1	\N	T1210	\N	\N	f	2026-04-16 20:21:45.921334
31	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Application Layer Protocol succeeded on 192.168.1.2	Persistent backdoor installed on 192.168.1.2	\N	T1071	\N	\N	f	2026-04-16 20:21:45.927414
32	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Endpoint Denial of Service succeeded on 192.168.1.3	Control registers read/written on 192.168.1.3	\N	T1499	\N	\N	f	2026-04-16 20:21:45.930711
33	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] File and Directory Discovery succeeded on 192.168.1.2	Credentials extracted from 192.168.1.2	\N	T1083	\N	\N	f	2026-04-16 20:21:45.939098
34	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.2	Persistent backdoor installed on 192.168.1.2	\N	T1190	\N	\N	f	2026-04-16 20:22:52.486157
35	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Valid Accounts — Default Credentials succeeded on 192.168.1.3	Full access gained to 192.168.1.3	\N	T1078	\N	\N	f	2026-04-16 20:22:52.492572
36	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] Create Account succeeded on 192.168.1.3	Full access gained to 192.168.1.3	\N	T1136	\N	\N	f	2026-04-16 20:22:52.50199
37	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Remote Services succeeded on 192.168.1.1	Persistent backdoor installed on 192.168.1.1	\N	T1021	\N	\N	f	2026-04-16 20:22:52.503755
38	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.1	Credentials extracted from 192.168.1.1	\N	T1210	\N	\N	f	2026-04-16 20:22:52.505523
39	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Application Layer Protocol succeeded on 192.168.1.2	Persistent backdoor installed on 192.168.1.2	\N	T1071	\N	\N	f	2026-04-16 20:22:52.510761
40	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Endpoint Denial of Service succeeded on 192.168.1.3	Control registers read/written on 192.168.1.3	\N	T1499	\N	\N	f	2026-04-16 20:22:52.512465
41	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] File and Directory Discovery succeeded on 192.168.1.2	Credentials extracted from 192.168.1.2	\N	T1083	\N	\N	f	2026-04-16 20:22:52.518867
42	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.4	Credentials extracted from 192.168.1.4	\N	T1190	\N	\N	f	2026-04-17 17:35:18.24448
43	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] Create Account succeeded on 192.168.1.1	Persistent backdoor installed on 192.168.1.1	\N	T1136	\N	\N	f	2026-04-17 17:35:18.274642
44	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1210	\N	\N	f	2026-04-17 17:35:18.280291
45	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Network Sniffing succeeded on 192.168.1.4	Full access gained to 192.168.1.4	\N	T1040	\N	\N	f	2026-04-17 17:35:18.284154
46	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Data Manipulation succeeded on 192.168.1.1	Full access gained to 192.168.1.1	\N	T1565	\N	\N	f	2026-04-17 17:35:18.296331
47	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.4	Credentials extracted from 192.168.1.4	\N	T1190	\N	\N	f	2026-04-17 17:35:27.890152
48	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] Create Account succeeded on 192.168.1.1	Persistent backdoor installed on 192.168.1.1	\N	T1136	\N	\N	f	2026-04-17 17:35:27.902859
49	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1210	\N	\N	f	2026-04-17 17:35:27.907843
50	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Network Sniffing succeeded on 192.168.1.4	Full access gained to 192.168.1.4	\N	T1040	\N	\N	f	2026-04-17 17:35:27.909511
51	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Data Manipulation succeeded on 192.168.1.1	Full access gained to 192.168.1.1	\N	T1565	\N	\N	f	2026-04-17 17:35:27.915509
52	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.4	Credentials extracted from 192.168.1.4	\N	T1190	\N	\N	f	2026-04-17 17:36:09.147162
53	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] Create Account succeeded on 192.168.1.1	Persistent backdoor installed on 192.168.1.1	\N	T1136	\N	\N	f	2026-04-17 17:36:09.162564
54	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1210	\N	\N	f	2026-04-17 17:36:09.167348
55	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Network Sniffing succeeded on 192.168.1.4	Full access gained to 192.168.1.4	\N	T1040	\N	\N	f	2026-04-17 17:36:09.170002
56	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Data Manipulation succeeded on 192.168.1.1	Full access gained to 192.168.1.1	\N	T1565	\N	\N	f	2026-04-17 17:36:09.1826
57	twin_simulation	AIPET Digital Twin	High	Attack simulation: Customer Data Server compromised	Blast radius: 1 devices at risk. Simulated lateral movement from 192.168.1.2.	\N	T1021	\N	\N	f	2026-04-17 22:08:40.705966
58	twin_simulation	AIPET Digital Twin	High	Attack simulation: Water Treatment RTU compromised	Blast radius: 0 devices at risk. Simulated lateral movement from 10.0.1.11.	\N	T1021	\N	\N	f	2026-04-17 22:09:18.23745
59	twin_simulation	AIPET Digital Twin	High	Attack simulation: Pressure Sensor B compromised	Blast radius: 0 devices at risk. Simulated lateral movement from 10.0.2.11.	\N	T1021	\N	\N	f	2026-04-17 22:09:28.007074
60	twin_simulation	AIPET Digital Twin	High	Attack simulation: Temperature Sensor A compromised	Blast radius: 0 devices at risk. Simulated lateral movement from 10.0.2.10.	\N	T1021	\N	\N	f	2026-04-17 22:09:36.499318
61	twin_simulation	AIPET Digital Twin	High	Attack simulation: PLC Controller compromised	Blast radius: 1 devices at risk. Simulated lateral movement from 10.0.1.10.	\N	T1021	\N	\N	f	2026-04-17 22:09:44.815026
62	ot_ics_finding	AIPET OT/ICS Scanner (ETHERNETIP)	Critical	EtherNet/IP CIP device accessible without authentication	Common Industrial Protocol (CIP) service accepts connections without authentication. Rockwell/Allen-Bradley PLCs with unauthenticated CIP access can have their logic read and potentially modified by any network host.	\N	T0817	\N	\N	f	2026-04-19 17:21:15.251521
63	twin_simulation	AIPET Digital Twin	High	Attack simulation: Customer Data Server compromised	Blast radius: 1 devices at risk. Simulated lateral movement from 192.168.1.2.	\N	T1021	\N	\N	f	2026-04-19 17:23:07.80686
64	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1190	\N	\N	f	2026-04-19 17:23:50.165744
65	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Server Software Component succeeded on 192.168.1.4	Control registers read/written on 192.168.1.4	\N	T1505	\N	\N	f	2026-04-19 17:23:50.175766
66	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Data from Cloud Storage succeeded on 192.168.1.3	Sensitive data exfiltrated from 192.168.1.3	\N	T1530	\N	\N	f	2026-04-19 17:23:50.186108
67	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] Network Service Discovery succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1046	\N	\N	t	2026-04-19 17:23:50.192203
68	zero_trust	AIPET Zero-Trust	High	Zero-Trust BLOCK: 192.168.1.1	Trust score dropped to 50. Factors: 2 Critical finding(s) — -50 pts	\N	T1078	\N	\N	f	2026-04-21 23:17:36.547216
69	defense_action	AIPET Autonomous Defense	High	IP blocked by Autonomous Defense: manual	Manual trigger of playbook: Respond to brute force attacks	\N	T1071	\N	\N	f	2026-04-21 23:19:03.303966
70	ot_ics_finding	AIPET OT/ICS Scanner (ETHERNETIP)	Critical	EtherNet/IP CIP device accessible without authentication	Common Industrial Protocol (CIP) service accepts connections without authentication. Rockwell/Allen-Bradley PLCs with unauthenticated CIP access can have their logic read and potentially modified by any network host.	\N	T0817	\N	\N	f	2026-04-21 23:45:57.635741
71	twin_simulation	AIPET Digital Twin	High	Attack simulation: IP Camera compromised	Blast radius: 0 devices at risk. Simulated lateral movement from 10.0.3.10.	\N	T1021	\N	\N	f	2026-04-21 23:47:29.319788
72	twin_simulation	AIPET Digital Twin	High	Attack simulation: Customer Data Server compromised	Blast radius: 1 devices at risk. Simulated lateral movement from 192.168.1.2.	\N	T1021	\N	\N	f	2026-04-21 23:47:39.126288
89	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Exploitation for Client Execution succeeded on 192.168.1.4	Full access gained to 192.168.1.4	\N	T1203	\N	\N	f	2026-04-21 23:49:01.615749
90	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Server Software Component succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1505	\N	\N	f	2026-04-21 23:49:01.6176
91	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Remote Services succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1021	\N	\N	f	2026-04-21 23:49:01.62109
92	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.4	Control registers read/written on 192.168.1.4	\N	T1210	\N	\N	f	2026-04-21 23:49:01.622955
93	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Data from Cloud Storage succeeded on 192.168.1.1	Full access gained to 192.168.1.1	\N	T1530	\N	\N	f	2026-04-21 23:49:01.626484
94	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Endpoint Denial of Service succeeded on 192.168.1.3	Sensitive data exfiltrated from 192.168.1.3	\N	T1499	\N	\N	f	2026-04-21 23:49:01.629191
95	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Data Manipulation succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1565	\N	\N	f	2026-04-21 23:49:01.630741
73	twin_simulation	AIPET Digital Twin	High	Attack simulation: Corporate Firewall compromised	Blast radius: 2 devices at risk. Simulated lateral movement from 10.0.0.1.	\N	T1021	\N	\N	f	2026-04-21 23:47:48.437332
74	twin_simulation	AIPET Digital Twin	High	Attack simulation: Water Treatment RTU compromised	Blast radius: 0 devices at risk. Simulated lateral movement from 10.0.1.11.	\N	T1021	\N	\N	f	2026-04-21 23:47:56.946137
75	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.2	Credentials extracted from 192.168.1.2	\N	T1190	\N	\N	f	2026-04-21 23:48:32.532745
76	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Server Software Component succeeded on 192.168.1.2	Full access gained to 192.168.1.2	\N	T1505	\N	\N	f	2026-04-21 23:48:32.542851
77	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Remote Services succeeded on 192.168.1.1	Persistent backdoor installed on 192.168.1.1	\N	T1021	\N	\N	f	2026-04-21 23:48:32.548706
78	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Network Sniffing succeeded on 192.168.1.3	Persistent backdoor installed on 192.168.1.3	\N	T1040	\N	\N	f	2026-04-21 23:48:32.553652
79	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Data from Cloud Storage succeeded on 192.168.1.1	Full access gained to 192.168.1.1	\N	T1530	\N	\N	f	2026-04-21 23:48:32.556001
80	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Endpoint Denial of Service succeeded on 192.168.1.3	Sensitive data exfiltrated from 192.168.1.3	\N	T1499	\N	\N	f	2026-04-21 23:48:32.5623
81	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Data Manipulation succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1565	\N	\N	f	2026-04-21 23:48:32.566505
96	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Exploitation for Client Execution succeeded on 192.168.1.4	Full access gained to 192.168.1.4	\N	T1203	\N	\N	f	2026-04-21 23:49:13.16625
97	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Server Software Component succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1505	\N	\N	f	2026-04-21 23:49:13.168519
98	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Remote Services succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1021	\N	\N	f	2026-04-21 23:49:13.180684
99	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.4	Control registers read/written on 192.168.1.4	\N	T1210	\N	\N	f	2026-04-21 23:49:13.1843
100	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Data from Cloud Storage succeeded on 192.168.1.1	Full access gained to 192.168.1.1	\N	T1530	\N	\N	f	2026-04-21 23:49:13.189467
101	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Endpoint Denial of Service succeeded on 192.168.1.3	Sensitive data exfiltrated from 192.168.1.3	\N	T1499	\N	\N	f	2026-04-21 23:49:13.198666
102	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Data Manipulation succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1565	\N	\N	f	2026-04-21 23:49:13.201856
82	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Exploitation for Client Execution succeeded on 192.168.1.4	Full access gained to 192.168.1.4	\N	T1203	\N	\N	f	2026-04-21 23:48:57.039326
83	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Server Software Component succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1505	\N	\N	f	2026-04-21 23:48:57.041273
84	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Remote Services succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1021	\N	\N	f	2026-04-21 23:48:57.043947
85	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.4	Control registers read/written on 192.168.1.4	\N	T1210	\N	\N	f	2026-04-21 23:48:57.045399
86	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Data from Cloud Storage succeeded on 192.168.1.1	Full access gained to 192.168.1.1	\N	T1530	\N	\N	f	2026-04-21 23:48:57.048022
87	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Endpoint Denial of Service succeeded on 192.168.1.3	Sensitive data exfiltrated from 192.168.1.3	\N	T1499	\N	\N	f	2026-04-21 23:48:57.050904
88	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Data Manipulation succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1565	\N	\N	f	2026-04-21 23:48:57.052412
\.


--
-- Data for Name: siem_incidents; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.siem_incidents (id, title, description, severity, status, assigned_to, created_by, event_count, created_at, updated_at) FROM stdin;
1	Critical: Default credentials on IoT devices	Two devices found with default credentials. Immediate password change required.	Critical	open	\N	\N	2	2026-04-16 14:10:37.434026	2026-04-16 14:10:37.43403
2	Unencrypted protocols in production network	Telnet and plain MQTT detected. Lateral movement risk HIGH.	High	investigating	\N	\N	2	2026-04-16 14:10:37.434031	2026-04-16 14:10:37.434032
3	[Auto] Critical finding auto-incident	Rule triggered by: Default credentials detected on 192.168.2.10	Critical	open	\N	\N	1	2026-04-16 15:09:31.738921	2026-04-16 15:09:31.738929
4	[AUTO] Autonomous Defense: 192.168.1.2	Manual trigger of playbook: Auto-quarantine critical devices	Critical	open	\N	\N	1	2026-04-16 16:20:46.299814	2026-04-16 16:20:46.299819
5	[AUTO] Autonomous Defense: manual	Manual trigger of playbook: Respond to brute force attacks	Critical	open	\N	\N	1	2026-04-21 23:19:03.306814	2026-04-21 23:19:03.30682
\.


--
-- Data for Name: siem_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.siem_reports (id, user_id, event_source, total_events, correlated, critical_alerts, incidents, risk_score, summary, alerts, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: siem_rules; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.siem_rules (id, name, description, condition, action, severity, enabled, trigger_count, created_by, created_at) FROM stdin;
3	Telnet exposure alert	Alert when Telnet is found exposed	{"field": "title", "op": "contains", "value": "Telnet"}	alert	Critical	t	0	\N	2026-04-16 14:10:37.429375
1	Critical finding auto-incident	Automatically create incident for any Critical severity event	{"field": "severity", "op": "eq", "value": "Critical"}	incident	Critical	t	1	\N	2026-04-16 14:10:37.429369
2	Default credentials alert	Alert when default credentials are detected	{"field": "title", "op": "contains", "value": "default credentials"}	alert	High	t	1	\N	2026-04-16 14:10:37.429374
4	Brute force detection	Alert on multiple failed login attempts	{"field": "event_type", "op": "eq", "value": "auth_event"}	alert	High	t	1	\N	2026-04-16 14:10:37.429375
\.


--
-- Data for Name: soc_twin_actions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.soc_twin_actions (id, session_id, priority, phase, action, owner, timeframe, mitre_ref, node_meta, created_at) FROM stdin;
e2dc8c45-4e9a-40f3-8dfd-074536b62ec5	34def81e-1dd7-4b4a-85f4-b46670c58a8c	1	Immediate	Isolate all affected systems from the network immediately. Disconnect from LAN and Wi-Fi.	SOC Tier 1	0-15 mins	RS.MI-1	{}	2026-04-22 03:16:05.601879
90265510-9c03-4e17-9907-689c192a8299	34def81e-1dd7-4b4a-85f4-b46670c58a8c	2	Immediate	Alert CISO, IT leadership and legal team. Activate incident response plan.	Incident Commander	0-15 mins	\N	{}	2026-04-22 03:16:05.601889
e059ffef-c3ab-4d3b-81aa-c56efb2c3682	34def81e-1dd7-4b4a-85f4-b46670c58a8c	3	Containment	Identify patient zero and ransomware variant. Preserve memory and disk images for forensics.	SOC Tier 2 / Forensics	15-60 mins	T1486	{}	2026-04-22 03:16:05.601893
2ffaab3a-272f-4f96-81ce-91eafca905e5	34def81e-1dd7-4b4a-85f4-b46670c58a8c	4	Containment	Block C2 IP addresses and domains at firewall and DNS level.	Network Security	15-60 mins	T1071	{}	2026-04-22 03:16:05.601896
92742d85-71c1-4867-86d3-be21326e01f1	34def81e-1dd7-4b4a-85f4-b46670c58a8c	5	Eradication	Restore systems from clean backups. Verify backup integrity before restoration.	IT Operations	1-24 hrs	\N	{}	2026-04-22 03:16:05.601899
9368bd90-9f75-49d1-b35b-9b48f6356ebd	34def81e-1dd7-4b4a-85f4-b46670c58a8c	6	Recovery	Re-image compromised endpoints. Apply all patches before reconnecting to network.	IT Operations	1-48 hrs	\N	{}	2026-04-22 03:16:05.601902
24c186b9-5e84-4a60-8af3-86b25b8d27a7	34def81e-1dd7-4b4a-85f4-b46670c58a8c	7	Post-Incident	Notify regulators and affected parties per legal obligations. Conduct post-mortem.	Legal / Compliance	24-72 hrs	\N	{}	2026-04-22 03:16:05.601905
\.


--
-- Data for Name: soc_twin_sessions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.soc_twin_sessions (id, user_id, scenario_name, scenario_type, threat_actor, severity, risk_score, impact_score, status, summary, created_at, node_meta) FROM stdin;
34def81e-1dd7-4b4a-85f4-b46670c58a8c	1	Unnamed Incident	RANSOMWARE	Financially Motivated Ransomware Group	CRITICAL	95	90	complete	SOC Twin simulation complete. Scenario classified as: RANSOMWARE. Threat actor profile: Financially Motivated Ransomware Group. Risk: 95/100. 7 response action(s) generated.	2026-04-22 03:16:05.597527	{}
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.sso_providers (id, name, client_id, tenant_id, metadata_url, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: synthetic_checks; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.synthetic_checks (id, user_id, check_name, check_type, target_url, overall_status, uptime_pct, avg_latency_ms, sla_met, total_checks, failed_checks, issues, summary, results_data, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: te_clusters; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.te_clusters (id, title, cluster_type, severity, event_count, modules_involved, ai_summary, status, started_at, created_at) FROM stdin;
1	Active Attack Chain: Contractor Account Compromise	attack_chain	Critical	5	["drift", "behavioral", "network", "identity_graph"]	Contractor account shows classic signs of compromise: MFA disabled, geographic anomaly from Romania, privilege escalation to Contributor role, then lateral movement to 8 new systems. The PLC Controller traffic spike 18 minutes later suggests attacker pivoted from IT to OT network. Immediate action: disable contractor account, isolate affected systems, activate incident response.	active	2026-04-19 09:11:56.742658	2026-04-19 15:11:56.744582
2	Supply Chain Risk: Log4Shell + Spring4Shell in Production	compliance_breach	Critical	4	["supply_chain", "compliance", "api_security"]	Two critical RCE vulnerabilities (Log4Shell CVE-2021-44228 CVSS 10.0 and Spring4Shell CVE-2022-22965 CVSS 9.8) detected in production components. Both have public exploits and are in CISA KEV. Combined with API endpoints missing authentication, this creates a viable attack path into production systems. Patch immediately — estimated risk window closing in 48 hours.	active	2026-04-19 03:11:56.742658	2026-04-19 15:11:56.744587
3	Data Exposure: Public S3 + Unencrypted PHI Database	data_incident	Critical	3	["dspm", "network", "compliance"]	IoT telemetry S3 bucket publicly accessible AND Patient database unencrypted at rest — both discovered simultaneously. Network analysis shows data flows from IoT Gateway directly to public S3 bucket bypassing corporate controls. This constitutes a GDPR Art.32 violation and potential NIS2 Art.21 breach. Regulatory notification may be required within 72 hours.	active	2026-04-19 12:11:56.742658	2026-04-19 15:11:56.744589
4	Correlated Alert: aws-admin-role-prod — 2 events across 1 modules	attack_chain	Critical	2	["drift"]	AIPET X Security Analysis for aws-admin-role-prod\n\nWhat is happening: The production admin IAM role has been modified with two dangerous changes — a wildcard permission granting full AWS access and a trust relationship allowing an unknown external account to assume this role.\n\nLikely attack pattern: This is consistent with privilege escalation followed by persistence establishment. An attacker has either compromised credentials with IAM modification rights or exploited a misconfiguration to grant themselves god-mode access and create a backdoor through cross-account trust, enabling them to return at will from infrastructure you do not control.\n\nImmediate actions needed: Revoke the cross-account trust policy immediately and remove the wildcard permission. Identify the principal that made these changes via CloudTrail and disable or rotate those credentials. Audit all API calls made using this role in the past 24-48 hours to assess blast radius. Treat the unknown account ID as hostile and	active	2026-04-19 12:11:56.742658	2026-04-22 00:17:03.569599
\.


--
-- Data for Name: te_events; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.te_events (id, source_module, event_type, severity, title, description, entity, entity_type, mitre_id, cluster_id, correlated, risk_score, raw_ref_id, resolved, created_at) FROM stdin;
1	drift	mfa_disabled	Critical	MFA disabled on contractor account with Contributor access	\N	contractor-external-01	identity	\N	1	t	95	\N	f	2026-04-19 09:11:56.742658
2	behavioral	geo_anomaly	Critical	Contractor account login from Romania — baseline shows UK only	\N	contractor_01	user	T1078	1	t	91	\N	f	2026-04-19 09:16:56.742658
3	drift	privilege_escalation	Critical	Contractor escalated from Reader to Contributor role	\N	contractor-external-01	identity	\N	1	t	95	\N	f	2026-04-19 09:26:56.742658
4	behavioral	lateral_movement	High	Contractor accessing 8 new systems outside contracted scope	\N	contractor_01	user	T1021	1	t	80	\N	f	2026-04-19 09:41:56.742658
5	network	network_issue	Critical	PLC Controller reachable via 3 unencrypted hops	\N	PLC Controller	network_node	\N	1	t	92	\N	f	2026-04-19 09:59:56.742658
6	supply_chain	critical_cve	Critical	CVE-2021-44228: Log4Shell RCE in log4j-core v2.14.1	\N	log4j-core v2.14.1	software_component	\N	2	t	100	\N	f	2026-04-19 03:11:56.742658
7	supply_chain	critical_cve	Critical	CVE-2022-22965: Spring4Shell RCE in Spring Framework	\N	spring-framework v5.3.18	software_component	\N	2	t	98	\N	f	2026-04-19 03:21:56.742658
8	api_security	broken_auth	Critical	Admin user API accessible without authentication	\N	GET /admin/api/users	api_endpoint	T1190	2	t	98	\N	f	2026-04-19 03:41:56.742658
9	compliance	control_failed	High	NIS2-6: Vulnerability handling SLA exceeded — 8 critical CVEs	\N	NIS2 Framework	compliance_framework	\N	2	t	75	\N	f	2026-04-19 05:11:56.742658
10	dspm	public_exposure	Critical	IoT telemetry S3 bucket publicly accessible — 892GB OT data	\N	iot-telemetry-bucket	data_store	\N	3	t	95	\N	f	2026-04-19 12:11:56.742658
11	dspm	unencrypted_at_rest	Critical	Patient database unencrypted — 125,000 PHI records	\N	patient-records-db	data_store	\N	3	t	95	\N	f	2026-04-19 12:21:56.742658
15	api_security	no_rate_limit	Critical	Login endpoint has no rate limiting — brute force possible	\N	POST /api/auth/login	api_endpoint	\N	\N	f	80	\N	f	2026-04-19 11:11:56.742658
16	supply_chain	critical_cve	Critical	CVE-2022-42889: Text4Shell RCE in Apache Commons Text	\N	commons-text v1.9	software_component	\N	\N	f	98	\N	f	2026-04-19 07:11:56.742658
17	network	network_issue	Critical	SCADA server connected to corporate AD via unencrypted LDAP	\N	SCADA Server	network_node	\N	\N	f	90	\N	f	2026-04-19 10:11:56.742658
18	dspm	no_access_control	Critical	PLC configuration files with no authentication	\N	plc-config-fileshare	data_store	\N	\N	f	98	\N	f	2026-04-19 09:11:56.742658
19	behavioral	beacon	High	IoT Gateway beaconing every 60 seconds to external IP	\N	IoT Gateway — Building A	device	T1071	\N	f	85	\N	f	2026-04-19 09:11:56.742658
13	behavioral	traffic_spike	High	Water Treatment Controller — 12x traffic spike	\N	Water Treatment Controller	device	T1041	\N	f	85	\N	t	2026-04-19 14:11:56.742658
12	network	network_issue	Critical	IoT Gateway routing OT data directly to public S3	\N	IoT Gateway	network_node	\N	3	t	90	\N	t	2026-04-19 12:41:56.742658
21	behavioral	protocol_change	High	PLC Controller using HTTP — not in baseline protocol set	PLC device using HTTP protocol. Baseline only shows Modbus and DNP3. Possible firmware compromise or misconfiguration.	PLC Controller — Production Line A	device_or_user	T1040	\N	f	62	3	f	2026-04-18 11:32:38.609785
22	behavioral	unusual_hours	High	PLC Controller active at 03:00 — 5.1σ outside normal window	PLC showing activity at 03:00. Baseline active hours: 06:00-18:00. Unscheduled maintenance or attacker persistence.	PLC Controller — Production Line A	device_or_user	T1078	\N	f	51	4	f	2026-04-18 10:32:38.609785
23	behavioral	data_exfil	High	IP Camera exfiltrating 6x normal data volume	Camera sending 2.7MB/hour vs baseline 450KB/hour. Data leaving network to unknown destination on port 4444.	IP Camera — Floor 2	device_or_user	T1041	\N	f	48	5	f	2026-04-18 09:32:38.609785
24	behavioral	geo_anomaly	Critical	Contractor account login from Romania — baseline shows UK only	Authentication from Bucharest, Romania. Account baseline shows United Kingdom only across 6-month history.	contractor_01	device_or_user	T1078	\N	f	91	6	f	2026-04-18 08:32:38.609785
25	behavioral	beacon	High	IoT Gateway beaconing every 60 seconds to external IP	Regular periodic connections to 45.89.123.45 every 60 seconds. Classic C2 beaconing pattern. Connection started 6 hours ago.	IoT Gateway — Building A	device_or_user	T1071	\N	f	72	8	f	2026-04-18 07:32:38.609785
26	drift	wildcard_permission	Critical	Wildcard aws:* permission added to production admin role	Full AWS account access wildcard added outside change window. Not in original baseline of 5 specific permissions.	aws-admin-role-prod	identity	\N	\N	f	80	1	f	2026-04-19 12:54:38.195651
27	drift	cross_account_access	Critical	Cross-account trust policy added — unknown account 123456789	IAM role trust policy modified to allow external AWS account 123456789 to assume this role. Account not in approved vendor list.	aws-admin-role-prod	identity	\N	\N	f	80	2	f	2026-04-19 11:54:38.195651
28	drift	privilege_escalation	Critical	Contractor account escalated from read-only to Contributor role	External contractor account had read-only VM access at baseline. Now has Azure Contributor role — can create, modify, delete all resources.	contractor-external-01	identity	\N	\N	f	80	3	f	2026-04-19 13:54:38.195651
29	drift	mfa_disabled	Critical	MFA disabled on contractor account with elevated privileges	Multi-factor authentication was active at baseline. MFA has been disabled on this account which now has Contributor access.	contractor-external-01	identity	\N	\N	f	80	4	f	2026-04-19 13:54:38.195651
30	drift	role_added	High	CI/CD service principal granted Owner role on subscription	Azure subscription Owner role assigned to CI/CD principal. Baseline shows deploy-only access. Full subscription control possible.	ci-cd-service-principal	identity	\N	\N	f	60	6	f	2026-04-19 09:54:38.195651
31	network	network_issue	Critical	Patient database unencrypted at rest — 125K PHI records exposed	RDS storing PHI without encryption. Cross-zone connection also unencrypted.	Patient Database (RDS)	network_node	\N	\N	f	85	1	f	2026-04-18 20:17:41.597266
32	network	network_issue	Critical	S3 bucket with OT telemetry publicly accessible	IoT telemetry S3 bucket has public read access. 892GB exposed.	IoT Data Lake (S3)	network_node	\N	\N	f	85	2	f	2026-04-18 20:17:41.597271
33	network	network_issue	Critical	PLC Controller reachable via 3 unencrypted network hops	Critical infrastructure accessible via Internet to PLC. All connections unencrypted.	PLC Controller	network_node	\N	\N	f	85	3	f	2026-04-18 20:17:41.597272
34	network	network_issue	Critical	Water treatment controller connected to internet via unencrypted path	DNP3 traffic flows to internet-accessible S3 bucket unencrypted.	Water Treatment Controller	network_node	\N	\N	f	85	4	f	2026-04-18 20:17:41.597273
14	drift	wildcard_permission	Critical	Wildcard aws:* permission added to production admin role	\N	aws-admin-role-prod	identity	\N	4	t	95	\N	f	2026-04-19 13:11:56.742658
35	network	network_issue	Critical	SCADA server connected to corporate AD via unencrypted LDAP	AD communicating with SCADA using unencrypted LDAP. IT/OT boundary violation.	SCADA Server	network_node	\N	\N	f	85	5	f	2026-04-18 20:17:41.597274
36	api_security	broken_auth	Critical	Admin user management API accessible without authentication	GET /admin/api/users returns full user list including password hashes without any authentication token	GET /admin/api/users	api_endpoint	\N	\N	f	90	1	f	2026-04-18 14:46:08.858422
37	api_security	excessive_exposure	Critical	User API returning password hashes and internal fields	Response includes password_hash, internal_id, admin_notes — not required by any client	GET /admin/api/users	api_endpoint	\N	\N	f	90	4	f	2026-04-18 14:46:08.858429
38	api_security	broken_auth	Critical	IoT telemetry endpoint accepts data without device authentication	Any device or attacker can POST telemetry data — enables false sensor injection	POST /api/v1/telemetry	api_endpoint	\N	\N	f	90	5	f	2026-04-18 14:46:08.85843
39	api_security	missing_encryption	Critical	IoT telemetry transmitted over HTTP — OT data in plaintext	Sensor readings including industrial process data transmitted without TLS	POST /api/v1/telemetry	api_endpoint	\N	\N	f	90	6	f	2026-04-18 14:46:08.858431
40	api_security	broken_auth	Critical	Deprecated config endpoint exposes device configuration without auth	v0 config endpoint returns full device configuration including credentials	GET /api/v0/config	api_endpoint	\N	\N	f	90	9	f	2026-04-18 14:46:08.858432
41	supply_chain	critical_cve	Critical	CVE-2021-44228: Log4Shell — Remote Code Execution via JNDI injection	Apache Log4j2 JNDI features used in configuration allow attacker to execute arbitrary code	log4j-core v2.14.1	software_component	\N	\N	f	100	1	f	2026-04-18 14:57:11.011045
42	supply_chain	critical_cve	Critical	CVE-2021-45046: Log4Shell bypass — incomplete fix in 2.15.0	The fix for CVE-2021-44228 was incomplete and could be bypassed	log4j-core v2.14.1	software_component	\N	\N	f	90	2	f	2026-04-18 14:57:11.01105
43	supply_chain	critical_cve	Critical	CVE-2022-0778: OpenSSL infinite loop in BN_mod_sqrt()	OpenSSL certificate parsing triggers infinite loop causing DoS	openssl v1.1.1n	software_component	\N	\N	f	75	4	f	2026-04-18 14:57:11.011052
44	supply_chain	critical_cve	Critical	CVE-2022-22965: Spring4Shell — RCE in Spring Framework	Spring Framework RCE via data binding on JDK9+ (Spring4Shell)	spring-framework v5.3.18	software_component	\N	\N	f	98	6	f	2026-04-18 14:57:11.011053
45	supply_chain	critical_cve	Critical	CVE-2022-39227: python-jwt algorithm confusion — token forgery	Attacker can forge JWT tokens by exploiting algorithm confusion	python-jwt v3.3.3	software_component	\N	\N	f	91	11	f	2026-04-18 14:57:11.011055
46	dspm	unencrypted_at_rest	Critical	Patient records DB not encrypted at rest — 125,000 PHI records at risk	AWS RDS instance storing Protected Health Information without encryption at rest. GDPR Art.32 violation.	patient-records-db	data_store	\N	\N	f	95	1	f	2026-04-18 14:10:58.114242
47	dspm	public_exposure	Critical	IoT telemetry S3 bucket publicly accessible — OT data exposed	S3 bucket containing operational technology telemetry data has public read access. 892GB of OT data exposed.	iot-telemetry-bucket	data_store	\N	\N	f	95	3	f	2026-04-18 14:10:58.114251
48	dspm	unencrypted_at_rest	Critical	SCADA historian database storing 8.5M OT records without encryption	On-premise database containing 5 years of operational process data unencrypted	scada-historian-db	data_store	\N	\N	f	95	6	f	2026-04-18 14:10:58.114253
20	drift	cross_account_access	Critical	Cross-account trust added to production role — unknown account	\N	aws-admin-role-prod	identity	\N	4	t	95	\N	f	2026-04-19 12:11:56.742658
\.


--
-- Data for Name: tenant_assessments; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.tenant_assessments (id, user_id, tenant_name, tenant_type, isolation_score, risk_score, total_tenants, issues, summary, findings, tenants_data, created_at, node_meta) FROM stdin;
\.


--
-- Data for Name: terminal_audit_log; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.terminal_audit_log (id, user_id, session_key, raw_input, parsed_cmd, module, success, error, duration_ms, ip_address, created_at) FROM stdin;
1	1	\N	status	status	status	t	\N	79	127.0.0.1	2026-04-19 00:39:24.578516
2	1	\N	identity risks	identity	identity	t	\N	23	127.0.0.1	2026-04-19 00:39:24.633509
3	1	\N	help	help	terminal	t	\N	0	127.0.0.1	2026-04-19 05:36:51.835095
4	1	\N	status	status	status	t	\N	87	127.0.0.1	2026-04-19 05:37:14.886864
5	1	\N	scan	nl_detect	terminal	t	\N	0	127.0.0.1	2026-04-19 05:38:36.021918
6	1	\N	scan	ask scan	ask	t	\N	0	127.0.0.1	2026-04-19 05:38:59.683341
7	1	\N	compliance status	compliance	compliance	t	\N	2	127.0.0.1	2026-04-22 00:05:33.114207
8	1	\N	help	help	terminal	t	\N	0	127.0.0.1	2026-04-22 00:06:02.282958
9	1	\N	whoami	whoami	terminal	t	\N	2	127.0.0.1	2026-04-22 00:06:26.945841
10	1	\N	network issues	network	network	t	\N	27	127.0.0.1	2026-04-22 00:06:51.48576
11	1	\N	id	nl_detect	terminal	t	\N	0	127.0.0.1	2026-04-22 00:07:27.27124
12	1	\N	id	whoami	terminal	t	\N	0	127.0.0.1	2026-04-22 00:09:15.159463
13	1	\N	narrative executive	narrative	narrative	t	\N	10	127.0.0.1	2026-04-22 00:12:02.125882
14	1	\N	Risk Narrative	nl_detect	terminal	t	\N	0	127.0.0.1	2026-04-22 00:12:42.253681
15	1	\N	Risk Narrative	narrative executive	narrative	t	\N	0	127.0.0.1	2026-04-22 00:12:50.909644
\.


--
-- Data for Name: terminal_sessions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.terminal_sessions (id, user_id, session_key, last_command, context, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: threat_intel_feeds; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.threat_intel_feeds (id, user_id, feed_name, feed_type, total_iocs, critical_iocs, threat_actors, ttps_mapped, risk_score, summary, created_at, node_meta) FROM stdin;
88b6d9d6-1ca3-43d6-b98e-e7acaeb46c92	1	Manual Intel Feed	manual	4	1	2	6	92.5	Threat Intel ingestion complete for Manual Intel Feed. 4 IOC(s) extracted — 1 critical. 2 threat actor(s) identified: APT29, LockBit. 6 TTP(s) mapped to MITRE ATT&CK.	2026-04-22 19:07:00.708257	{"actors": ["APT29", "LockBit"], "ttps": ["T1566 Phishing", "T1486 Ransomware", "T1003 Credential Dump", "T1190 Exploit Public App", "T1071 C2 Communication", "T1041 Exfiltration"]}
\.


--
-- Data for Name: threat_intel_iocs; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.threat_intel_iocs (id, feed_id, ioc_type, ioc_value, severity, confidence, threat_actor, ttp, description, first_seen, node_meta, created_at) FROM stdin;
44d97760-3883-4266-97a3-6c5e5b3f8759	88b6d9d6-1ca3-43d6-b98e-e7acaeb46c92	IP Address	185.220.101.45	HIGH	HIGH	APT29	T1566 Phishing	IP Address indicator of compromise extracted from threat intelligence feed.	2026-04-22	{}	2026-04-22 19:07:00.713068
c18c7c99-9ec9-4503-a72e-dbfdbdc179e1	88b6d9d6-1ca3-43d6-b98e-e7acaeb46c92	Domain	update-service.microsoft-cdn.com	MEDIUM	MEDIUM	APT29	T1566 Phishing	Domain indicator of compromise extracted from threat intelligence feed.	2026-04-22	{}	2026-04-22 19:07:00.713079
be6eee93-913c-4526-8e1d-dfc2a38cc078	88b6d9d6-1ca3-43d6-b98e-e7acaeb46c92	SHA256 Hash	a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2	CRITICAL	HIGH	APT29	T1566 Phishing	SHA256 Hash indicator of compromise extracted from threat intelligence feed.	2026-04-22	{}	2026-04-22 19:07:00.713084
75ea41da-e90a-4021-8156-7a8a0be4284f	88b6d9d6-1ca3-43d6-b98e-e7acaeb46c92	CVE	CVE-2023-23397	HIGH	HIGH	APT29	T1566 Phishing	CVE indicator of compromise extracted from threat intelligence feed.	2026-04-22	{}	2026-04-22 19:07:00.713088
\.


--
-- Data for Name: threat_matches; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.threat_matches (id, ioc_entry_id, scan_id, matched_value, match_source, threat_type, confidence, severity, details, user_id, created_at) FROM stdin;
1	\N	\N	91.219.28.12	Local IOC Database	c2	98	Critical	[{"source": "Local IOC Database", "matched": true, "confidence": 98, "severity": "Critical", "threat_type": "c2", "description": "Confirmed C2 server \\u2014 associated with Mirai botnet variant targeting IoT devices"}]	1	2026-04-16 15:44:31.027283
2	\N	\N	91.219.28.12	Local IOC Database	c2	98	Critical	[{"source": "Local IOC Database", "matched": true, "confidence": 98, "severity": "Critical", "threat_type": "c2", "description": "Confirmed C2 server \\u2014 associated with Mirai botnet variant targeting IoT devices"}]	1	2026-04-16 15:46:51.842616
\.


--
-- Data for Name: threat_radar_reports; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.threat_radar_reports (id, user_id, organisation, region, sector, risk_score, severity, threat_count, summary, created_at, node_meta) FROM stdin;
089c9ecc-20a0-44e6-8acc-883dbb86bc05	1	Your Organisation	uk	finance	90	CRITICAL	6	Global Threat Radar scan complete for Your Organisation (Finance sector, UK region). Risk score: 90/100. Severity: CRITICAL. 6 active threat actor(s) identified.	2026-04-22 03:37:22.641481	{"sector_note": "Financial sector faces elevated threat from ransomware, BEC fraud, and nation-state espionage targeting SWIFT systems and trading platforms.", "region_note": "UK organisations face elevated threats from Russian APT groups, ransomware affiliates and state-sponsored espionage. NCSC advisories should be monitored regularly."}
\.


--
-- Data for Name: threat_radar_threats; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.threat_radar_threats (id, report_id, threat_type, actor, severity, confidence, description, mitigation, mitre_tactic, node_meta, created_at) FROM stdin;
8937d087-2e97-44dc-ba0b-9a87c636a454	089c9ecc-20a0-44e6-8acc-883dbb86bc05	RANSOMWARE	LockBit 3.0	CRITICAL	HIGH	Most prolific ransomware group globally. Targets all sectors with double-extortion tactics. Uses affiliate model.	Implement offline backups, network segmentation, EDR, and patch management. Block known LockBit IOCs.	Impact — T1486 Data Encrypted for Impact	{}	2026-04-22 03:37:22.646496
a7a38f28-6e2e-4cc0-a5cb-56778165022d	089c9ecc-20a0-44e6-8acc-883dbb86bc05	RANSOMWARE	BlackCat (ALPHV)	CRITICAL	HIGH	Sophisticated ransomware-as-a-service group. Uses Rust-based malware. Targets critical infrastructure.	Deploy EDR with behavioural detection. Enforce MFA. Monitor for lateral movement and credential dumping.	Impact — T1486 Data Encrypted for Impact	{}	2026-04-22 03:37:22.646509
1c49a7ca-5438-4287-97d9-146d91dc48a9	089c9ecc-20a0-44e6-8acc-883dbb86bc05	APT	APT29 (Cozy Bear)	CRITICAL	HIGH	Russian SVR intelligence group. Targets government, defence, healthcare. Known for supply chain attacks (SolarWinds).	Implement Zero Trust architecture. Monitor privileged access. Deploy UEBA and threat hunting capability.	Collection — T1213 Data from Information Repositories	{}	2026-04-22 03:37:22.646514
2e59a04d-4a49-443c-aacb-e7fda3dd9a8b	089c9ecc-20a0-44e6-8acc-883dbb86bc05	APT	APT41 (Winnti)	CRITICAL	HIGH	Chinese state-sponsored group conducting espionage and financially motivated attacks simultaneously.	Patch internet-facing applications urgently. Monitor for web shells and living-off-the-land techniques.	Initial Access — T1190 Exploit Public-Facing Application	{}	2026-04-22 03:37:22.646518
58a8af25-b3bd-47fb-8c3e-2d7dcac4aecc	089c9ecc-20a0-44e6-8acc-883dbb86bc05	CYBERCRIMINAL	FIN7	HIGH	HIGH	Financially motivated group targeting retail, hospitality and finance. Uses sophisticated phishing and POS malware.	Deploy email security with sandboxing. Implement POS security controls and network segmentation.	Initial Access — T1566 Phishing	{}	2026-04-22 03:37:22.646522
4789beee-90e8-4d2d-936a-532f6b4fdfce	089c9ecc-20a0-44e6-8acc-883dbb86bc05	CYBERCRIMINAL	TA505	HIGH	MEDIUM	Prolific cybercriminal group distributing banking trojans and ransomware via mass phishing campaigns.	Implement email filtering, employee phishing training, and endpoint protection with behaviour monitoring.	Initial Access — T1566.001 Spearphishing Attachment	{}	2026-04-22 03:37:22.646526
\.


--
-- Data for Name: timeline_events; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.timeline_events (id, source, event_type, severity, title, detail, entity, mitre_id, user_id, resolved, created_at) FROM stdin;
1	siem	critical_alert	Critical	Ransomware C2 communication detected on 192.168.1.45	SIEM rule triggered: outbound connection to known ransomware C2 server	192.168.1.45	\N	\N	f	2026-04-17 15:05:02.463759
2	redteam	redteam_finding	Critical	[RED TEAM] Default credentials succeeded on PLC Controller	Valid Accounts attack succeeded — admin:admin credentials accepted	10.0.1.10	T1078	\N	f	2026-04-17 14:05:02.463759
3	finding	new_finding	Critical	CVE-2024-1234 — Remote Code Execution on IP Camera	CVSS 9.8 — Unauthenticated RCE via exposed management interface	192.168.1.22	\N	\N	f	2026-04-17 13:05:02.463759
4	zerotrust	policy_violation	High	Zero-Trust policy violated — SCADA accessed from guest network	Device 192.168.2.10 attempted lateral movement across network boundary	192.168.2.10	\N	\N	f	2026-04-17 12:05:02.463759
5	watch	anomaly	High	Anomalous traffic spike on IoT Gateway — 400% above baseline	Device generating 4x normal traffic volume — possible data exfiltration	192.168.1.5	\N	\N	f	2026-04-17 11:05:02.463759
6	predict	prediction	High	Predicted: Water Treatment Controller at high compromise risk	ML model predicts 87% probability of compromise within 72 hours	10.0.2.20	\N	\N	f	2026-04-17 10:05:02.463759
7	scan	scan_complete	Medium	Scan completed — 13 findings on 3 devices	Full network scan: 3 critical, 3 high, 2 medium, 5 low	192.168.1.0/24	\N	\N	f	2026-04-17 08:05:02.463759
8	compliance	compliance_check	Medium	NIS2 compliance score dropped to 67%	3 new non-compliant controls detected after latest scan	NIS2 Framework	\N	\N	f	2026-04-17 06:05:02.463759
9	defense	playbook_triggered	Medium	Autonomous Defense: Isolation playbook triggered	Device 192.168.1.45 automatically isolated after C2 detection	192.168.1.45	\N	\N	f	2026-04-17 14:35:02.463759
10	user	login	Info	User logged in from new location	Login from IP 82.45.123.67 — United Kingdom	user@aipet.io	\N	\N	f	2026-04-17 04:05:02.463759
11	marketplace	plugin_installed	Info	Plugin installed: Microsoft Teams Alerts	Plugin activated and configured for security notifications	ms-teams-alerts	\N	\N	f	2026-04-16 16:05:02.463759
12	siem	rule_triggered	High	SIEM: Brute force attack detected on SSH port	150 failed login attempts from 45.89.123.45 in 60 seconds	192.168.1.1	\N	\N	f	2026-04-16 14:05:02.463759
13	redteam	campaign_complete	Info	Red Team campaign completed — Defence score: 33/100	OT/ICS Protocol Attack Simulation completed. 5 techniques succeeded.	OT Network	\N	\N	f	2026-04-15 16:05:02.463759
14	finding	resolved	Info	Finding resolved: CVE-2023-4567 patched on Router	Firmware updated to v3.2.1 — vulnerability remediated	192.168.1.1	\N	\N	t	2026-04-15 13:05:02.463759
15	compliance	audit	Info	ISO 27001 audit report generated	Annual compliance report generated — 78% overall compliance	ISO 27001	\N	\N	f	2026-04-14 16:05:02.463759
16	scan	scan_started	Info	Scheduled scan started on OT network	Weekly automated scan of industrial control systems	10.0.1.0/24	\N	\N	f	2026-04-14 15:05:02.463759
17	zerotrust	trust_update	Medium	Device trust score updated — Corporate Firewall: 15→45	Firmware patched — trust score improved after remediation	Corporate Firewall	\N	\N	f	2026-04-13 16:05:02.463759
18	siem	incident_created	Critical	SIEM Incident created: Possible ransomware spread	Multiple devices showing encrypted file activity simultaneously	Multiple	\N	\N	f	2026-04-12 16:05:02.463759
19	user	api_key_created	Info	New API key generated	API key created for CI/CD integration	user@aipet.io	\N	\N	f	2026-04-11 16:05:02.463759
20	predict	alert_cleared	Info	Predict alert cleared — IP Camera no longer at risk	Risk probability dropped below threshold after patch applied	192.168.1.22	\N	\N	t	2026-04-10 16:05:02.463759
\.


--
-- Data for Name: twin_edges; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.twin_edges (id, source_id, target_id, edge_type, protocol, port, encrypted, bandwidth, latency_ms, active, created_at) FROM stdin;
1	1	2	management	HTTPS	443	t	1Gbps	2	t	2026-04-16 20:05:11.656944
2	1	3	data_flow	HTTPS	443	t	1Gbps	1	t	2026-04-16 20:05:11.656949
3	2	4	control	MQTT	1883	f	100Mbps	5	t	2026-04-16 20:05:11.65695
4	2	5	management	HTTPS	443	t	100Mbps	3	t	2026-04-16 20:05:11.65695
5	5	6	control	Modbus	502	f	10Mbps	10	t	2026-04-16 20:05:11.656951
6	5	10	control	DNP3	20000	f	1Mbps	20	t	2026-04-16 20:05:11.656951
7	4	7	data_flow	MQTT	1883	f	1Mbps	15	t	2026-04-16 20:05:11.656951
8	4	8	data_flow	MQTT	1883	f	1Mbps	15	t	2026-04-16 20:05:11.656952
9	6	10	dependency	Modbus	502	f	1Mbps	5	t	2026-04-16 20:05:11.656952
10	3	9	management	HTTP	80	f	10Mbps	8	t	2026-04-16 20:05:11.656953
\.


--
-- Data for Name: twin_nodes; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.twin_nodes (id, name, node_type, ip_address, mac_address, vendor, firmware, location, zone, expected_state, actual_state, diverged, risk_score, online, x_pos, y_pos, created_at, updated_at) FROM stdin;
1	Corporate Firewall	router	10.0.0.1	\N	Palo Alto Networks	10.2.4	Server Room — Rack 1	enterprise	{"risk_level": "Low", "findings": []}	{"risk_level": "Low", "findings": []}	f	15	t	400	60	2026-04-16 20:05:11.636141	2026-04-16 20:05:11.636145
6	PLC Controller	plc	10.0.1.10	\N	Schneider Electric	2.60	Production Floor	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Critical", "findings": ["modbus_unauthenticated"]}	t	90	t	150	400	2026-04-16 20:05:11.63615	2026-04-16 20:05:11.636151
7	Temperature Sensor A	sensor	10.0.2.10	\N	Honeywell	3.1.2	Production Floor — Zone A	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Low", "findings": []}	f	10	t	100	500	2026-04-16 20:05:11.636151	2026-04-16 20:05:11.636151
8	Pressure Sensor B	sensor	10.0.2.11	\N	Emerson	2.8.0	Production Floor — Zone B	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Low", "findings": []}	f	8	t	250	500	2026-04-16 20:05:11.636152	2026-04-16 20:05:11.636152
9	IP Camera	camera	10.0.3.10	\N	Hikvision	V5.5.800	Production Floor — Entry	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Medium", "findings": ["weak_password"]}	t	45	t	600	400	2026-04-16 20:05:11.636152	2026-04-16 20:05:11.636153
10	Water Treatment RTU	actuator	10.0.1.11	\N	ABB	11.7.3	Water Treatment Plant	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Critical", "findings": ["dnp3_no_auth"]}	t	88	t	350	500	2026-04-16 20:05:11.636153	2026-04-16 20:05:11.636153
5	IoT Gateway	gateway	192.168.1.4	\N	Cisco	IOS 15.2	IoT Gateway Room	operations	{"risk_level": "Low", "findings": []}	{"ip": "192.168.1.4", "findings": [{"severity": "Medium", "attack": "no_firewall"}], "risk_level": "Medium", "last_seen": "2026-04-16 19:11:11.295367+00:00"}	t	8	t	400	280	2026-04-16 20:05:11.63615	2026-04-16 20:11:11.295367
4	MQTT Broker	hub	192.168.1.3	\N	Eclipse Mosquitto	2.0.15	IoT Gateway Room	operations	{"risk_level": "Low", "findings": []}	{"ip": "192.168.1.3", "findings": [{"severity": "High", "attack": "unencrypted_mqtt"}], "risk_level": "High", "last_seen": "2026-04-16 19:11:11.295367+00:00"}	t	15	t	200	280	2026-04-16 20:05:11.636149	2026-04-16 20:11:11.295367
2	SCADA Server	server	192.168.1.1	\N	Wonderware	2021.1	Control Room	supervisory	{"risk_level": "Medium", "findings": []}	{"ip": "192.168.1.1", "findings": [{"severity": "Critical", "attack": "open_telnet"}, {"severity": "Critical", "attack": "open_telnet"}], "risk_level": "Critical", "last_seen": "2026-04-16 19:11:11.295367+00:00"}	t	50	t	250	160	2026-04-16 20:05:11.636146	2026-04-16 20:11:11.295367
3	Customer Data Server	server	192.168.1.2	\N	Dell EMC	iDRAC 5.0	Server Room — Rack 2	enterprise	{"risk_level": "Low", "findings": []}	{"ip": "192.168.1.2", "findings": [{"severity": "Critical", "attack": "default_credentials"}], "risk_level": "Critical", "last_seen": "2026-04-16 19:11:11.295367+00:00"}	t	25	t	550	160	2026-04-16 20:05:11.636148	2026-04-16 20:11:11.295367
\.


--
-- Data for Name: twin_snapshots; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.twin_snapshots (id, label, snapshot_type, node_count, edge_count, diverged_count, risk_avg, data, created_by, created_at) FROM stdin;
1	Initial twin state — baseline	auto	10	10	7	53.1	\N	\N	2026-04-16 20:05:11.665688
2	Pre-simulation: PLC Controller	pre_simulation	10	10	7	53.1	\N	1	2026-04-16 20:09:08.582582
3	Pre-simulation: SCADA Server	pre_simulation	10	10	7	53.1	\N	1	2026-04-16 20:10:28.895686
4	Manual snapshot — 16/04/2026, 20:11:01	manual	10	10	7	53.1	[{"id": 1, "name": "Corporate Firewall", "node_type": "router", "ip_address": "10.0.0.1", "mac_address": null, "vendor": "Palo Alto Networks", "firmware": "10.2.4", "location": "Server Room \\u2014 Rack 1", "zone": "enterprise", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "diverged": false, "risk_score": 15, "online": true, "x_pos": 400.0, "y_pos": 60.0, "updated_at": "2026-04-16 20:05:11.636145"}, {"id": 2, "name": "SCADA Server", "node_type": "server", "ip_address": "192.168.1.1", "mac_address": null, "vendor": "Wonderware", "firmware": "2021.1", "location": "Control Room", "zone": "supervisory", "expected_state": "{\\"risk_level\\": \\"Medium\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Critical\\", \\"findings\\": [\\"open_telnet\\"]}", "diverged": true, "risk_score": 75, "online": true, "x_pos": 250.0, "y_pos": 160.0, "updated_at": "2026-04-16 20:05:11.636147"}, {"id": 3, "name": "Customer Data Server", "node_type": "server", "ip_address": "192.168.1.2", "mac_address": null, "vendor": "Dell EMC", "firmware": "iDRAC 5.0", "location": "Server Room \\u2014 Rack 2", "zone": "enterprise", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Critical\\", \\"findings\\": [\\"default_credentials\\"]}", "diverged": true, "risk_score": 85, "online": true, "x_pos": 550.0, "y_pos": 160.0, "updated_at": "2026-04-16 20:05:11.636148"}, {"id": 4, "name": "MQTT Broker", "node_type": "hub", "ip_address": "192.168.1.3", "mac_address": null, "vendor": "Eclipse Mosquitto", "firmware": "2.0.15", "location": "IoT Gateway Room", "zone": "operations", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"High\\", \\"findings\\": [\\"unencrypted_mqtt\\"]}", "diverged": true, "risk_score": 60, "online": true, "x_pos": 200.0, "y_pos": 280.0, "updated_at": "2026-04-16 20:05:11.636149"}, {"id": 5, "name": "IoT Gateway", "node_type": "gateway", "ip_address": "192.168.1.4", "mac_address": null, "vendor": "Cisco", "firmware": "IOS 15.2", "location": "IoT Gateway Room", "zone": "operations", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"High\\", \\"findings\\": [\\"missing_firewall\\"]}", "diverged": true, "risk_score": 55, "online": true, "x_pos": 400.0, "y_pos": 280.0, "updated_at": "2026-04-16 20:05:11.636150"}, {"id": 6, "name": "PLC Controller", "node_type": "plc", "ip_address": "10.0.1.10", "mac_address": null, "vendor": "Schneider Electric", "firmware": "2.60", "location": "Production Floor", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Critical\\", \\"findings\\": [\\"modbus_unauthenticated\\"]}", "diverged": true, "risk_score": 90, "online": true, "x_pos": 150.0, "y_pos": 400.0, "updated_at": "2026-04-16 20:05:11.636151"}, {"id": 7, "name": "Temperature Sensor A", "node_type": "sensor", "ip_address": "10.0.2.10", "mac_address": null, "vendor": "Honeywell", "firmware": "3.1.2", "location": "Production Floor \\u2014 Zone A", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "diverged": false, "risk_score": 10, "online": true, "x_pos": 100.0, "y_pos": 500.0, "updated_at": "2026-04-16 20:05:11.636151"}, {"id": 8, "name": "Pressure Sensor B", "node_type": "sensor", "ip_address": "10.0.2.11", "mac_address": null, "vendor": "Emerson", "firmware": "2.8.0", "location": "Production Floor \\u2014 Zone B", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "diverged": false, "risk_score": 8, "online": true, "x_pos": 250.0, "y_pos": 500.0, "updated_at": "2026-04-16 20:05:11.636152"}, {"id": 9, "name": "IP Camera", "node_type": "camera", "ip_address": "10.0.3.10", "mac_address": null, "vendor": "Hikvision", "firmware": "V5.5.800", "location": "Production Floor \\u2014 Entry", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Medium\\", \\"findings\\": [\\"weak_password\\"]}", "diverged": true, "risk_score": 45, "online": true, "x_pos": 600.0, "y_pos": 400.0, "updated_at": "2026-04-16 20:05:11.636153"}, {"id": 10, "name": "Water Treatment RTU", "node_type": "actuator", "ip_address": "10.0.1.11", "mac_address": null, "vendor": "ABB", "firmware": "11.7.3", "location": "Water Treatment Plant", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Critical\\", \\"findings\\": [\\"dnp3_no_auth\\"]}", "diverged": true, "risk_score": 88, "online": true, "x_pos": 350.0, "y_pos": 500.0, "updated_at": "2026-04-16 20:05:11.636153"}]	1	2026-04-16 20:11:01.845502
5	Pre-simulation: Customer Data Server	pre_simulation	10	10	7	35.4	\N	1	2026-04-17 22:08:40.691794
6	Pre-simulation: Water Treatment RTU	pre_simulation	10	10	7	35.4	\N	1	2026-04-17 22:09:18.232783
7	Pre-simulation: Pressure Sensor B	pre_simulation	10	10	7	35.4	\N	1	2026-04-17 22:09:28.003989
8	Pre-simulation: Temperature Sensor A	pre_simulation	10	10	7	35.4	\N	1	2026-04-17 22:09:36.495919
9	Pre-simulation: PLC Controller	pre_simulation	10	10	7	35.4	\N	1	2026-04-17 22:09:44.805457
10	Pre-simulation: Customer Data Server	pre_simulation	10	10	7	35.4	\N	1	2026-04-19 17:23:07.790486
11	Pre-simulation: IP Camera	pre_simulation	10	10	7	35.4	\N	1	2026-04-21 23:47:29.314397
12	Pre-simulation: Customer Data Server	pre_simulation	10	10	7	35.4	\N	1	2026-04-21 23:47:39.124392
13	Pre-simulation: Corporate Firewall	pre_simulation	10	10	7	35.4	\N	1	2026-04-21 23:47:48.435817
14	Pre-simulation: Water Treatment RTU	pre_simulation	10	10	7	35.4	\N	1	2026-04-21 23:47:56.942839
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assigned_at) FROM stdin;
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.user_settings (id, user_id, slack_webhook_url, teams_webhook_url, notify_critical, notify_high, notify_cve, created_at, updated_at, siem_webhook_url) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.users (id, email, password_hash, name, plan, scans_used, scans_limit, created_at, last_login, is_active, stripe_customer_id, stripe_subscription_id, plan_expires_at) FROM stdin;
1	test@aipet.io	$2b$12$wgEcI9DJXURKO0Dwhk8mLekA0BCcRS4FpDRLLGoC0lsZ4ZDJ6ZY12	Test User	enterprise	20	999999	2026-03-29 23:20:50.618499	2026-04-23 01:20:50.050332	t	cus_UEwnvwFwOEvO5Z	sub_1TGT75EOqz4Ugi362qNaY7M5	2026-04-30 00:51:27
2	byallew@gmail.com	$2b$12$R7I6t4d7rKteJLRdDacon.fZHwdEDbGKO3RRWQqpFKJD39dAVAjBi	Binyam Yallew	free	5	5	2026-04-05 05:43:49.663051	\N	t	\N	\N	\N
\.


--
-- Data for Name: watch_alerts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.watch_alerts (id, user_id, device_ip, alert_type, severity, description, details, is_acknowledged, created_at) FROM stdin;
\.


--
-- Data for Name: watch_baselines; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.watch_baselines (id, user_id, device_ip, device_function, baseline_data, first_seen, last_seen, is_active, created_at) FROM stdin;
1	1	192.168.1.1	Infrastructure / Network	{"status": "monitored", "device_ip": "192.168.1.1", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 25, "attack_types": ["open_telnet"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Critical", "device_function": "Infrastructure / Network", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 0, "Critical": 1}}	2026-04-04 07:53:27.112634	2026-04-04 23:37:54.727022	t	2026-04-04 07:53:27.112639
2	1	192.168.1.2	Customer Data	{"status": "monitored", "device_ip": "192.168.1.2", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 25, "attack_types": ["default_credentials"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Critical", "device_function": "Customer Data", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 0, "Critical": 1}}	2026-04-04 07:53:27.114672	2026-04-04 23:37:54.730338	t	2026-04-04 07:53:27.114675
3	1	192.168.1.3	Operations / Manufacturing	{"status": "monitored", "device_ip": "192.168.1.3", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["mqtt"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 15, "attack_types": ["unencrypted_mqtt"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "High", "device_function": "Operations / Manufacturing", "severity_profile": {"Low": 0, "High": 1, "Info": 0, "Medium": 0, "Critical": 0}}	2026-04-04 07:53:27.116038	2026-04-04 23:37:54.731253	t	2026-04-04 07:53:27.116041
4	1	192.168.1.4	General IT	{"status": "monitored", "device_ip": "192.168.1.4", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 8, "attack_types": ["no_firewall"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Medium", "device_function": "General IT", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 1, "Critical": 0}}	2026-04-04 07:53:27.117355	2026-04-04 23:37:54.732501	t	2026-04-04 07:53:27.117358
\.


--
-- Data for Name: zt_access_log; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.zt_access_log (id, source_ip, dest_ip, port, protocol, action, policy_id, policy_name, reason, trust_score, created_at) FROM stdin;
1	192.168.1.1	8.8.8.8	53	udp	block	\N	Block quarantined devices — all traffic	Device quarantined (trust score: 30)	30	2026-04-16 15:51:14.242514
2	192.168.1.2	203.0.113.10	443	tcp	alert	\N	Restrict customer data server — no external access	Matched policy: Restrict customer data server	45	2026-04-16 15:44:14.242514
3	192.168.1.3	192.168.1.0	1883	tcp	allow	\N	Allow MQTT broker — internal only	Matched policy: Allow MQTT broker	72	2026-04-16 15:36:14.242514
4	192.168.1.4	192.168.1.1	23	tcp	block	\N	Block Telnet — all devices	Matched policy: Block Telnet — all devices	62	2026-04-16 15:21:14.242514
5	192.168.0.5	192.168.1.3	22	tcp	allow	\N	Allow management traffic — admin subnet	Matched policy: Allow management traffic	100	2026-04-16 14:56:14.242514
6	192.168.1.1	8.8.8.8	53	any	block	\N	Quarantine Override	Device quarantined (trust score: 30)	30	2026-04-16 16:00:58.627409
\.


--
-- Data for Name: zt_device_trust; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.zt_device_trust (id, device_ip, device_name, trust_score, status, risk_factors, last_scan_id, last_assessed, created_at, updated_at) FROM stdin;
4	192.168.1.4	IoT Gateway	92	trusted	["1 Medium finding(s) \\u2014 -8 pts"]	\N	2026-04-21 23:17:38.251846	2026-04-16 15:56:14.230469	2026-04-21 23:17:38.251846
3	192.168.1.3	MQTT Broker	85	monitored	["1 High finding(s) \\u2014 -15 pts"]	\N	2026-04-21 23:17:38.251846	2026-04-16 15:56:14.230468	2026-04-21 23:17:38.251846
1	192.168.1.1	Network Gateway	50	restricted	["2 Critical finding(s) \\u2014 -50 pts"]	\N	2026-04-21 23:17:38.251846	2026-04-16 15:56:14.230463	2026-04-21 23:17:38.251846
2	192.168.1.2	Customer Data Server	75	monitored	["1 Critical finding(s) \\u2014 -25 pts"]	\N	2026-04-21 23:17:38.251846	2026-04-16 15:56:14.230467	2026-04-21 23:17:38.251846
5	manual	\N	0	quarantined	["Auto-quarantined: Manual trigger of playbook: Respond to brute force attacks"]	\N	2026-04-21 23:19:03.317606	2026-04-21 23:19:03.317761	2026-04-21 23:19:03.317763
\.


--
-- Data for Name: zt_policies; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.zt_policies (id, name, description, source, destination, port, protocol, action, priority, enabled, hit_count, created_by, created_at) FROM stdin;
2	Restrict customer data server — no external access	Customer data server may only communicate with internal management subnet	192.168.1.2	*	*	any	alert	10	t	0	\N	2026-04-16 15:56:14.236932
3	Allow MQTT broker — internal only	MQTT broker allowed to communicate on port 1883 internally	192.168.1.3	192.168.1.0	1883	tcp	allow	20	t	0	\N	2026-04-16 15:56:14.236933
4	Block Telnet — all devices	Telnet (port 23) is blocked on all devices — unencrypted protocol	*	*	23	tcp	block	5	t	0	\N	2026-04-16 15:56:14.236933
5	Allow management traffic — admin subnet	All devices allow SSH from management subnet 192.168.0.0	192.168.0.0	*	22	tcp	allow	15	t	0	\N	2026-04-16 15:56:14.236933
\.


--
-- Name: ap_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ap_analyses_id_seq', 3, true);


--
-- Name: ap_paths_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ap_paths_id_seq', 15, true);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 5, true);


--
-- Name: as_endpoints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.as_endpoints_id_seq', 15, true);


--
-- Name: as_findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.as_findings_id_seq', 25, true);


--
-- Name: as_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.as_scans_id_seq', 1, true);


--
-- Name: ba_anomalies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ba_anomalies_id_seq', 17, true);


--
-- Name: ba_baselines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ba_baselines_id_seq', 8, true);


--
-- Name: ba_patterns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ba_patterns_id_seq', 504, true);


--
-- Name: ca_assessments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ca_assessments_id_seq', 25, true);


--
-- Name: ca_controls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ca_controls_id_seq', 68, true);


--
-- Name: ca_frameworks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ca_frameworks_id_seq', 4, true);


--
-- Name: cloud_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.cloud_accounts_id_seq', 4, true);


--
-- Name: cloud_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.cloud_assets_id_seq', 24, true);


--
-- Name: cloud_findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.cloud_findings_id_seq', 14, true);


--
-- Name: compliance_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.compliance_results_id_seq', 12, true);


--
-- Name: cs_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.cs_recommendations_id_seq', 10, true);


--
-- Name: cs_resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.cs_resources_id_seq', 12, true);


--
-- Name: dd_baselines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.dd_baselines_id_seq', 10, true);


--
-- Name: dd_drifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.dd_drifts_id_seq', 12, true);


--
-- Name: dd_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.dd_scans_id_seq', 2, true);


--
-- Name: defense_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.defense_actions_id_seq', 11, true);


--
-- Name: defense_playbooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.defense_playbooks_id_seq', 5, true);


--
-- Name: device_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.device_tags_id_seq', 4, true);


--
-- Name: dspm_datastores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.dspm_datastores_id_seq', 10, true);


--
-- Name: dspm_findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.dspm_findings_id_seq', 14, true);


--
-- Name: dspm_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.dspm_scans_id_seq', 1, true);


--
-- Name: explain_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.explain_results_id_seq', 48, true);


--
-- Name: findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.findings_id_seq', 5, true);


--
-- Name: ig_edges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ig_edges_id_seq', 11, true);


--
-- Name: ig_identities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ig_identities_id_seq', 12, true);


--
-- Name: ig_risks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ig_risks_id_seq', 6, true);


--
-- Name: ioc_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ioc_entries_id_seq', 8, true);


--
-- Name: ioc_feeds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ioc_feeds_id_seq', 2, true);


--
-- Name: ir_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ir_incidents_id_seq', 3, true);


--
-- Name: ir_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ir_tasks_id_seq', 24, true);


--
-- Name: mp_installs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.mp_installs_id_seq', 1, true);


--
-- Name: mp_plugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.mp_plugins_id_seq', 15, true);


--
-- Name: mp_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.mp_reviews_id_seq', 1, false);


--
-- Name: nv_edges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.nv_edges_id_seq', 20, true);


--
-- Name: nv_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.nv_issues_id_seq', 10, true);


--
-- Name: nv_nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.nv_nodes_id_seq', 20, true);


--
-- Name: ot_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ot_devices_id_seq', 6, true);


--
-- Name: ot_findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ot_findings_id_seq', 14, true);


--
-- Name: ot_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ot_scans_id_seq', 7, true);


--
-- Name: predict_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.predict_alerts_id_seq', 14, true);


--
-- Name: protocol_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.protocol_scans_id_seq', 8, true);


--
-- Name: re_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.re_assets_id_seq', 10, true);


--
-- Name: re_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.re_plans_id_seq', 4, true);


--
-- Name: re_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.re_tests_id_seq', 8, true);


--
-- Name: remediation_kb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.remediation_kb_id_seq', 30, true);


--
-- Name: risk_narratives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.risk_narratives_id_seq', 1, false);


--
-- Name: rt_attacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.rt_attacks_id_seq', 173, true);


--
-- Name: rt_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.rt_campaigns_id_seq', 3, true);


--
-- Name: sc_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.sc_components_id_seq', 15, true);


--
-- Name: sc_sboms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.sc_sboms_id_seq', 1, false);


--
-- Name: sc_vulns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.sc_vulns_id_seq', 12, true);


--
-- Name: scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.scans_id_seq', 26, true);


--
-- Name: score_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.score_results_id_seq', 7, true);


--
-- Name: siem_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.siem_events_id_seq', 102, true);


--
-- Name: siem_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.siem_incidents_id_seq', 5, true);


--
-- Name: siem_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.siem_rules_id_seq', 4, true);


--
-- Name: te_clusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.te_clusters_id_seq', 4, true);


--
-- Name: te_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.te_events_id_seq', 48, true);


--
-- Name: terminal_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.terminal_audit_log_id_seq', 15, true);


--
-- Name: terminal_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.terminal_sessions_id_seq', 1, false);


--
-- Name: threat_matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.threat_matches_id_seq', 2, true);


--
-- Name: timeline_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.timeline_events_id_seq', 20, true);


--
-- Name: twin_edges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.twin_edges_id_seq', 10, true);


--
-- Name: twin_nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.twin_nodes_id_seq', 10, true);


--
-- Name: twin_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.twin_snapshots_id_seq', 14, true);


--
-- Name: user_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.user_settings_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: watch_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.watch_alerts_id_seq', 1, false);


--
-- Name: watch_baselines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.watch_baselines_id_seq', 4, true);


--
-- Name: zt_access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.zt_access_log_id_seq', 6, true);


--
-- Name: zt_device_trust_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.zt_device_trust_id_seq', 5, true);


--
-- Name: zt_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.zt_policies_id_seq', 5, true);


--
-- Name: adversary_profiles adversary_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.adversary_profiles
    ADD CONSTRAINT adversary_profiles_pkey PRIMARY KEY (id);


--
-- Name: ap_analyses ap_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ap_analyses
    ADD CONSTRAINT ap_analyses_pkey PRIMARY KEY (id);


--
-- Name: ap_paths ap_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ap_paths
    ADD CONSTRAINT ap_paths_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: apm_reports apm_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.apm_reports
    ADD CONSTRAINT apm_reports_pkey PRIMARY KEY (id);


--
-- Name: arch_builder_components arch_builder_components_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.arch_builder_components
    ADD CONSTRAINT arch_builder_components_pkey PRIMARY KEY (id);


--
-- Name: arch_builder_designs arch_builder_designs_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.arch_builder_designs
    ADD CONSTRAINT arch_builder_designs_pkey PRIMARY KEY (id);


--
-- Name: as_endpoints as_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.as_endpoints
    ADD CONSTRAINT as_endpoints_pkey PRIMARY KEY (id);


--
-- Name: as_findings as_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.as_findings
    ADD CONSTRAINT as_findings_pkey PRIMARY KEY (id);


--
-- Name: as_scans as_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.as_scans
    ADD CONSTRAINT as_scans_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: ba_anomalies ba_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ba_anomalies
    ADD CONSTRAINT ba_anomalies_pkey PRIMARY KEY (id);


--
-- Name: ba_baselines ba_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ba_baselines
    ADD CONSTRAINT ba_baselines_pkey PRIMARY KEY (id);


--
-- Name: ba_patterns ba_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ba_patterns
    ADD CONSTRAINT ba_patterns_pkey PRIMARY KEY (id);


--
-- Name: ca_assessments ca_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ca_assessments
    ADD CONSTRAINT ca_assessments_pkey PRIMARY KEY (id);


--
-- Name: ca_controls ca_controls_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ca_controls
    ADD CONSTRAINT ca_controls_pkey PRIMARY KEY (id);


--
-- Name: ca_frameworks ca_frameworks_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ca_frameworks
    ADD CONSTRAINT ca_frameworks_pkey PRIMARY KEY (id);


--
-- Name: cloud_accounts cloud_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_accounts
    ADD CONSTRAINT cloud_accounts_pkey PRIMARY KEY (id);


--
-- Name: cloud_assets cloud_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_assets
    ADD CONSTRAINT cloud_assets_pkey PRIMARY KEY (id);


--
-- Name: cloud_dashboard_snapshots cloud_dashboard_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_dashboard_snapshots
    ADD CONSTRAINT cloud_dashboard_snapshots_pkey PRIMARY KEY (id);


--
-- Name: cloud_findings cloud_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_findings
    ADD CONSTRAINT cloud_findings_pkey PRIMARY KEY (id);


--
-- Name: cloud_hardener_findings cloud_hardener_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_hardener_findings
    ADD CONSTRAINT cloud_hardener_findings_pkey PRIMARY KEY (id);


--
-- Name: cloud_hardener_scans cloud_hardener_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_hardener_scans
    ADD CONSTRAINT cloud_hardener_scans_pkey PRIMARY KEY (id);


--
-- Name: cloud_runtime_findings cloud_runtime_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_runtime_findings
    ADD CONSTRAINT cloud_runtime_findings_pkey PRIMARY KEY (id);


--
-- Name: cloud_runtime_scans cloud_runtime_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_runtime_scans
    ADD CONSTRAINT cloud_runtime_scans_pkey PRIMARY KEY (id);


--
-- Name: code_findings code_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.code_findings
    ADD CONSTRAINT code_findings_pkey PRIMARY KEY (id);


--
-- Name: code_sbom code_sbom_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.code_sbom
    ADD CONSTRAINT code_sbom_pkey PRIMARY KEY (id);


--
-- Name: code_scans code_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.code_scans
    ADD CONSTRAINT code_scans_pkey PRIMARY KEY (id);


--
-- Name: compliance_assessments compliance_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_assessments
    ADD CONSTRAINT compliance_assessments_pkey PRIMARY KEY (id);


--
-- Name: compliance_fabric_controls compliance_fabric_controls_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_fabric_controls
    ADD CONSTRAINT compliance_fabric_controls_pkey PRIMARY KEY (id);


--
-- Name: compliance_fabric_reports compliance_fabric_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_fabric_reports
    ADD CONSTRAINT compliance_fabric_reports_pkey PRIMARY KEY (id);


--
-- Name: compliance_results compliance_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_pkey PRIMARY KEY (id);


--
-- Name: cs_recommendations cs_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cs_recommendations
    ADD CONSTRAINT cs_recommendations_pkey PRIMARY KEY (id);


--
-- Name: cs_resources cs_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cs_resources
    ADD CONSTRAINT cs_resources_pkey PRIMARY KEY (id);


--
-- Name: dd_baselines dd_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dd_baselines
    ADD CONSTRAINT dd_baselines_pkey PRIMARY KEY (id);


--
-- Name: dd_drifts dd_drifts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dd_drifts
    ADD CONSTRAINT dd_drifts_pkey PRIMARY KEY (id);


--
-- Name: dd_scans dd_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dd_scans
    ADD CONSTRAINT dd_scans_pkey PRIMARY KEY (id);


--
-- Name: defense_actions defense_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_actions
    ADD CONSTRAINT defense_actions_pkey PRIMARY KEY (id);


--
-- Name: defense_mesh_pillars defense_mesh_pillars_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_mesh_pillars
    ADD CONSTRAINT defense_mesh_pillars_pkey PRIMARY KEY (id);


--
-- Name: defense_mesh_recommendations defense_mesh_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_mesh_recommendations
    ADD CONSTRAINT defense_mesh_recommendations_pkey PRIMARY KEY (id);


--
-- Name: defense_mesh_reports defense_mesh_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_mesh_reports
    ADD CONSTRAINT defense_mesh_reports_pkey PRIMARY KEY (id);


--
-- Name: defense_playbooks defense_playbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_playbooks
    ADD CONSTRAINT defense_playbooks_pkey PRIMARY KEY (id);


--
-- Name: device_tags device_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_pkey PRIMARY KEY (id);


--
-- Name: device_tags device_tags_user_id_device_ip_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_user_id_device_ip_key UNIQUE (user_id, device_ip);


--
-- Name: digital_twin_v2_anomalies digital_twin_v2_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.digital_twin_v2_anomalies
    ADD CONSTRAINT digital_twin_v2_anomalies_pkey PRIMARY KEY (id);


--
-- Name: digital_twin_v2_devices digital_twin_v2_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.digital_twin_v2_devices
    ADD CONSTRAINT digital_twin_v2_devices_pkey PRIMARY KEY (id);


--
-- Name: digital_twin_v2_environments digital_twin_v2_environments_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.digital_twin_v2_environments
    ADD CONSTRAINT digital_twin_v2_environments_pkey PRIMARY KEY (id);


--
-- Name: dspm_datastores dspm_datastores_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dspm_datastores
    ADD CONSTRAINT dspm_datastores_pkey PRIMARY KEY (id);


--
-- Name: dspm_findings dspm_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dspm_findings
    ADD CONSTRAINT dspm_findings_pkey PRIMARY KEY (id);


--
-- Name: dspm_scans dspm_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dspm_scans
    ADD CONSTRAINT dspm_scans_pkey PRIMARY KEY (id);


--
-- Name: endpoint_findings endpoint_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.endpoint_findings
    ADD CONSTRAINT endpoint_findings_pkey PRIMARY KEY (id);


--
-- Name: endpoint_scans endpoint_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.endpoint_scans
    ADD CONSTRAINT endpoint_scans_pkey PRIMARY KEY (id);


--
-- Name: enterprise_reports enterprise_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.enterprise_reports
    ADD CONSTRAINT enterprise_reports_pkey PRIMARY KEY (id);


--
-- Name: explain_results explain_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_pkey PRIMARY KEY (id);


--
-- Name: findings findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_pkey PRIMARY KEY (id);


--
-- Name: forensic_artifacts forensic_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.forensic_artifacts
    ADD CONSTRAINT forensic_artifacts_pkey PRIMARY KEY (id);


--
-- Name: forensic_cases forensic_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.forensic_cases
    ADD CONSTRAINT forensic_cases_pkey PRIMARY KEY (id);


--
-- Name: forensic_timeline forensic_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.forensic_timeline
    ADD CONSTRAINT forensic_timeline_pkey PRIMARY KEY (id);


--
-- Name: iam_exposure_findings iam_exposure_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.iam_exposure_findings
    ADD CONSTRAINT iam_exposure_findings_pkey PRIMARY KEY (id);


--
-- Name: iam_exposure_scans iam_exposure_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.iam_exposure_scans
    ADD CONSTRAINT iam_exposure_scans_pkey PRIMARY KEY (id);


--
-- Name: identity_guardian_alerts identity_guardian_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.identity_guardian_alerts
    ADD CONSTRAINT identity_guardian_alerts_pkey PRIMARY KEY (id);


--
-- Name: identity_guardian_signals identity_guardian_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.identity_guardian_signals
    ADD CONSTRAINT identity_guardian_signals_pkey PRIMARY KEY (id);


--
-- Name: ig_edges ig_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_edges
    ADD CONSTRAINT ig_edges_pkey PRIMARY KEY (id);


--
-- Name: ig_identities ig_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_identities
    ADD CONSTRAINT ig_identities_pkey PRIMARY KEY (id);


--
-- Name: ig_risks ig_risks_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_risks
    ADD CONSTRAINT ig_risks_pkey PRIMARY KEY (id);


--
-- Name: ioc_entries ioc_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_entries
    ADD CONSTRAINT ioc_entries_pkey PRIMARY KEY (id);


--
-- Name: ioc_feeds ioc_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_feeds
    ADD CONSTRAINT ioc_feeds_pkey PRIMARY KEY (id);


--
-- Name: ir_incidents ir_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ir_incidents
    ADD CONSTRAINT ir_incidents_pkey PRIMARY KEY (id);


--
-- Name: ir_tasks ir_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ir_tasks
    ADD CONSTRAINT ir_tasks_pkey PRIMARY KEY (id);


--
-- Name: itdr_findings itdr_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.itdr_findings
    ADD CONSTRAINT itdr_findings_pkey PRIMARY KEY (id);


--
-- Name: itdr_scans itdr_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.itdr_scans
    ADD CONSTRAINT itdr_scans_pkey PRIMARY KEY (id);


--
-- Name: k8s_findings k8s_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.k8s_findings
    ADD CONSTRAINT k8s_findings_pkey PRIMARY KEY (id);


--
-- Name: k8s_scans k8s_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.k8s_scans
    ADD CONSTRAINT k8s_scans_pkey PRIMARY KEY (id);


--
-- Name: log_analysis_reports log_analysis_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.log_analysis_reports
    ADD CONSTRAINT log_analysis_reports_pkey PRIMARY KEY (id);


--
-- Name: metrics_reports metrics_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.metrics_reports
    ADD CONSTRAINT metrics_reports_pkey PRIMARY KEY (id);


--
-- Name: mp_installs mp_installs_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_installs
    ADD CONSTRAINT mp_installs_pkey PRIMARY KEY (id);


--
-- Name: mp_plugins mp_plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_plugins
    ADD CONSTRAINT mp_plugins_pkey PRIMARY KEY (id);


--
-- Name: mp_plugins mp_plugins_slug_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_plugins
    ADD CONSTRAINT mp_plugins_slug_key UNIQUE (slug);


--
-- Name: mp_reviews mp_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_reviews
    ADD CONSTRAINT mp_reviews_pkey PRIMARY KEY (id);


--
-- Name: multicloud_scale_reports multicloud_scale_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.multicloud_scale_reports
    ADD CONSTRAINT multicloud_scale_reports_pkey PRIMARY KEY (id);


--
-- Name: network_exposure_assets network_exposure_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.network_exposure_assets
    ADD CONSTRAINT network_exposure_assets_pkey PRIMARY KEY (id);


--
-- Name: network_exposure_paths network_exposure_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.network_exposure_paths
    ADD CONSTRAINT network_exposure_paths_pkey PRIMARY KEY (id);


--
-- Name: network_exposure_scans network_exposure_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.network_exposure_scans
    ADD CONSTRAINT network_exposure_scans_pkey PRIMARY KEY (id);


--
-- Name: nv_edges nv_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_edges
    ADD CONSTRAINT nv_edges_pkey PRIMARY KEY (id);


--
-- Name: nv_issues nv_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_issues
    ADD CONSTRAINT nv_issues_pkey PRIMARY KEY (id);


--
-- Name: nv_nodes nv_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_nodes
    ADD CONSTRAINT nv_nodes_pkey PRIMARY KEY (id);


--
-- Name: ot_devices ot_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_devices
    ADD CONSTRAINT ot_devices_pkey PRIMARY KEY (id);


--
-- Name: ot_findings ot_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_findings
    ADD CONSTRAINT ot_findings_pkey PRIMARY KEY (id);


--
-- Name: ot_scans ot_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_scans
    ADD CONSTRAINT ot_scans_pkey PRIMARY KEY (id);


--
-- Name: patch_brain_items patch_brain_items_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.patch_brain_items
    ADD CONSTRAINT patch_brain_items_pkey PRIMARY KEY (id);


--
-- Name: patch_brain_sessions patch_brain_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.patch_brain_sessions
    ADD CONSTRAINT patch_brain_sessions_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: policy_brain_policies policy_brain_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.policy_brain_policies
    ADD CONSTRAINT policy_brain_policies_pkey PRIMARY KEY (id);


--
-- Name: policy_brain_sections policy_brain_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.policy_brain_sections
    ADD CONSTRAINT policy_brain_sections_pkey PRIMARY KEY (id);


--
-- Name: predict_alerts predict_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts
    ADD CONSTRAINT predict_alerts_pkey PRIMARY KEY (id);


--
-- Name: protocol_scans protocol_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans
    ADD CONSTRAINT protocol_scans_pkey PRIMARY KEY (id);


--
-- Name: rbac_assessments rbac_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rbac_assessments
    ADD CONSTRAINT rbac_assessments_pkey PRIMARY KEY (id);


--
-- Name: rbac_roles rbac_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rbac_roles
    ADD CONSTRAINT rbac_roles_pkey PRIMARY KEY (id);


--
-- Name: re_assets re_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.re_assets
    ADD CONSTRAINT re_assets_pkey PRIMARY KEY (id);


--
-- Name: re_plans re_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.re_plans
    ADD CONSTRAINT re_plans_pkey PRIMARY KEY (id);


--
-- Name: re_tests re_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.re_tests
    ADD CONSTRAINT re_tests_pkey PRIMARY KEY (id);


--
-- Name: realtime_snapshots realtime_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.realtime_snapshots
    ADD CONSTRAINT realtime_snapshots_pkey PRIMARY KEY (id);


--
-- Name: remediation_kb remediation_kb_attack_type_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb
    ADD CONSTRAINT remediation_kb_attack_type_key UNIQUE (attack_type);


--
-- Name: remediation_kb remediation_kb_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb
    ADD CONSTRAINT remediation_kb_pkey PRIMARY KEY (id);


--
-- Name: risk_narratives risk_narratives_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.risk_narratives
    ADD CONSTRAINT risk_narratives_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: rt_attacks rt_attacks_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_attacks
    ADD CONSTRAINT rt_attacks_pkey PRIMARY KEY (id);


--
-- Name: rt_campaigns rt_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_campaigns
    ADD CONSTRAINT rt_campaigns_pkey PRIMARY KEY (id);


--
-- Name: runtime_protection_findings runtime_protection_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.runtime_protection_findings
    ADD CONSTRAINT runtime_protection_findings_pkey PRIMARY KEY (id);


--
-- Name: runtime_protection_scans runtime_protection_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.runtime_protection_scans
    ADD CONSTRAINT runtime_protection_scans_pkey PRIMARY KEY (id);


--
-- Name: sandbox_analyses sandbox_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sandbox_analyses
    ADD CONSTRAINT sandbox_analyses_pkey PRIMARY KEY (id);


--
-- Name: sandbox_findings sandbox_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sandbox_findings
    ADD CONSTRAINT sandbox_findings_pkey PRIMARY KEY (id);


--
-- Name: sc_components sc_components_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sc_components
    ADD CONSTRAINT sc_components_pkey PRIMARY KEY (id);


--
-- Name: sc_sboms sc_sboms_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sc_sboms
    ADD CONSTRAINT sc_sboms_pkey PRIMARY KEY (id);


--
-- Name: sc_vulns sc_vulns_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sc_vulns
    ADD CONSTRAINT sc_vulns_pkey PRIMARY KEY (id);


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- Name: score_results score_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_pkey PRIMARY KEY (id);


--
-- Name: siem_events siem_events_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_events
    ADD CONSTRAINT siem_events_pkey PRIMARY KEY (id);


--
-- Name: siem_incidents siem_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_incidents
    ADD CONSTRAINT siem_incidents_pkey PRIMARY KEY (id);


--
-- Name: siem_reports siem_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_reports
    ADD CONSTRAINT siem_reports_pkey PRIMARY KEY (id);


--
-- Name: siem_rules siem_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_rules
    ADD CONSTRAINT siem_rules_pkey PRIMARY KEY (id);


--
-- Name: soc_twin_actions soc_twin_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.soc_twin_actions
    ADD CONSTRAINT soc_twin_actions_pkey PRIMARY KEY (id);


--
-- Name: soc_twin_sessions soc_twin_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.soc_twin_sessions
    ADD CONSTRAINT soc_twin_sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: synthetic_checks synthetic_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.synthetic_checks
    ADD CONSTRAINT synthetic_checks_pkey PRIMARY KEY (id);


--
-- Name: te_clusters te_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.te_clusters
    ADD CONSTRAINT te_clusters_pkey PRIMARY KEY (id);


--
-- Name: te_events te_events_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.te_events
    ADD CONSTRAINT te_events_pkey PRIMARY KEY (id);


--
-- Name: tenant_assessments tenant_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.tenant_assessments
    ADD CONSTRAINT tenant_assessments_pkey PRIMARY KEY (id);


--
-- Name: terminal_audit_log terminal_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.terminal_audit_log
    ADD CONSTRAINT terminal_audit_log_pkey PRIMARY KEY (id);


--
-- Name: terminal_sessions terminal_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.terminal_sessions
    ADD CONSTRAINT terminal_sessions_pkey PRIMARY KEY (id);


--
-- Name: terminal_sessions terminal_sessions_session_key_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.terminal_sessions
    ADD CONSTRAINT terminal_sessions_session_key_key UNIQUE (session_key);


--
-- Name: threat_intel_feeds threat_intel_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_intel_feeds
    ADD CONSTRAINT threat_intel_feeds_pkey PRIMARY KEY (id);


--
-- Name: threat_intel_iocs threat_intel_iocs_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_intel_iocs
    ADD CONSTRAINT threat_intel_iocs_pkey PRIMARY KEY (id);


--
-- Name: threat_matches threat_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches
    ADD CONSTRAINT threat_matches_pkey PRIMARY KEY (id);


--
-- Name: threat_radar_reports threat_radar_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_radar_reports
    ADD CONSTRAINT threat_radar_reports_pkey PRIMARY KEY (id);


--
-- Name: threat_radar_threats threat_radar_threats_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_radar_threats
    ADD CONSTRAINT threat_radar_threats_pkey PRIMARY KEY (id);


--
-- Name: timeline_events timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT timeline_events_pkey PRIMARY KEY (id);


--
-- Name: twin_edges twin_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_edges
    ADD CONSTRAINT twin_edges_pkey PRIMARY KEY (id);


--
-- Name: twin_nodes twin_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_nodes
    ADD CONSTRAINT twin_nodes_pkey PRIMARY KEY (id);


--
-- Name: twin_snapshots twin_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_snapshots
    ADD CONSTRAINT twin_snapshots_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_key UNIQUE (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_stripe_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_key UNIQUE (stripe_customer_id);


--
-- Name: users users_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: watch_alerts watch_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts
    ADD CONSTRAINT watch_alerts_pkey PRIMARY KEY (id);


--
-- Name: watch_baselines watch_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_pkey PRIMARY KEY (id);


--
-- Name: watch_baselines watch_baselines_user_id_device_ip_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_user_id_device_ip_key UNIQUE (user_id, device_ip);


--
-- Name: zt_access_log zt_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_access_log
    ADD CONSTRAINT zt_access_log_pkey PRIMARY KEY (id);


--
-- Name: zt_device_trust zt_device_trust_device_ip_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_device_trust
    ADD CONSTRAINT zt_device_trust_device_ip_key UNIQUE (device_ip);


--
-- Name: zt_device_trust zt_device_trust_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_device_trust
    ADD CONSTRAINT zt_device_trust_pkey PRIMARY KEY (id);


--
-- Name: zt_policies zt_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_policies
    ADD CONSTRAINT zt_policies_pkey PRIMARY KEY (id);


--
-- Name: ix_findings_scan_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_findings_scan_id ON public.findings USING btree (scan_id);


--
-- Name: ix_scans_user_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_scans_user_id ON public.scans USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ap_analyses ap_analyses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ap_analyses
    ADD CONSTRAINT ap_analyses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: ap_paths ap_paths_analysis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ap_paths
    ADD CONSTRAINT ap_paths_analysis_id_fkey FOREIGN KEY (analysis_id) REFERENCES public.ap_analyses(id);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: arch_builder_components arch_builder_components_design_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.arch_builder_components
    ADD CONSTRAINT arch_builder_components_design_id_fkey FOREIGN KEY (design_id) REFERENCES public.arch_builder_designs(id);


--
-- Name: as_findings as_findings_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.as_findings
    ADD CONSTRAINT as_findings_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.as_endpoints(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ba_anomalies ba_anomalies_baseline_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ba_anomalies
    ADD CONSTRAINT ba_anomalies_baseline_id_fkey FOREIGN KEY (baseline_id) REFERENCES public.ba_baselines(id);


--
-- Name: ba_patterns ba_patterns_baseline_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ba_patterns
    ADD CONSTRAINT ba_patterns_baseline_id_fkey FOREIGN KEY (baseline_id) REFERENCES public.ba_baselines(id);


--
-- Name: ca_assessments ca_assessments_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ca_assessments
    ADD CONSTRAINT ca_assessments_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.ca_frameworks(id);


--
-- Name: ca_controls ca_controls_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ca_controls
    ADD CONSTRAINT ca_controls_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.ca_frameworks(id);


--
-- Name: cloud_accounts cloud_accounts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_accounts
    ADD CONSTRAINT cloud_accounts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: cloud_assets cloud_assets_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_assets
    ADD CONSTRAINT cloud_assets_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.cloud_accounts(id);


--
-- Name: cloud_findings cloud_findings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_findings
    ADD CONSTRAINT cloud_findings_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.cloud_accounts(id);


--
-- Name: cloud_findings cloud_findings_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_findings
    ADD CONSTRAINT cloud_findings_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.cloud_assets(id);


--
-- Name: cloud_hardener_findings cloud_hardener_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_hardener_findings
    ADD CONSTRAINT cloud_hardener_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.cloud_hardener_scans(id);


--
-- Name: cloud_runtime_findings cloud_runtime_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_runtime_findings
    ADD CONSTRAINT cloud_runtime_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.cloud_runtime_scans(id);


--
-- Name: code_findings code_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.code_findings
    ADD CONSTRAINT code_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.code_scans(id);


--
-- Name: code_sbom code_sbom_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.code_sbom
    ADD CONSTRAINT code_sbom_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.code_scans(id);


--
-- Name: code_scans code_scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.code_scans
    ADD CONSTRAINT code_scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: compliance_fabric_controls compliance_fabric_controls_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_fabric_controls
    ADD CONSTRAINT compliance_fabric_controls_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.compliance_fabric_reports(id);


--
-- Name: compliance_results compliance_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: compliance_results compliance_results_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cs_recommendations cs_recommendations_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cs_recommendations
    ADD CONSTRAINT cs_recommendations_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.cs_resources(id);


--
-- Name: dd_drifts dd_drifts_baseline_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dd_drifts
    ADD CONSTRAINT dd_drifts_baseline_id_fkey FOREIGN KEY (baseline_id) REFERENCES public.dd_baselines(id);


--
-- Name: defense_actions defense_actions_playbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_actions
    ADD CONSTRAINT defense_actions_playbook_id_fkey FOREIGN KEY (playbook_id) REFERENCES public.defense_playbooks(id);


--
-- Name: defense_mesh_pillars defense_mesh_pillars_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_mesh_pillars
    ADD CONSTRAINT defense_mesh_pillars_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.defense_mesh_reports(id);


--
-- Name: defense_mesh_recommendations defense_mesh_recommendations_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_mesh_recommendations
    ADD CONSTRAINT defense_mesh_recommendations_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.defense_mesh_reports(id);


--
-- Name: defense_playbooks defense_playbooks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_playbooks
    ADD CONSTRAINT defense_playbooks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: device_tags device_tags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: digital_twin_v2_anomalies digital_twin_v2_anomalies_env_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.digital_twin_v2_anomalies
    ADD CONSTRAINT digital_twin_v2_anomalies_env_id_fkey FOREIGN KEY (env_id) REFERENCES public.digital_twin_v2_environments(id);


--
-- Name: digital_twin_v2_devices digital_twin_v2_devices_env_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.digital_twin_v2_devices
    ADD CONSTRAINT digital_twin_v2_devices_env_id_fkey FOREIGN KEY (env_id) REFERENCES public.digital_twin_v2_environments(id);


--
-- Name: dspm_findings dspm_findings_datastore_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.dspm_findings
    ADD CONSTRAINT dspm_findings_datastore_id_fkey FOREIGN KEY (datastore_id) REFERENCES public.dspm_datastores(id);


--
-- Name: endpoint_findings endpoint_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.endpoint_findings
    ADD CONSTRAINT endpoint_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.endpoint_scans(id);


--
-- Name: explain_results explain_results_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id);


--
-- Name: explain_results explain_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: findings findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: forensic_artifacts forensic_artifacts_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.forensic_artifacts
    ADD CONSTRAINT forensic_artifacts_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.forensic_cases(id);


--
-- Name: forensic_timeline forensic_timeline_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.forensic_timeline
    ADD CONSTRAINT forensic_timeline_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.forensic_cases(id);


--
-- Name: iam_exposure_findings iam_exposure_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.iam_exposure_findings
    ADD CONSTRAINT iam_exposure_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.iam_exposure_scans(id);


--
-- Name: identity_guardian_signals identity_guardian_signals_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.identity_guardian_signals
    ADD CONSTRAINT identity_guardian_signals_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.identity_guardian_alerts(id);


--
-- Name: ig_edges ig_edges_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_edges
    ADD CONSTRAINT ig_edges_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.ig_identities(id);


--
-- Name: ig_edges ig_edges_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_edges
    ADD CONSTRAINT ig_edges_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.ig_identities(id);


--
-- Name: ig_risks ig_risks_identity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ig_risks
    ADD CONSTRAINT ig_risks_identity_id_fkey FOREIGN KEY (identity_id) REFERENCES public.ig_identities(id);


--
-- Name: ioc_entries ioc_entries_feed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_entries
    ADD CONSTRAINT ioc_entries_feed_id_fkey FOREIGN KEY (feed_id) REFERENCES public.ioc_feeds(id);


--
-- Name: ir_incidents ir_incidents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ir_incidents
    ADD CONSTRAINT ir_incidents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: ir_tasks ir_tasks_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ir_tasks
    ADD CONSTRAINT ir_tasks_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.ir_incidents(id);


--
-- Name: itdr_findings itdr_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.itdr_findings
    ADD CONSTRAINT itdr_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.itdr_scans(id);


--
-- Name: k8s_findings k8s_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.k8s_findings
    ADD CONSTRAINT k8s_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.k8s_scans(id);


--
-- Name: mp_installs mp_installs_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_installs
    ADD CONSTRAINT mp_installs_plugin_id_fkey FOREIGN KEY (plugin_id) REFERENCES public.mp_plugins(id);


--
-- Name: mp_installs mp_installs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_installs
    ADD CONSTRAINT mp_installs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mp_reviews mp_reviews_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_reviews
    ADD CONSTRAINT mp_reviews_plugin_id_fkey FOREIGN KEY (plugin_id) REFERENCES public.mp_plugins(id);


--
-- Name: mp_reviews mp_reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_reviews
    ADD CONSTRAINT mp_reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: network_exposure_assets network_exposure_assets_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.network_exposure_assets
    ADD CONSTRAINT network_exposure_assets_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.network_exposure_scans(id);


--
-- Name: network_exposure_paths network_exposure_paths_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.network_exposure_paths
    ADD CONSTRAINT network_exposure_paths_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.network_exposure_scans(id);


--
-- Name: nv_edges nv_edges_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_edges
    ADD CONSTRAINT nv_edges_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.nv_nodes(id);


--
-- Name: nv_edges nv_edges_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_edges
    ADD CONSTRAINT nv_edges_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.nv_nodes(id);


--
-- Name: nv_issues nv_issues_edge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_issues
    ADD CONSTRAINT nv_issues_edge_id_fkey FOREIGN KEY (edge_id) REFERENCES public.nv_edges(id);


--
-- Name: nv_issues nv_issues_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.nv_issues
    ADD CONSTRAINT nv_issues_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nv_nodes(id);


--
-- Name: ot_findings ot_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_findings
    ADD CONSTRAINT ot_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.ot_scans(id);


--
-- Name: ot_scans ot_scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_scans
    ADD CONSTRAINT ot_scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: patch_brain_items patch_brain_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.patch_brain_items
    ADD CONSTRAINT patch_brain_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.patch_brain_sessions(id);


--
-- Name: policy_brain_sections policy_brain_sections_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.policy_brain_sections
    ADD CONSTRAINT policy_brain_sections_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policy_brain_policies(id);


--
-- Name: predict_alerts predict_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts
    ADD CONSTRAINT predict_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: protocol_scans protocol_scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans
    ADD CONSTRAINT protocol_scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: re_plans re_plans_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.re_plans
    ADD CONSTRAINT re_plans_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.re_assets(id);


--
-- Name: re_tests re_tests_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.re_tests
    ADD CONSTRAINT re_tests_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.re_assets(id);


--
-- Name: risk_narratives risk_narratives_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.risk_narratives
    ADD CONSTRAINT risk_narratives_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id);


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: rt_attacks rt_attacks_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_attacks
    ADD CONSTRAINT rt_attacks_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.rt_campaigns(id);


--
-- Name: rt_campaigns rt_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_campaigns
    ADD CONSTRAINT rt_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: runtime_protection_findings runtime_protection_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.runtime_protection_findings
    ADD CONSTRAINT runtime_protection_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.runtime_protection_scans(id);


--
-- Name: sandbox_findings sandbox_findings_analysis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sandbox_findings
    ADD CONSTRAINT sandbox_findings_analysis_id_fkey FOREIGN KEY (analysis_id) REFERENCES public.sandbox_analyses(id);


--
-- Name: sc_vulns sc_vulns_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sc_vulns
    ADD CONSTRAINT sc_vulns_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.sc_components(id);


--
-- Name: scans scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: score_results score_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: score_results score_results_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: siem_events siem_events_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_events
    ADD CONSTRAINT siem_events_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.siem_incidents(id);


--
-- Name: siem_events siem_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_events
    ADD CONSTRAINT siem_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: siem_incidents siem_incidents_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_incidents
    ADD CONSTRAINT siem_incidents_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: siem_incidents siem_incidents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_incidents
    ADD CONSTRAINT siem_incidents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: siem_rules siem_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_rules
    ADD CONSTRAINT siem_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: soc_twin_actions soc_twin_actions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.soc_twin_actions
    ADD CONSTRAINT soc_twin_actions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.soc_twin_sessions(id);


--
-- Name: te_events te_events_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.te_events
    ADD CONSTRAINT te_events_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.te_clusters(id);


--
-- Name: terminal_audit_log terminal_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.terminal_audit_log
    ADD CONSTRAINT terminal_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: terminal_sessions terminal_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.terminal_sessions
    ADD CONSTRAINT terminal_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: threat_intel_iocs threat_intel_iocs_feed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_intel_iocs
    ADD CONSTRAINT threat_intel_iocs_feed_id_fkey FOREIGN KEY (feed_id) REFERENCES public.threat_intel_feeds(id);


--
-- Name: threat_matches threat_matches_ioc_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches
    ADD CONSTRAINT threat_matches_ioc_entry_id_fkey FOREIGN KEY (ioc_entry_id) REFERENCES public.ioc_entries(id);


--
-- Name: threat_matches threat_matches_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches
    ADD CONSTRAINT threat_matches_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: threat_matches threat_matches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches
    ADD CONSTRAINT threat_matches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: threat_radar_threats threat_radar_threats_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_radar_threats
    ADD CONSTRAINT threat_radar_threats_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.threat_radar_reports(id);


--
-- Name: timeline_events timeline_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT timeline_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: twin_edges twin_edges_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_edges
    ADD CONSTRAINT twin_edges_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.twin_nodes(id);


--
-- Name: twin_edges twin_edges_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_edges
    ADD CONSTRAINT twin_edges_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.twin_nodes(id);


--
-- Name: twin_snapshots twin_snapshots_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_snapshots
    ADD CONSTRAINT twin_snapshots_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: watch_alerts watch_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts
    ADD CONSTRAINT watch_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: watch_baselines watch_baselines_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: zt_access_log zt_access_log_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_access_log
    ADD CONSTRAINT zt_access_log_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.zt_policies(id);


--
-- Name: zt_device_trust zt_device_trust_last_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_device_trust
    ADD CONSTRAINT zt_device_trust_last_scan_id_fkey FOREIGN KEY (last_scan_id) REFERENCES public.scans(id);


--
-- Name: zt_policies zt_policies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_policies
    ADD CONSTRAINT zt_policies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict fP1w9OZ99fyv44pjp8pMi4ZzSq3MOrYCZsBePjahlohhbmCk2BCfTXbaSYfbi4w

