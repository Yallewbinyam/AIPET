--
-- PostgreSQL database dump
--

\restrict FmS6RaSqcTLdLp1SA3drM5YXRKb1XnbhtBkfWutOwumZiCcaXDrDe99ETdtHE9e

-- Dumped from database version 17.5 (Debian 17.5-1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    name character varying(255),
    last_used timestamp without time zone,
    created_at timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.api_keys OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: compliance_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.compliance_results (
    id integer NOT NULL,
    user_id integer NOT NULL,
    scan_id integer NOT NULL,
    framework character varying(50) NOT NULL,
    score integer NOT NULL,
    total integer NOT NULL,
    controls json,
    created_at timestamp without time zone
);


ALTER TABLE public.compliance_results OWNER TO aipet_user;

--
-- Name: compliance_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.compliance_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_results_id_seq OWNER TO aipet_user;

--
-- Name: compliance_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.compliance_results_id_seq OWNED BY public.compliance_results.id;


--
-- Name: device_tags; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.device_tags (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    business_function character varying(100) NOT NULL,
    industry character varying(100) DEFAULT 'General Business'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.device_tags OWNER TO aipet_user;

--
-- Name: device_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.device_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.device_tags_id_seq OWNER TO aipet_user;

--
-- Name: device_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.device_tags_id_seq OWNED BY public.device_tags.id;


--
-- Name: explain_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.explain_results (
    id integer NOT NULL,
    scan_id integer,
    finding_id integer,
    explain_type character varying(50) NOT NULL,
    content text NOT NULL,
    model_used character varying(100) NOT NULL,
    tokens_used integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.explain_results OWNER TO aipet_user;

--
-- Name: explain_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.explain_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.explain_results_id_seq OWNER TO aipet_user;

--
-- Name: explain_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.explain_results_id_seq OWNED BY public.explain_results.id;


--
-- Name: findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.findings (
    id integer NOT NULL,
    scan_id integer NOT NULL,
    module character varying(100) NOT NULL,
    attack character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    description text,
    target character varying(255),
    created_at timestamp without time zone,
    fix_status character varying(50) DEFAULT 'open'::character varying,
    fix_notes text
);


ALTER TABLE public.findings OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.findings_id_seq OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.findings_id_seq OWNED BY public.findings.id;


--
-- Name: predict_alerts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.predict_alerts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    cve_id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    description text NOT NULL,
    severity character varying(50) NOT NULL,
    cvss_score double precision DEFAULT 0.0,
    affected_devices jsonb,
    weaponisation_pct integer DEFAULT 0,
    published_date timestamp without time zone NOT NULL,
    nvd_url character varying(500),
    is_reviewed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.predict_alerts OWNER TO aipet_user;

--
-- Name: predict_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.predict_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.predict_alerts_id_seq OWNER TO aipet_user;

--
-- Name: predict_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.predict_alerts_id_seq OWNED BY public.predict_alerts.id;


--
-- Name: protocol_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.protocol_scans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    protocol character varying(50) NOT NULL,
    target character varying(255) NOT NULL,
    status character varying(50),
    findings json,
    device_count integer,
    risk_level character varying(50),
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.protocol_scans OWNER TO aipet_user;

--
-- Name: protocol_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.protocol_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.protocol_scans_id_seq OWNER TO aipet_user;

--
-- Name: protocol_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.protocol_scans_id_seq OWNED BY public.protocol_scans.id;


--
-- Name: remediation_kb; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.remediation_kb (
    id integer NOT NULL,
    attack_type character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    explanation text NOT NULL,
    fix_commands text NOT NULL,
    time_estimate_minutes integer NOT NULL,
    difficulty character varying(50) NOT NULL,
    source character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.remediation_kb OWNER TO aipet_user;

--
-- Name: remediation_kb_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.remediation_kb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.remediation_kb_id_seq OWNER TO aipet_user;

--
-- Name: remediation_kb_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.remediation_kb_id_seq OWNED BY public.remediation_kb.id;


--
-- Name: scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.scans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target character varying(255) NOT NULL,
    mode character varying(50),
    status character varying(50),
    result_dir character varying(500),
    report_path character varying(500),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone,
    critical integer,
    high integer,
    medium integer,
    low integer
);


ALTER TABLE public.scans OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scans_id_seq OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.scans_id_seq OWNED BY public.scans.id;


--
-- Name: score_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.score_results (
    id integer NOT NULL,
    scan_id integer NOT NULL,
    user_id integer NOT NULL,
    industry character varying(100) NOT NULL,
    total_exposure_gbp bigint DEFAULT 0 NOT NULL,
    findings_breakdown jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.score_results OWNER TO aipet_user;

--
-- Name: score_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.score_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.score_results_id_seq OWNER TO aipet_user;

--
-- Name: score_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.score_results_id_seq OWNED BY public.score_results.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    plan character varying(50),
    scans_used integer,
    scans_limit integer,
    created_at timestamp without time zone,
    last_login timestamp without time zone,
    is_active boolean,
    stripe_customer_id character varying(100),
    stripe_subscription_id character varying(100),
    plan_expires_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: watch_alerts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.watch_alerts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(50) NOT NULL,
    description text NOT NULL,
    details jsonb,
    is_acknowledged boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.watch_alerts OWNER TO aipet_user;

--
-- Name: watch_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.watch_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watch_alerts_id_seq OWNER TO aipet_user;

--
-- Name: watch_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.watch_alerts_id_seq OWNED BY public.watch_alerts.id;


--
-- Name: watch_baselines; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.watch_baselines (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    device_function character varying(100) DEFAULT 'Unknown'::character varying,
    baseline_data jsonb NOT NULL,
    first_seen timestamp without time zone DEFAULT now(),
    last_seen timestamp without time zone DEFAULT now(),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.watch_baselines OWNER TO aipet_user;

--
-- Name: watch_baselines_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.watch_baselines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watch_baselines_id_seq OWNER TO aipet_user;

--
-- Name: watch_baselines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.watch_baselines_id_seq OWNED BY public.watch_baselines.id;


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: compliance_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results ALTER COLUMN id SET DEFAULT nextval('public.compliance_results_id_seq'::regclass);


--
-- Name: device_tags id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags ALTER COLUMN id SET DEFAULT nextval('public.device_tags_id_seq'::regclass);


--
-- Name: explain_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results ALTER COLUMN id SET DEFAULT nextval('public.explain_results_id_seq'::regclass);


--
-- Name: findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings ALTER COLUMN id SET DEFAULT nextval('public.findings_id_seq'::regclass);


--
-- Name: predict_alerts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts ALTER COLUMN id SET DEFAULT nextval('public.predict_alerts_id_seq'::regclass);


--
-- Name: protocol_scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans ALTER COLUMN id SET DEFAULT nextval('public.protocol_scans_id_seq'::regclass);


--
-- Name: remediation_kb id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb ALTER COLUMN id SET DEFAULT nextval('public.remediation_kb_id_seq'::regclass);


--
-- Name: scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans ALTER COLUMN id SET DEFAULT nextval('public.scans_id_seq'::regclass);


--
-- Name: score_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results ALTER COLUMN id SET DEFAULT nextval('public.score_results_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: watch_alerts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts ALTER COLUMN id SET DEFAULT nextval('public.watch_alerts_id_seq'::regclass);


--
-- Name: watch_baselines id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines ALTER COLUMN id SET DEFAULT nextval('public.watch_baselines_id_seq'::regclass);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.api_keys (id, user_id, key_hash, name, last_used, created_at, is_active) FROM stdin;
1	1	2cf027461a731b41b3d9cc55789dedb5e73595fadbc678c157405ce5d5be3b28	My CI/CD Pipeline	\N	2026-03-30 16:28:58.227803	f
2	1	4582d10b9e9f90dff98b800eebd04b4971b8285781f4d6a22b2029e5f200c220	Production CI/CD	\N	2026-03-30 16:47:46.966119	t
3	1	7b17991ccbdb3b7168b2520919490d2f8a94589b016f747c3216b50022ff38a0	End-to-end test	2026-03-31 20:15:39.858877	2026-03-31 20:13:29.613879	t
\.


--
-- Data for Name: compliance_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.compliance_results (id, user_id, scan_id, framework, score, total, controls, created_at) FROM stdin;
1	1	12	nis2	100	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "pass", "impact": "low"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "pass", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "pass", "impact": "low"}]	2026-04-05 03:37:48.07048
2	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:00.935568
3	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:24.900825
4	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-05 03:45:36.414102
5	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:49.845372
6	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-05 04:30:40.252263
7	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-06 02:29:56.849636
8	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-06 02:30:04.723787
9	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-06 02:30:09.185256
10	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-06 02:30:51.437074
\.


--
-- Data for Name: device_tags; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.device_tags (id, user_id, device_ip, business_function, industry, created_at, updated_at) FROM stdin;
1	1	192.168.1.1	Infrastructure / Network	Education	2026-04-04 03:40:12.604108	2026-04-04 03:40:12.604111
2	1	192.168.1.2	Customer Data	Education	2026-04-04 03:40:12.606089	2026-04-04 03:40:12.606091
3	1	192.168.1.3	Operations / Manufacturing	Education	2026-04-04 03:40:12.607352	2026-04-04 03:40:12.607354
4	1	192.168.1.4	General IT	Education	2026-04-04 03:40:12.609235	2026-04-04 03:40:12.609237
\.


--
-- Data for Name: explain_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.explain_results (id, scan_id, finding_id, explain_type, content, model_used, tokens_used, created_at) FROM stdin;
1	9	2	finding	WHY THIS IS DANGEROUS\nYour device is essentially leaving its front door wide open with a welcome mat for attackers. Anyone on your network can remotely take complete control of this device, access all its data, and use it as a launching pad to attack other systems in your organization. In the worst case, criminals could shut down your operations, steal sensitive information, or hold your entire network hostage for ransom.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour confidential data, customer information, and business operations are all at serious risk of being compromised or completely disrupted. If you handle sensitive information like patient records or financial data, this vulnerability could lead to massive regulatory fines and legal liability when that information gets stolen.	claude-sonnet-4-20250514	155	2026-04-03 19:03:53.670008
3	9	3	finding	WHY THIS IS DANGEROUS\nThis device is still using the factory-set username and password that came with it, which means anyone can look up these credentials online and gain complete control of the device. An attacker could use this access to spy on your operations, steal sensitive information, or use the device as a stepping stone to break into other systems on your network. In the worst case, they could shut down critical operations, steal customer data, or plant malicious software that spreads throughout your entire organization.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour confidential business data, customer information, and operational systems are all at immediate risk of unauthorized access and theft. Depending on your industry, this could result in expensive regulatory fines, legal liability, and complete shutdown of business operations until the security breach is contained.	claude-sonnet-4-20250514	172	2026-04-03 19:08:29.903672
4	9	5	finding	WHY THIS IS DANGEROUS\nThis device is like having a building with no security guards or locked doors - anyone on your network can walk right in and take control of it. An attacker could use this device as their base of operations to spy on your network, steal sensitive information, or launch attacks against other systems in your organization. In the worst case, they could shut down critical operations, access patient records or financial data, or use your network to attack other businesses.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour business operations could be disrupted if someone gains unauthorized access to this device and uses it to interfere with other connected systems or steal confidential information. Depending on your industry, this security gap could also put you at risk of failing compliance audits or facing regulatory penalties for not properly protecting sensitive data.	claude-sonnet-4-20250514	172	2026-04-03 23:06:06.17326
5	9	4	finding	WHY THIS IS DANGEROUS\n\nThis device is sending and receiving messages without any protection, like having phone conversations on a loudspeaker that anyone nearby can hear. An attacker on your network could intercept sensitive information being transmitted, spy on your operations, or even send fake commands to control connected equipment. In the worst case, this could allow someone to manipulate your IoT devices, steal confidential data, or disrupt critical business processes.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\n\nYour organization faces potential data breaches where sensitive operational information could be stolen, and there's a risk that attackers could interfere with or take control of connected devices and systems. This vulnerability could lead to compliance violations, regulatory fines, operational downtime, and loss of customer trust if security incidents occur.	claude-sonnet-4-20250514	168	2026-04-03 23:07:12.799799
6	1	1	finding	WHY THIS IS DANGEROUS\nYour IoT device is essentially leaving its front door wide open with no lock, allowing anyone on your network to walk right in and take complete control. An attacker could use this device as a launching pad to access your entire network, steal sensitive data like customer information or financial records, or completely shut down your operations. In the worst case, they could hold your entire business hostage by encrypting all your files and demanding payment to get them back.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour business operations could be completely disrupted if an attacker gains access, potentially costing thousands in lost revenue and emergency IT repairs. Any sensitive customer data, employee records, or financial information stored on your network could be stolen, leading to regulatory fines and serious damage to your company's reputation.	claude-sonnet-4-20250514	172	2026-04-03 23:16:25.73228
48	9	\N	executive_report	EXECUTIVE SUMMARY\n\nOur cybersecurity team conducted a comprehensive assessment of the organization's network infrastructure, evaluating 4 critical business systems. The assessment reveals a HIGH risk security posture with 4 significant vulnerabilities identified, including 2 critical-severity issues that require immediate remediation.\n\nKEY RISKS IDENTIFIED\n\n• Unsecured remote access channels allow attackers to gain direct control of core network equipment, potentially causing complete system shutdown or data theft\n\n• Default login credentials on critical systems provide easy entry points for cybercriminals, who commonly exploit these well-known password combinations to access sensitive business data\n\n• Unprotected data transmission channels expose confidential business communications and customer information as it travels across the network, making interception simple for malicious actors\n\n• Missing network security barriers leave systems vulnerable to both external attacks and internal threats, with no mechanism to detect or prevent unauthorized access attempts\n\nIMMEDIATE ACTIONS REQUIRED\n\n1. Disable all remote access services on the primary network router (192.168.1.1) immediately and replace with secure encrypted alternatives within 48 hours\n\n2. Change all default usernames and passwords on the secondary system (192.168.1.2) to complex, unique credentials and implement mandatory password changes every 90 days\n\n3. Install and configure network firewall protection on the unprotected system (192.168.1.4) and establish baseline security rules to block unauthorized traffic\n\nOVERALL SECURITY ASSESSMENT\n\nThe organization's current security posture presents serious operational and financial risks that demand urgent executive attention. With 2 critical vulnerabilities providing direct pathways for cybercriminals to access our systems, the likelihood of a successful attack is extremely high if no action is taken. The absence of basic security controls across multiple systems indicates systemic security gaps that could result in significant business disruption, regulatory penalties, and reputational damage. However, the identified vulnerabilities are well-understood issues with proven solutions, meaning rapid improvement is achievable with proper resource allocation and management commitment to implementing the recommended security measures.	claude-sonnet-4-20250514	435	2026-04-04 12:39:20.605739
\.


--
-- Data for Name: findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.findings (id, scan_id, module, attack, severity, description, target, created_at, fix_status, fix_notes) FROM stdin;
1	1	network	open_telnet	Critical	Telnet service detected on port 23	192.168.1.1	\N	fixed	Telnet disabled and removed on 3 April 2026
2	9	network	open_telnet	Critical	Telnet service detected on port 23	192.168.1.1	\N	open	\N
3	9	network	default_credentials	Critical	Default credentials accepted on admin panel	192.168.1.2	\N	open	\N
4	9	mqtt	unencrypted_mqtt	High	MQTT broker running without TLS on port 1883	192.168.1.3	\N	open	\N
5	9	network	no_firewall	Medium	No firewall rules configured on device	192.168.1.4	\N	open	\N
\.


--
-- Data for Name: predict_alerts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.predict_alerts (id, user_id, cve_id, title, description, severity, cvss_score, affected_devices, weaponisation_pct, published_date, nvd_url, is_reviewed, created_at) FROM stdin;
6	1	CVE-2026-5030	CVE-2026-5030 — Telnet vulnerability affecting your IoT devices	A vulnerability has been found in Totolink NR1800X 9.1.0u.6279_B20210910. This issue affects the function NTPSyncWithHost of the file /cgi-bin/cstecgi.cgi of the component Telnet Service. The manipulation of the argument host_time leads to command injection. The attack can be initiated remotely. The exploit has been disclosed to the public and may be used.	Medium	6.3	[{"ip": "192.168.1.1", "matches": ["telnet"], "function": "Infrastructure / Network"}]	25	2026-03-29 05:15:55.603	https://nvd.nist.gov/vuln/detail/CVE-2026-5030	f	2026-04-04 06:49:17.122989
7	1	CVE-2026-4993	CVE-2026-4993 — Hard-Coded vulnerability affecting your IoT devices	A vulnerability has been found in wandb OpenUI up to 0.0.0.0/1.0. This impacts an unknown function of the file backend/openui/config.py. The manipulation of the argument LITELLM_MASTER_KEY leads to hard-coded credentials. An attack has to be approached locally. The exploit has been disclosed to the public and may be used. The vendor was contacted early about this disclosure but did not respond in any way.	Low	3.3	[{"ip": "192.168.1.2", "matches": ["hard-coded"], "function": "Customer Data"}]	10	2026-03-28 10:16:31.853	https://nvd.nist.gov/vuln/detail/CVE-2026-4993	f	2026-04-04 06:49:17.122989
8	1	CVE-2025-7741	CVE-2025-7741 — Hardcoded vulnerability affecting your IoT devices	Hardcoded Password Vulnerability have been found in CENTUM. Affected products contain a hardcoded password for the user account (PROG) used for CENTUM Authentication Mode within the system. Under the following conditions, there is a risk that an attacker could log in as the PROG user.\n\nThe default permission for the PROG users is S1 permission (equivalent to OFFUSER). Therefore, for properly permission-controlled targets of operation and monitoring, even if an attacker user in as the PROG user, the risk of critical operations or configuration changes being performed is considered low. (If the PROG user's permissions have been changed for any reason, there is a risk that operations or configuration changes may be performed under the modified permissions. The CVSS values below are for the default permissions.)\n\nAdditionally, exploiting this vulnerability requires an attacker to already have access to the HIS screen controls. Therefore, an attacker can already operate and monitor at that point, regardless of this vulnerability.\n\nThe conditions under which this vulnerability is exploited:\n\nIf all of the following conditions are met, the affected products are vulnerable to this vulnerability.\n\n-An attacker obtains the hardcoded password using a certain method.\n\n-The HIS with the affected product installed is configured in CTM authentication mode.\n\n-An attacker must have direct access to the aforementioned HIS or be able to break into it remotely using a certain method and perform screen operations.\n\n\nThe affected products and versions are as follows: CENTUM VP R5.01.00 to R5.04.20, R6.01.00 to R6.12.00 and R7.01.00.	Unknown	0	[{"ip": "192.168.1.2", "matches": ["hardcoded"], "function": "Customer Data"}]	30	2026-03-30 00:16:00.943	https://nvd.nist.gov/vuln/detail/CVE-2025-7741	f	2026-04-04 06:49:17.12299
9	1	CVE-2026-1612	CVE-2026-1612 — Hard-Coded vulnerability affecting your IoT devices	AL-KO Robolinho Update Software has hard-coded AWS Access and Secret keys that allow anyone to access AL-KO's AWS bucket. Using the keys directly might give the attacker greater access than the app itself. Key grants AT LEAST read access to some of the objects in bucket.\n\nThe vendor was notified early about this vulnerability, but didn't respond with the details of vulnerability or vulnerable version range. Only versions 8.0.21.0610 was tested and confirmed as vulnerable, other versions were not tested and might also be vulnerable.	Unknown	0	[{"ip": "192.168.1.2", "matches": ["hard-coded"], "function": "Customer Data"}]	10	2026-03-30 11:16:04.557	https://nvd.nist.gov/vuln/detail/CVE-2026-1612	f	2026-04-04 06:49:17.12299
10	1	CVE-2025-9497	CVE-2025-9497 — Hard-Coded vulnerability affecting your IoT devices	Use of Hard-coded Credentials vulnerability in Microchip Time Provider 4100 allows Malicious Manual Software Update.This issue affects Time Provider 4100: before 2.5.0.	Critical	9.8	[{"ip": "192.168.1.2", "matches": ["hard-coded"], "function": "Customer Data"}]	55	2026-03-28 11:16:35.337	https://nvd.nist.gov/vuln/detail/CVE-2025-9497	f	2026-04-04 07:10:15.760289
11	1	CVE-2026-0562	CVE-2026-0562 — Router vulnerability affecting your IoT devices	A critical security vulnerability in parisneo/lollms versions up to 2.2.0 allows any authenticated user to accept or reject friend requests belonging to other users. The `respond_request()` function in `backend/routers/friends.py` does not implement proper authorization checks, enabling Insecure Direct Object Reference (IDOR) attacks. Specifically, the `/api/friends/requests/{friendship_id}` endpoint fails to verify whether the authenticated user is part of the friendship or the intended recipient of the request. This vulnerability can lead to unauthorized access, privacy violations, and potential social engineering attacks. The issue has been addressed in version 2.2.0.	High	8.3	[{"ip": "192.168.1.1", "matches": ["router"], "function": "Infrastructure / Network"}]	40	2026-03-29 18:16:14.46	https://nvd.nist.gov/vuln/detail/CVE-2026-0562	f	2026-04-04 07:10:15.760291
12	1	CVE-2026-0560	CVE-2026-0560 — Router vulnerability affecting your IoT devices	A Server-Side Request Forgery (SSRF) vulnerability exists in parisneo/lollms versions prior to 2.2.0, specifically in the `/api/files/export-content` endpoint. The `_download_image_to_temp()` function in `backend/routers/files.py` fails to validate user-controlled URLs, allowing attackers to make arbitrary HTTP requests to internal services and cloud metadata endpoints. This vulnerability can lead to internal network access, cloud metadata access, information disclosure, port scanning, and potentially remote code execution.	High	7.5	[{"ip": "192.168.1.1", "matches": ["router"], "function": "Infrastructure / Network"}]	60	2026-03-29 18:16:14.303	https://nvd.nist.gov/vuln/detail/CVE-2026-0560	f	2026-04-04 07:10:15.760292
13	1	CVE-2026-5018	CVE-2026-5018 — Router vulnerability affecting your IoT devices	A weakness has been identified in code-projects Simple Food Order System 1.0. Affected is an unknown function of the file register-router.php of the component Parameter Handler. Executing a manipulation of the argument Name can lead to sql injection. The attack can be launched remotely. The exploit has been made available to the public and could be used for attacks.	High	7.3	[{"ip": "192.168.1.1", "matches": ["router"], "function": "Infrastructure / Network"}]	40	2026-03-28 23:16:44.663	https://nvd.nist.gov/vuln/detail/CVE-2026-5018	f	2026-04-04 07:10:15.760292
14	1	CVE-2026-34472	CVE-2026-34472 — Router vulnerability affecting your IoT devices	Unauthenticated credential disclosure in the wizard interface in ZTE ZXHN H188A V6.0.10P2_TE and V6.0.10P3N3_TE allows unauthenticated attackers on the local network to retrieve sensitive credentials from the router's web management interface, including the default administrator password, WLAN PSK, and PPPoE credentials. In some observed cases, configuration changes may also be performed without authentication.	High	7.1	[{"ip": "192.168.1.1", "matches": ["router"], "function": "Infrastructure / Network"}]	40	2026-03-30 16:16:07.703	https://nvd.nist.gov/vuln/detail/CVE-2026-34472	f	2026-04-04 07:10:15.760293
\.


--
-- Data for Name: protocol_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.protocol_scans (id, user_id, protocol, target, status, findings, device_count, risk_level, created_at, completed_at) FROM stdin;
1	1	modbus	192.168.1.100	completed	[{"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-001", "title": "No authentication required", "severity": "critical", "description": "Modbus TCP endpoint accepts commands from any source without authentication."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}]	3	critical	2026-04-05 04:05:52.170882	2026-04-05 04:05:52.169904
2	1	modbus	10.0.2.15	completed	[{"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}, {"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}]	3	high	2026-04-05 04:10:06.396635	2026-04-05 04:10:06.396281
3	1	modbus	192.168.1.50	completed	[{"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}]	5	high	2026-04-05 04:11:24.833174	2026-04-05 04:11:24.83276
4	1	modbus	192.168.1.50	completed	[{"id": "MB-002", "title": "Coil write access exposed", "severity": "critical", "description": "Write access to output coils allows direct control of physical devices."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}, {"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}]	5	critical	2026-04-05 04:11:40.976058	2026-04-05 04:11:40.97572
\.


--
-- Data for Name: remediation_kb; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.remediation_kb (id, attack_type, title, severity, explanation, fix_commands, time_estimate_minutes, difficulty, source, created_at) FROM stdin;
1	open_telnet	Telnet Open on Port 23	Critical	Telnet transmits all data including usernames and passwords in plain text. Any attacker on the same network can intercept and read everything. Telnet was designed in 1969 before security was a concern and should never be used on any modern device.	sudo systemctl stop telnet\nsudo systemctl disable telnet\nsudo apt remove telnetd -y	2	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011036
2	default_credentials	Default Credentials Not Changed	Critical	The device is using factory default username and password combinations. These are publicly listed in manufacturer documentation and are the first thing every attacker tries. Leaving default credentials is equivalent to leaving your front door unlocked.	# Access device admin panel\n# Navigate to: Settings > Security > Change Password\n# Set a strong password: minimum 12 characters, mixed case, numbers, symbols\n# Disable default admin account if possible\n# Enable account lockout after 5 failed attempts	5	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011041
3	unencrypted_mqtt	MQTT Running Without TLS Encryption	High	MQTT messages are being transmitted in plain text on port 1883. Anyone on the network can read all device messages, inject false commands, and intercept sensitive sensor data. This is especially dangerous for industrial and medical IoT devices.	# In your MQTT broker config (mosquitto.conf):\nlistener 8883\ncafile /etc/mosquitto/certs/ca.crt\ncertfile /etc/mosquitto/certs/server.crt\nkeyfile /etc/mosquitto/certs/server.key\nrequire_certificate true\n\n# Restart broker:\nsudo systemctl restart mosquitto	30	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011042
4	mqtt_no_auth	MQTT Broker Allows Anonymous Access	High	The MQTT broker accepts connections from any client without requiring a username or password. This means anyone who can reach the broker can subscribe to all topics and publish any message — including commands to connected devices.	# In mosquitto.conf:\nallow_anonymous false\npassword_file /etc/mosquitto/passwd\n\n# Create user:\nsudo mosquitto_passwd -c /etc/mosquitto/passwd your_username\n\n# Restart:\nsudo systemctl restart mosquitto	10	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011042
5	open_ftp	FTP Service Open on Port 21	High	FTP transmits files and credentials in plain text. Port 21 is one of the most commonly attacked ports on the internet. If FTP is needed for file transfers, it must be replaced with SFTP which encrypts the connection.	# Disable FTP:\nsudo systemctl stop vsftpd\nsudo systemctl disable vsftpd\n\n# Install SFTP instead (part of SSH):\nsudo apt install openssh-server -y\nsudo systemctl enable ssh	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011043
6	open_ssh_root	SSH Root Login Enabled	High	SSH is configured to allow direct root login. This means an attacker who brute-forces the SSH password immediately has full system control. Root login should always be disabled — users should SSH as a normal user and then use sudo.	# Edit SSH config:\nsudo nano /etc/ssh/sshd_config\n\n# Change this line:\nPermitRootLogin no\n\n# Also add:\nMaxAuthTries 3\nPasswordAuthentication no\n\n# Restart SSH:\nsudo systemctl restart sshd	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011043
7	http_no_https	Web Interface Running on HTTP Without HTTPS	High	The device web interface transmits login credentials and configuration data without encryption. Any attacker performing a man-in-the-middle attack on the network can capture admin passwords and take control of the device.	# Generate self-signed certificate:\nopenssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes\n\n# For Nginx:\nserver {\n    listen 443 ssl;\n    ssl_certificate /path/to/cert.pem;\n    ssl_certificate_key /path/to/key.pem;\n}\n\n# Redirect HTTP to HTTPS:\nserver {\n    listen 80;\n    return 301 https://$host$request_uri;\n}	20	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011043
8	open_vnc	VNC Remote Desktop Open Without Authentication	Critical	VNC is running and accepting connections without requiring a password. This gives any attacker on the network full graphical control of the device — they can see the screen, move the mouse, and type as if they were sitting in front of it.	# Disable VNC if not needed:\nsudo systemctl stop vncserver\nsudo systemctl disable vncserver\n\n# If VNC is needed, set a strong password:\nvncpasswd\n\n# Restrict to localhost only and use SSH tunnel:\nvncserver -localhost yes	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011044
9	open_snmp	SNMP Running with Default Community String	High	SNMP is configured with the default community string 'public' which is publicly known. This allows attackers to read all device configuration, network topology, and system information. SNMPv1 and v2c transmit this string in plain text.	# Disable SNMPv1 and v2c, use SNMPv3:\nsudo nano /etc/snmp/snmpd.conf\n\n# Remove: rocommunity public\n# Add SNMPv3 user:\ncreateUser myuser SHA mypassword AES myencryptkey\nrouser myuser\n\n# Restart:\nsudo systemctl restart snmpd	15	Moderate	CIS Benchmark	2026-04-03 00:37:29.011044
10	outdated_firmware	Device Running Outdated Firmware	High	The device firmware has not been updated and contains known, publicly documented vulnerabilities. Attackers actively scan for devices running outdated firmware because exploits are already written and publicly available for these versions.	# Check current firmware version in device admin panel\n# Navigate to: Settings > Firmware > Check for Updates\n# Download latest firmware from manufacturer website\n# Backup device configuration before updating\n# Apply firmware update\n# Verify version number after update\n# Re-apply configuration if reset occurred	30	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011044
11	weak_password_policy	No Password Policy Enforced	Medium	The device or application does not enforce minimum password requirements. Users can set passwords like '1234' or 'password' which can be cracked in seconds. Without a password policy, brute force attacks are trivial.	# For Linux systems:\nsudo nano /etc/pam.d/common-password\n\n# Add:\npassword requisite pam_pwquality.so minlen=12 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1\n\n# Install pwquality if needed:\nsudo apt install libpam-pwquality -y	10	Quick Win	NIST SP 800-63B	2026-04-03 00:37:29.011045
12	no_account_lockout	No Account Lockout After Failed Logins	Medium	The device allows unlimited login attempts without locking the account. This makes it completely vulnerable to brute force attacks where software automatically tries thousands of password combinations per second.	# For SSH using fail2ban:\nsudo apt install fail2ban -y\nsudo systemctl enable fail2ban\n\n# Configure:\nsudo nano /etc/fail2ban/jail.local\n[sshd]\nenabled = true\nmaxretry = 5\nbantime = 900\nfindtime = 600	10	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011045
13	open_redis	Redis Database Exposed Without Authentication	Critical	Redis is accessible on the network without a password. An attacker can read all cached data, write arbitrary data, and in many configurations execute system commands. Redis should never be exposed to the network without authentication.	# Bind Redis to localhost only:\nsudo nano /etc/redis/redis.conf\n\n# Change:\nbind 127.0.0.1\n\n# Set password:\nrequirepass your_strong_password_here\n\n# Disable dangerous commands:\nrename-command FLUSHALL ""\nrename-command CONFIG ""\n\n# Restart:\nsudo systemctl restart redis	10	Quick Win	OWASP Top 10	2026-04-03 00:37:29.011045
14	coap_no_dtls	CoAP Running Without DTLS Encryption	High	CoAP messages between IoT devices are transmitted without encryption. DTLS (Datagram Transport Layer Security) is the CoAP equivalent of TLS and must be enabled to prevent eavesdropping and message injection attacks.	# Generate DTLS certificates:\nopenssl ecparam -name prime256v1 -genkey -noout -out coap-key.pem\nopenssl req -new -x509 -key coap-key.pem -out coap-cert.pem -days 365\n\n# Configure your CoAP library to use DTLS\n# Refer to your specific CoAP implementation documentation\n# Common libraries: libcoap, aiocoap, californium	45	Complex	RFC 7252	2026-04-03 00:37:29.011045
15	open_database_port	Database Port Exposed to Network	Critical	The database port is accessible from outside the device or server. Databases should never be directly accessible from the network — only the application running on the same machine should be able to connect. Direct database exposure allows credential attacks and data theft.	# Block database port with firewall:\nsudo ufw deny 5432\nsudo ufw deny 3306\nsudo ufw deny 27017\n\n# Bind database to localhost:\n# PostgreSQL - in postgresql.conf:\nlisten_addresses = 'localhost'\n\n# MySQL - in my.cnf:\nbind-address = 127.0.0.1	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011046
16	ssl_expired_certificate	SSL Certificate Expired or Invalid	High	The device is using an expired or self-signed SSL certificate. Users and connecting devices receive security warnings and may disable certificate validation entirely — which makes them vulnerable to man-in-the-middle attacks that an attacker can exploit.	# Install certbot for free Let's Encrypt certificate:\nsudo apt install certbot -y\nsudo certbot certonly --standalone -d yourdomain.com\n\n# Auto-renewal:\nsudo certbot renew --dry-run\n\n# Add to crontab for auto-renewal:\n0 0 1 * * certbot renew --quiet	15	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011046
17	unnecessary_services	Unnecessary Network Services Running	Medium	The device is running services that are not required for its function. Every running service is an attack surface. A smart camera does not need an FTP server. A temperature sensor does not need a web server. Unused services should always be disabled.	# List all running services:\nsudo systemctl list-units --type=service --state=running\n\n# Disable unnecessary service:\nsudo systemctl stop service-name\nsudo systemctl disable service-name\n\n# Check open ports:\nsudo ss -tlnp	20	Moderate	CIS Benchmark	2026-04-03 00:37:29.011046
18	no_firewall	No Firewall Configured	High	The device has no firewall rules configured. All ports are accessible to anyone on the network. A firewall is the most basic network security control — it should only allow traffic on ports the device actually needs.	# Enable UFW firewall:\nsudo apt install ufw -y\nsudo ufw default deny incoming\nsudo ufw default allow outgoing\n\n# Allow only needed ports (example):\nsudo ufw allow 22/tcp\nsudo ufw allow 443/tcp\n\n# Enable:\nsudo ufw enable\nsudo ufw status verbose	10	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011047
19	insecure_api	API Endpoint Without Authentication	High	One or more API endpoints accept requests without verifying who is making them. An attacker can call these endpoints directly to read data, trigger actions, or modify device configuration without any credentials.	# Implement JWT authentication on all endpoints\n# Example for Flask:\nfrom flask_jwt_extended import jwt_required\n\n@app.route('/api/data')\n@jwt_required()\ndef get_data():\n    pass\n\n# Ensure every route that returns data\n# or triggers actions requires authentication	60	Complex	OWASP API Security Top 10	2026-04-03 00:37:29.011047
20	hardcoded_credentials	Hardcoded Credentials Found in Firmware	Critical	The device firmware contains hardcoded usernames and passwords embedded directly in the code. These cannot be changed by the user. Every device of this model ships with identical credentials — finding them once gives an attacker access to every device worldwide.	# This requires a firmware update from the manufacturer\n# Contact manufacturer immediately and report the vulnerability\n# Check manufacturer website for security patches\n# If no patch available, isolate device from network\n# Consider replacing device with one from a security-conscious vendor\n# Report to NCSC if critical infrastructure: https://www.ncsc.gov.uk	60	Complex	OWASP IoT Top 10	2026-04-03 00:37:29.011047
21	open_rsync	Rsync Service Exposed on Port 873	High	Rsync is running and accessible from the network. Without proper access controls, attackers can use rsync to download all files from the device or upload malicious files. This has been exploited in several major data breaches.	# Disable rsync if not needed:\nsudo systemctl stop rsync\nsudo systemctl disable rsync\n\n# If needed, restrict access in /etc/rsyncd.conf:\nhosts allow = 192.168.1.0/24\nhosts deny = *\n\n# Or block with firewall:\nsudo ufw deny 873	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011048
22	cleartext_storage	Sensitive Data Stored in Plaintext	High	The device stores sensitive information such as passwords, API keys, or personal data in plaintext files. If an attacker gains any access to the filesystem, they immediately have all credentials and sensitive data without needing to crack anything.	# Encrypt sensitive config files:\ngpg --symmetric --cipher-algo AES256 config.txt\n\n# For passwords, always use hashing:\n# Python example:\nfrom bcrypt import hashpw, gensalt\nhashed = hashpw(password.encode(), gensalt())\n\n# Never store passwords in plaintext\n# Use environment variables for secrets:\nexport API_KEY=your_key\n# Access in code: os.environ.get('API_KEY')	60	Complex	OWASP IoT Top 10	2026-04-03 00:37:29.011048
23	no_update_mechanism	No Secure Update Mechanism Available	Medium	The device has no way to receive security updates. Once a vulnerability is discovered, it cannot be patched remotely. This means the device will remain vulnerable forever unless physically replaced. This is a design flaw common in cheap IoT hardware.	# This requires manufacturer action for firmware updates\n# Short-term mitigations:\n# 1. Isolate device on a separate VLAN\nsudo ip link add link eth0 name eth0.10 type vlan id 10\n\n# 2. Block all inbound connections with firewall\nsudo ufw default deny incoming\n\n# 3. Monitor device traffic for anomalies\n# 4. Plan device replacement with a supported model	30	Moderate	NIST SP 800-213	2026-04-03 00:37:29.011048
24	open_upnp	UPnP Enabled and Exposed	High	Universal Plug and Play is enabled on this device. UPnP automatically opens ports in your router without any authentication. Attackers have used UPnP to punch holes in firewalls, redirect traffic, and gain access to internal networks from the internet.	# Disable UPnP on the device:\n# Navigate to device admin panel\n# Settings > Network > UPnP > Disable\n\n# Also disable on your router:\n# Router admin panel > Advanced > UPnP > Disable\n\n# Verify no unexpected port mappings exist:\n# Router admin > Port Forwarding — remove unknown entries	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011048
25	open_nfs	NFS Network File System Exposed	Critical	Network File System shares are accessible from the network, potentially without authentication. NFS was designed for trusted internal networks and has minimal security controls. Exposed NFS shares allow attackers to read and write files directly.	# Disable NFS if not needed:\nsudo systemctl stop nfs-server\nsudo systemctl disable nfs-server\n\n# If NFS is needed, restrict in /etc/exports:\n/data 192.168.1.0/24(ro,sync,no_root_squash)\n\n# Restart and verify:\nsudo exportfs -ra\nsudo showmount -e localhost	10	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011049
26	debug_interface_exposed	Debug Interface Accessible on Network	Critical	A debug or development interface is accessible on the network. Debug interfaces are designed for developers and typically bypass all authentication and security controls. They provide direct access to device internals and are never appropriate in production.	# Identify and disable the debug service:\nsudo systemctl stop debug-service\nsudo systemctl disable debug-service\n\n# Block the port:\nsudo ufw deny [debug-port]\n\n# Check for debug flags in application config\n# Ensure DEBUG=False in all production configs\n# Remove or comment out any debug endpoints in code	15	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011049
27	no_logging	Security Event Logging Not Configured	Medium	The device is not logging security events such as failed logins, configuration changes, or connection attempts. Without logs, there is no way to detect an attack in progress or investigate a breach after it occurs. Logging is essential for any device handling sensitive data.	# Enable system logging:\nsudo apt install rsyslog -y\nsudo systemctl enable rsyslog\n\n# Configure audit logging:\nsudo apt install auditd -y\nsudo systemctl enable auditd\n\n# Log failed logins:\nsudo auditctl -w /var/log/auth.log -p wa -k auth_log\n\n# View logs:\nsudo journalctl -f	15	Moderate	NIST SP 800-92	2026-04-03 00:37:29.011049
28	insecure_deserialization	Insecure Deserialization Vulnerability	Critical	The device or application deserializes data from untrusted sources without validation. Insecure deserialization can allow attackers to execute arbitrary code, manipulate application logic, or perform denial of service attacks by sending specially crafted data.	# Never deserialize data from untrusted sources\n# Use safe formats instead of pickle/Java serialization:\n# Python - use JSON instead of pickle:\nimport json\ndata = json.loads(untrusted_input)  # Safe\n# NOT: pickle.loads(untrusted_input)  # Dangerous\n\n# Validate and sanitise all input before processing\n# Implement integrity checks on serialized data\n# Use allowlists for acceptable classes during deserialization	60	Complex	OWASP Top 10	2026-04-03 00:37:29.011049
29	open_memcached	Memcached Exposed on Port 11211	Critical	Memcached is accessible from the network without authentication. This has been used in some of the largest DDoS amplification attacks in history, with attackers using exposed Memcached servers to amplify traffic by up to 51,000x. It also exposes all cached application data.	# Bind Memcached to localhost:\nsudo nano /etc/memcached.conf\n\n# Change:\n-l 127.0.0.1\n\n# Disable UDP (used in amplification attacks):\n-U 0\n\n# Restart:\nsudo systemctl restart memcached\n\n# Block with firewall:\nsudo ufw deny 11211	5	Quick Win	NCSC Advisory	2026-04-03 00:37:29.01105
30	privilege_escalation_risk	Excessive User Privileges Configured	High	User accounts or processes are running with more privileges than required. Following the principle of least privilege, every user and process should have only the minimum permissions needed to perform its function. Excessive privileges mean a compromised account can cause maximum damage.	# Audit current sudo privileges:\nsudo cat /etc/sudoers\nsudo visudo\n\n# Check user groups:\ngroups username\n\n# Remove from unnecessary groups:\nsudo deluser username groupname\n\n# Run services as dedicated low-privilege users:\nsudo useradd -r -s /bin/false serviceuser\nsudo chown serviceuser:serviceuser /opt/service	20	Moderate	CIS Benchmark	2026-04-03 00:37:29.01105
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.scans (id, user_id, target, mode, status, result_dir, report_path, started_at, completed_at, created_at, critical, high, medium, low) FROM stdin;
1	1	localhost	demo	failed	\N	\N	\N	\N	2026-03-31 20:15:39.867425	0	0	0	0
2	1		demo	complete	\N	\N	\N	2026-04-01 09:46:47.736038	2026-04-01 09:45:46.176547	0	0	0	0
3	1		demo	failed	\N	\N	\N	\N	2026-04-01 10:01:43.288689	0	0	0	0
4	1		demo	failed	\N	\N	\N	\N	2026-04-02 01:15:29.528845	0	0	0	0
5	1	10.0.2.15	live	complete	\N	\N	\N	2026-04-02 01:44:58.017747	2026-04-02 01:44:30.971065	0	0	0	0
6	1		demo	queued	\N	\N	\N	\N	2026-04-02 01:51:46.538644	0	0	0	0
7	1	localhost	demo	complete	\N	\N	\N	2026-04-02 08:14:14.5211	2026-04-02 08:13:28.294726	0	0	0	0
8	1		demo	complete	\N	\N	\N	2026-04-02 09:10:46.959833	2026-04-02 09:09:57.733046	0	0	0	0
9	1	192.168.1.0/24	network	completed	\N	\N	\N	\N	\N	2	1	1	0
10	1		demo	failed	\N	\N	\N	\N	2026-04-03 17:06:14.043743	0	0	0	0
11	1		demo	failed	\N	\N	\N	\N	2026-04-04 08:29:12.952477	0	0	0	0
12	1		demo	queued	\N	\N	\N	\N	2026-04-05 01:35:55.509033	0	0	0	0
13	1	192.168.1.1	live	complete	\N	\N	\N	2026-04-05 06:20:23.329482	2026-04-05 06:20:12.626642	0	0	0	0
14	1		demo	queued	\N	\N	\N	\N	2026-04-06 02:24:03.255418	0	0	0	0
15	1		demo	failed	\N	\N	\N	\N	2026-04-06 02:27:46.105339	0	0	0	0
\.


--
-- Data for Name: score_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.score_results (id, scan_id, user_id, industry, total_exposure_gbp, findings_breakdown, created_at) FROM stdin;
7	9	1	Manufacturing	1063600	[{"attack": "default_credentials", "target": "192.168.1.2", "severity": "Critical", "finding_id": 3, "fix_status": "open", "exposure_fmt": "£544,000", "exposure_gbp": 544000, "device_function": "Customer Data", "breach_probability": 85}, {"attack": "open_telnet", "target": "192.168.1.1", "severity": "Critical", "finding_id": 2, "fix_status": "open", "exposure_fmt": "£240,000", "exposure_gbp": 240000, "device_function": "Infrastructure / Network", "breach_probability": 75}, {"attack": "unencrypted_mqtt", "target": "192.168.1.3", "severity": "High", "finding_id": 4, "fix_status": "open", "exposure_fmt": "£201,600", "exposure_gbp": 201600, "device_function": "Operations / Manufacturing", "breach_probability": 60}, {"attack": "no_firewall", "target": "192.168.1.4", "severity": "Medium", "finding_id": 5, "fix_status": "open", "exposure_fmt": "£78,000", "exposure_gbp": 78000, "device_function": "General IT", "breach_probability": 65}]	2026-04-05 00:10:13.712168
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.users (id, email, password_hash, name, plan, scans_used, scans_limit, created_at, last_login, is_active, stripe_customer_id, stripe_subscription_id, plan_expires_at) FROM stdin;
2	byallew@gmail.com	$2b$12$R7I6t4d7rKteJLRdDacon.fZHwdEDbGKO3RRWQqpFKJD39dAVAjBi	Binyam Yallew	free	0	5	2026-04-05 05:43:49.663051	\N	t	\N	\N	\N
1	test@aipet.io	$2b$12$wgEcI9DJXURKO0Dwhk8mLekA0BCcRS4FpDRLLGoC0lsZ4ZDJ6ZY12	Test User	enterprise	14	5	2026-03-29 23:20:50.618499	2026-04-09 01:49:16.45437	t	cus_UEwnvwFwOEvO5Z	sub_1TGT75EOqz4Ugi362qNaY7M5	2026-04-30 00:51:27
\.


--
-- Data for Name: watch_alerts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.watch_alerts (id, user_id, device_ip, alert_type, severity, description, details, is_acknowledged, created_at) FROM stdin;
\.


--
-- Data for Name: watch_baselines; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.watch_baselines (id, user_id, device_ip, device_function, baseline_data, first_seen, last_seen, is_active, created_at) FROM stdin;
1	1	192.168.1.1	Infrastructure / Network	{"status": "monitored", "device_ip": "192.168.1.1", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 25, "attack_types": ["open_telnet"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Critical", "device_function": "Infrastructure / Network", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 0, "Critical": 1}}	2026-04-04 07:53:27.112634	2026-04-04 23:37:54.727022	t	2026-04-04 07:53:27.112639
2	1	192.168.1.2	Customer Data	{"status": "monitored", "device_ip": "192.168.1.2", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 25, "attack_types": ["default_credentials"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Critical", "device_function": "Customer Data", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 0, "Critical": 1}}	2026-04-04 07:53:27.114672	2026-04-04 23:37:54.730338	t	2026-04-04 07:53:27.114675
3	1	192.168.1.3	Operations / Manufacturing	{"status": "monitored", "device_ip": "192.168.1.3", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["mqtt"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 15, "attack_types": ["unencrypted_mqtt"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "High", "device_function": "Operations / Manufacturing", "severity_profile": {"Low": 0, "High": 1, "Info": 0, "Medium": 0, "Critical": 0}}	2026-04-04 07:53:27.116038	2026-04-04 23:37:54.731253	t	2026-04-04 07:53:27.116041
4	1	192.168.1.4	General IT	{"status": "monitored", "device_ip": "192.168.1.4", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 8, "attack_types": ["no_firewall"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Medium", "device_function": "General IT", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 1, "Critical": 0}}	2026-04-04 07:53:27.117355	2026-04-04 23:37:54.732501	t	2026-04-04 07:53:27.117358
\.


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 3, true);


--
-- Name: compliance_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.compliance_results_id_seq', 10, true);


--
-- Name: device_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.device_tags_id_seq', 4, true);


--
-- Name: explain_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.explain_results_id_seq', 48, true);


--
-- Name: findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.findings_id_seq', 5, true);


--
-- Name: predict_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.predict_alerts_id_seq', 14, true);


--
-- Name: protocol_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.protocol_scans_id_seq', 4, true);


--
-- Name: remediation_kb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.remediation_kb_id_seq', 30, true);


--
-- Name: scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.scans_id_seq', 15, true);


--
-- Name: score_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.score_results_id_seq', 7, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: watch_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.watch_alerts_id_seq', 1, false);


--
-- Name: watch_baselines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.watch_baselines_id_seq', 4, true);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: compliance_results compliance_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_pkey PRIMARY KEY (id);


--
-- Name: device_tags device_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_pkey PRIMARY KEY (id);


--
-- Name: device_tags device_tags_user_id_device_ip_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_user_id_device_ip_key UNIQUE (user_id, device_ip);


--
-- Name: explain_results explain_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_pkey PRIMARY KEY (id);


--
-- Name: findings findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_pkey PRIMARY KEY (id);


--
-- Name: predict_alerts predict_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts
    ADD CONSTRAINT predict_alerts_pkey PRIMARY KEY (id);


--
-- Name: protocol_scans protocol_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans
    ADD CONSTRAINT protocol_scans_pkey PRIMARY KEY (id);


--
-- Name: remediation_kb remediation_kb_attack_type_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb
    ADD CONSTRAINT remediation_kb_attack_type_key UNIQUE (attack_type);


--
-- Name: remediation_kb remediation_kb_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb
    ADD CONSTRAINT remediation_kb_pkey PRIMARY KEY (id);


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- Name: score_results score_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_stripe_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_key UNIQUE (stripe_customer_id);


--
-- Name: users users_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: watch_alerts watch_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts
    ADD CONSTRAINT watch_alerts_pkey PRIMARY KEY (id);


--
-- Name: watch_baselines watch_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_pkey PRIMARY KEY (id);


--
-- Name: watch_baselines watch_baselines_user_id_device_ip_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_user_id_device_ip_key UNIQUE (user_id, device_ip);


--
-- Name: ix_findings_scan_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_findings_scan_id ON public.findings USING btree (scan_id);


--
-- Name: ix_scans_user_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_scans_user_id ON public.scans USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: compliance_results compliance_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: compliance_results compliance_results_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: device_tags device_tags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: explain_results explain_results_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id);


--
-- Name: explain_results explain_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: findings findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: predict_alerts predict_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts
    ADD CONSTRAINT predict_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: protocol_scans protocol_scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans
    ADD CONSTRAINT protocol_scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: scans scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: score_results score_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: score_results score_results_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: watch_alerts watch_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts
    ADD CONSTRAINT watch_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: watch_baselines watch_baselines_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict FmS6RaSqcTLdLp1SA3drM5YXRKb1XnbhtBkfWutOwumZiCcaXDrDe99ETdtHE9e

