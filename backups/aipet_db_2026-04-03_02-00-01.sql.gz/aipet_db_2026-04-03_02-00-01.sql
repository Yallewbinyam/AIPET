--
-- PostgreSQL database dump
--

\restrict FdwYuHewKsow1wjUZ9BfCVTL7J7gLtmn0j6glo2Z2IpZEfAHBZg5T7Mjfrzve7N

-- Dumped from database version 17.5 (Debian 17.5-1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    name character varying(255),
    last_used timestamp without time zone,
    created_at timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.api_keys OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.findings (
    id integer NOT NULL,
    scan_id integer NOT NULL,
    module character varying(100) NOT NULL,
    attack character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    description text,
    target character varying(255),
    created_at timestamp without time zone,
    fix_status character varying(50) DEFAULT 'open'::character varying,
    fix_notes text
);


ALTER TABLE public.findings OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.findings_id_seq OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.findings_id_seq OWNED BY public.findings.id;


--
-- Name: remediation_kb; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.remediation_kb (
    id integer NOT NULL,
    attack_type character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    explanation text NOT NULL,
    fix_commands text NOT NULL,
    time_estimate_minutes integer NOT NULL,
    difficulty character varying(50) NOT NULL,
    source character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.remediation_kb OWNER TO aipet_user;

--
-- Name: remediation_kb_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.remediation_kb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.remediation_kb_id_seq OWNER TO aipet_user;

--
-- Name: remediation_kb_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.remediation_kb_id_seq OWNED BY public.remediation_kb.id;


--
-- Name: scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.scans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target character varying(255) NOT NULL,
    mode character varying(50),
    status character varying(50),
    result_dir character varying(500),
    report_path character varying(500),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone,
    critical integer,
    high integer,
    medium integer,
    low integer
);


ALTER TABLE public.scans OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scans_id_seq OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.scans_id_seq OWNED BY public.scans.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    plan character varying(50),
    scans_used integer,
    scans_limit integer,
    created_at timestamp without time zone,
    last_login timestamp without time zone,
    is_active boolean,
    stripe_customer_id character varying(100),
    stripe_subscription_id character varying(100),
    plan_expires_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings ALTER COLUMN id SET DEFAULT nextval('public.findings_id_seq'::regclass);


--
-- Name: remediation_kb id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb ALTER COLUMN id SET DEFAULT nextval('public.remediation_kb_id_seq'::regclass);


--
-- Name: scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans ALTER COLUMN id SET DEFAULT nextval('public.scans_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.api_keys (id, user_id, key_hash, name, last_used, created_at, is_active) FROM stdin;
1	1	2cf027461a731b41b3d9cc55789dedb5e73595fadbc678c157405ce5d5be3b28	My CI/CD Pipeline	\N	2026-03-30 16:28:58.227803	f
2	1	4582d10b9e9f90dff98b800eebd04b4971b8285781f4d6a22b2029e5f200c220	Production CI/CD	\N	2026-03-30 16:47:46.966119	t
3	1	7b17991ccbdb3b7168b2520919490d2f8a94589b016f747c3216b50022ff38a0	End-to-end test	2026-03-31 20:15:39.858877	2026-03-31 20:13:29.613879	t
\.


--
-- Data for Name: findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.findings (id, scan_id, module, attack, severity, description, target, created_at, fix_status, fix_notes) FROM stdin;
1	1	network	open_telnet	Critical	Telnet service detected on port 23	192.168.1.1	\N	fixed	Telnet disabled and removed on 3 April 2026
\.


--
-- Data for Name: remediation_kb; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.remediation_kb (id, attack_type, title, severity, explanation, fix_commands, time_estimate_minutes, difficulty, source, created_at) FROM stdin;
1	open_telnet	Telnet Open on Port 23	Critical	Telnet transmits all data including usernames and passwords in plain text. Any attacker on the same network can intercept and read everything. Telnet was designed in 1969 before security was a concern and should never be used on any modern device.	sudo systemctl stop telnet\nsudo systemctl disable telnet\nsudo apt remove telnetd -y	2	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011036
2	default_credentials	Default Credentials Not Changed	Critical	The device is using factory default username and password combinations. These are publicly listed in manufacturer documentation and are the first thing every attacker tries. Leaving default credentials is equivalent to leaving your front door unlocked.	# Access device admin panel\n# Navigate to: Settings > Security > Change Password\n# Set a strong password: minimum 12 characters, mixed case, numbers, symbols\n# Disable default admin account if possible\n# Enable account lockout after 5 failed attempts	5	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011041
3	unencrypted_mqtt	MQTT Running Without TLS Encryption	High	MQTT messages are being transmitted in plain text on port 1883. Anyone on the network can read all device messages, inject false commands, and intercept sensitive sensor data. This is especially dangerous for industrial and medical IoT devices.	# In your MQTT broker config (mosquitto.conf):\nlistener 8883\ncafile /etc/mosquitto/certs/ca.crt\ncertfile /etc/mosquitto/certs/server.crt\nkeyfile /etc/mosquitto/certs/server.key\nrequire_certificate true\n\n# Restart broker:\nsudo systemctl restart mosquitto	30	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011042
4	mqtt_no_auth	MQTT Broker Allows Anonymous Access	High	The MQTT broker accepts connections from any client without requiring a username or password. This means anyone who can reach the broker can subscribe to all topics and publish any message — including commands to connected devices.	# In mosquitto.conf:\nallow_anonymous false\npassword_file /etc/mosquitto/passwd\n\n# Create user:\nsudo mosquitto_passwd -c /etc/mosquitto/passwd your_username\n\n# Restart:\nsudo systemctl restart mosquitto	10	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011042
5	open_ftp	FTP Service Open on Port 21	High	FTP transmits files and credentials in plain text. Port 21 is one of the most commonly attacked ports on the internet. If FTP is needed for file transfers, it must be replaced with SFTP which encrypts the connection.	# Disable FTP:\nsudo systemctl stop vsftpd\nsudo systemctl disable vsftpd\n\n# Install SFTP instead (part of SSH):\nsudo apt install openssh-server -y\nsudo systemctl enable ssh	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011043
6	open_ssh_root	SSH Root Login Enabled	High	SSH is configured to allow direct root login. This means an attacker who brute-forces the SSH password immediately has full system control. Root login should always be disabled — users should SSH as a normal user and then use sudo.	# Edit SSH config:\nsudo nano /etc/ssh/sshd_config\n\n# Change this line:\nPermitRootLogin no\n\n# Also add:\nMaxAuthTries 3\nPasswordAuthentication no\n\n# Restart SSH:\nsudo systemctl restart sshd	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011043
7	http_no_https	Web Interface Running on HTTP Without HTTPS	High	The device web interface transmits login credentials and configuration data without encryption. Any attacker performing a man-in-the-middle attack on the network can capture admin passwords and take control of the device.	# Generate self-signed certificate:\nopenssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes\n\n# For Nginx:\nserver {\n    listen 443 ssl;\n    ssl_certificate /path/to/cert.pem;\n    ssl_certificate_key /path/to/key.pem;\n}\n\n# Redirect HTTP to HTTPS:\nserver {\n    listen 80;\n    return 301 https://$host$request_uri;\n}	20	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011043
8	open_vnc	VNC Remote Desktop Open Without Authentication	Critical	VNC is running and accepting connections without requiring a password. This gives any attacker on the network full graphical control of the device — they can see the screen, move the mouse, and type as if they were sitting in front of it.	# Disable VNC if not needed:\nsudo systemctl stop vncserver\nsudo systemctl disable vncserver\n\n# If VNC is needed, set a strong password:\nvncpasswd\n\n# Restrict to localhost only and use SSH tunnel:\nvncserver -localhost yes	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011044
9	open_snmp	SNMP Running with Default Community String	High	SNMP is configured with the default community string 'public' which is publicly known. This allows attackers to read all device configuration, network topology, and system information. SNMPv1 and v2c transmit this string in plain text.	# Disable SNMPv1 and v2c, use SNMPv3:\nsudo nano /etc/snmp/snmpd.conf\n\n# Remove: rocommunity public\n# Add SNMPv3 user:\ncreateUser myuser SHA mypassword AES myencryptkey\nrouser myuser\n\n# Restart:\nsudo systemctl restart snmpd	15	Moderate	CIS Benchmark	2026-04-03 00:37:29.011044
10	outdated_firmware	Device Running Outdated Firmware	High	The device firmware has not been updated and contains known, publicly documented vulnerabilities. Attackers actively scan for devices running outdated firmware because exploits are already written and publicly available for these versions.	# Check current firmware version in device admin panel\n# Navigate to: Settings > Firmware > Check for Updates\n# Download latest firmware from manufacturer website\n# Backup device configuration before updating\n# Apply firmware update\n# Verify version number after update\n# Re-apply configuration if reset occurred	30	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011044
11	weak_password_policy	No Password Policy Enforced	Medium	The device or application does not enforce minimum password requirements. Users can set passwords like '1234' or 'password' which can be cracked in seconds. Without a password policy, brute force attacks are trivial.	# For Linux systems:\nsudo nano /etc/pam.d/common-password\n\n# Add:\npassword requisite pam_pwquality.so minlen=12 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1\n\n# Install pwquality if needed:\nsudo apt install libpam-pwquality -y	10	Quick Win	NIST SP 800-63B	2026-04-03 00:37:29.011045
12	no_account_lockout	No Account Lockout After Failed Logins	Medium	The device allows unlimited login attempts without locking the account. This makes it completely vulnerable to brute force attacks where software automatically tries thousands of password combinations per second.	# For SSH using fail2ban:\nsudo apt install fail2ban -y\nsudo systemctl enable fail2ban\n\n# Configure:\nsudo nano /etc/fail2ban/jail.local\n[sshd]\nenabled = true\nmaxretry = 5\nbantime = 900\nfindtime = 600	10	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011045
13	open_redis	Redis Database Exposed Without Authentication	Critical	Redis is accessible on the network without a password. An attacker can read all cached data, write arbitrary data, and in many configurations execute system commands. Redis should never be exposed to the network without authentication.	# Bind Redis to localhost only:\nsudo nano /etc/redis/redis.conf\n\n# Change:\nbind 127.0.0.1\n\n# Set password:\nrequirepass your_strong_password_here\n\n# Disable dangerous commands:\nrename-command FLUSHALL ""\nrename-command CONFIG ""\n\n# Restart:\nsudo systemctl restart redis	10	Quick Win	OWASP Top 10	2026-04-03 00:37:29.011045
14	coap_no_dtls	CoAP Running Without DTLS Encryption	High	CoAP messages between IoT devices are transmitted without encryption. DTLS (Datagram Transport Layer Security) is the CoAP equivalent of TLS and must be enabled to prevent eavesdropping and message injection attacks.	# Generate DTLS certificates:\nopenssl ecparam -name prime256v1 -genkey -noout -out coap-key.pem\nopenssl req -new -x509 -key coap-key.pem -out coap-cert.pem -days 365\n\n# Configure your CoAP library to use DTLS\n# Refer to your specific CoAP implementation documentation\n# Common libraries: libcoap, aiocoap, californium	45	Complex	RFC 7252	2026-04-03 00:37:29.011045
15	open_database_port	Database Port Exposed to Network	Critical	The database port is accessible from outside the device or server. Databases should never be directly accessible from the network — only the application running on the same machine should be able to connect. Direct database exposure allows credential attacks and data theft.	# Block database port with firewall:\nsudo ufw deny 5432\nsudo ufw deny 3306\nsudo ufw deny 27017\n\n# Bind database to localhost:\n# PostgreSQL - in postgresql.conf:\nlisten_addresses = 'localhost'\n\n# MySQL - in my.cnf:\nbind-address = 127.0.0.1	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011046
16	ssl_expired_certificate	SSL Certificate Expired or Invalid	High	The device is using an expired or self-signed SSL certificate. Users and connecting devices receive security warnings and may disable certificate validation entirely — which makes them vulnerable to man-in-the-middle attacks that an attacker can exploit.	# Install certbot for free Let's Encrypt certificate:\nsudo apt install certbot -y\nsudo certbot certonly --standalone -d yourdomain.com\n\n# Auto-renewal:\nsudo certbot renew --dry-run\n\n# Add to crontab for auto-renewal:\n0 0 1 * * certbot renew --quiet	15	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011046
17	unnecessary_services	Unnecessary Network Services Running	Medium	The device is running services that are not required for its function. Every running service is an attack surface. A smart camera does not need an FTP server. A temperature sensor does not need a web server. Unused services should always be disabled.	# List all running services:\nsudo systemctl list-units --type=service --state=running\n\n# Disable unnecessary service:\nsudo systemctl stop service-name\nsudo systemctl disable service-name\n\n# Check open ports:\nsudo ss -tlnp	20	Moderate	CIS Benchmark	2026-04-03 00:37:29.011046
18	no_firewall	No Firewall Configured	High	The device has no firewall rules configured. All ports are accessible to anyone on the network. A firewall is the most basic network security control — it should only allow traffic on ports the device actually needs.	# Enable UFW firewall:\nsudo apt install ufw -y\nsudo ufw default deny incoming\nsudo ufw default allow outgoing\n\n# Allow only needed ports (example):\nsudo ufw allow 22/tcp\nsudo ufw allow 443/tcp\n\n# Enable:\nsudo ufw enable\nsudo ufw status verbose	10	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011047
19	insecure_api	API Endpoint Without Authentication	High	One or more API endpoints accept requests without verifying who is making them. An attacker can call these endpoints directly to read data, trigger actions, or modify device configuration without any credentials.	# Implement JWT authentication on all endpoints\n# Example for Flask:\nfrom flask_jwt_extended import jwt_required\n\n@app.route('/api/data')\n@jwt_required()\ndef get_data():\n    pass\n\n# Ensure every route that returns data\n# or triggers actions requires authentication	60	Complex	OWASP API Security Top 10	2026-04-03 00:37:29.011047
20	hardcoded_credentials	Hardcoded Credentials Found in Firmware	Critical	The device firmware contains hardcoded usernames and passwords embedded directly in the code. These cannot be changed by the user. Every device of this model ships with identical credentials — finding them once gives an attacker access to every device worldwide.	# This requires a firmware update from the manufacturer\n# Contact manufacturer immediately and report the vulnerability\n# Check manufacturer website for security patches\n# If no patch available, isolate device from network\n# Consider replacing device with one from a security-conscious vendor\n# Report to NCSC if critical infrastructure: https://www.ncsc.gov.uk	60	Complex	OWASP IoT Top 10	2026-04-03 00:37:29.011047
21	open_rsync	Rsync Service Exposed on Port 873	High	Rsync is running and accessible from the network. Without proper access controls, attackers can use rsync to download all files from the device or upload malicious files. This has been exploited in several major data breaches.	# Disable rsync if not needed:\nsudo systemctl stop rsync\nsudo systemctl disable rsync\n\n# If needed, restrict access in /etc/rsyncd.conf:\nhosts allow = 192.168.1.0/24\nhosts deny = *\n\n# Or block with firewall:\nsudo ufw deny 873	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011048
22	cleartext_storage	Sensitive Data Stored in Plaintext	High	The device stores sensitive information such as passwords, API keys, or personal data in plaintext files. If an attacker gains any access to the filesystem, they immediately have all credentials and sensitive data without needing to crack anything.	# Encrypt sensitive config files:\ngpg --symmetric --cipher-algo AES256 config.txt\n\n# For passwords, always use hashing:\n# Python example:\nfrom bcrypt import hashpw, gensalt\nhashed = hashpw(password.encode(), gensalt())\n\n# Never store passwords in plaintext\n# Use environment variables for secrets:\nexport API_KEY=your_key\n# Access in code: os.environ.get('API_KEY')	60	Complex	OWASP IoT Top 10	2026-04-03 00:37:29.011048
23	no_update_mechanism	No Secure Update Mechanism Available	Medium	The device has no way to receive security updates. Once a vulnerability is discovered, it cannot be patched remotely. This means the device will remain vulnerable forever unless physically replaced. This is a design flaw common in cheap IoT hardware.	# This requires manufacturer action for firmware updates\n# Short-term mitigations:\n# 1. Isolate device on a separate VLAN\nsudo ip link add link eth0 name eth0.10 type vlan id 10\n\n# 2. Block all inbound connections with firewall\nsudo ufw default deny incoming\n\n# 3. Monitor device traffic for anomalies\n# 4. Plan device replacement with a supported model	30	Moderate	NIST SP 800-213	2026-04-03 00:37:29.011048
24	open_upnp	UPnP Enabled and Exposed	High	Universal Plug and Play is enabled on this device. UPnP automatically opens ports in your router without any authentication. Attackers have used UPnP to punch holes in firewalls, redirect traffic, and gain access to internal networks from the internet.	# Disable UPnP on the device:\n# Navigate to device admin panel\n# Settings > Network > UPnP > Disable\n\n# Also disable on your router:\n# Router admin panel > Advanced > UPnP > Disable\n\n# Verify no unexpected port mappings exist:\n# Router admin > Port Forwarding — remove unknown entries	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011048
25	open_nfs	NFS Network File System Exposed	Critical	Network File System shares are accessible from the network, potentially without authentication. NFS was designed for trusted internal networks and has minimal security controls. Exposed NFS shares allow attackers to read and write files directly.	# Disable NFS if not needed:\nsudo systemctl stop nfs-server\nsudo systemctl disable nfs-server\n\n# If NFS is needed, restrict in /etc/exports:\n/data 192.168.1.0/24(ro,sync,no_root_squash)\n\n# Restart and verify:\nsudo exportfs -ra\nsudo showmount -e localhost	10	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011049
26	debug_interface_exposed	Debug Interface Accessible on Network	Critical	A debug or development interface is accessible on the network. Debug interfaces are designed for developers and typically bypass all authentication and security controls. They provide direct access to device internals and are never appropriate in production.	# Identify and disable the debug service:\nsudo systemctl stop debug-service\nsudo systemctl disable debug-service\n\n# Block the port:\nsudo ufw deny [debug-port]\n\n# Check for debug flags in application config\n# Ensure DEBUG=False in all production configs\n# Remove or comment out any debug endpoints in code	15	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011049
27	no_logging	Security Event Logging Not Configured	Medium	The device is not logging security events such as failed logins, configuration changes, or connection attempts. Without logs, there is no way to detect an attack in progress or investigate a breach after it occurs. Logging is essential for any device handling sensitive data.	# Enable system logging:\nsudo apt install rsyslog -y\nsudo systemctl enable rsyslog\n\n# Configure audit logging:\nsudo apt install auditd -y\nsudo systemctl enable auditd\n\n# Log failed logins:\nsudo auditctl -w /var/log/auth.log -p wa -k auth_log\n\n# View logs:\nsudo journalctl -f	15	Moderate	NIST SP 800-92	2026-04-03 00:37:29.011049
28	insecure_deserialization	Insecure Deserialization Vulnerability	Critical	The device or application deserializes data from untrusted sources without validation. Insecure deserialization can allow attackers to execute arbitrary code, manipulate application logic, or perform denial of service attacks by sending specially crafted data.	# Never deserialize data from untrusted sources\n# Use safe formats instead of pickle/Java serialization:\n# Python - use JSON instead of pickle:\nimport json\ndata = json.loads(untrusted_input)  # Safe\n# NOT: pickle.loads(untrusted_input)  # Dangerous\n\n# Validate and sanitise all input before processing\n# Implement integrity checks on serialized data\n# Use allowlists for acceptable classes during deserialization	60	Complex	OWASP Top 10	2026-04-03 00:37:29.011049
29	open_memcached	Memcached Exposed on Port 11211	Critical	Memcached is accessible from the network without authentication. This has been used in some of the largest DDoS amplification attacks in history, with attackers using exposed Memcached servers to amplify traffic by up to 51,000x. It also exposes all cached application data.	# Bind Memcached to localhost:\nsudo nano /etc/memcached.conf\n\n# Change:\n-l 127.0.0.1\n\n# Disable UDP (used in amplification attacks):\n-U 0\n\n# Restart:\nsudo systemctl restart memcached\n\n# Block with firewall:\nsudo ufw deny 11211	5	Quick Win	NCSC Advisory	2026-04-03 00:37:29.01105
30	privilege_escalation_risk	Excessive User Privileges Configured	High	User accounts or processes are running with more privileges than required. Following the principle of least privilege, every user and process should have only the minimum permissions needed to perform its function. Excessive privileges mean a compromised account can cause maximum damage.	# Audit current sudo privileges:\nsudo cat /etc/sudoers\nsudo visudo\n\n# Check user groups:\ngroups username\n\n# Remove from unnecessary groups:\nsudo deluser username groupname\n\n# Run services as dedicated low-privilege users:\nsudo useradd -r -s /bin/false serviceuser\nsudo chown serviceuser:serviceuser /opt/service	20	Moderate	CIS Benchmark	2026-04-03 00:37:29.01105
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.scans (id, user_id, target, mode, status, result_dir, report_path, started_at, completed_at, created_at, critical, high, medium, low) FROM stdin;
1	1	localhost	demo	failed	\N	\N	\N	\N	2026-03-31 20:15:39.867425	0	0	0	0
2	1		demo	complete	\N	\N	\N	2026-04-01 09:46:47.736038	2026-04-01 09:45:46.176547	0	0	0	0
3	1		demo	failed	\N	\N	\N	\N	2026-04-01 10:01:43.288689	0	0	0	0
4	1		demo	failed	\N	\N	\N	\N	2026-04-02 01:15:29.528845	0	0	0	0
5	1	10.0.2.15	live	complete	\N	\N	\N	2026-04-02 01:44:58.017747	2026-04-02 01:44:30.971065	0	0	0	0
6	1		demo	queued	\N	\N	\N	\N	2026-04-02 01:51:46.538644	0	0	0	0
7	1	localhost	demo	complete	\N	\N	\N	2026-04-02 08:14:14.5211	2026-04-02 08:13:28.294726	0	0	0	0
8	1		demo	complete	\N	\N	\N	2026-04-02 09:10:46.959833	2026-04-02 09:09:57.733046	0	0	0	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.users (id, email, password_hash, name, plan, scans_used, scans_limit, created_at, last_login, is_active, stripe_customer_id, stripe_subscription_id, plan_expires_at) FROM stdin;
1	test@aipet.io	$2b$12$wgEcI9DJXURKO0Dwhk8mLekA0BCcRS4FpDRLLGoC0lsZ4ZDJ6ZY12	Test User	enterprise	8	5	2026-03-29 23:20:50.618499	2026-04-03 01:52:38.364313	t	cus_UEwnvwFwOEvO5Z	sub_1TGT75EOqz4Ugi362qNaY7M5	2026-04-30 00:51:27
\.


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 3, true);


--
-- Name: findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.findings_id_seq', 1, true);


--
-- Name: remediation_kb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.remediation_kb_id_seq', 30, true);


--
-- Name: scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.scans_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: findings findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_pkey PRIMARY KEY (id);


--
-- Name: remediation_kb remediation_kb_attack_type_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb
    ADD CONSTRAINT remediation_kb_attack_type_key UNIQUE (attack_type);


--
-- Name: remediation_kb remediation_kb_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb
    ADD CONSTRAINT remediation_kb_pkey PRIMARY KEY (id);


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_stripe_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_key UNIQUE (stripe_customer_id);


--
-- Name: users users_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: ix_findings_scan_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_findings_scan_id ON public.findings USING btree (scan_id);


--
-- Name: ix_scans_user_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_scans_user_id ON public.scans USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: findings findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: scans scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict FdwYuHewKsow1wjUZ9BfCVTL7J7gLtmn0j6glo2Z2IpZEfAHBZg5T7Mjfrzve7N

