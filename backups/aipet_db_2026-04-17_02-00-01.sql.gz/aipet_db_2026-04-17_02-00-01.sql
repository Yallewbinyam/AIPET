--
-- PostgreSQL database dump
--

\restrict Kzn0TMoHj4KKXWP8LdyGRI2YOfRm8r7eMc4ov32ZMopPbXeEI97A8TaQLJFKobb

-- Dumped from database version 17.5 (Debian 17.5-1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    name character varying(255),
    last_used timestamp without time zone,
    created_at timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.api_keys OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO aipet_user;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.audit_log (
    id character varying(36) NOT NULL,
    user_id integer,
    action character varying(100) NOT NULL,
    resource character varying(100),
    ip_address character varying(45),
    user_agent text,
    "timestamp" timestamp without time zone,
    status character varying(20)
);


ALTER TABLE public.audit_log OWNER TO aipet_user;

--
-- Name: cloud_accounts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_accounts (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    provider character varying(50) NOT NULL,
    account_id character varying(200),
    region character varying(100),
    status character varying(30),
    asset_count integer,
    finding_count integer,
    last_scan timestamp without time zone,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.cloud_accounts OWNER TO aipet_user;

--
-- Name: cloud_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.cloud_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cloud_accounts_id_seq OWNER TO aipet_user;

--
-- Name: cloud_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.cloud_accounts_id_seq OWNED BY public.cloud_accounts.id;


--
-- Name: cloud_assets; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_assets (
    id integer NOT NULL,
    account_id integer NOT NULL,
    asset_id character varying(200) NOT NULL,
    name character varying(200),
    asset_type character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    region character varying(100),
    ip_address character varying(100),
    tags text,
    risk_score integer,
    public boolean,
    encrypted boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.cloud_assets OWNER TO aipet_user;

--
-- Name: cloud_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.cloud_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cloud_assets_id_seq OWNER TO aipet_user;

--
-- Name: cloud_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.cloud_assets_id_seq OWNED BY public.cloud_assets.id;


--
-- Name: cloud_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.cloud_findings (
    id integer NOT NULL,
    account_id integer,
    asset_id integer,
    provider character varying(50) NOT NULL,
    finding_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    resource character varying(300),
    remediation text,
    mitre_id character varying(50),
    created_at timestamp without time zone
);


ALTER TABLE public.cloud_findings OWNER TO aipet_user;

--
-- Name: cloud_findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.cloud_findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cloud_findings_id_seq OWNER TO aipet_user;

--
-- Name: cloud_findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.cloud_findings_id_seq OWNED BY public.cloud_findings.id;


--
-- Name: compliance_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.compliance_results (
    id integer NOT NULL,
    user_id integer NOT NULL,
    scan_id integer NOT NULL,
    framework character varying(50) NOT NULL,
    score integer NOT NULL,
    total integer NOT NULL,
    controls json,
    created_at timestamp without time zone
);


ALTER TABLE public.compliance_results OWNER TO aipet_user;

--
-- Name: compliance_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.compliance_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_results_id_seq OWNER TO aipet_user;

--
-- Name: compliance_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.compliance_results_id_seq OWNED BY public.compliance_results.id;


--
-- Name: defense_actions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.defense_actions (
    id integer NOT NULL,
    playbook_id integer,
    playbook_name character varying(200),
    action_type character varying(100) NOT NULL,
    target character varying(200),
    status character varying(20),
    reason text,
    outcome text,
    triggered_by character varying(100),
    created_at timestamp without time zone
);


ALTER TABLE public.defense_actions OWNER TO aipet_user;

--
-- Name: defense_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.defense_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.defense_actions_id_seq OWNER TO aipet_user;

--
-- Name: defense_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.defense_actions_id_seq OWNED BY public.defense_actions.id;


--
-- Name: defense_playbooks; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.defense_playbooks (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    enabled boolean,
    trigger_field character varying(50) NOT NULL,
    trigger_op character varying(20) NOT NULL,
    trigger_value character varying(200) NOT NULL,
    actions text NOT NULL,
    cooldown_minutes integer,
    trigger_count integer,
    last_triggered timestamp without time zone,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.defense_playbooks OWNER TO aipet_user;

--
-- Name: defense_playbooks_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.defense_playbooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.defense_playbooks_id_seq OWNER TO aipet_user;

--
-- Name: defense_playbooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.defense_playbooks_id_seq OWNED BY public.defense_playbooks.id;


--
-- Name: device_tags; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.device_tags (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    business_function character varying(100) NOT NULL,
    industry character varying(100) DEFAULT 'General Business'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.device_tags OWNER TO aipet_user;

--
-- Name: device_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.device_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.device_tags_id_seq OWNER TO aipet_user;

--
-- Name: device_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.device_tags_id_seq OWNED BY public.device_tags.id;


--
-- Name: explain_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.explain_results (
    id integer NOT NULL,
    scan_id integer,
    finding_id integer,
    explain_type character varying(50) NOT NULL,
    content text NOT NULL,
    model_used character varying(100) NOT NULL,
    tokens_used integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.explain_results OWNER TO aipet_user;

--
-- Name: explain_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.explain_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.explain_results_id_seq OWNER TO aipet_user;

--
-- Name: explain_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.explain_results_id_seq OWNED BY public.explain_results.id;


--
-- Name: findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.findings (
    id integer NOT NULL,
    scan_id integer NOT NULL,
    module character varying(100) NOT NULL,
    attack character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    description text,
    target character varying(255),
    created_at timestamp without time zone,
    fix_status character varying(50) DEFAULT 'open'::character varying,
    fix_notes text
);


ALTER TABLE public.findings OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.findings_id_seq OWNER TO aipet_user;

--
-- Name: findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.findings_id_seq OWNED BY public.findings.id;


--
-- Name: ioc_entries; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ioc_entries (
    id integer NOT NULL,
    feed_id integer NOT NULL,
    ioc_type character varying(20) NOT NULL,
    value character varying(500) NOT NULL,
    threat_type character varying(100),
    confidence integer,
    severity character varying(20),
    description text,
    source_ref character varying(500),
    active boolean,
    created_at timestamp without time zone,
    expires_at timestamp without time zone
);


ALTER TABLE public.ioc_entries OWNER TO aipet_user;

--
-- Name: ioc_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ioc_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ioc_entries_id_seq OWNER TO aipet_user;

--
-- Name: ioc_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ioc_entries_id_seq OWNED BY public.ioc_entries.id;


--
-- Name: ioc_feeds; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ioc_feeds (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    feed_type character varying(50) NOT NULL,
    description text,
    enabled boolean,
    api_key text,
    last_sync timestamp without time zone,
    entry_count integer,
    created_at timestamp without time zone
);


ALTER TABLE public.ioc_feeds OWNER TO aipet_user;

--
-- Name: ioc_feeds_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ioc_feeds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ioc_feeds_id_seq OWNER TO aipet_user;

--
-- Name: ioc_feeds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ioc_feeds_id_seq OWNED BY public.ioc_feeds.id;


--
-- Name: mp_installs; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.mp_installs (
    id integer NOT NULL,
    plugin_id integer NOT NULL,
    user_id integer NOT NULL,
    config text,
    enabled boolean,
    installed_at timestamp without time zone
);


ALTER TABLE public.mp_installs OWNER TO aipet_user;

--
-- Name: mp_installs_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.mp_installs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mp_installs_id_seq OWNER TO aipet_user;

--
-- Name: mp_installs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.mp_installs_id_seq OWNED BY public.mp_installs.id;


--
-- Name: mp_plugins; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.mp_plugins (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    long_desc text,
    category character varying(50) NOT NULL,
    publisher character varying(200) NOT NULL,
    version character varying(20),
    icon character varying(10),
    tags text,
    verified boolean,
    free boolean,
    price_gbp double precision,
    install_count integer,
    avg_rating double precision,
    review_count integer,
    active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.mp_plugins OWNER TO aipet_user;

--
-- Name: mp_plugins_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.mp_plugins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mp_plugins_id_seq OWNER TO aipet_user;

--
-- Name: mp_plugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.mp_plugins_id_seq OWNED BY public.mp_plugins.id;


--
-- Name: mp_reviews; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.mp_reviews (
    id integer NOT NULL,
    plugin_id integer NOT NULL,
    user_id integer NOT NULL,
    rating integer NOT NULL,
    review text,
    created_at timestamp without time zone
);


ALTER TABLE public.mp_reviews OWNER TO aipet_user;

--
-- Name: mp_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.mp_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mp_reviews_id_seq OWNER TO aipet_user;

--
-- Name: mp_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.mp_reviews_id_seq OWNED BY public.mp_reviews.id;


--
-- Name: ot_devices; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ot_devices (
    id integer NOT NULL,
    device_ip character varying(100) NOT NULL,
    device_name character varying(200),
    protocol character varying(50) NOT NULL,
    port integer,
    vendor character varying(200),
    model character varying(200),
    firmware character varying(100),
    zone character varying(50),
    criticality character varying(20),
    location character varying(200),
    last_seen timestamp without time zone,
    online boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.ot_devices OWNER TO aipet_user;

--
-- Name: ot_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ot_devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ot_devices_id_seq OWNER TO aipet_user;

--
-- Name: ot_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ot_devices_id_seq OWNED BY public.ot_devices.id;


--
-- Name: ot_findings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ot_findings (
    id integer NOT NULL,
    scan_id integer,
    device_ip character varying(100) NOT NULL,
    protocol character varying(50) NOT NULL,
    finding_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    evidence text,
    mitre_ics_id character varying(50),
    remediation text,
    created_at timestamp without time zone
);


ALTER TABLE public.ot_findings OWNER TO aipet_user;

--
-- Name: ot_findings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ot_findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ot_findings_id_seq OWNER TO aipet_user;

--
-- Name: ot_findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ot_findings_id_seq OWNED BY public.ot_findings.id;


--
-- Name: ot_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.ot_scans (
    id integer NOT NULL,
    target character varying(200) NOT NULL,
    protocol character varying(50) NOT NULL,
    status character varying(30),
    findings_count integer,
    risk_level character varying(20),
    scan_duration double precision,
    user_id integer,
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.ot_scans OWNER TO aipet_user;

--
-- Name: ot_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.ot_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ot_scans_id_seq OWNER TO aipet_user;

--
-- Name: ot_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.ot_scans_id_seq OWNED BY public.ot_scans.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.permissions (
    id character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    resource character varying(50),
    action character varying(50)
);


ALTER TABLE public.permissions OWNER TO aipet_user;

--
-- Name: predict_alerts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.predict_alerts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    cve_id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    description text NOT NULL,
    severity character varying(50) NOT NULL,
    cvss_score double precision DEFAULT 0.0,
    affected_devices jsonb,
    weaponisation_pct integer DEFAULT 0,
    published_date timestamp without time zone NOT NULL,
    nvd_url character varying(500),
    is_reviewed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.predict_alerts OWNER TO aipet_user;

--
-- Name: predict_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.predict_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.predict_alerts_id_seq OWNER TO aipet_user;

--
-- Name: predict_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.predict_alerts_id_seq OWNED BY public.predict_alerts.id;


--
-- Name: protocol_scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.protocol_scans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    protocol character varying(50) NOT NULL,
    target character varying(255) NOT NULL,
    status character varying(50),
    findings json,
    device_count integer,
    risk_level character varying(50),
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.protocol_scans OWNER TO aipet_user;

--
-- Name: protocol_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.protocol_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.protocol_scans_id_seq OWNER TO aipet_user;

--
-- Name: protocol_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.protocol_scans_id_seq OWNED BY public.protocol_scans.id;


--
-- Name: remediation_kb; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.remediation_kb (
    id integer NOT NULL,
    attack_type character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    explanation text NOT NULL,
    fix_commands text NOT NULL,
    time_estimate_minutes integer NOT NULL,
    difficulty character varying(50) NOT NULL,
    source character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.remediation_kb OWNER TO aipet_user;

--
-- Name: remediation_kb_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.remediation_kb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.remediation_kb_id_seq OWNER TO aipet_user;

--
-- Name: remediation_kb_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.remediation_kb_id_seq OWNED BY public.remediation_kb.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.role_permissions (
    role_id character varying(36) NOT NULL,
    permission_id character varying(36) NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO aipet_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.roles (
    id character varying(36) NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp without time zone
);


ALTER TABLE public.roles OWNER TO aipet_user;

--
-- Name: rt_attacks; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.rt_attacks (
    id integer NOT NULL,
    campaign_id integer NOT NULL,
    mitre_id character varying(50) NOT NULL,
    tactic character varying(100) NOT NULL,
    technique character varying(200) NOT NULL,
    target character varying(200),
    result character varying(30),
    impact text,
    evidence text,
    blocked_by character varying(200),
    severity character varying(20),
    executed_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.rt_attacks OWNER TO aipet_user;

--
-- Name: rt_attacks_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.rt_attacks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rt_attacks_id_seq OWNER TO aipet_user;

--
-- Name: rt_attacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.rt_attacks_id_seq OWNED BY public.rt_attacks.id;


--
-- Name: rt_campaigns; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.rt_campaigns (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    scope text,
    objectives text,
    status character varying(30),
    attack_count integer,
    success_count integer,
    blocked_count integer,
    overall_score integer,
    duration_sec integer,
    created_by integer,
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.rt_campaigns OWNER TO aipet_user;

--
-- Name: rt_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.rt_campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rt_campaigns_id_seq OWNER TO aipet_user;

--
-- Name: rt_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.rt_campaigns_id_seq OWNED BY public.rt_campaigns.id;


--
-- Name: scans; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.scans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target character varying(255) NOT NULL,
    mode character varying(50),
    status character varying(50),
    result_dir character varying(500),
    report_path character varying(500),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone,
    critical integer,
    high integer,
    medium integer,
    low integer
);


ALTER TABLE public.scans OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scans_id_seq OWNER TO aipet_user;

--
-- Name: scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.scans_id_seq OWNED BY public.scans.id;


--
-- Name: score_results; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.score_results (
    id integer NOT NULL,
    scan_id integer NOT NULL,
    user_id integer NOT NULL,
    industry character varying(100) NOT NULL,
    total_exposure_gbp bigint DEFAULT 0 NOT NULL,
    findings_breakdown jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.score_results OWNER TO aipet_user;

--
-- Name: score_results_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.score_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.score_results_id_seq OWNER TO aipet_user;

--
-- Name: score_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.score_results_id_seq OWNED BY public.score_results.id;


--
-- Name: siem_events; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.siem_events (
    id integer NOT NULL,
    event_type character varying(100) NOT NULL,
    source character varying(200) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    raw_payload text,
    mitre_id character varying(50),
    user_id integer,
    incident_id integer,
    acknowledged boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.siem_events OWNER TO aipet_user;

--
-- Name: siem_events_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.siem_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.siem_events_id_seq OWNER TO aipet_user;

--
-- Name: siem_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.siem_events_id_seq OWNED BY public.siem_events.id;


--
-- Name: siem_incidents; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.siem_incidents (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    severity character varying(20) NOT NULL,
    status character varying(50),
    assigned_to integer,
    created_by integer,
    event_count integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.siem_incidents OWNER TO aipet_user;

--
-- Name: siem_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.siem_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.siem_incidents_id_seq OWNER TO aipet_user;

--
-- Name: siem_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.siem_incidents_id_seq OWNED BY public.siem_incidents.id;


--
-- Name: siem_rules; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.siem_rules (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    condition text NOT NULL,
    action character varying(50),
    severity character varying(20),
    enabled boolean,
    trigger_count integer,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.siem_rules OWNER TO aipet_user;

--
-- Name: siem_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.siem_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.siem_rules_id_seq OWNER TO aipet_user;

--
-- Name: siem_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.siem_rules_id_seq OWNED BY public.siem_rules.id;


--
-- Name: sso_providers; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.sso_providers (
    id character varying(36) NOT NULL,
    name character varying(50) NOT NULL,
    client_id text,
    tenant_id text,
    metadata_url text,
    enabled boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.sso_providers OWNER TO aipet_user;

--
-- Name: threat_matches; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.threat_matches (
    id integer NOT NULL,
    ioc_entry_id integer,
    scan_id integer,
    matched_value character varying(500) NOT NULL,
    match_source character varying(100) NOT NULL,
    threat_type character varying(100),
    confidence integer,
    severity character varying(20),
    details text,
    user_id integer,
    created_at timestamp without time zone
);


ALTER TABLE public.threat_matches OWNER TO aipet_user;

--
-- Name: threat_matches_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.threat_matches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.threat_matches_id_seq OWNER TO aipet_user;

--
-- Name: threat_matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.threat_matches_id_seq OWNED BY public.threat_matches.id;


--
-- Name: twin_edges; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.twin_edges (
    id integer NOT NULL,
    source_id integer NOT NULL,
    target_id integer NOT NULL,
    edge_type character varying(50),
    protocol character varying(50),
    port integer,
    encrypted boolean,
    bandwidth character varying(50),
    latency_ms integer,
    active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.twin_edges OWNER TO aipet_user;

--
-- Name: twin_edges_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.twin_edges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.twin_edges_id_seq OWNER TO aipet_user;

--
-- Name: twin_edges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.twin_edges_id_seq OWNED BY public.twin_edges.id;


--
-- Name: twin_nodes; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.twin_nodes (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    node_type character varying(50) NOT NULL,
    ip_address character varying(100),
    mac_address character varying(50),
    vendor character varying(200),
    firmware character varying(100),
    location character varying(200),
    zone character varying(50),
    expected_state text,
    actual_state text,
    diverged boolean,
    risk_score integer,
    online boolean,
    x_pos double precision,
    y_pos double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.twin_nodes OWNER TO aipet_user;

--
-- Name: twin_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.twin_nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.twin_nodes_id_seq OWNER TO aipet_user;

--
-- Name: twin_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.twin_nodes_id_seq OWNED BY public.twin_nodes.id;


--
-- Name: twin_snapshots; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.twin_snapshots (
    id integer NOT NULL,
    label character varying(200),
    snapshot_type character varying(50),
    node_count integer,
    edge_count integer,
    diverged_count integer,
    risk_avg double precision,
    data text,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.twin_snapshots OWNER TO aipet_user;

--
-- Name: twin_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.twin_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.twin_snapshots_id_seq OWNER TO aipet_user;

--
-- Name: twin_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.twin_snapshots_id_seq OWNED BY public.twin_snapshots.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.user_roles (
    id character varying(36) NOT NULL,
    user_id integer NOT NULL,
    role_id character varying(36) NOT NULL,
    assigned_by integer,
    assigned_at timestamp without time zone
);


ALTER TABLE public.user_roles OWNER TO aipet_user;

--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.user_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    slack_webhook_url text,
    teams_webhook_url text,
    notify_critical boolean DEFAULT true,
    notify_high boolean DEFAULT false,
    notify_cve boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    siem_webhook_url text
);


ALTER TABLE public.user_settings OWNER TO aipet_user;

--
-- Name: user_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.user_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_settings_id_seq OWNER TO aipet_user;

--
-- Name: user_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.user_settings_id_seq OWNED BY public.user_settings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    plan character varying(50),
    scans_used integer,
    scans_limit integer,
    created_at timestamp without time zone,
    last_login timestamp without time zone,
    is_active boolean,
    stripe_customer_id character varying(100),
    stripe_subscription_id character varying(100),
    plan_expires_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO aipet_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: watch_alerts; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.watch_alerts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(50) NOT NULL,
    description text NOT NULL,
    details jsonb,
    is_acknowledged boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.watch_alerts OWNER TO aipet_user;

--
-- Name: watch_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.watch_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watch_alerts_id_seq OWNER TO aipet_user;

--
-- Name: watch_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.watch_alerts_id_seq OWNED BY public.watch_alerts.id;


--
-- Name: watch_baselines; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.watch_baselines (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_ip character varying(255) NOT NULL,
    device_function character varying(100) DEFAULT 'Unknown'::character varying,
    baseline_data jsonb NOT NULL,
    first_seen timestamp without time zone DEFAULT now(),
    last_seen timestamp without time zone DEFAULT now(),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.watch_baselines OWNER TO aipet_user;

--
-- Name: watch_baselines_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.watch_baselines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watch_baselines_id_seq OWNER TO aipet_user;

--
-- Name: watch_baselines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.watch_baselines_id_seq OWNED BY public.watch_baselines.id;


--
-- Name: zt_access_log; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.zt_access_log (
    id integer NOT NULL,
    source_ip character varying(100) NOT NULL,
    dest_ip character varying(100),
    port character varying(50),
    protocol character varying(20),
    action character varying(30) NOT NULL,
    policy_id integer,
    policy_name character varying(200),
    reason text,
    trust_score integer,
    created_at timestamp without time zone
);


ALTER TABLE public.zt_access_log OWNER TO aipet_user;

--
-- Name: zt_access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.zt_access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zt_access_log_id_seq OWNER TO aipet_user;

--
-- Name: zt_access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.zt_access_log_id_seq OWNED BY public.zt_access_log.id;


--
-- Name: zt_device_trust; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.zt_device_trust (
    id integer NOT NULL,
    device_ip character varying(100) NOT NULL,
    device_name character varying(200),
    trust_score integer,
    status character varying(30),
    risk_factors text,
    last_scan_id integer,
    last_assessed timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.zt_device_trust OWNER TO aipet_user;

--
-- Name: zt_device_trust_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.zt_device_trust_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zt_device_trust_id_seq OWNER TO aipet_user;

--
-- Name: zt_device_trust_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.zt_device_trust_id_seq OWNED BY public.zt_device_trust.id;


--
-- Name: zt_policies; Type: TABLE; Schema: public; Owner: aipet_user
--

CREATE TABLE public.zt_policies (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    source character varying(200) NOT NULL,
    destination character varying(200) NOT NULL,
    port character varying(50),
    protocol character varying(20),
    action character varying(30) NOT NULL,
    priority integer,
    enabled boolean,
    hit_count integer,
    created_by integer,
    created_at timestamp without time zone
);


ALTER TABLE public.zt_policies OWNER TO aipet_user;

--
-- Name: zt_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: aipet_user
--

CREATE SEQUENCE public.zt_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zt_policies_id_seq OWNER TO aipet_user;

--
-- Name: zt_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aipet_user
--

ALTER SEQUENCE public.zt_policies_id_seq OWNED BY public.zt_policies.id;


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: cloud_accounts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_accounts ALTER COLUMN id SET DEFAULT nextval('public.cloud_accounts_id_seq'::regclass);


--
-- Name: cloud_assets id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_assets ALTER COLUMN id SET DEFAULT nextval('public.cloud_assets_id_seq'::regclass);


--
-- Name: cloud_findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_findings ALTER COLUMN id SET DEFAULT nextval('public.cloud_findings_id_seq'::regclass);


--
-- Name: compliance_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results ALTER COLUMN id SET DEFAULT nextval('public.compliance_results_id_seq'::regclass);


--
-- Name: defense_actions id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_actions ALTER COLUMN id SET DEFAULT nextval('public.defense_actions_id_seq'::regclass);


--
-- Name: defense_playbooks id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_playbooks ALTER COLUMN id SET DEFAULT nextval('public.defense_playbooks_id_seq'::regclass);


--
-- Name: device_tags id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags ALTER COLUMN id SET DEFAULT nextval('public.device_tags_id_seq'::regclass);


--
-- Name: explain_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results ALTER COLUMN id SET DEFAULT nextval('public.explain_results_id_seq'::regclass);


--
-- Name: findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings ALTER COLUMN id SET DEFAULT nextval('public.findings_id_seq'::regclass);


--
-- Name: ioc_entries id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_entries ALTER COLUMN id SET DEFAULT nextval('public.ioc_entries_id_seq'::regclass);


--
-- Name: ioc_feeds id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_feeds ALTER COLUMN id SET DEFAULT nextval('public.ioc_feeds_id_seq'::regclass);


--
-- Name: mp_installs id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_installs ALTER COLUMN id SET DEFAULT nextval('public.mp_installs_id_seq'::regclass);


--
-- Name: mp_plugins id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_plugins ALTER COLUMN id SET DEFAULT nextval('public.mp_plugins_id_seq'::regclass);


--
-- Name: mp_reviews id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_reviews ALTER COLUMN id SET DEFAULT nextval('public.mp_reviews_id_seq'::regclass);


--
-- Name: ot_devices id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_devices ALTER COLUMN id SET DEFAULT nextval('public.ot_devices_id_seq'::regclass);


--
-- Name: ot_findings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_findings ALTER COLUMN id SET DEFAULT nextval('public.ot_findings_id_seq'::regclass);


--
-- Name: ot_scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_scans ALTER COLUMN id SET DEFAULT nextval('public.ot_scans_id_seq'::regclass);


--
-- Name: predict_alerts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts ALTER COLUMN id SET DEFAULT nextval('public.predict_alerts_id_seq'::regclass);


--
-- Name: protocol_scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans ALTER COLUMN id SET DEFAULT nextval('public.protocol_scans_id_seq'::regclass);


--
-- Name: remediation_kb id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb ALTER COLUMN id SET DEFAULT nextval('public.remediation_kb_id_seq'::regclass);


--
-- Name: rt_attacks id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_attacks ALTER COLUMN id SET DEFAULT nextval('public.rt_attacks_id_seq'::regclass);


--
-- Name: rt_campaigns id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_campaigns ALTER COLUMN id SET DEFAULT nextval('public.rt_campaigns_id_seq'::regclass);


--
-- Name: scans id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans ALTER COLUMN id SET DEFAULT nextval('public.scans_id_seq'::regclass);


--
-- Name: score_results id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results ALTER COLUMN id SET DEFAULT nextval('public.score_results_id_seq'::regclass);


--
-- Name: siem_events id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_events ALTER COLUMN id SET DEFAULT nextval('public.siem_events_id_seq'::regclass);


--
-- Name: siem_incidents id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_incidents ALTER COLUMN id SET DEFAULT nextval('public.siem_incidents_id_seq'::regclass);


--
-- Name: siem_rules id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_rules ALTER COLUMN id SET DEFAULT nextval('public.siem_rules_id_seq'::regclass);


--
-- Name: threat_matches id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches ALTER COLUMN id SET DEFAULT nextval('public.threat_matches_id_seq'::regclass);


--
-- Name: twin_edges id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_edges ALTER COLUMN id SET DEFAULT nextval('public.twin_edges_id_seq'::regclass);


--
-- Name: twin_nodes id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_nodes ALTER COLUMN id SET DEFAULT nextval('public.twin_nodes_id_seq'::regclass);


--
-- Name: twin_snapshots id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_snapshots ALTER COLUMN id SET DEFAULT nextval('public.twin_snapshots_id_seq'::regclass);


--
-- Name: user_settings id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_settings ALTER COLUMN id SET DEFAULT nextval('public.user_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: watch_alerts id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts ALTER COLUMN id SET DEFAULT nextval('public.watch_alerts_id_seq'::regclass);


--
-- Name: watch_baselines id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines ALTER COLUMN id SET DEFAULT nextval('public.watch_baselines_id_seq'::regclass);


--
-- Name: zt_access_log id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_access_log ALTER COLUMN id SET DEFAULT nextval('public.zt_access_log_id_seq'::regclass);


--
-- Name: zt_device_trust id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_device_trust ALTER COLUMN id SET DEFAULT nextval('public.zt_device_trust_id_seq'::regclass);


--
-- Name: zt_policies id; Type: DEFAULT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_policies ALTER COLUMN id SET DEFAULT nextval('public.zt_policies_id_seq'::regclass);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.api_keys (id, user_id, key_hash, name, last_used, created_at, is_active) FROM stdin;
1	1	2cf027461a731b41b3d9cc55789dedb5e73595fadbc678c157405ce5d5be3b28	My CI/CD Pipeline	\N	2026-03-30 16:28:58.227803	f
3	1	7b17991ccbdb3b7168b2520919490d2f8a94589b016f747c3216b50022ff38a0	End-to-end test	2026-03-31 20:15:39.858877	2026-03-31 20:13:29.613879	t
4	1	59f2a21c6276395ea2c8eb2e71fdd36f476471a7c1c25679caa85ba4c57d72ca	Test Key	\N	2026-04-09 16:34:43.62576	t
5	1	ca11c6af63b9dc2fae56f1a5be98236898e0fbaf5282f94c0a10047815177bb5	Test Key	\N	2026-04-09 16:34:56.359076	t
2	1	4582d10b9e9f90dff98b800eebd04b4971b8285781f4d6a22b2029e5f200c220	Production CI/CD	\N	2026-03-30 16:47:46.966119	f
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.audit_log (id, user_id, action, resource, ip_address, user_agent, "timestamp", status) FROM stdin;
2135e45c-be32-4552-897f-4535ea2ab136	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 00:30:46.088256	blocked
62527630-0b6c-4016-b894-6c11e8a256df	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 00:31:48.005888	blocked
eb9cf4ce-7bee-4edb-9e8f-71b0a9907faa	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 00:42:46.720903	blocked
61237597-770b-4846-af4c-f2d46f17f171	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 00:56:55.555092	blocked
c16de546-6eff-44f2-bf08-f05e3a04adfd	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 01:15:28.89233	blocked
fc2af1bd-c469-42f4-a068-2603b9cced89	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 02:39:02.856133	blocked
ae656c85-4dda-49a7-a7be-a517ad4a89d2	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 13:30:30.404773	blocked
cae4541f-3b16-47cc-9279-2bdd68af0fba	1	permission_denied:audit:read	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-16 19:38:23.547961	blocked
\.


--
-- Data for Name: cloud_accounts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_accounts (id, name, provider, account_id, region, status, asset_count, finding_count, last_scan, created_by, created_at) FROM stdin;
2	Azure NHS IoT Platform	azure	a1b2c3d4-e5f6-7890-abcd-ef1234567890	uksouth	connected	5	3	2026-04-16 19:54:02.215596	\N	2026-04-16 19:54:02.186342
3	GCP Analytics Platform	gcp	aipet-analytics-prod	europe-west2	connected	4	2	2026-04-16 19:54:02.223421	\N	2026-04-16 19:54:02.186343
4	On-Premise Data Centre	onprem	dc-london-01	London DC	connected	3	2	2026-04-16 19:54:02.233074	\N	2026-04-16 19:54:02.186344
1	AWS Production — EU West	aws	123456789012	eu-west-2	connected	6	3	2026-04-16 19:57:50.488421	\N	2026-04-16 19:54:02.186336
\.


--
-- Data for Name: cloud_assets; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_assets (id, account_id, asset_id, name, asset_type, provider, region, ip_address, tags, risk_score, public, encrypted, created_at) FROM stdin;
7	2	azure-iot_hub-001	Azure IoT Hub Production	iot_hub	azure	uksouth	\N	\N	53	t	t	2026-04-16 19:54:02.208377
8	2	azure-vm-002	IoT Edge Gateway VM	vm	azure	uksouth	\N	\N	53	t	t	2026-04-16 19:54:02.208383
9	2	azure-storage-003	Blob IoT Firmware Store	storage	azure	uksouth	\N	\N	43	f	f	2026-04-16 19:54:02.208383
10	2	azure-function-004	Azure IoT Function App	function	azure	uksouth	\N	\N	23	f	t	2026-04-16 19:54:02.208384
11	2	azure-kubernetes-005	AKS IoT Processing Cluster	kubernetes	azure	uksouth	\N	\N	23	f	t	2026-04-16 19:54:02.208384
12	3	gcp-iot_hub-001	Cloud IoT Core	iot_hub	gcp	europe-west2	\N	\N	53	t	t	2026-04-16 19:54:02.220034
13	3	gcp-storage-002	GCS IoT Certs Backup	storage	gcp	europe-west2	\N	\N	53	t	t	2026-04-16 19:54:02.22004
14	3	gcp-vm-003	IoT Gateway GCE Instance	vm	gcp	europe-west2	\N	\N	53	t	t	2026-04-16 19:54:02.220041
15	3	gcp-function-004	Cloud Functions IoT	function	gcp	europe-west2	\N	\N	23	f	t	2026-04-16 19:54:02.220041
16	4	onprem-vm-001	VMware IoT Management	vm	onprem	London DC	\N	\N	23	f	t	2026-04-16 19:54:02.230544
17	4	onprem-storage-002	NAS IoT Logs	storage	onprem	London DC	\N	\N	43	f	f	2026-04-16 19:54:02.230549
18	4	onprem-network-003	IoT VLAN Gateway	network	onprem	London DC	\N	\N	23	f	t	2026-04-16 19:54:02.230549
19	1	aws-vm-001	IoT Management Server	vm	aws	eu-west-2	\N	\N	68	t	t	2026-04-16 19:57:50.48561
20	1	aws-iot_hub-002	AWS IoT Core	iot_hub	aws	eu-west-2	\N	\N	68	t	t	2026-04-16 19:57:50.485615
21	1	aws-storage-003	S3 IoT Config Bucket	storage	aws	eu-west-2	\N	\N	88	t	f	2026-04-16 19:57:50.485616
22	1	aws-database-004	IoT Telemetry RDS	database	aws	eu-west-2	\N	\N	58	f	f	2026-04-16 19:57:50.485616
23	1	aws-function-005	IoT Lambda Processor	function	aws	eu-west-2	\N	\N	38	f	t	2026-04-16 19:57:50.485617
24	1	aws-container-006	ECS IoT Gateway	container	aws	eu-west-2	\N	\N	38	f	t	2026-04-16 19:57:50.485617
\.


--
-- Data for Name: cloud_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.cloud_findings (id, account_id, asset_id, provider, finding_type, severity, title, description, resource, remediation, mitre_id, created_at) FROM stdin;
5	2	\N	azure	iot_hub_exposed	Critical	Azure IoT Hub management API publicly accessible	The Azure IoT Hub service endpoint is accessible from the internet without IP restrictions. Device registration and management APIs are exposed.	iot-hub-production.azure-devices.net	Configure IoT Hub IP filter rules. Use Private Endpoint for IoT Hub. Restrict management API to VNet only.	T1190	2026-04-16 19:54:02.221502
6	2	\N	azure	unencrypted_storage	High	Azure Blob Storage container with HTTP access enabled	A storage container allows HTTP (unencrypted) access. IoT device firmware and configuration files can be intercepted in transit.	storageaccount.blob.core.windows.net/iot-firmware	Enable 'Secure transfer required' on storage account. Disable HTTP access and enforce HTTPS only.	T1557	2026-04-16 19:54:02.221505
7	2	\N	azure	no_logging	Medium	Azure Monitor diagnostic logs not configured	Azure IoT Hub and Key Vault resources have no diagnostic logging configured. Security events, access attempts, and configuration changes are not captured.	IoT Hub + Key Vault — diagnostic settings missing	Enable diagnostic settings on all resources. Send logs to Log Analytics workspace. Configure alerts for critical events.	T1562	2026-04-16 19:54:02.221506
8	3	\N	gcp	public_storage	Critical	GCS bucket allUsers has storage.objects.get permission	A Google Cloud Storage bucket grants read access to allUsers (public internet). IoT device certificates and private keys may be exposed.	gs://iot-certs-backup	Remove allUsers and allAuthenticatedUsers from IAM. Enable uniform bucket-level access. Audit bucket contents for sensitive files.	T1530	2026-04-16 19:54:02.231831
9	3	\N	gcp	overprivileged_role	High	GCP service account has project Owner role	A service account used by IoT processing pipelines has project Owner IAM role. Compromise of this account gives full control of the entire GCP project.	iot-processor@project.iam.gserviceaccount.com	Replace Owner role with specific roles (e.g., pubsub.publisher). Apply principle of least privilege to all service accounts.	T1078.004	2026-04-16 19:54:02.231834
10	4	\N	onprem	weak_credentials	Critical	On-premise management server using default credentials	VMware vCenter server is accessible with default administrator credentials. All virtual machines hosting IoT workloads can be compromised.	vcenter.internal — admin/vmware (default)	Change all default credentials immediately. Enable vCenter SSO with AD integration. Implement privileged access workstation (PAW) policy.	T1078	2026-04-16 19:54:02.236788
11	4	\N	onprem	unencrypted_storage	High	On-premise NAS share without encryption	Network Attached Storage share containing IoT device logs and configurations is accessible over SMB without encryption. Traffic visible on internal network.	\\\\nas01\\iot-logs (SMBv1 without signing)	Disable SMBv1. Enable SMB signing and encryption. Migrate to SMBv3 with AES-128-CCM encryption.	T1557	2026-04-16 19:54:02.236794
12	1	\N	aws	public_storage	Critical	S3 bucket publicly accessible — data exposure risk	An S3 bucket has public read access enabled. Any internet user can list and download bucket contents including IoT device configurations and certificates.	s3://iot-device-configs-prod	Remove public ACL from S3 bucket. Enable S3 Block Public Access at account level. Review bucket policy for overly permissive rules.	T1530	2026-04-16 19:57:50.497602
13	1	\N	aws	open_security_group	Critical	EC2 security group allows all inbound traffic (0.0.0.0/0)	An EC2 security group has an inbound rule permitting all traffic from any IP address on all ports. IoT management server is exposed to the entire internet.	sg-0abc123def456789 (IoT Management Server)	Remove 0.0.0.0/0 inbound rules. Restrict access to specific IP ranges or VPC CIDRs only.	T1190	2026-04-16 19:57:50.497608
14	1	\N	aws	no_logging	High	AWS CloudTrail logging disabled in IoT region	CloudTrail is not enabled in the eu-west-2 region. All API calls, configuration changes, and user actions in this region are unaudited and undetectable.	CloudTrail — eu-west-2	Enable CloudTrail in all active regions. Enable log file validation. Send CloudTrail logs to CloudWatch for alerting.	T1562.008	2026-04-16 19:57:50.497609
\.


--
-- Data for Name: compliance_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.compliance_results (id, user_id, scan_id, framework, score, total, controls, created_at) FROM stdin;
1	1	12	nis2	100	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "pass", "impact": "low"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "pass", "impact": "low"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "pass", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "pass", "impact": "low"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "pass", "impact": "low"}]	2026-04-05 03:37:48.07048
2	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:00.935568
3	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:24.900825
4	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-05 03:45:36.414102
5	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-05 03:45:49.845372
6	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-05 04:30:40.252263
7	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-06 02:29:56.849636
8	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-06 02:30:04.723787
9	1	9	iso27001	0	10	[{"id": "ISO-5.1", "clause": "5.1", "title": "Information security policies", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-5.15", "clause": "5.15", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-5.23", "clause": "5.23", "title": "Cloud services security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-6.8", "clause": "6.8", "title": "Information security events", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.7", "clause": "8.7", "title": "Protection against malware", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "ISO-8.8", "clause": "8.8", "title": "Management of vulnerabilities", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.12", "clause": "8.12", "title": "Data leakage prevention", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "ISO-8.20", "clause": "8.20", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "ISO-8.22", "clause": "8.22", "title": "Web filtering", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "ISO-8.29", "clause": "8.29", "title": "Secure coding", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}]	2026-04-06 02:30:09.185256
10	1	9	nist	0	10	[{"id": "NIST-GV1", "function": "GOVERN", "title": "Organisational context", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-ID1", "function": "IDENTIFY", "title": "Asset management", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIST-ID2", "function": "IDENTIFY", "title": "Risk assessment", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-PR1", "function": "PROTECT", "title": "Identity management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR2", "function": "PROTECT", "title": "Awareness and training", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIST-PR3", "function": "PROTECT", "title": "Data security", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-PR4", "function": "PROTECT", "title": "Platform security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-DE1", "function": "DETECT", "title": "Continuous monitoring", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIST-RS1", "function": "RESPOND", "title": "Incident management", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIST-RC1", "function": "RECOVER", "title": "Incident recovery", "severity": ["critical", "high"], "status": "fail", "impact": "high"}]	2026-04-06 02:30:51.437074
11	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-09 16:09:07.467959
12	1	9	nis2	0	10	[{"id": "NIS2-1", "article": "Article 21a", "title": "Risk analysis", "severity": ["critical", "high", "medium", "low"], "status": "fail", "impact": "high"}, {"id": "NIS2-2", "article": "Article 21b", "title": "Incident handling", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-3", "article": "Article 21c", "title": "Business continuity", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-4", "article": "Article 21d", "title": "Supply chain security", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-5", "article": "Article 21e", "title": "Network security", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}, {"id": "NIS2-6", "article": "Article 21f", "title": "Access control", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-7", "article": "Article 21g", "title": "Cryptography", "severity": ["high", "medium"], "status": "fail", "impact": "medium"}, {"id": "NIS2-8", "article": "Article 21h", "title": "Human resources security", "severity": ["medium", "low"], "status": "fail", "impact": "low"}, {"id": "NIS2-9", "article": "Article 21i", "title": "Authentication", "severity": ["critical", "high"], "status": "fail", "impact": "high"}, {"id": "NIS2-10", "article": "Article 21j", "title": "Vulnerability disclosure", "severity": ["critical", "high", "medium"], "status": "fail", "impact": "high"}]	2026-04-09 16:33:08.107816
\.


--
-- Data for Name: defense_actions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.defense_actions (id, playbook_id, playbook_name, action_type, target, status, reason, outcome, triggered_by, created_at) FROM stdin;
1	1	Auto-quarantine critical devices	quarantine_device	192.168.1.1	executed	Auto-response to Critical SIEM event: Telnet exposed	Device 192.168.1.1 quarantined in Zero-Trust	event:2	2026-04-16 14:14:49.710418
2	1	Auto-quarantine critical devices	create_incident	192.168.1.1	executed	Auto-response to Critical SIEM event: Telnet exposed	SIEM incident created for 192.168.1.1	event:2	2026-04-16 14:14:49.710418
3	1	Auto-quarantine critical devices	send_alert	192.168.1.2	executed	Auto-response to Critical SIEM event: Default credentials	Critical alert pushed to SIEM for 192.168.1.2	event:1	2026-04-16 14:09:49.710418
4	2	Block malicious IP on detection	block_ip	91.219.28.12	executed	Threat Intel match: C2 server detected	Block event logged for IP 91.219.28.12	event:5	2026-04-16 11:14:49.710418
5	3	Reassess trust on scan findings	reassess_trust	192.168.1.3	executed	New scan finding on 192.168.1.3	Trust reassessed: 192.168.1.3 score=72 status=monitored	event:3	2026-04-16 15:14:49.710418
6	1	Auto-quarantine critical devices	quarantine_device	192.168.1.2	executed	Manual trigger of playbook: Auto-quarantine critical devices	Device 192.168.1.2 quarantined in Zero-Trust	manual:user:1	2026-04-16 16:20:46.289825
7	1	Auto-quarantine critical devices	create_incident	192.168.1.2	executed	Manual trigger of playbook: Auto-quarantine critical devices	SIEM incident created for 192.168.1.2	manual:user:1	2026-04-16 16:20:46.289832
8	1	Auto-quarantine critical devices	send_alert	192.168.1.2	executed	Manual trigger of playbook: Auto-quarantine critical devices	Critical alert pushed to SIEM for 192.168.1.2	manual:user:1	2026-04-16 16:20:46.289833
\.


--
-- Data for Name: defense_playbooks; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.defense_playbooks (id, name, description, enabled, trigger_field, trigger_op, trigger_value, actions, cooldown_minutes, trigger_count, last_triggered, created_by, created_at) FROM stdin;
2	Block malicious IP on detection	Block and alert when a Threat Intel match is found in the SIEM feed	t	event_type	eq	threat_intel	["block_ip", "create_incident", "send_alert"]	5	2	2026-04-16 11:14:49.704342	\N	2026-04-16 16:14:49.705759
3	Reassess trust on scan findings	Recalculate Zero-Trust score for a device when new scan findings arrive	t	event_type	eq	scan_finding	["reassess_trust", "send_alert"]	15	5	2026-04-16 15:14:49.704342	\N	2026-04-16 16:14:49.70576
4	Respond to brute force attacks	Quarantine source device and create incident when brute force is detected	t	title	contains	failed login	["quarantine_device", "block_ip", "create_incident"]	30	1	2026-04-16 08:14:49.704342	\N	2026-04-16 16:14:49.705761
5	Alert on Zero-Trust policy violations	Send alert when a Zero-Trust block or quarantine action is logged	t	event_type	eq	zero_trust	["send_alert", "create_incident"]	5	2	2026-04-16 13:14:49.704342	\N	2026-04-16 16:14:49.705761
1	Auto-quarantine critical devices	Immediately quarantine any device that generates a Critical SIEM event	t	severity	eq	Critical	["quarantine_device", "create_incident", "send_alert"]	10	4	2026-04-16 16:20:46.286197	\N	2026-04-16 16:14:49.705756
\.


--
-- Data for Name: device_tags; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.device_tags (id, user_id, device_ip, business_function, industry, created_at, updated_at) FROM stdin;
1	1	192.168.1.1	Infrastructure / Network	Education	2026-04-04 03:40:12.604108	2026-04-04 03:40:12.604111
2	1	192.168.1.2	Customer Data	Education	2026-04-04 03:40:12.606089	2026-04-04 03:40:12.606091
3	1	192.168.1.3	Operations / Manufacturing	Education	2026-04-04 03:40:12.607352	2026-04-04 03:40:12.607354
4	1	192.168.1.4	Financial / Payment	Education	2026-04-04 03:40:12.609235	2026-04-04 03:40:12.609237
\.


--
-- Data for Name: explain_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.explain_results (id, scan_id, finding_id, explain_type, content, model_used, tokens_used, created_at) FROM stdin;
1	9	2	finding	WHY THIS IS DANGEROUS\nYour device is essentially leaving its front door wide open with a welcome mat for attackers. Anyone on your network can remotely take complete control of this device, access all its data, and use it as a launching pad to attack other systems in your organization. In the worst case, criminals could shut down your operations, steal sensitive information, or hold your entire network hostage for ransom.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour confidential data, customer information, and business operations are all at serious risk of being compromised or completely disrupted. If you handle sensitive information like patient records or financial data, this vulnerability could lead to massive regulatory fines and legal liability when that information gets stolen.	claude-sonnet-4-20250514	155	2026-04-03 19:03:53.670008
3	9	3	finding	WHY THIS IS DANGEROUS\nThis device is still using the factory-set username and password that came with it, which means anyone can look up these credentials online and gain complete control of the device. An attacker could use this access to spy on your operations, steal sensitive information, or use the device as a stepping stone to break into other systems on your network. In the worst case, they could shut down critical operations, steal customer data, or plant malicious software that spreads throughout your entire organization.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour confidential business data, customer information, and operational systems are all at immediate risk of unauthorized access and theft. Depending on your industry, this could result in expensive regulatory fines, legal liability, and complete shutdown of business operations until the security breach is contained.	claude-sonnet-4-20250514	172	2026-04-03 19:08:29.903672
4	9	5	finding	WHY THIS IS DANGEROUS\nThis device is like having a building with no security guards or locked doors - anyone on your network can walk right in and take control of it. An attacker could use this device as their base of operations to spy on your network, steal sensitive information, or launch attacks against other systems in your organization. In the worst case, they could shut down critical operations, access patient records or financial data, or use your network to attack other businesses.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour business operations could be disrupted if someone gains unauthorized access to this device and uses it to interfere with other connected systems or steal confidential information. Depending on your industry, this security gap could also put you at risk of failing compliance audits or facing regulatory penalties for not properly protecting sensitive data.	claude-sonnet-4-20250514	172	2026-04-03 23:06:06.17326
5	9	4	finding	WHY THIS IS DANGEROUS\n\nThis device is sending and receiving messages without any protection, like having phone conversations on a loudspeaker that anyone nearby can hear. An attacker on your network could intercept sensitive information being transmitted, spy on your operations, or even send fake commands to control connected equipment. In the worst case, this could allow someone to manipulate your IoT devices, steal confidential data, or disrupt critical business processes.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\n\nYour organization faces potential data breaches where sensitive operational information could be stolen, and there's a risk that attackers could interfere with or take control of connected devices and systems. This vulnerability could lead to compliance violations, regulatory fines, operational downtime, and loss of customer trust if security incidents occur.	claude-sonnet-4-20250514	168	2026-04-03 23:07:12.799799
6	1	1	finding	WHY THIS IS DANGEROUS\nYour IoT device is essentially leaving its front door wide open with no lock, allowing anyone on your network to walk right in and take complete control. An attacker could use this device as a launching pad to access your entire network, steal sensitive data like customer information or financial records, or completely shut down your operations. In the worst case, they could hold your entire business hostage by encrypting all your files and demanding payment to get them back.\n\nWHAT THIS MEANS FOR YOUR BUSINESS\nYour business operations could be completely disrupted if an attacker gains access, potentially costing thousands in lost revenue and emergency IT repairs. Any sensitive customer data, employee records, or financial information stored on your network could be stolen, leading to regulatory fines and serious damage to your company's reputation.	claude-sonnet-4-20250514	172	2026-04-03 23:16:25.73228
48	9	\N	executive_report	EXECUTIVE SUMMARY\n\nOur cybersecurity team conducted a comprehensive assessment of the organization's network infrastructure, evaluating 4 critical business systems. The assessment reveals a HIGH risk security posture with 4 significant vulnerabilities identified, including 2 critical-severity issues that require immediate remediation.\n\nKEY RISKS IDENTIFIED\n\n• Unsecured remote access channels allow attackers to gain direct control of core network equipment, potentially causing complete system shutdown or data theft\n\n• Default login credentials on critical systems provide easy entry points for cybercriminals, who commonly exploit these well-known password combinations to access sensitive business data\n\n• Unprotected data transmission channels expose confidential business communications and customer information as it travels across the network, making interception simple for malicious actors\n\n• Missing network security barriers leave systems vulnerable to both external attacks and internal threats, with no mechanism to detect or prevent unauthorized access attempts\n\nIMMEDIATE ACTIONS REQUIRED\n\n1. Disable all remote access services on the primary network router (192.168.1.1) immediately and replace with secure encrypted alternatives within 48 hours\n\n2. Change all default usernames and passwords on the secondary system (192.168.1.2) to complex, unique credentials and implement mandatory password changes every 90 days\n\n3. Install and configure network firewall protection on the unprotected system (192.168.1.4) and establish baseline security rules to block unauthorized traffic\n\nOVERALL SECURITY ASSESSMENT\n\nThe organization's current security posture presents serious operational and financial risks that demand urgent executive attention. With 2 critical vulnerabilities providing direct pathways for cybercriminals to access our systems, the likelihood of a successful attack is extremely high if no action is taken. The absence of basic security controls across multiple systems indicates systemic security gaps that could result in significant business disruption, regulatory penalties, and reputational damage. However, the identified vulnerabilities are well-understood issues with proven solutions, meaning rapid improvement is achievable with proper resource allocation and management commitment to implementing the recommended security measures.	claude-sonnet-4-20250514	435	2026-04-04 12:39:20.605739
\.


--
-- Data for Name: findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.findings (id, scan_id, module, attack, severity, description, target, created_at, fix_status, fix_notes) FROM stdin;
1	1	network	open_telnet	Critical	Telnet service detected on port 23	192.168.1.1	\N	fixed	Telnet disabled and removed on 3 April 2026
2	9	network	open_telnet	Critical	Telnet service detected on port 23	192.168.1.1	\N	open	\N
3	9	network	default_credentials	Critical	Default credentials accepted on admin panel	192.168.1.2	\N	open	\N
4	9	mqtt	unencrypted_mqtt	High	MQTT broker running without TLS on port 1883	192.168.1.3	\N	open	\N
5	9	network	no_firewall	Medium	No firewall rules configured on device	192.168.1.4	\N	open	\N
\.


--
-- Data for Name: ioc_entries; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ioc_entries (id, feed_id, ioc_type, value, threat_type, confidence, severity, description, source_ref, active, created_at, expires_at) FROM stdin;
1	1	ip	185.220.101.45	tor_exit_node	95	High	Known Tor exit node — frequently used for anonymous scanning and attacks	https://www.dan.me.uk/torlist/	t	2026-04-16 15:36:54.69434	\N
3	1	ip	45.142.212.100	scanner	85	Medium	Mass internet scanner — performs automated IoT vulnerability scanning on port 23, 2323, 8080	https://www.shodan.io	t	2026-04-16 15:36:54.694351	\N
4	1	ip	194.165.16.78	botnet	92	Critical	Active botnet C2 — recruiting vulnerable IoT devices via default credential brute force	https://threatfox.abuse.ch	t	2026-04-16 15:36:54.694352	\N
5	1	domain	malware-c2.duckdns.org	c2	99	Critical	Dynamic DNS domain used as C2 for IoT malware — seen in Mozi botnet traffic	https://abuse.ch	t	2026-04-16 15:36:54.694353	\N
6	1	ip	5.188.206.14	malware	88	High	Malware distribution server — hosts IoT exploit payloads targeting CVE-2023-1389	https://threatfox.abuse.ch	t	2026-04-16 15:36:54.694353	\N
7	1	ip	80.82.77.33	scanner	78	Medium	Shodan crawler — automated internet-wide scanning. Not malicious but indicates your device is visible	https://www.shodan.io	t	2026-04-16 15:36:54.694354	\N
8	1	hash	d41d8cd98f00b204e9800998ecf8427e	malware	100	Critical	Known IoT malware hash — Mirai variant targeting MIPS architecture devices	https://www.virustotal.com	t	2026-04-16 15:36:54.694354	\N
\.


--
-- Data for Name: ioc_feeds; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ioc_feeds (id, name, feed_type, description, enabled, api_key, last_sync, entry_count, created_at) FROM stdin;
2	AbuseIPDB	abuseipdb	Crowdsourced malicious IP database — 3M+ reported IPs, 1,000 free lookups/day	t	\N	\N	0	2026-04-16 15:36:54.680814
1	Local IOC Database	local	Manually curated indicators — your own threat hunting, IR findings, ISAC sharing	t	\N	2026-04-16 15:36:54.678626	8	2026-04-16 15:36:54.680809
\.


--
-- Data for Name: mp_installs; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.mp_installs (id, plugin_id, user_id, config, enabled, installed_at) FROM stdin;
1	4	1	{}	t	2026-04-16 20:33:32.41759
\.


--
-- Data for Name: mp_plugins; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.mp_plugins (id, name, slug, description, long_desc, category, publisher, version, icon, tags, verified, free, price_gbp, install_count, avg_rating, review_count, active, created_at) FROM stdin;
1	Jira Security Tickets	jira-security-tickets	Automatically create Jira issues for every AIPET finding. Assign to teams, set priorities, track remediation.	Full bidirectional sync between AIPET findings and Jira. When AIPET discovers a Critical vulnerability, a P1 Jira ticket is created instantly with full context, CVSS score, and remediation steps. When the ticket is resolved in Jira, AIPET marks the finding as remediated.	integration	AIPET Official	2.1.0	🎫	["jira", "ticketing", "remediation", "devops"]	t	t	0	847	4.8	124	t	2026-01-16 19:30:21.764667
2	PagerDuty Incident Alerts	pagerduty-incidents	Route Critical AIPET SIEM events to PagerDuty. Wake up your on-call engineer when it matters.	Maps AIPET severity levels to PagerDuty urgency. Critical = P1 page. High = P2 alert. Includes escalation policies and acknowledgement sync.	integration	AIPET Official	1.3.2	📟	["pagerduty", "oncall", "alerting", "sre"]	t	t	0	612	4.7	89	t	2026-01-31 19:30:21.764667
3	ServiceNow ITSM Bridge	servicenow-itsm	Enterprise ITSM integration. Sync AIPET findings with ServiceNow incidents, change requests, and CMDB.	Connects AIPET X to ServiceNow via REST API. Findings become incidents. Device inventory syncs to CMDB. Compliance results trigger change requests. Full audit trail maintained in both systems.	integration	SecureOps Ltd	1.0.5	🔧	["servicenow", "itsm", "cmdb", "enterprise"]	t	f	29	234	4.5	41	t	2026-02-15 19:30:21.764667
5	Splunk HEC Forwarder	splunk-hec-forwarder	Forward all AIPET events to Splunk via HTTP Event Collector. Full JSON schema with sourcetype mappings included.	Streams AIPET SIEM events, scan findings, and compliance results to Splunk HEC in real time. Includes pre-built Splunk dashboards, saved searches, and alert configurations.	integration	Splunk Community	3.0.1	📊	["splunk", "siem", "log-management", "analytics"]	t	t	0	489	4.6	67	t	2026-01-26 19:30:21.764667
6	Zigbee Security Scanner	zigbee-scanner	Scan Zigbee mesh networks for security issues. Detects unencrypted traffic, weak keys, and rogue devices.	Full Zigbee security assessment including network key extraction, device enumeration, traffic capture, and replay attack detection. Requires Zigbee USB adapter (CC2531 or similar).	scan_module	IoTSec Research	1.2.0	📡	["zigbee", "wireless", "iot", "mesh"]	t	f	49	156	4.4	28	t	2026-03-02 19:30:21.764667
7	LoRaWAN Security Audit	lorawan-audit	Assess LoRaWAN network security. Tests join procedure, frame counter, and ABP vs OTAA configuration.	Comprehensive LoRaWAN security assessment covering AppKey/NwkKey exposure, DevEUI enumeration, frame counter replay, and ADR manipulation. Essential for smart city and industrial IoT deployments.	scan_module	IoTSec Research	1.0.3	📻	["lorawan", "lpwan", "wireless", "smart-city"]	t	f	49	98	4.3	19	t	2026-03-17 19:30:21.764667
8	CVE Auto-Enricher	cve-auto-enricher	Automatically enrich every finding with EPSS scores, PoC availability, and active exploitation status from multiple threat intel sources.	Integrates with NVD, ExploitDB, CISA KEV, and AttackerKB to provide real-time exploit availability scores. Shows whether a CVE has active exploits in the wild, EPSS probability scores, and CISA Known Exploited status.	scan_module	AIPET Official	2.0.0	🔍	["cve", "enrichment", "threat-intel", "epss"]	t	t	0	723	4.9	145	t	2026-01-06 19:30:21.764667
9	ISO 27001 Compliance Report	iso-27001-report	Generate audit-ready ISO 27001 compliance reports from AIPET scan data. Maps all findings to Annex A controls.	Professional ISO 27001 report template with automatic control mapping, gap analysis, risk register, and statement of applicability. Accepted by major certification bodies including BSI, Lloyd's Register, and Bureau Veritas.	report_template	CompliancePro	3.1.0	📋	["iso27001", "compliance", "audit", "certification"]	t	f	79	312	4.7	54	t	2025-11-17 19:30:21.764667
10	NHS DSPT Assessment Template	nhs-dspt-template	Data Security and Protection Toolkit report template. Maps AIPET findings to DSPT assertions for NHS organisations.	Specifically designed for NHS trusts and healthcare organisations. Automatically maps IoT security findings to DSPT mandatory evidence items. Includes supporting evidence documentation and board-level summary.	report_template	HealthTech Security	2.0.1	🏥	["nhs", "dspt", "healthcare", "uk-compliance"]	t	f	99	187	4.8	38	t	2026-02-15 19:30:21.764667
11	NHS Cybersecurity AI Pack	nhs-ai-pack	Custom AI SOC analyst trained on NHS cybersecurity frameworks, DSPT requirements, and healthcare IoT threats.	Extends the AIPET AI SOC with NHS-specific knowledge including DSPT v6 requirements, NHS Digital security standards, clinical network segmentation best practices, and medical device cybersecurity guidance.	ai_pack	HealthTech Security	1.1.0	🤖	["nhs", "healthcare", "ai", "compliance"]	t	f	39	143	4.6	27	t	2026-03-07 19:30:21.764667
12	ICS/OT Specialist AI Pack	ics-ot-ai-pack	AI SOC analyst specialised in industrial control systems — Purdue Model, IEC 62443, NERC CIP, and OT incident response.	Deep expertise in industrial cybersecurity including IEC 62443 zone and conduit model, NERC CIP compliance for power utilities, ISA/IEC standards, and OT-specific incident response playbooks.	ai_pack	IndustrialCyber Ltd	1.0.2	🏭	["ics", "ot", "ai", "industrial"]	t	f	49	89	4.5	18	t	2026-03-22 19:30:21.764667
13	IoT Threat Intelligence Feed	iot-threat-feed	Daily updated IOC feed specifically for IoT devices — Mirai C2s, IoT botnet IPs, vulnerable firmware hashes.	Curated threat intelligence feed focused entirely on IoT threats. Updated daily with C2 servers, botnet infrastructure, known malicious IoT firmware hashes, and IP ranges associated with IoT-targeting threat actors.	threat_feed	ThreatFox Community	live	🎯	["threat-intel", "ioc", "iot", "botnet"]	t	t	0	534	4.7	92	t	2025-09-28 20:30:21.764667
14	CISA KEV Sync	cisa-kev-sync	Automatically flag AIPET findings that match CISA Known Exploited Vulnerabilities catalogue. Updated daily.	Syncs with CISA Known Exploited Vulnerabilities (KEV) catalogue daily. Any AIPET CVE finding that appears in the KEV catalogue is immediately flagged as actively exploited and escalated to Critical priority.	threat_feed	AIPET Official	1.4.0	🇺🇸	["cisa", "kev", "cve", "government"]	t	t	0	891	4.9	167	t	2025-10-18 20:30:21.764667
15	Executive Risk Dashboard	exec-risk-dashboard	Board-level security metrics widget. Clean, visual risk summary designed for non-technical executives.	A single-page executive dashboard widget showing: overall risk trend (30 days), top 3 risks in plain English, compliance status traffic lights, and financial exposure estimate. Designed to be shared at board meetings.	dashboard_widget	AIPET Official	1.2.0	📈	["executive", "dashboard", "reporting", "board"]	t	t	0	445	4.6	78	t	2026-01-16 19:30:21.764667
4	Microsoft Teams Alerts	ms-teams-alerts	Rich adaptive card notifications to Teams channels. Critical findings include device context, risk score, and one-click remediation links.	Beautiful adaptive cards with colour-coded severity, device details, MITRE ATT&CK mappings, and direct links to the AIPET dashboard. Supports multiple channel routing based on severity or device type.	integration	AIPET Official	1.5.0	💬	["teams", "microsoft", "notifications", "collaboration"]	t	t	0	1204	4.9	201	t	2025-12-17 19:30:21.764667
\.


--
-- Data for Name: mp_reviews; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.mp_reviews (id, plugin_id, user_id, rating, review, created_at) FROM stdin;
\.


--
-- Data for Name: ot_devices; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ot_devices (id, device_ip, device_name, protocol, port, vendor, model, firmware, zone, criticality, location, last_seen, online, created_at) FROM stdin;
1	10.0.1.10	Main Production PLC	modbus	502	Schneider Electric	Modicon M340	2.60	field	critical	Production Floor — Zone A	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889598
2	10.0.1.11	Water Treatment RTU	dnp3	20000	ABB	RTU560	11.7.3	field	critical	Water Treatment Plant — Building 3	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889602
3	10.0.2.20	Substation Protection IED	iec61850	102	Siemens	SIPROTEC 5	9.20	control	critical	Electrical Substation — Room 1	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889602
4	10.0.2.21	Assembly Line Controller	ethernetip	44818	Rockwell Automation	ControlLogix 5580	20.011	control	high	Assembly Line — Station 4	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889603
5	10.0.3.30	HVAC Building Controller	bacnet	47808	Johnson Controls	Metasys NAE55	10.0.5	supervisory	medium	Facilities — BMS Room	2026-04-16 19:38:20.887992	t	2026-04-16 19:38:20.889603
6	10.0.3.31	Pump Station RTU	modbus	502	Emerson	ROC800	3.80	field	high	Pump Station — Outbuilding 2	2026-04-16 17:38:20.887992	t	2026-04-16 19:38:20.889603
\.


--
-- Data for Name: ot_findings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ot_findings (id, scan_id, device_ip, protocol, finding_type, severity, title, description, evidence, mitre_ics_id, remediation, created_at) FROM stdin;
1	1	10.0.1.10	modbus	unauthenticated_access	Critical	Modbus TCP has no authentication — any device can send commands	Modbus TCP accepts commands without credentials. Main Production PLC (Schneider Modicon M340) is fully exposed.	Function code 0x01 accepted without credentials on Unit ID 1	T0817	Deploy Modbus firewall. Implement network segmentation.	2026-04-16 16:38:20.895533
2	1	10.0.1.10	modbus	coil_write_enabled	Critical	Modbus coil writing enabled — production line physically controllable	Write Multiple Coils (FC 0x0F) accepted. An attacker can directly start/stop the production line.	Function code 0x0F accepted on Unit ID 1, Coils 0-15	T0831	Block write function codes at firewall. Implement read-only Modbus proxy.	2026-04-16 16:38:20.895533
3	1	10.0.1.10	modbus	network_exposure	High	Modbus PLC reachable from corporate IT network	Production PLC TCP port 502 responds to connections from the corporate IT subnet — OT/IT boundary not enforced.	TCP port 502 responding from 10.0.1.10 to IT subnet 192.168.1.0/24	T0886	Implement industrial DMZ. Deploy data diode.	2026-04-16 16:38:20.895533
4	2	10.0.1.11	dnp3	unauthenticated_access	Critical	DNP3 Secure Authentication not enabled on water treatment RTU	DNP3 SA v5 not configured on Water Treatment RTU. Spoofed commands could open/close water treatment valves.	DNP3 master-outstation handshake without SA challenge	T0817	Enable DNP3 SA v5 with HMAC-SHA256.	2026-04-16 17:38:20.895533
5	2	10.0.1.11	dnp3	unencrypted_comms	High	DNP3 water treatment SCADA commands transmitted unencrypted	All commands to Water Treatment RTU transmitted in cleartext. Sensor readings and valve commands visible to network observers.	DNP3 application layer captured without decryption required	T0885	Tunnel DNP3 over TLS.	2026-04-16 17:38:20.895533
6	3	10.0.2.20	iec61850	network_exposure	Critical	IEC 61850 MMS server exposed — substation circuit breakers accessible	MMS service on Siemens SIPROTEC 5 accessible without restriction. Circuit breaker control and protection relay settings readable.	MMS connection established on TCP 102 from test host	T0886	Restrict MMS to engineering workstations. Implement IEC 62351-4 TLS.	2026-04-16 18:38:20.895533
7	3	10.0.2.20	iec61850	insecure_config	High	IEC 61850 GOOSE messages unsigned — protection relay bypass risk	GOOSE messages not cryptographically signed. Attacker on substation LAN could trigger false protection trips.	GOOSE PDU captured without signature field	T0820	Implement IEC 62351-6 GOOSE signing.	2026-04-16 18:38:20.895533
8	4	10.0.2.21	ethernetip	unauthenticated_access	Critical	EtherNet/IP CIP device accessible without authentication	Common Industrial Protocol (CIP) service accepts connections without authentication. Rockwell/Allen-Bradley PLCs with unauthenticated CIP access can have their logic read and potentially modified by any network host.	CIP Forward Open service accepted connection without identity challenge	T0817	Enable CIP Security using TLS and DTLS. Configure device-level firewall on managed switches. Upgrade to controllers supporting CIP Security.	2026-04-16 19:43:15.817626
9	4	10.0.2.21	ethernetip	firmware_outdated	High	EtherNet/IP device firmware has known vulnerabilities	The detected firmware version is affected by published CVEs including buffer overflow vulnerabilities in the CIP stack that could allow remote code execution.	Firmware version 20.011 — affects CVE-2020-6998, CVE-2021-27478	T0857	Update firmware to latest vendor release. Apply vendor security patches immediately. Isolate device until patching is complete.	2026-04-16 19:43:15.817628
10	5	10.0.1.10	modbus	unauthenticated_access	Critical	Modbus TCP has no authentication — any device can send commands	Modbus TCP protocol has no built-in authentication mechanism. Any host on the network can read sensor data and write control commands to connected PLCs and field devices.	Function code 0x01 (Read Coils) accepted without credentials	T0817	Deploy Modbus firewall or application-aware gateway. Implement network segmentation to isolate Modbus devices. Use VPN for any remote access to Modbus networks.	2026-04-16 19:44:19.9946
11	5	10.0.1.10	modbus	coil_write_enabled	Critical	Modbus coil writing enabled — physical control registers writable	Modbus Function Code 0x0F (Write Multiple Coils) is enabled. An attacker can write to coil registers to directly control connected physical equipment such as motors, valves, and relays.	Function code 0x0F accepted on Unit ID 1	T0831	Disable write function codes at the firewall level. Implement read-only Modbus proxy for monitoring systems. Require explicit authorisation for any write operations.	2026-04-16 19:44:19.994602
\.


--
-- Data for Name: ot_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.ot_scans (id, target, protocol, status, findings_count, risk_level, scan_duration, user_id, created_at, completed_at) FROM stdin;
1	10.0.1.10	modbus	completed	3	CRITICAL	2.4	\N	2026-04-16 16:38:20.895533	2026-04-16 16:38:20.895533
2	10.0.1.11	dnp3	completed	2	HIGH	1.8	\N	2026-04-16 17:38:20.895533	2026-04-16 17:38:20.895533
3	10.0.2.20	iec61850	completed	2	CRITICAL	3.1	\N	2026-04-16 18:38:20.895533	2026-04-16 18:38:20.895533
4	10.0.2.21	ethernetip	completed	2	CRITICAL	0	1	2026-04-16 19:43:15.814686	2026-04-16 19:43:15.816096
5	10.0.1.10	modbus	completed	2	CRITICAL	0	2	2026-04-16 19:44:19.993357	2026-04-16 19:44:19.994293
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.permissions (id, name, description, resource, action) FROM stdin;
ea1f061a-72b4-44d8-98ff-27772e4e3a5c	scan:create	\N	scan	create
fb831269-5756-4f99-926e-afa8b1522f63	scan:read	\N	scan	read
93d83973-dffa-4161-9578-8c27f3e2f914	findings:read	\N	findings	read
bfaa1ebc-53a0-4103-bb03-7237bf6e7039	reports:read	\N	reports	read
65b4317a-f419-4f27-94a8-a5eb6a045ef6	reports:create	\N	reports	create
f2b473c1-7b25-424b-826e-f54b3784fe44	billing:manage	\N	billing	manage
dbe2ae73-ae4a-4a2b-85c4-e6812372fdf5	iam:manage	\N	iam	manage
8fdd6eb5-721e-4155-bb67-b9a85032abae	audit:read	\N	audit	read
9d93093f-db1f-4b6e-955a-ae668d6dac9b	sso:manage	\N	sso	manage
5c3e003c-ae91-4834-babc-27b36afb3257	terminal:use	\N	terminal	use
\.


--
-- Data for Name: predict_alerts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.predict_alerts (id, user_id, cve_id, title, description, severity, cvss_score, affected_devices, weaponisation_pct, published_date, nvd_url, is_reviewed, created_at) FROM stdin;
\.


--
-- Data for Name: protocol_scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.protocol_scans (id, user_id, protocol, target, status, findings, device_count, risk_level, created_at, completed_at) FROM stdin;
1	1	modbus	192.168.1.100	completed	[{"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-001", "title": "No authentication required", "severity": "critical", "description": "Modbus TCP endpoint accepts commands from any source without authentication."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}]	3	critical	2026-04-05 04:05:52.170882	2026-04-05 04:05:52.169904
2	1	modbus	10.0.2.15	completed	[{"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}, {"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}]	3	high	2026-04-05 04:10:06.396635	2026-04-05 04:10:06.396281
3	1	modbus	192.168.1.50	completed	[{"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}]	5	high	2026-04-05 04:11:24.833174	2026-04-05 04:11:24.83276
4	1	modbus	192.168.1.50	completed	[{"id": "MB-002", "title": "Coil write access exposed", "severity": "critical", "description": "Write access to output coils allows direct control of physical devices."}, {"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}, {"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}]	5	critical	2026-04-05 04:11:40.976058	2026-04-05 04:11:40.97572
5	1	modbus	192.168.56.101	completed	[{"id": "MB-003", "title": "Holding register disclosure", "severity": "high", "description": "Holding registers expose sensitive process values without access control."}, {"id": "MB-004", "title": "No TLS encryption", "severity": "high", "description": "Modbus TCP traffic transmitted in plaintext \\u2014 susceptible to MITM."}, {"id": "MB-005", "title": "Function code abuse", "severity": "medium", "description": "Unrestricted function codes allow device identification and enumeration."}, {"id": "MB-006", "title": "No rate limiting", "severity": "low", "description": "No rate limiting on Modbus requests \\u2014 DoS attacks possible."}, {"id": "MB-002", "title": "Coil write access exposed", "severity": "critical", "description": "Write access to output coils allows direct control of physical devices."}, {"id": "MB-001", "title": "No authentication required", "severity": "critical", "description": "Modbus TCP endpoint accepts commands from any source without authentication."}]	5	critical	2026-04-09 16:25:31.22255	2026-04-09 16:25:31.221427
\.


--
-- Data for Name: remediation_kb; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.remediation_kb (id, attack_type, title, severity, explanation, fix_commands, time_estimate_minutes, difficulty, source, created_at) FROM stdin;
1	open_telnet	Telnet Open on Port 23	Critical	Telnet transmits all data including usernames and passwords in plain text. Any attacker on the same network can intercept and read everything. Telnet was designed in 1969 before security was a concern and should never be used on any modern device.	sudo systemctl stop telnet\nsudo systemctl disable telnet\nsudo apt remove telnetd -y	2	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011036
2	default_credentials	Default Credentials Not Changed	Critical	The device is using factory default username and password combinations. These are publicly listed in manufacturer documentation and are the first thing every attacker tries. Leaving default credentials is equivalent to leaving your front door unlocked.	# Access device admin panel\n# Navigate to: Settings > Security > Change Password\n# Set a strong password: minimum 12 characters, mixed case, numbers, symbols\n# Disable default admin account if possible\n# Enable account lockout after 5 failed attempts	5	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011041
3	unencrypted_mqtt	MQTT Running Without TLS Encryption	High	MQTT messages are being transmitted in plain text on port 1883. Anyone on the network can read all device messages, inject false commands, and intercept sensitive sensor data. This is especially dangerous for industrial and medical IoT devices.	# In your MQTT broker config (mosquitto.conf):\nlistener 8883\ncafile /etc/mosquitto/certs/ca.crt\ncertfile /etc/mosquitto/certs/server.crt\nkeyfile /etc/mosquitto/certs/server.key\nrequire_certificate true\n\n# Restart broker:\nsudo systemctl restart mosquitto	30	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011042
4	mqtt_no_auth	MQTT Broker Allows Anonymous Access	High	The MQTT broker accepts connections from any client without requiring a username or password. This means anyone who can reach the broker can subscribe to all topics and publish any message — including commands to connected devices.	# In mosquitto.conf:\nallow_anonymous false\npassword_file /etc/mosquitto/passwd\n\n# Create user:\nsudo mosquitto_passwd -c /etc/mosquitto/passwd your_username\n\n# Restart:\nsudo systemctl restart mosquitto	10	Quick Win	OWASP IoT Top 10	2026-04-03 00:37:29.011042
5	open_ftp	FTP Service Open on Port 21	High	FTP transmits files and credentials in plain text. Port 21 is one of the most commonly attacked ports on the internet. If FTP is needed for file transfers, it must be replaced with SFTP which encrypts the connection.	# Disable FTP:\nsudo systemctl stop vsftpd\nsudo systemctl disable vsftpd\n\n# Install SFTP instead (part of SSH):\nsudo apt install openssh-server -y\nsudo systemctl enable ssh	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011043
6	open_ssh_root	SSH Root Login Enabled	High	SSH is configured to allow direct root login. This means an attacker who brute-forces the SSH password immediately has full system control. Root login should always be disabled — users should SSH as a normal user and then use sudo.	# Edit SSH config:\nsudo nano /etc/ssh/sshd_config\n\n# Change this line:\nPermitRootLogin no\n\n# Also add:\nMaxAuthTries 3\nPasswordAuthentication no\n\n# Restart SSH:\nsudo systemctl restart sshd	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011043
7	http_no_https	Web Interface Running on HTTP Without HTTPS	High	The device web interface transmits login credentials and configuration data without encryption. Any attacker performing a man-in-the-middle attack on the network can capture admin passwords and take control of the device.	# Generate self-signed certificate:\nopenssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes\n\n# For Nginx:\nserver {\n    listen 443 ssl;\n    ssl_certificate /path/to/cert.pem;\n    ssl_certificate_key /path/to/key.pem;\n}\n\n# Redirect HTTP to HTTPS:\nserver {\n    listen 80;\n    return 301 https://$host$request_uri;\n}	20	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011043
8	open_vnc	VNC Remote Desktop Open Without Authentication	Critical	VNC is running and accepting connections without requiring a password. This gives any attacker on the network full graphical control of the device — they can see the screen, move the mouse, and type as if they were sitting in front of it.	# Disable VNC if not needed:\nsudo systemctl stop vncserver\nsudo systemctl disable vncserver\n\n# If VNC is needed, set a strong password:\nvncpasswd\n\n# Restrict to localhost only and use SSH tunnel:\nvncserver -localhost yes	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011044
9	open_snmp	SNMP Running with Default Community String	High	SNMP is configured with the default community string 'public' which is publicly known. This allows attackers to read all device configuration, network topology, and system information. SNMPv1 and v2c transmit this string in plain text.	# Disable SNMPv1 and v2c, use SNMPv3:\nsudo nano /etc/snmp/snmpd.conf\n\n# Remove: rocommunity public\n# Add SNMPv3 user:\ncreateUser myuser SHA mypassword AES myencryptkey\nrouser myuser\n\n# Restart:\nsudo systemctl restart snmpd	15	Moderate	CIS Benchmark	2026-04-03 00:37:29.011044
10	outdated_firmware	Device Running Outdated Firmware	High	The device firmware has not been updated and contains known, publicly documented vulnerabilities. Attackers actively scan for devices running outdated firmware because exploits are already written and publicly available for these versions.	# Check current firmware version in device admin panel\n# Navigate to: Settings > Firmware > Check for Updates\n# Download latest firmware from manufacturer website\n# Backup device configuration before updating\n# Apply firmware update\n# Verify version number after update\n# Re-apply configuration if reset occurred	30	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011044
11	weak_password_policy	No Password Policy Enforced	Medium	The device or application does not enforce minimum password requirements. Users can set passwords like '1234' or 'password' which can be cracked in seconds. Without a password policy, brute force attacks are trivial.	# For Linux systems:\nsudo nano /etc/pam.d/common-password\n\n# Add:\npassword requisite pam_pwquality.so minlen=12 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1\n\n# Install pwquality if needed:\nsudo apt install libpam-pwquality -y	10	Quick Win	NIST SP 800-63B	2026-04-03 00:37:29.011045
12	no_account_lockout	No Account Lockout After Failed Logins	Medium	The device allows unlimited login attempts without locking the account. This makes it completely vulnerable to brute force attacks where software automatically tries thousands of password combinations per second.	# For SSH using fail2ban:\nsudo apt install fail2ban -y\nsudo systemctl enable fail2ban\n\n# Configure:\nsudo nano /etc/fail2ban/jail.local\n[sshd]\nenabled = true\nmaxretry = 5\nbantime = 900\nfindtime = 600	10	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011045
13	open_redis	Redis Database Exposed Without Authentication	Critical	Redis is accessible on the network without a password. An attacker can read all cached data, write arbitrary data, and in many configurations execute system commands. Redis should never be exposed to the network without authentication.	# Bind Redis to localhost only:\nsudo nano /etc/redis/redis.conf\n\n# Change:\nbind 127.0.0.1\n\n# Set password:\nrequirepass your_strong_password_here\n\n# Disable dangerous commands:\nrename-command FLUSHALL ""\nrename-command CONFIG ""\n\n# Restart:\nsudo systemctl restart redis	10	Quick Win	OWASP Top 10	2026-04-03 00:37:29.011045
14	coap_no_dtls	CoAP Running Without DTLS Encryption	High	CoAP messages between IoT devices are transmitted without encryption. DTLS (Datagram Transport Layer Security) is the CoAP equivalent of TLS and must be enabled to prevent eavesdropping and message injection attacks.	# Generate DTLS certificates:\nopenssl ecparam -name prime256v1 -genkey -noout -out coap-key.pem\nopenssl req -new -x509 -key coap-key.pem -out coap-cert.pem -days 365\n\n# Configure your CoAP library to use DTLS\n# Refer to your specific CoAP implementation documentation\n# Common libraries: libcoap, aiocoap, californium	45	Complex	RFC 7252	2026-04-03 00:37:29.011045
15	open_database_port	Database Port Exposed to Network	Critical	The database port is accessible from outside the device or server. Databases should never be directly accessible from the network — only the application running on the same machine should be able to connect. Direct database exposure allows credential attacks and data theft.	# Block database port with firewall:\nsudo ufw deny 5432\nsudo ufw deny 3306\nsudo ufw deny 27017\n\n# Bind database to localhost:\n# PostgreSQL - in postgresql.conf:\nlisten_addresses = 'localhost'\n\n# MySQL - in my.cnf:\nbind-address = 127.0.0.1	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011046
16	ssl_expired_certificate	SSL Certificate Expired or Invalid	High	The device is using an expired or self-signed SSL certificate. Users and connecting devices receive security warnings and may disable certificate validation entirely — which makes them vulnerable to man-in-the-middle attacks that an attacker can exploit.	# Install certbot for free Let's Encrypt certificate:\nsudo apt install certbot -y\nsudo certbot certonly --standalone -d yourdomain.com\n\n# Auto-renewal:\nsudo certbot renew --dry-run\n\n# Add to crontab for auto-renewal:\n0 0 1 * * certbot renew --quiet	15	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011046
17	unnecessary_services	Unnecessary Network Services Running	Medium	The device is running services that are not required for its function. Every running service is an attack surface. A smart camera does not need an FTP server. A temperature sensor does not need a web server. Unused services should always be disabled.	# List all running services:\nsudo systemctl list-units --type=service --state=running\n\n# Disable unnecessary service:\nsudo systemctl stop service-name\nsudo systemctl disable service-name\n\n# Check open ports:\nsudo ss -tlnp	20	Moderate	CIS Benchmark	2026-04-03 00:37:29.011046
18	no_firewall	No Firewall Configured	High	The device has no firewall rules configured. All ports are accessible to anyone on the network. A firewall is the most basic network security control — it should only allow traffic on ports the device actually needs.	# Enable UFW firewall:\nsudo apt install ufw -y\nsudo ufw default deny incoming\nsudo ufw default allow outgoing\n\n# Allow only needed ports (example):\nsudo ufw allow 22/tcp\nsudo ufw allow 443/tcp\n\n# Enable:\nsudo ufw enable\nsudo ufw status verbose	10	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011047
19	insecure_api	API Endpoint Without Authentication	High	One or more API endpoints accept requests without verifying who is making them. An attacker can call these endpoints directly to read data, trigger actions, or modify device configuration without any credentials.	# Implement JWT authentication on all endpoints\n# Example for Flask:\nfrom flask_jwt_extended import jwt_required\n\n@app.route('/api/data')\n@jwt_required()\ndef get_data():\n    pass\n\n# Ensure every route that returns data\n# or triggers actions requires authentication	60	Complex	OWASP API Security Top 10	2026-04-03 00:37:29.011047
20	hardcoded_credentials	Hardcoded Credentials Found in Firmware	Critical	The device firmware contains hardcoded usernames and passwords embedded directly in the code. These cannot be changed by the user. Every device of this model ships with identical credentials — finding them once gives an attacker access to every device worldwide.	# This requires a firmware update from the manufacturer\n# Contact manufacturer immediately and report the vulnerability\n# Check manufacturer website for security patches\n# If no patch available, isolate device from network\n# Consider replacing device with one from a security-conscious vendor\n# Report to NCSC if critical infrastructure: https://www.ncsc.gov.uk	60	Complex	OWASP IoT Top 10	2026-04-03 00:37:29.011047
21	open_rsync	Rsync Service Exposed on Port 873	High	Rsync is running and accessible from the network. Without proper access controls, attackers can use rsync to download all files from the device or upload malicious files. This has been exploited in several major data breaches.	# Disable rsync if not needed:\nsudo systemctl stop rsync\nsudo systemctl disable rsync\n\n# If needed, restrict access in /etc/rsyncd.conf:\nhosts allow = 192.168.1.0/24\nhosts deny = *\n\n# Or block with firewall:\nsudo ufw deny 873	5	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011048
22	cleartext_storage	Sensitive Data Stored in Plaintext	High	The device stores sensitive information such as passwords, API keys, or personal data in plaintext files. If an attacker gains any access to the filesystem, they immediately have all credentials and sensitive data without needing to crack anything.	# Encrypt sensitive config files:\ngpg --symmetric --cipher-algo AES256 config.txt\n\n# For passwords, always use hashing:\n# Python example:\nfrom bcrypt import hashpw, gensalt\nhashed = hashpw(password.encode(), gensalt())\n\n# Never store passwords in plaintext\n# Use environment variables for secrets:\nexport API_KEY=your_key\n# Access in code: os.environ.get('API_KEY')	60	Complex	OWASP IoT Top 10	2026-04-03 00:37:29.011048
23	no_update_mechanism	No Secure Update Mechanism Available	Medium	The device has no way to receive security updates. Once a vulnerability is discovered, it cannot be patched remotely. This means the device will remain vulnerable forever unless physically replaced. This is a design flaw common in cheap IoT hardware.	# This requires manufacturer action for firmware updates\n# Short-term mitigations:\n# 1. Isolate device on a separate VLAN\nsudo ip link add link eth0 name eth0.10 type vlan id 10\n\n# 2. Block all inbound connections with firewall\nsudo ufw default deny incoming\n\n# 3. Monitor device traffic for anomalies\n# 4. Plan device replacement with a supported model	30	Moderate	NIST SP 800-213	2026-04-03 00:37:29.011048
24	open_upnp	UPnP Enabled and Exposed	High	Universal Plug and Play is enabled on this device. UPnP automatically opens ports in your router without any authentication. Attackers have used UPnP to punch holes in firewalls, redirect traffic, and gain access to internal networks from the internet.	# Disable UPnP on the device:\n# Navigate to device admin panel\n# Settings > Network > UPnP > Disable\n\n# Also disable on your router:\n# Router admin panel > Advanced > UPnP > Disable\n\n# Verify no unexpected port mappings exist:\n# Router admin > Port Forwarding — remove unknown entries	5	Quick Win	NIST SP 800-213	2026-04-03 00:37:29.011048
25	open_nfs	NFS Network File System Exposed	Critical	Network File System shares are accessible from the network, potentially without authentication. NFS was designed for trusted internal networks and has minimal security controls. Exposed NFS shares allow attackers to read and write files directly.	# Disable NFS if not needed:\nsudo systemctl stop nfs-server\nsudo systemctl disable nfs-server\n\n# If NFS is needed, restrict in /etc/exports:\n/data 192.168.1.0/24(ro,sync,no_root_squash)\n\n# Restart and verify:\nsudo exportfs -ra\nsudo showmount -e localhost	10	Quick Win	CIS Benchmark	2026-04-03 00:37:29.011049
26	debug_interface_exposed	Debug Interface Accessible on Network	Critical	A debug or development interface is accessible on the network. Debug interfaces are designed for developers and typically bypass all authentication and security controls. They provide direct access to device internals and are never appropriate in production.	# Identify and disable the debug service:\nsudo systemctl stop debug-service\nsudo systemctl disable debug-service\n\n# Block the port:\nsudo ufw deny [debug-port]\n\n# Check for debug flags in application config\n# Ensure DEBUG=False in all production configs\n# Remove or comment out any debug endpoints in code	15	Moderate	OWASP IoT Top 10	2026-04-03 00:37:29.011049
27	no_logging	Security Event Logging Not Configured	Medium	The device is not logging security events such as failed logins, configuration changes, or connection attempts. Without logs, there is no way to detect an attack in progress or investigate a breach after it occurs. Logging is essential for any device handling sensitive data.	# Enable system logging:\nsudo apt install rsyslog -y\nsudo systemctl enable rsyslog\n\n# Configure audit logging:\nsudo apt install auditd -y\nsudo systemctl enable auditd\n\n# Log failed logins:\nsudo auditctl -w /var/log/auth.log -p wa -k auth_log\n\n# View logs:\nsudo journalctl -f	15	Moderate	NIST SP 800-92	2026-04-03 00:37:29.011049
28	insecure_deserialization	Insecure Deserialization Vulnerability	Critical	The device or application deserializes data from untrusted sources without validation. Insecure deserialization can allow attackers to execute arbitrary code, manipulate application logic, or perform denial of service attacks by sending specially crafted data.	# Never deserialize data from untrusted sources\n# Use safe formats instead of pickle/Java serialization:\n# Python - use JSON instead of pickle:\nimport json\ndata = json.loads(untrusted_input)  # Safe\n# NOT: pickle.loads(untrusted_input)  # Dangerous\n\n# Validate and sanitise all input before processing\n# Implement integrity checks on serialized data\n# Use allowlists for acceptable classes during deserialization	60	Complex	OWASP Top 10	2026-04-03 00:37:29.011049
29	open_memcached	Memcached Exposed on Port 11211	Critical	Memcached is accessible from the network without authentication. This has been used in some of the largest DDoS amplification attacks in history, with attackers using exposed Memcached servers to amplify traffic by up to 51,000x. It also exposes all cached application data.	# Bind Memcached to localhost:\nsudo nano /etc/memcached.conf\n\n# Change:\n-l 127.0.0.1\n\n# Disable UDP (used in amplification attacks):\n-U 0\n\n# Restart:\nsudo systemctl restart memcached\n\n# Block with firewall:\nsudo ufw deny 11211	5	Quick Win	NCSC Advisory	2026-04-03 00:37:29.01105
30	privilege_escalation_risk	Excessive User Privileges Configured	High	User accounts or processes are running with more privileges than required. Following the principle of least privilege, every user and process should have only the minimum permissions needed to perform its function. Excessive privileges mean a compromised account can cause maximum damage.	# Audit current sudo privileges:\nsudo cat /etc/sudoers\nsudo visudo\n\n# Check user groups:\ngroups username\n\n# Remove from unnecessary groups:\nsudo deluser username groupname\n\n# Run services as dedicated low-privilege users:\nsudo useradd -r -s /bin/false serviceuser\nsudo chown serviceuser:serviceuser /opt/service	20	Moderate	CIS Benchmark	2026-04-03 00:37:29.01105
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.roles (id, name, description, created_at) FROM stdin;
e9a3c585-d129-4a32-8efb-aebee4f93a0c	owner	Full platform access including billing and IAM	2026-04-15 23:56:53.728861
7d8e1906-69f7-4b40-a7cd-a55570d6334f	admin	Full security access, no billing	2026-04-15 23:56:53.732295
bfdaeb70-70c5-4954-b3af-d182259a8adc	analyst	Read, scan, and analyse — no admin settings	2026-04-15 23:56:53.734753
1b8acad3-ea4c-4a00-98b3-c9dbfe44e365	viewer	Read-only access to findings and reports	2026-04-15 23:56:53.736664
\.


--
-- Data for Name: rt_attacks; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.rt_attacks (id, campaign_id, mitre_id, tactic, technique, target, result, impact, evidence, blocked_by, severity, executed_at, created_at) FROM stdin;
1	1	T1190	Initial Access	Exploit Public-Facing Application	192.168.1.4	success	Control registers read/written on 192.168.1.4	Successful Exploit Public-Facing Application — RCE attempts	\N	Critical	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526356
2	1	T1078	Initial Access	Valid Accounts — Default Credentials	192.168.1.4	success	Control registers read/written on 192.168.1.4	Successful Valid Accounts — Default Credentials — admin:password	\N	Critical	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526361
3	1	T1059	Execution	Command and Scripting Interpreter	192.168.1.4	blocked	Zero-Trust policy denied access	Blocked attempt: SSH execution detected and terminated	Multi-Factor Authentication	High	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526362
4	1	T1203	Execution	Exploitation for Client Execution	192.168.1.3	partial	Partial data access — encryption prevented full exfil	Partial Exploitation for Client Execution — Format string (partially mitigated)	Zero-Trust Policy (AIPET X)	High	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526363
5	1	T1505	Persistence	Server Software Component	192.168.1.1	blocked	Attack blocked by network segmentation	Blocked attempt: Init script modification detected and terminated	Multi-Factor Authentication	High	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526363
6	1	T1136	Persistence	Create Account	192.168.1.4	success	Persistent backdoor installed on 192.168.1.4	Successful Create Account — Hidden user creation	\N	Medium	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526363
7	1	T1021	Lateral Movement	Remote Services	192.168.1.2	success	Control registers read/written on 192.168.1.2	Successful Remote Services — WMI execution	\N	Critical	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526364
8	1	T1210	Lateral Movement	Exploitation of Remote Services	192.168.1.2	success	Full access gained to 192.168.1.2	Successful Exploitation of Remote Services — EternalBlue	\N	Critical	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526364
9	1	T1040	Collection	Network Sniffing	192.168.1.4	success	Sensitive data exfiltrated from 192.168.1.4	Successful Network Sniffing — DNP3 interception	\N	High	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526365
10	1	T1530	Collection	Data from Cloud Storage	192.168.1.3	blocked	Zero-Trust policy denied access	Blocked attempt: GCS object listing detected and terminated	Zero-Trust Policy (AIPET X)	High	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526365
11	1	T1071	Command and Control	Application Layer Protocol	192.168.1.3	partial	Some credentials found — MFA prevented full compromise	Partial Application Layer Protocol — DNS tunneling (partially mitigated)	Autonomous Defense Playbook	High	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526365
12	1	T1499	Impact	Endpoint Denial of Service	192.168.1.2	success	Full access gained to 192.168.1.2	Successful Endpoint Denial of Service — Config wipe	\N	Critical	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526366
13	1	T1565	Impact	Data Manipulation	192.168.1.1	success	Full access gained to 192.168.1.1	Successful Data Manipulation — Replay attacks	\N	Critical	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526366
14	1	T1046	Discovery	Network Service Discovery	192.168.1.2	partial	Some credentials found — MFA prevented full compromise	Partial Network Service Discovery — Port scanning (partially mitigated)	Encryption	Medium	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526366
15	1	T1083	Discovery	File and Directory Discovery	192.168.1.4	partial	Limited access obtained — privilege escalation needed	Partial File and Directory Discovery — Config file access (partially mitigated)	Multi-Factor Authentication	Medium	2026-04-09 20:18:08.519523	2026-04-16 20:18:08.526367
16	2	T1190	Initial Access	Exploit Public-Facing Application	10.0.1.11	success	Persistent backdoor installed on 10.0.1.11	Successful Exploit Public-Facing Application — RCE attempts	\N	Critical	2026-04-13 20:18:08.519523	2026-04-16 20:18:08.526367
17	2	T1078	Initial Access	Valid Accounts — Default Credentials	192.168.1.1	success	Persistent backdoor installed on 192.168.1.1	Successful Valid Accounts — Default Credentials — user:user	\N	Critical	2026-04-13 20:18:08.519523	2026-04-16 20:18:08.526367
18	2	T1021	Lateral Movement	Remote Services	192.168.1.1	blocked	Encryption defeated traffic interception attempt	Blocked attempt: RDP hopping detected and terminated	SIEM Detection Rule	Critical	2026-04-13 20:18:08.519523	2026-04-16 20:18:08.526368
19	2	T1210	Lateral Movement	Exploitation of Remote Services	192.168.1.1	partial	Foothold established but detected by monitoring	Partial Exploitation of Remote Services — EternalBlue (partially mitigated)	Encryption	Critical	2026-04-13 20:18:08.519523	2026-04-16 20:18:08.526368
20	2	T1040	Collection	Network Sniffing	10.0.1.10	success	Persistent backdoor installed on 10.0.1.10	Successful Network Sniffing — Modbus register reads	\N	High	2026-04-13 20:18:08.519523	2026-04-16 20:18:08.526368
21	2	T1530	Collection	Data from Cloud Storage	10.0.1.11	success	Sensitive data exfiltrated from 10.0.1.11	Successful Data from Cloud Storage — GCS object listing	\N	High	2026-04-13 20:18:08.519523	2026-04-16 20:18:08.526368
22	2	T1499	Impact	Endpoint Denial of Service	192.168.1.1	success	Full access gained to 192.168.1.1	Successful Endpoint Denial of Service — Config wipe	\N	Critical	2026-04-13 20:18:08.519523	2026-04-16 20:18:08.526369
23	2	T1565	Impact	Data Manipulation	10.0.2.20	blocked	SIEM detection rule triggered — connection terminated	Blocked attempt: Register manipulation detected and terminated	Autonomous Defense Playbook	Critical	2026-04-13 20:18:08.519523	2026-04-16 20:18:08.526369
39	3	T1190	Initial Access	Exploit Public-Facing Application	192.168.1.2	success	Persistent backdoor installed on 192.168.1.2	Successful Exploit Public-Facing Application — CVE exploitation	\N	Critical	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.485366
40	3	T1078	Initial Access	Valid Accounts — Default Credentials	192.168.1.3	success	Full access gained to 192.168.1.3	Successful Valid Accounts — Default Credentials — user:user	\N	Critical	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.49161
41	3	T1059	Execution	Command and Scripting Interpreter	192.168.1.2	blocked	Strong authentication prevented credential attack	Blocked attempt: Telnet commands detected and terminated	Multi-Factor Authentication	High	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.49601
42	3	T1203	Execution	Exploitation for Client Execution	192.168.1.4	blocked	Zero-Trust policy denied access	Blocked attempt: Buffer overflow detected and terminated	Autonomous Defense Playbook	High	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.498732
43	3	T1505	Persistence	Server Software Component	192.168.1.1	blocked	Attack blocked by network segmentation	Blocked attempt: Cron job injection detected and terminated	Network Segmentation	High	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.500211
44	3	T1136	Persistence	Create Account	192.168.1.3	success	Full access gained to 192.168.1.3	Successful Create Account — SSH key injection	\N	Medium	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.501468
45	3	T1021	Lateral Movement	Remote Services	192.168.1.1	success	Persistent backdoor installed on 192.168.1.1	Successful Remote Services — SSH pivoting	\N	Critical	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.503278
46	3	T1210	Lateral Movement	Exploitation of Remote Services	192.168.1.1	success	Credentials extracted from 192.168.1.1	Successful Exploitation of Remote Services — Log4Shell	\N	Critical	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.50494
47	3	T1040	Collection	Network Sniffing	192.168.1.3	partial	Limited access obtained — privilege escalation needed	Partial Network Sniffing — DNP3 interception (partially mitigated)	SIEM Detection Rule	High	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.507461
48	3	T1530	Collection	Data from Cloud Storage	192.168.1.2	blocked	SIEM detection rule triggered — connection terminated	Blocked attempt: S3 bucket enumeration detected and terminated	Patch Management	High	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.508688
49	3	T1071	Command and Control	Application Layer Protocol	192.168.1.2	success	Persistent backdoor installed on 192.168.1.2	Successful Application Layer Protocol — CoAP beaconing	\N	High	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.510257
50	3	T1499	Impact	Endpoint Denial of Service	192.168.1.3	success	Control registers read/written on 192.168.1.3	Successful Endpoint Denial of Service — Firmware corruption	\N	Critical	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.512033
51	3	T1565	Impact	Data Manipulation	192.168.1.1	partial	Foothold established but detected by monitoring	Partial Data Manipulation — False sensor data injection (partially mitigated)	Encryption	Critical	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.513738
52	3	T1046	Discovery	Network Service Discovery	192.168.1.2	partial	Some credentials found — MFA prevented full compromise	Partial Network Service Discovery — Port scanning (partially mitigated)	Encryption	Medium	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.515776
53	3	T1083	Discovery	File and Directory Discovery	192.168.1.2	success	Credentials extracted from 192.168.1.2	Successful File and Directory Discovery — Config file access	\N	Medium	2026-04-16 20:22:52.484164	2026-04-16 20:22:52.516851
\.


--
-- Data for Name: rt_campaigns; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.rt_campaigns (id, name, description, scope, objectives, status, attack_count, success_count, blocked_count, overall_score, duration_sec, created_by, created_at, completed_at) FROM stdin;
1	Full IoT Network Assessment — Q2 2026	Comprehensive red team assessment of all IoT devices and control systems across the production network.	192.168.1.0/24, 10.0.1.0/24, 10.0.2.0/24	Identify exploitable attack paths, test defence coverage, validate Zero-Trust policies and SIEM detection rules.	completed	15	8	3	33	45	\N	2026-04-09 20:18:08.519523	2026-04-09 20:18:53.519523
2	OT/ICS Protocol Attack Simulation	Focused assessment of industrial control system security — Modbus, DNP3, and IEC 61850 attack paths.	10.0.1.0/24 (OT network)	Test industrial protocol security, validate OT segmentation, assess physical impact potential of cyber attacks.	completed	8	5	2	31	32	\N	2026-04-13 20:18:08.519523	2026-04-13 20:18:40.519523
3	Cloud Attack Surface Assessment	Red team assessment targeting cloud infrastructure — AWS S3 buckets, Azure IoT Hub, GCP service accounts.	AWS Production, Azure NHS Platform, GCP Analytics	Test cloud security posture, validate IAM controls, assess data exfiltration risk.	completed	15	8	4	36	0	\N	2026-04-16 18:18:08.519523	2026-04-16 20:22:52.516731
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.scans (id, user_id, target, mode, status, result_dir, report_path, started_at, completed_at, created_at, critical, high, medium, low) FROM stdin;
1	1	localhost	demo	failed	\N	\N	\N	\N	2026-03-31 20:15:39.867425	0	0	0	0
2	1		demo	complete	\N	\N	\N	2026-04-01 09:46:47.736038	2026-04-01 09:45:46.176547	0	0	0	0
3	1		demo	failed	\N	\N	\N	\N	2026-04-01 10:01:43.288689	0	0	0	0
4	1		demo	failed	\N	\N	\N	\N	2026-04-02 01:15:29.528845	0	0	0	0
5	1	10.0.2.15	live	complete	\N	\N	\N	2026-04-02 01:44:58.017747	2026-04-02 01:44:30.971065	0	0	0	0
6	1		demo	queued	\N	\N	\N	\N	2026-04-02 01:51:46.538644	0	0	0	0
7	1	localhost	demo	complete	\N	\N	\N	2026-04-02 08:14:14.5211	2026-04-02 08:13:28.294726	0	0	0	0
8	1		demo	complete	\N	\N	\N	2026-04-02 09:10:46.959833	2026-04-02 09:09:57.733046	0	0	0	0
9	1	192.168.1.0/24	network	completed	\N	\N	\N	\N	\N	2	1	1	0
10	1		demo	failed	\N	\N	\N	\N	2026-04-03 17:06:14.043743	0	0	0	0
11	1		demo	failed	\N	\N	\N	\N	2026-04-04 08:29:12.952477	0	0	0	0
12	1		demo	queued	\N	\N	\N	\N	2026-04-05 01:35:55.509033	0	0	0	0
13	1	192.168.1.1	live	complete	\N	\N	\N	2026-04-05 06:20:23.329482	2026-04-05 06:20:12.626642	0	0	0	0
14	1		demo	queued	\N	\N	\N	\N	2026-04-06 02:24:03.255418	0	0	0	0
15	1		demo	failed	\N	\N	\N	\N	2026-04-06 02:27:46.105339	0	0	0	0
16	2		demo	queued	\N	\N	\N	\N	2026-04-09 15:31:43.276384	0	0	0	0
17	2	192.168.1.1	live	queued	\N	\N	\N	\N	2026-04-09 15:32:03.608879	0	0	0	0
18	2	192.168.1.1	live	queued	\N	\N	\N	\N	2026-04-09 15:33:02.198088	0	0	0	0
19	2	192.168.1.1	live	queued	\N	\N	\N	\N	2026-04-09 15:35:14.106329	0	0	0	0
20	2		demo	queued	\N	\N	\N	\N	2026-04-09 15:37:24.222427	0	0	0	0
21	1	192.168.56.105	live	complete	\N	\N	\N	2026-04-09 16:01:07.26435	2026-04-09 16:00:37.618773	0	0	0	0
22	1	192.168.56.101	live	complete	\N	\N	\N	2026-04-09 16:04:16.636736	2026-04-09 16:04:12.89033	0	0	0	0
23	1	192.168.56.101	live	complete	\N	\N	\N	2026-04-09 16:23:52.009325	2026-04-09 16:23:46.617861	0	0	0	0
24	1	192.168.56.101	live	complete	\N	\N	\N	2026-04-09 23:17:44.338576	2026-04-09 23:17:38.446817	0	0	0	0
25	1	192.168.1.0/24 	live	failed	\N	\N	\N	\N	2026-04-10 01:02:48.682954	0	0	0	0
\.


--
-- Data for Name: score_results; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.score_results (id, scan_id, user_id, industry, total_exposure_gbp, findings_breakdown, created_at) FROM stdin;
7	9	1	Manufacturing	1063600	[{"attack": "default_credentials", "target": "192.168.1.2", "severity": "Critical", "finding_id": 3, "fix_status": "open", "exposure_fmt": "£544,000", "exposure_gbp": 544000, "device_function": "Customer Data", "breach_probability": 85}, {"attack": "open_telnet", "target": "192.168.1.1", "severity": "Critical", "finding_id": 2, "fix_status": "open", "exposure_fmt": "£240,000", "exposure_gbp": 240000, "device_function": "Infrastructure / Network", "breach_probability": 75}, {"attack": "unencrypted_mqtt", "target": "192.168.1.3", "severity": "High", "finding_id": 4, "fix_status": "open", "exposure_fmt": "£201,600", "exposure_gbp": 201600, "device_function": "Operations / Manufacturing", "breach_probability": 60}, {"attack": "no_firewall", "target": "192.168.1.4", "severity": "Medium", "finding_id": 5, "fix_status": "open", "exposure_fmt": "£78,000", "exposure_gbp": 78000, "device_function": "General IT", "breach_probability": 65}]	2026-04-05 00:10:13.712168
\.


--
-- Data for Name: siem_events; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.siem_events (id, event_type, source, severity, title, description, raw_payload, mitre_id, user_id, incident_id, acknowledged, created_at) FROM stdin;
2	scan_finding	AIPET Scanner	Critical	Telnet service exposed on 192.168.1.1	Unencrypted remote access protocol detected on port 23.	\N	T1021.004	\N	\N	f	2026-04-16 13:58:37.420157
3	scan_finding	AIPET Scanner	High	Unencrypted MQTT broker on 192.168.1.3	MQTT running without TLS. All messages visible in plaintext.	\N	T1040	\N	\N	f	2026-04-16 13:45:37.420157
4	scan_finding	AIPET Scanner	High	Missing firewall rules on 192.168.1.4	No ACL rules found. Unrestricted lateral movement possible.	\N	T1090	\N	\N	f	2026-04-16 13:10:37.420157
5	auth_event	AIPET Auth	Medium	Multiple failed login attempts from 10.0.0.55	5 failed login attempts in 2 minutes.	\N	T1110	\N	\N	f	2026-04-16 12:10:37.420157
6	network_anomaly	AIPET Watch	Medium	Unusual outbound traffic from 192.168.1.2	Device sent 450MB to external IP in 10 minutes.	\N	T1048	\N	\N	f	2026-04-16 11:10:37.420157
7	scan_finding	AIPET Scanner	Low	HTTP instead of HTTPS on management portal	Admin interface accessible over unencrypted HTTP.	\N	T1557	\N	\N	f	2026-04-16 09:10:37.420157
8	system	AIPET System	Info	Scheduled scan completed — 4 devices scanned	Scan ID 9 completed. 5 findings. Risk level: HIGH.	\N	\N	\N	\N	f	2026-04-16 08:10:37.420157
9	test	Manual Test	Low	SIEM ingest endpoint working	\N	{}	\N	\N	\N	t	2026-04-16 14:24:53.128652
1	scan_finding	AIPET Scanner	Critical	Default credentials detected on 192.168.1.2	Device responded to default admin:admin login attempt.	\N	T1078	\N	\N	t	2026-04-16 14:05:37.420157
10	scan_finding	AIPET Scanner	Critical	Default credentials detected on 192.168.2.10	New device found with admin:admin credentials.	{}	T1078	\N	3	f	2026-04-16 15:09:31.725969
11	auth_event	AIPET Auth	High	10 failed login attempts from 185.220.101.45	Possible brute force — attacker IP is a known Tor exit node.	{}	T1110	\N	\N	f	2026-04-16 15:10:16.202014
12	network_anomaly	Fortinet Firewall	High	Blocked connection attempt to C2 server 91.219.28.12	Device 192.168.1.3 attempted outbound connection to known malware C2.	{"blocked": true, "destination_port": 443}	T1071	\N	\N	f	2026-04-16 15:11:02.697691
13	threat_intel	AIPET Threat Intel (Local IOC Database)	Critical	Threat Intel match: 91.219.28.12	Device IP matched c2 indicator in Local IOC Database feed.	\N	T1071.001	\N	\N	f	2026-04-16 15:44:31.02512
14	threat_intel	AIPET Threat Intel (Local IOC Database)	Critical	Threat Intel match: 91.219.28.12	Device IP matched c2 indicator in Local IOC Database feed.	\N	T1071.001	\N	\N	f	2026-04-16 15:46:51.841157
15	zero_trust	AIPET Zero-Trust	Critical	Zero-Trust QUARANTINE: 192.168.1.1	Quarantined device attempted access to 8.8.8.8:53	\N	T1078	\N	\N	f	2026-04-16 16:00:58.62548
16	zero_trust	AIPET Zero-Trust	High	Zero-Trust BLOCK: 192.168.1.1	Trust score dropped to 50. Factors: 2 Critical finding(s) — -50 pts	\N	T1078	\N	\N	f	2026-04-16 16:05:35.776704
17	zero_trust	AIPET Zero-Trust	High	Zero-Trust BLOCK: 192.168.1.1	Trust score dropped to 50. Factors: 2 Critical finding(s) — -50 pts	\N	T1078	\N	\N	f	2026-04-16 16:10:27.207967
18	defense_action	AIPET Autonomous Defense	Critical	[AUTONOMOUS DEFENSE ALERT] 192.168.1.2	Manual trigger of playbook: Auto-quarantine critical devices	\N	T1078	\N	\N	f	2026-04-16 16:20:46.296623
19	ot_ics_finding	AIPET OT/ICS Scanner (ETHERNETIP)	Critical	EtherNet/IP CIP device accessible without authentication	Common Industrial Protocol (CIP) service accepts connections without authentication. Rockwell/Allen-Bradley PLCs with unauthenticated CIP access can have their logic read and potentially modified by any network host.	\N	T0817	\N	\N	f	2026-04-16 19:43:15.824967
20	ot_ics_finding	AIPET OT/ICS Scanner (MODBUS)	Critical	Modbus TCP has no authentication — any device can send commands	Modbus TCP protocol has no built-in authentication mechanism. Any host on the network can read sensor data and write control commands to connected PLCs and field devices.	\N	T0817	\N	\N	f	2026-04-16 19:44:19.996485
21	ot_ics_finding	AIPET OT/ICS Scanner (MODBUS)	Critical	Modbus coil writing enabled — physical control registers writable	Modbus Function Code 0x0F (Write Multiple Coils) is enabled. An attacker can write to coil registers to directly control connected physical equipment such as motors, valves, and relays.	\N	T0831	\N	\N	f	2026-04-16 19:44:19.996488
22	cloud_finding	AIPET Multi-Cloud (AWS)	Critical	S3 bucket publicly accessible — data exposure risk	An S3 bucket has public read access enabled. Any internet user can list and download bucket contents including IoT device configurations and certificates.	\N	T1530	\N	\N	f	2026-04-16 19:57:50.50253
23	cloud_finding	AIPET Multi-Cloud (AWS)	Critical	EC2 security group allows all inbound traffic (0.0.0.0/0)	An EC2 security group has an inbound rule permitting all traffic from any IP address on all ports. IoT management server is exposed to the entire internet.	\N	T1190	\N	\N	f	2026-04-16 19:57:50.502536
24	twin_simulation	AIPET Digital Twin	High	Attack simulation: PLC Controller compromised	Blast radius: 1 devices at risk. Simulated lateral movement from 10.0.1.10.	\N	T1021	\N	\N	f	2026-04-16 20:09:08.585394
25	twin_simulation	AIPET Digital Twin	High	Attack simulation: SCADA Server compromised	Blast radius: 6 devices at risk. Simulated lateral movement from 192.168.1.1.	\N	T1021	\N	\N	f	2026-04-16 20:10:28.899982
26	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.1	Control registers read/written on 192.168.1.1	\N	T1190	\N	\N	f	2026-04-16 20:21:45.892865
27	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Exploitation for Client Execution succeeded on 192.168.1.3	Full access gained to 192.168.1.3	\N	T1203	\N	\N	f	2026-04-16 20:21:45.908238
28	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] Create Account succeeded on 192.168.1.2	Control registers read/written on 192.168.1.2	\N	T1136	\N	\N	f	2026-04-16 20:21:45.913247
29	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Remote Services succeeded on 192.168.1.2	Sensitive data exfiltrated from 192.168.1.2	\N	T1021	\N	\N	f	2026-04-16 20:21:45.918811
30	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.1	Credentials extracted from 192.168.1.1	\N	T1210	\N	\N	f	2026-04-16 20:21:45.921334
31	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Application Layer Protocol succeeded on 192.168.1.2	Persistent backdoor installed on 192.168.1.2	\N	T1071	\N	\N	f	2026-04-16 20:21:45.927414
32	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Endpoint Denial of Service succeeded on 192.168.1.3	Control registers read/written on 192.168.1.3	\N	T1499	\N	\N	f	2026-04-16 20:21:45.930711
33	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] File and Directory Discovery succeeded on 192.168.1.2	Credentials extracted from 192.168.1.2	\N	T1083	\N	\N	f	2026-04-16 20:21:45.939098
34	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploit Public-Facing Application succeeded on 192.168.1.2	Persistent backdoor installed on 192.168.1.2	\N	T1190	\N	\N	f	2026-04-16 20:22:52.486157
35	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Valid Accounts — Default Credentials succeeded on 192.168.1.3	Full access gained to 192.168.1.3	\N	T1078	\N	\N	f	2026-04-16 20:22:52.492572
36	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] Create Account succeeded on 192.168.1.3	Full access gained to 192.168.1.3	\N	T1136	\N	\N	f	2026-04-16 20:22:52.50199
37	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Remote Services succeeded on 192.168.1.1	Persistent backdoor installed on 192.168.1.1	\N	T1021	\N	\N	f	2026-04-16 20:22:52.503755
38	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Exploitation of Remote Services succeeded on 192.168.1.1	Credentials extracted from 192.168.1.1	\N	T1210	\N	\N	f	2026-04-16 20:22:52.505523
39	redteam_finding	AIPET AI Red Team	High	[RED TEAM] Application Layer Protocol succeeded on 192.168.1.2	Persistent backdoor installed on 192.168.1.2	\N	T1071	\N	\N	f	2026-04-16 20:22:52.510761
40	redteam_finding	AIPET AI Red Team	Critical	[RED TEAM] Endpoint Denial of Service succeeded on 192.168.1.3	Control registers read/written on 192.168.1.3	\N	T1499	\N	\N	f	2026-04-16 20:22:52.512465
41	redteam_finding	AIPET AI Red Team	Medium	[RED TEAM] File and Directory Discovery succeeded on 192.168.1.2	Credentials extracted from 192.168.1.2	\N	T1083	\N	\N	f	2026-04-16 20:22:52.518867
\.


--
-- Data for Name: siem_incidents; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.siem_incidents (id, title, description, severity, status, assigned_to, created_by, event_count, created_at, updated_at) FROM stdin;
1	Critical: Default credentials on IoT devices	Two devices found with default credentials. Immediate password change required.	Critical	open	\N	\N	2	2026-04-16 14:10:37.434026	2026-04-16 14:10:37.43403
2	Unencrypted protocols in production network	Telnet and plain MQTT detected. Lateral movement risk HIGH.	High	investigating	\N	\N	2	2026-04-16 14:10:37.434031	2026-04-16 14:10:37.434032
3	[Auto] Critical finding auto-incident	Rule triggered by: Default credentials detected on 192.168.2.10	Critical	open	\N	\N	1	2026-04-16 15:09:31.738921	2026-04-16 15:09:31.738929
4	[AUTO] Autonomous Defense: 192.168.1.2	Manual trigger of playbook: Auto-quarantine critical devices	Critical	open	\N	\N	1	2026-04-16 16:20:46.299814	2026-04-16 16:20:46.299819
\.


--
-- Data for Name: siem_rules; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.siem_rules (id, name, description, condition, action, severity, enabled, trigger_count, created_by, created_at) FROM stdin;
3	Telnet exposure alert	Alert when Telnet is found exposed	{"field": "title", "op": "contains", "value": "Telnet"}	alert	Critical	t	0	\N	2026-04-16 14:10:37.429375
1	Critical finding auto-incident	Automatically create incident for any Critical severity event	{"field": "severity", "op": "eq", "value": "Critical"}	incident	Critical	t	1	\N	2026-04-16 14:10:37.429369
2	Default credentials alert	Alert when default credentials are detected	{"field": "title", "op": "contains", "value": "default credentials"}	alert	High	t	1	\N	2026-04-16 14:10:37.429374
4	Brute force detection	Alert on multiple failed login attempts	{"field": "event_type", "op": "eq", "value": "auth_event"}	alert	High	t	1	\N	2026-04-16 14:10:37.429375
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.sso_providers (id, name, client_id, tenant_id, metadata_url, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: threat_matches; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.threat_matches (id, ioc_entry_id, scan_id, matched_value, match_source, threat_type, confidence, severity, details, user_id, created_at) FROM stdin;
1	\N	\N	91.219.28.12	Local IOC Database	c2	98	Critical	[{"source": "Local IOC Database", "matched": true, "confidence": 98, "severity": "Critical", "threat_type": "c2", "description": "Confirmed C2 server \\u2014 associated with Mirai botnet variant targeting IoT devices"}]	1	2026-04-16 15:44:31.027283
2	\N	\N	91.219.28.12	Local IOC Database	c2	98	Critical	[{"source": "Local IOC Database", "matched": true, "confidence": 98, "severity": "Critical", "threat_type": "c2", "description": "Confirmed C2 server \\u2014 associated with Mirai botnet variant targeting IoT devices"}]	1	2026-04-16 15:46:51.842616
\.


--
-- Data for Name: twin_edges; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.twin_edges (id, source_id, target_id, edge_type, protocol, port, encrypted, bandwidth, latency_ms, active, created_at) FROM stdin;
1	1	2	management	HTTPS	443	t	1Gbps	2	t	2026-04-16 20:05:11.656944
2	1	3	data_flow	HTTPS	443	t	1Gbps	1	t	2026-04-16 20:05:11.656949
3	2	4	control	MQTT	1883	f	100Mbps	5	t	2026-04-16 20:05:11.65695
4	2	5	management	HTTPS	443	t	100Mbps	3	t	2026-04-16 20:05:11.65695
5	5	6	control	Modbus	502	f	10Mbps	10	t	2026-04-16 20:05:11.656951
6	5	10	control	DNP3	20000	f	1Mbps	20	t	2026-04-16 20:05:11.656951
7	4	7	data_flow	MQTT	1883	f	1Mbps	15	t	2026-04-16 20:05:11.656951
8	4	8	data_flow	MQTT	1883	f	1Mbps	15	t	2026-04-16 20:05:11.656952
9	6	10	dependency	Modbus	502	f	1Mbps	5	t	2026-04-16 20:05:11.656952
10	3	9	management	HTTP	80	f	10Mbps	8	t	2026-04-16 20:05:11.656953
\.


--
-- Data for Name: twin_nodes; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.twin_nodes (id, name, node_type, ip_address, mac_address, vendor, firmware, location, zone, expected_state, actual_state, diverged, risk_score, online, x_pos, y_pos, created_at, updated_at) FROM stdin;
1	Corporate Firewall	router	10.0.0.1	\N	Palo Alto Networks	10.2.4	Server Room — Rack 1	enterprise	{"risk_level": "Low", "findings": []}	{"risk_level": "Low", "findings": []}	f	15	t	400	60	2026-04-16 20:05:11.636141	2026-04-16 20:05:11.636145
6	PLC Controller	plc	10.0.1.10	\N	Schneider Electric	2.60	Production Floor	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Critical", "findings": ["modbus_unauthenticated"]}	t	90	t	150	400	2026-04-16 20:05:11.63615	2026-04-16 20:05:11.636151
7	Temperature Sensor A	sensor	10.0.2.10	\N	Honeywell	3.1.2	Production Floor — Zone A	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Low", "findings": []}	f	10	t	100	500	2026-04-16 20:05:11.636151	2026-04-16 20:05:11.636151
8	Pressure Sensor B	sensor	10.0.2.11	\N	Emerson	2.8.0	Production Floor — Zone B	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Low", "findings": []}	f	8	t	250	500	2026-04-16 20:05:11.636152	2026-04-16 20:05:11.636152
9	IP Camera	camera	10.0.3.10	\N	Hikvision	V5.5.800	Production Floor — Entry	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Medium", "findings": ["weak_password"]}	t	45	t	600	400	2026-04-16 20:05:11.636152	2026-04-16 20:05:11.636153
10	Water Treatment RTU	actuator	10.0.1.11	\N	ABB	11.7.3	Water Treatment Plant	field	{"risk_level": "Low", "findings": []}	{"risk_level": "Critical", "findings": ["dnp3_no_auth"]}	t	88	t	350	500	2026-04-16 20:05:11.636153	2026-04-16 20:05:11.636153
5	IoT Gateway	gateway	192.168.1.4	\N	Cisco	IOS 15.2	IoT Gateway Room	operations	{"risk_level": "Low", "findings": []}	{"ip": "192.168.1.4", "findings": [{"severity": "Medium", "attack": "no_firewall"}], "risk_level": "Medium", "last_seen": "2026-04-16 19:11:11.295367+00:00"}	t	8	t	400	280	2026-04-16 20:05:11.63615	2026-04-16 20:11:11.295367
4	MQTT Broker	hub	192.168.1.3	\N	Eclipse Mosquitto	2.0.15	IoT Gateway Room	operations	{"risk_level": "Low", "findings": []}	{"ip": "192.168.1.3", "findings": [{"severity": "High", "attack": "unencrypted_mqtt"}], "risk_level": "High", "last_seen": "2026-04-16 19:11:11.295367+00:00"}	t	15	t	200	280	2026-04-16 20:05:11.636149	2026-04-16 20:11:11.295367
2	SCADA Server	server	192.168.1.1	\N	Wonderware	2021.1	Control Room	supervisory	{"risk_level": "Medium", "findings": []}	{"ip": "192.168.1.1", "findings": [{"severity": "Critical", "attack": "open_telnet"}, {"severity": "Critical", "attack": "open_telnet"}], "risk_level": "Critical", "last_seen": "2026-04-16 19:11:11.295367+00:00"}	t	50	t	250	160	2026-04-16 20:05:11.636146	2026-04-16 20:11:11.295367
3	Customer Data Server	server	192.168.1.2	\N	Dell EMC	iDRAC 5.0	Server Room — Rack 2	enterprise	{"risk_level": "Low", "findings": []}	{"ip": "192.168.1.2", "findings": [{"severity": "Critical", "attack": "default_credentials"}], "risk_level": "Critical", "last_seen": "2026-04-16 19:11:11.295367+00:00"}	t	25	t	550	160	2026-04-16 20:05:11.636148	2026-04-16 20:11:11.295367
\.


--
-- Data for Name: twin_snapshots; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.twin_snapshots (id, label, snapshot_type, node_count, edge_count, diverged_count, risk_avg, data, created_by, created_at) FROM stdin;
1	Initial twin state — baseline	auto	10	10	7	53.1	\N	\N	2026-04-16 20:05:11.665688
2	Pre-simulation: PLC Controller	pre_simulation	10	10	7	53.1	\N	1	2026-04-16 20:09:08.582582
3	Pre-simulation: SCADA Server	pre_simulation	10	10	7	53.1	\N	1	2026-04-16 20:10:28.895686
4	Manual snapshot — 16/04/2026, 20:11:01	manual	10	10	7	53.1	[{"id": 1, "name": "Corporate Firewall", "node_type": "router", "ip_address": "10.0.0.1", "mac_address": null, "vendor": "Palo Alto Networks", "firmware": "10.2.4", "location": "Server Room \\u2014 Rack 1", "zone": "enterprise", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "diverged": false, "risk_score": 15, "online": true, "x_pos": 400.0, "y_pos": 60.0, "updated_at": "2026-04-16 20:05:11.636145"}, {"id": 2, "name": "SCADA Server", "node_type": "server", "ip_address": "192.168.1.1", "mac_address": null, "vendor": "Wonderware", "firmware": "2021.1", "location": "Control Room", "zone": "supervisory", "expected_state": "{\\"risk_level\\": \\"Medium\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Critical\\", \\"findings\\": [\\"open_telnet\\"]}", "diverged": true, "risk_score": 75, "online": true, "x_pos": 250.0, "y_pos": 160.0, "updated_at": "2026-04-16 20:05:11.636147"}, {"id": 3, "name": "Customer Data Server", "node_type": "server", "ip_address": "192.168.1.2", "mac_address": null, "vendor": "Dell EMC", "firmware": "iDRAC 5.0", "location": "Server Room \\u2014 Rack 2", "zone": "enterprise", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Critical\\", \\"findings\\": [\\"default_credentials\\"]}", "diverged": true, "risk_score": 85, "online": true, "x_pos": 550.0, "y_pos": 160.0, "updated_at": "2026-04-16 20:05:11.636148"}, {"id": 4, "name": "MQTT Broker", "node_type": "hub", "ip_address": "192.168.1.3", "mac_address": null, "vendor": "Eclipse Mosquitto", "firmware": "2.0.15", "location": "IoT Gateway Room", "zone": "operations", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"High\\", \\"findings\\": [\\"unencrypted_mqtt\\"]}", "diverged": true, "risk_score": 60, "online": true, "x_pos": 200.0, "y_pos": 280.0, "updated_at": "2026-04-16 20:05:11.636149"}, {"id": 5, "name": "IoT Gateway", "node_type": "gateway", "ip_address": "192.168.1.4", "mac_address": null, "vendor": "Cisco", "firmware": "IOS 15.2", "location": "IoT Gateway Room", "zone": "operations", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"High\\", \\"findings\\": [\\"missing_firewall\\"]}", "diverged": true, "risk_score": 55, "online": true, "x_pos": 400.0, "y_pos": 280.0, "updated_at": "2026-04-16 20:05:11.636150"}, {"id": 6, "name": "PLC Controller", "node_type": "plc", "ip_address": "10.0.1.10", "mac_address": null, "vendor": "Schneider Electric", "firmware": "2.60", "location": "Production Floor", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Critical\\", \\"findings\\": [\\"modbus_unauthenticated\\"]}", "diverged": true, "risk_score": 90, "online": true, "x_pos": 150.0, "y_pos": 400.0, "updated_at": "2026-04-16 20:05:11.636151"}, {"id": 7, "name": "Temperature Sensor A", "node_type": "sensor", "ip_address": "10.0.2.10", "mac_address": null, "vendor": "Honeywell", "firmware": "3.1.2", "location": "Production Floor \\u2014 Zone A", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "diverged": false, "risk_score": 10, "online": true, "x_pos": 100.0, "y_pos": 500.0, "updated_at": "2026-04-16 20:05:11.636151"}, {"id": 8, "name": "Pressure Sensor B", "node_type": "sensor", "ip_address": "10.0.2.11", "mac_address": null, "vendor": "Emerson", "firmware": "2.8.0", "location": "Production Floor \\u2014 Zone B", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "diverged": false, "risk_score": 8, "online": true, "x_pos": 250.0, "y_pos": 500.0, "updated_at": "2026-04-16 20:05:11.636152"}, {"id": 9, "name": "IP Camera", "node_type": "camera", "ip_address": "10.0.3.10", "mac_address": null, "vendor": "Hikvision", "firmware": "V5.5.800", "location": "Production Floor \\u2014 Entry", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Medium\\", \\"findings\\": [\\"weak_password\\"]}", "diverged": true, "risk_score": 45, "online": true, "x_pos": 600.0, "y_pos": 400.0, "updated_at": "2026-04-16 20:05:11.636153"}, {"id": 10, "name": "Water Treatment RTU", "node_type": "actuator", "ip_address": "10.0.1.11", "mac_address": null, "vendor": "ABB", "firmware": "11.7.3", "location": "Water Treatment Plant", "zone": "field", "expected_state": "{\\"risk_level\\": \\"Low\\", \\"findings\\": []}", "actual_state": "{\\"risk_level\\": \\"Critical\\", \\"findings\\": [\\"dnp3_no_auth\\"]}", "diverged": true, "risk_score": 88, "online": true, "x_pos": 350.0, "y_pos": 500.0, "updated_at": "2026-04-16 20:05:11.636153"}]	1	2026-04-16 20:11:01.845502
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assigned_at) FROM stdin;
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.user_settings (id, user_id, slack_webhook_url, teams_webhook_url, notify_critical, notify_high, notify_cve, created_at, updated_at, siem_webhook_url) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.users (id, email, password_hash, name, plan, scans_used, scans_limit, created_at, last_login, is_active, stripe_customer_id, stripe_subscription_id, plan_expires_at) FROM stdin;
1	test@aipet.io	$2b$12$wgEcI9DJXURKO0Dwhk8mLekA0BCcRS4FpDRLLGoC0lsZ4ZDJ6ZY12	Test User	enterprise	19	999999	2026-03-29 23:20:50.618499	2026-04-17 01:56:32.73783	t	cus_UEwnvwFwOEvO5Z	sub_1TGT75EOqz4Ugi362qNaY7M5	2026-04-30 00:51:27
2	byallew@gmail.com	$2b$12$R7I6t4d7rKteJLRdDacon.fZHwdEDbGKO3RRWQqpFKJD39dAVAjBi	Binyam Yallew	free	5	5	2026-04-05 05:43:49.663051	\N	t	\N	\N	\N
\.


--
-- Data for Name: watch_alerts; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.watch_alerts (id, user_id, device_ip, alert_type, severity, description, details, is_acknowledged, created_at) FROM stdin;
\.


--
-- Data for Name: watch_baselines; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.watch_baselines (id, user_id, device_ip, device_function, baseline_data, first_seen, last_seen, is_active, created_at) FROM stdin;
1	1	192.168.1.1	Infrastructure / Network	{"status": "monitored", "device_ip": "192.168.1.1", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 25, "attack_types": ["open_telnet"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Critical", "device_function": "Infrastructure / Network", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 0, "Critical": 1}}	2026-04-04 07:53:27.112634	2026-04-04 23:37:54.727022	t	2026-04-04 07:53:27.112639
2	1	192.168.1.2	Customer Data	{"status": "monitored", "device_ip": "192.168.1.2", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 25, "attack_types": ["default_credentials"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Critical", "device_function": "Customer Data", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 0, "Critical": 1}}	2026-04-04 07:53:27.114672	2026-04-04 23:37:54.730338	t	2026-04-04 07:53:27.114675
3	1	192.168.1.3	Operations / Manufacturing	{"status": "monitored", "device_ip": "192.168.1.3", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["mqtt"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 15, "attack_types": ["unencrypted_mqtt"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "High", "device_function": "Operations / Manufacturing", "severity_profile": {"Low": 0, "High": 1, "Info": 0, "Medium": 0, "Critical": 0}}	2026-04-04 07:53:27.116038	2026-04-04 23:37:54.731253	t	2026-04-04 07:53:27.116041
4	1	192.168.1.4	General IT	{"status": "monitored", "device_ip": "192.168.1.4", "last_seen": "2026-04-04T22:37:54.725772+00:00", "protocols": ["network"], "first_seen": "2026-04-04T22:37:54.725772+00:00", "risk_score": 8, "attack_types": ["no_firewall"], "finding_count": 1, "open_findings": 1, "fixed_findings": 0, "worst_severity": "Medium", "device_function": "General IT", "severity_profile": {"Low": 0, "High": 0, "Info": 0, "Medium": 1, "Critical": 0}}	2026-04-04 07:53:27.117355	2026-04-04 23:37:54.732501	t	2026-04-04 07:53:27.117358
\.


--
-- Data for Name: zt_access_log; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.zt_access_log (id, source_ip, dest_ip, port, protocol, action, policy_id, policy_name, reason, trust_score, created_at) FROM stdin;
1	192.168.1.1	8.8.8.8	53	udp	block	\N	Block quarantined devices — all traffic	Device quarantined (trust score: 30)	30	2026-04-16 15:51:14.242514
2	192.168.1.2	203.0.113.10	443	tcp	alert	\N	Restrict customer data server — no external access	Matched policy: Restrict customer data server	45	2026-04-16 15:44:14.242514
3	192.168.1.3	192.168.1.0	1883	tcp	allow	\N	Allow MQTT broker — internal only	Matched policy: Allow MQTT broker	72	2026-04-16 15:36:14.242514
4	192.168.1.4	192.168.1.1	23	tcp	block	\N	Block Telnet — all devices	Matched policy: Block Telnet — all devices	62	2026-04-16 15:21:14.242514
5	192.168.0.5	192.168.1.3	22	tcp	allow	\N	Allow management traffic — admin subnet	Matched policy: Allow management traffic	100	2026-04-16 14:56:14.242514
6	192.168.1.1	8.8.8.8	53	any	block	\N	Quarantine Override	Device quarantined (trust score: 30)	30	2026-04-16 16:00:58.627409
\.


--
-- Data for Name: zt_device_trust; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.zt_device_trust (id, device_ip, device_name, trust_score, status, risk_factors, last_scan_id, last_assessed, created_at, updated_at) FROM stdin;
2	192.168.1.2	Customer Data Server	75	quarantined	["1 Critical finding(s) \\u2014 -25 pts"]	\N	2026-04-16 16:10:27.201706	2026-04-16 15:56:14.230467	2026-04-16 16:20:46.285772
1	192.168.1.1	Network Gateway	50	quarantined	["2 Critical finding(s) \\u2014 -50 pts"]	\N	2026-04-16 16:10:27.201706	2026-04-16 15:56:14.230463	2026-04-16 20:38:52.025506
3	192.168.1.3	MQTT Broker	85	quarantined	["1 High finding(s) \\u2014 -15 pts"]	\N	2026-04-16 16:10:27.201706	2026-04-16 15:56:14.230468	2026-04-16 20:38:54.780038
4	192.168.1.4	IoT Gateway	92	quarantined	["1 Medium finding(s) \\u2014 -8 pts"]	\N	2026-04-16 16:10:27.201706	2026-04-16 15:56:14.230469	2026-04-16 20:38:57.000088
\.


--
-- Data for Name: zt_policies; Type: TABLE DATA; Schema: public; Owner: aipet_user
--

COPY public.zt_policies (id, name, description, source, destination, port, protocol, action, priority, enabled, hit_count, created_by, created_at) FROM stdin;
1	Block quarantined devices — all traffic	Any device with trust score < 40 is blocked from all outbound access	192.168.1.1	*	*	any	block	1	t	0	\N	2026-04-16 15:56:14.236928
2	Restrict customer data server — no external access	Customer data server may only communicate with internal management subnet	192.168.1.2	*	*	any	alert	10	t	0	\N	2026-04-16 15:56:14.236932
3	Allow MQTT broker — internal only	MQTT broker allowed to communicate on port 1883 internally	192.168.1.3	192.168.1.0	1883	tcp	allow	20	t	0	\N	2026-04-16 15:56:14.236933
4	Block Telnet — all devices	Telnet (port 23) is blocked on all devices — unencrypted protocol	*	*	23	tcp	block	5	t	0	\N	2026-04-16 15:56:14.236933
5	Allow management traffic — admin subnet	All devices allow SSH from management subnet 192.168.0.0	192.168.0.0	*	22	tcp	allow	15	t	0	\N	2026-04-16 15:56:14.236933
\.


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 5, true);


--
-- Name: cloud_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.cloud_accounts_id_seq', 4, true);


--
-- Name: cloud_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.cloud_assets_id_seq', 24, true);


--
-- Name: cloud_findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.cloud_findings_id_seq', 14, true);


--
-- Name: compliance_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.compliance_results_id_seq', 12, true);


--
-- Name: defense_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.defense_actions_id_seq', 8, true);


--
-- Name: defense_playbooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.defense_playbooks_id_seq', 5, true);


--
-- Name: device_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.device_tags_id_seq', 4, true);


--
-- Name: explain_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.explain_results_id_seq', 48, true);


--
-- Name: findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.findings_id_seq', 5, true);


--
-- Name: ioc_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ioc_entries_id_seq', 8, true);


--
-- Name: ioc_feeds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ioc_feeds_id_seq', 2, true);


--
-- Name: mp_installs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.mp_installs_id_seq', 1, true);


--
-- Name: mp_plugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.mp_plugins_id_seq', 15, true);


--
-- Name: mp_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.mp_reviews_id_seq', 1, false);


--
-- Name: ot_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ot_devices_id_seq', 6, true);


--
-- Name: ot_findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ot_findings_id_seq', 11, true);


--
-- Name: ot_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.ot_scans_id_seq', 5, true);


--
-- Name: predict_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.predict_alerts_id_seq', 14, true);


--
-- Name: protocol_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.protocol_scans_id_seq', 5, true);


--
-- Name: remediation_kb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.remediation_kb_id_seq', 30, true);


--
-- Name: rt_attacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.rt_attacks_id_seq', 53, true);


--
-- Name: rt_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.rt_campaigns_id_seq', 3, true);


--
-- Name: scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.scans_id_seq', 25, true);


--
-- Name: score_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.score_results_id_seq', 7, true);


--
-- Name: siem_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.siem_events_id_seq', 41, true);


--
-- Name: siem_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.siem_incidents_id_seq', 4, true);


--
-- Name: siem_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.siem_rules_id_seq', 4, true);


--
-- Name: threat_matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.threat_matches_id_seq', 2, true);


--
-- Name: twin_edges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.twin_edges_id_seq', 10, true);


--
-- Name: twin_nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.twin_nodes_id_seq', 10, true);


--
-- Name: twin_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.twin_snapshots_id_seq', 4, true);


--
-- Name: user_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.user_settings_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: watch_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.watch_alerts_id_seq', 1, false);


--
-- Name: watch_baselines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.watch_baselines_id_seq', 4, true);


--
-- Name: zt_access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.zt_access_log_id_seq', 6, true);


--
-- Name: zt_device_trust_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.zt_device_trust_id_seq', 4, true);


--
-- Name: zt_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aipet_user
--

SELECT pg_catalog.setval('public.zt_policies_id_seq', 5, true);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: cloud_accounts cloud_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_accounts
    ADD CONSTRAINT cloud_accounts_pkey PRIMARY KEY (id);


--
-- Name: cloud_assets cloud_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_assets
    ADD CONSTRAINT cloud_assets_pkey PRIMARY KEY (id);


--
-- Name: cloud_findings cloud_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_findings
    ADD CONSTRAINT cloud_findings_pkey PRIMARY KEY (id);


--
-- Name: compliance_results compliance_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_pkey PRIMARY KEY (id);


--
-- Name: defense_actions defense_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_actions
    ADD CONSTRAINT defense_actions_pkey PRIMARY KEY (id);


--
-- Name: defense_playbooks defense_playbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_playbooks
    ADD CONSTRAINT defense_playbooks_pkey PRIMARY KEY (id);


--
-- Name: device_tags device_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_pkey PRIMARY KEY (id);


--
-- Name: device_tags device_tags_user_id_device_ip_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_user_id_device_ip_key UNIQUE (user_id, device_ip);


--
-- Name: explain_results explain_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_pkey PRIMARY KEY (id);


--
-- Name: findings findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_pkey PRIMARY KEY (id);


--
-- Name: ioc_entries ioc_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_entries
    ADD CONSTRAINT ioc_entries_pkey PRIMARY KEY (id);


--
-- Name: ioc_feeds ioc_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_feeds
    ADD CONSTRAINT ioc_feeds_pkey PRIMARY KEY (id);


--
-- Name: mp_installs mp_installs_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_installs
    ADD CONSTRAINT mp_installs_pkey PRIMARY KEY (id);


--
-- Name: mp_plugins mp_plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_plugins
    ADD CONSTRAINT mp_plugins_pkey PRIMARY KEY (id);


--
-- Name: mp_plugins mp_plugins_slug_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_plugins
    ADD CONSTRAINT mp_plugins_slug_key UNIQUE (slug);


--
-- Name: mp_reviews mp_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_reviews
    ADD CONSTRAINT mp_reviews_pkey PRIMARY KEY (id);


--
-- Name: ot_devices ot_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_devices
    ADD CONSTRAINT ot_devices_pkey PRIMARY KEY (id);


--
-- Name: ot_findings ot_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_findings
    ADD CONSTRAINT ot_findings_pkey PRIMARY KEY (id);


--
-- Name: ot_scans ot_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_scans
    ADD CONSTRAINT ot_scans_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: predict_alerts predict_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts
    ADD CONSTRAINT predict_alerts_pkey PRIMARY KEY (id);


--
-- Name: protocol_scans protocol_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans
    ADD CONSTRAINT protocol_scans_pkey PRIMARY KEY (id);


--
-- Name: remediation_kb remediation_kb_attack_type_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb
    ADD CONSTRAINT remediation_kb_attack_type_key UNIQUE (attack_type);


--
-- Name: remediation_kb remediation_kb_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.remediation_kb
    ADD CONSTRAINT remediation_kb_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: rt_attacks rt_attacks_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_attacks
    ADD CONSTRAINT rt_attacks_pkey PRIMARY KEY (id);


--
-- Name: rt_campaigns rt_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_campaigns
    ADD CONSTRAINT rt_campaigns_pkey PRIMARY KEY (id);


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- Name: score_results score_results_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_pkey PRIMARY KEY (id);


--
-- Name: siem_events siem_events_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_events
    ADD CONSTRAINT siem_events_pkey PRIMARY KEY (id);


--
-- Name: siem_incidents siem_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_incidents
    ADD CONSTRAINT siem_incidents_pkey PRIMARY KEY (id);


--
-- Name: siem_rules siem_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_rules
    ADD CONSTRAINT siem_rules_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: threat_matches threat_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches
    ADD CONSTRAINT threat_matches_pkey PRIMARY KEY (id);


--
-- Name: twin_edges twin_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_edges
    ADD CONSTRAINT twin_edges_pkey PRIMARY KEY (id);


--
-- Name: twin_nodes twin_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_nodes
    ADD CONSTRAINT twin_nodes_pkey PRIMARY KEY (id);


--
-- Name: twin_snapshots twin_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_snapshots
    ADD CONSTRAINT twin_snapshots_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_key UNIQUE (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_stripe_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_key UNIQUE (stripe_customer_id);


--
-- Name: users users_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: watch_alerts watch_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts
    ADD CONSTRAINT watch_alerts_pkey PRIMARY KEY (id);


--
-- Name: watch_baselines watch_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_pkey PRIMARY KEY (id);


--
-- Name: watch_baselines watch_baselines_user_id_device_ip_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_user_id_device_ip_key UNIQUE (user_id, device_ip);


--
-- Name: zt_access_log zt_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_access_log
    ADD CONSTRAINT zt_access_log_pkey PRIMARY KEY (id);


--
-- Name: zt_device_trust zt_device_trust_device_ip_key; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_device_trust
    ADD CONSTRAINT zt_device_trust_device_ip_key UNIQUE (device_ip);


--
-- Name: zt_device_trust zt_device_trust_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_device_trust
    ADD CONSTRAINT zt_device_trust_pkey PRIMARY KEY (id);


--
-- Name: zt_policies zt_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_policies
    ADD CONSTRAINT zt_policies_pkey PRIMARY KEY (id);


--
-- Name: ix_findings_scan_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_findings_scan_id ON public.findings USING btree (scan_id);


--
-- Name: ix_scans_user_id; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE INDEX ix_scans_user_id ON public.scans USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: aipet_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cloud_accounts cloud_accounts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_accounts
    ADD CONSTRAINT cloud_accounts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: cloud_assets cloud_assets_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_assets
    ADD CONSTRAINT cloud_assets_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.cloud_accounts(id);


--
-- Name: cloud_findings cloud_findings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_findings
    ADD CONSTRAINT cloud_findings_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.cloud_accounts(id);


--
-- Name: cloud_findings cloud_findings_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.cloud_findings
    ADD CONSTRAINT cloud_findings_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.cloud_assets(id);


--
-- Name: compliance_results compliance_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: compliance_results compliance_results_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.compliance_results
    ADD CONSTRAINT compliance_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: defense_actions defense_actions_playbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_actions
    ADD CONSTRAINT defense_actions_playbook_id_fkey FOREIGN KEY (playbook_id) REFERENCES public.defense_playbooks(id);


--
-- Name: defense_playbooks defense_playbooks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.defense_playbooks
    ADD CONSTRAINT defense_playbooks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: device_tags device_tags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.device_tags
    ADD CONSTRAINT device_tags_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: explain_results explain_results_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id);


--
-- Name: explain_results explain_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.explain_results
    ADD CONSTRAINT explain_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: findings findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: ioc_entries ioc_entries_feed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ioc_entries
    ADD CONSTRAINT ioc_entries_feed_id_fkey FOREIGN KEY (feed_id) REFERENCES public.ioc_feeds(id);


--
-- Name: mp_installs mp_installs_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_installs
    ADD CONSTRAINT mp_installs_plugin_id_fkey FOREIGN KEY (plugin_id) REFERENCES public.mp_plugins(id);


--
-- Name: mp_installs mp_installs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_installs
    ADD CONSTRAINT mp_installs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mp_reviews mp_reviews_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_reviews
    ADD CONSTRAINT mp_reviews_plugin_id_fkey FOREIGN KEY (plugin_id) REFERENCES public.mp_plugins(id);


--
-- Name: mp_reviews mp_reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.mp_reviews
    ADD CONSTRAINT mp_reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ot_findings ot_findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_findings
    ADD CONSTRAINT ot_findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.ot_scans(id);


--
-- Name: ot_scans ot_scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.ot_scans
    ADD CONSTRAINT ot_scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: predict_alerts predict_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.predict_alerts
    ADD CONSTRAINT predict_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: protocol_scans protocol_scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.protocol_scans
    ADD CONSTRAINT protocol_scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id);


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: rt_attacks rt_attacks_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_attacks
    ADD CONSTRAINT rt_attacks_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.rt_campaigns(id);


--
-- Name: rt_campaigns rt_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.rt_campaigns
    ADD CONSTRAINT rt_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: scans scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: score_results score_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: score_results score_results_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.score_results
    ADD CONSTRAINT score_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: siem_events siem_events_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_events
    ADD CONSTRAINT siem_events_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.siem_incidents(id);


--
-- Name: siem_events siem_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_events
    ADD CONSTRAINT siem_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: siem_incidents siem_incidents_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_incidents
    ADD CONSTRAINT siem_incidents_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: siem_incidents siem_incidents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_incidents
    ADD CONSTRAINT siem_incidents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: siem_rules siem_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.siem_rules
    ADD CONSTRAINT siem_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: threat_matches threat_matches_ioc_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches
    ADD CONSTRAINT threat_matches_ioc_entry_id_fkey FOREIGN KEY (ioc_entry_id) REFERENCES public.ioc_entries(id);


--
-- Name: threat_matches threat_matches_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches
    ADD CONSTRAINT threat_matches_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id);


--
-- Name: threat_matches threat_matches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.threat_matches
    ADD CONSTRAINT threat_matches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: twin_edges twin_edges_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_edges
    ADD CONSTRAINT twin_edges_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.twin_nodes(id);


--
-- Name: twin_edges twin_edges_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_edges
    ADD CONSTRAINT twin_edges_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.twin_nodes(id);


--
-- Name: twin_snapshots twin_snapshots_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.twin_snapshots
    ADD CONSTRAINT twin_snapshots_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: watch_alerts watch_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_alerts
    ADD CONSTRAINT watch_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: watch_baselines watch_baselines_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.watch_baselines
    ADD CONSTRAINT watch_baselines_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: zt_access_log zt_access_log_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_access_log
    ADD CONSTRAINT zt_access_log_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.zt_policies(id);


--
-- Name: zt_device_trust zt_device_trust_last_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_device_trust
    ADD CONSTRAINT zt_device_trust_last_scan_id_fkey FOREIGN KEY (last_scan_id) REFERENCES public.scans(id);


--
-- Name: zt_policies zt_policies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aipet_user
--

ALTER TABLE ONLY public.zt_policies
    ADD CONSTRAINT zt_policies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Kzn0TMoHj4KKXWP8LdyGRI2YOfRm8r7eMc4ov32ZMopPbXeEI97A8TaQLJFKobb

